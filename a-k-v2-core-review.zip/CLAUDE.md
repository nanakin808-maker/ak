# A Stock Guard v2 — Claude Code 入口

## 1. 先读

```text
CLAUDE.md → docs/README.md → docs/PROJECT_STATUS.md
```

## 2. 当前阶段

```
✅ 框架层: DB / Domain / Runtime / Service
✅ 事件采集: speed_rank + shortline + limit_pool (全部接口)
✅ 盘口封板: composite_quote (pytdx → tencent → sina → eastmoney)
✅ 生命周期: PRE_CANDIDATE → CANDIDATE → CORE → open_board
✅ 评分管线: LegacyFullScoringExecutor (v2 原生, 不再依赖旧系统子进程)
✅ 去重逻辑: per-event dedup + signature-based limit_pool rescore
✅ 量能异动: 5日均量百分比 (不再用固定 0.08亿)
✅ 交易日识别: market_calendar (新浪指数探测 + 市场阶段)
✅ 前端: REST + WebSocket (WS 只推增量)
✅ pytest: 40 tests (scan pipeline / scoring / lifecycle / market_calendar)
✅ 文件规范: 全部 ≤ 300 行
⏳ 通知/自选: 待阶段 3
```

## 3. 禁止事项

```text
- 不修改旧目录 a-k/
- 不让单文件超 300 行
- 不要继续空中盖框架
- 不要把 score_snapshots.stage 当生命周期 stage
- 不要把 CORE 做成粘死状态
- 不删除现有 REST API
- 不让 WebSocket 替代 REST (WS 只推增量)
- 不要用固定阈值做量能判断
- 不要用 datetime.now() 获取交易日 (用 market_calendar)
```

## 4. 验证

```bash
cd ~/Documents/Codex/2026-04-26/a-k-v2
python3 scripts/verify_v2_stack.py         # 全栈验证
cd backend && python -m pytest tests/ -v   # pytest (40 tests)
```

## 5. 架构

```
sources/     → 外部 API (eastmoney, tencent, sina, pytdx, ths)
domain/      → 纯业务规则 (market_calendar, gates, lifecycle, scoring)
runtime/     → 扫描循环, 状态管理, 去重
realtime/    → WebSocket (event_bus, ws_manager, delta_builder)
services/    → 业务编排 (MonitoringEngine, ScoreWorker, ProviderBridge)
api/         → FastAPI 路由 + WS endpoint
```

## 6. 扫描循环 (5s/轮)

```
1. speed_rank → entry gate → PRE_CANDIDATE    (eastmoney)
2. shortline  → entry gate → PRE_CANDIDATE    (eastmoney 短线异动)
3. promote    → kline ready → CANDIDATE       (触发 candidate_entry 评分)
4. seal check → composite_quote → CORE/open   (pytdx→tencent→sina→eastmoney)
   ├── CANDIDATE + sealed → CORE + seal 评分
   └── CORE + opened → CANDIDATE + open 评分
5. limit_pool → 9-field signature check → 评分
6. volume_spike → 5日均量×3% → 量能评分
7. notification gate → 通知候选检查
```
