# AStock Guard v2

新前后端分离版本。旧项目 `a-k/` 为只读参考，不做修改。

## 状态

当前阶段：**第一阶段完成，第二阶段质量检查**。尚未迁移核心业务逻辑。

## 启动后端

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -e .
uvicorn app.main:app --host 0.0.0.0 --port 8766 --reload
```

API 文档：http://localhost:8766/docs

健康检查：`GET /health`、`GET /api/v1/health`

## 启动前端

```bash
cd frontend
npm install
npm run dev
```

前端：http://localhost:5173（通过 Vite proxy 转发 API 到 8766）

## 技术栈

| 层 | 技术 |
|----|------|
| 后端框架 | FastAPI (Python 3.12+) |
| 前端框架 | Vue 3 + TypeScript |
| 构建 | Vite |
| UI 库 | Element Plus |
| 状态 | Pinia + TanStack Query |
| 路由 | Vue Router |
