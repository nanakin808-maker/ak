from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.domain.decisions import CandidateStage, DecisionAction  # noqa: E402
from app.domain.events import EventSource, EventType, StockEvent  # noqa: E402
from app.domain.scores import ScoreType, StockScoreBundle  # noqa: E402
from app.domain.snapshots import BoardScoreSnapshot, BoardScoreSnapshotBundle, BoardScoreSnapshotType  # noqa: E402


def main() -> None:
    assert CandidateStage.PRE_CANDIDATE.value == "pre_candidate"
    assert CandidateStage.CANDIDATE.value == "candidate"
    assert CandidateStage.CORE.value == "core"
    assert CandidateStage.REJECTED_TODAY.value == "rejected_today"

    assert DecisionAction.ENTER_PRE_CANDIDATE.value == "enter_pre_candidate"
    assert DecisionAction.PROMOTE_TO_CORE.value == "promote_to_core"
    assert DecisionAction.DEMOTE_TO_CANDIDATE.value == "demote_to_candidate"

    assert EventType.LIMIT_UP_SEALED.value == "limit_up_sealed"
    assert EventType.LIMIT_UP_OPENED.value == "limit_up_opened"
    assert EventType.VOLUME_SPIKE.value == "volume_spike"
    assert EventSource.SHORTLINE.value == "shortline"
    assert EventSource.GAIN_RANK.value == "gain_rank"

    event = StockEvent(
        code="300750",
        name="宁德时代",
        event_type=EventType.LIMIT_UP_SEALED,
        event_time="09:40:11",
        source=EventSource.LIMIT_POOL,
        is_sealed=True,
        is_first_seal=True,
        seal_volume=2.8,
        open_count=0,
    )
    assert event.is_sealed is True
    assert event.seal_volume == 2.8

    assert ScoreType.ENTRY_SENTIMENT.value == "entry_sentiment"
    assert ScoreType.OPEN_BOARD_SENTIMENT.value == "open_board_sentiment"
    assert ScoreType.RESEAL_SENTIMENT.value == "reseal_sentiment"

    bundle = StockScoreBundle()
    assert bundle.entry_sentiment is None
    assert bundle.open_board_sentiment is None
    assert bundle.reseal_sentiment is None

    snapshot = BoardScoreSnapshot(
        snapshot_type=BoardScoreSnapshotType.SEAL,
        score=88,
        stage="seal",
        board_name="锂电池",
    )
    snapshots = BoardScoreSnapshotBundle(seal=snapshot)
    assert snapshots.seal is snapshot

    print("Domain model smoke tests passed.")


if __name__ == "__main__":
    main()
