"""
5-minute real-data stress test.

Runs the scan loop continuously, records per-cycle metrics.
Tests: API resilience, scoring pipeline, composite quote chain,
       DB integrity, WebSocket broadcast, memory stability.

No mocking. Uses real external APIs.
"""

import json
import sqlite3
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

TEST_DB = ROOT / "data" / "stress_test_5min.db"
DURATION_SECONDS = 300  # 5 minutes
REPORT_PATH = ROOT / "reports" / "stress_test_5min.json"


def main() -> None:
    # Clean start
    if TEST_DB.exists():
        TEST_DB.unlink()

    print(f"=== 5-Minute Stress Test ===")
    print(f"  Start: {datetime.now().isoformat()}")
    print(f"  Duration: {DURATION_SECONDS}s")
    print(f"  DB: {TEST_DB}")
    print()

    from app.runtime.realtime_dev_scan import RealtimeDevScanRunner
    from app.services.score_worker_service import StaticScoringExecutor

    # Pre-fetch one scan to warm caches
    runner = RealtimeDevScanRunner(
        db_path=str(TEST_DB), trading_date="20260509",
        scoring_executor=StaticScoringExecutor(),
    )

    cycles: list[dict[str, Any]] = []
    errors_by_source: dict[str, int] = {}
    t_start = time.time()
    cycle_count = 0

    try:
        while time.time() - t_start < DURATION_SECONDS:
            cycle_start = time.time()
            cycle_count += 1

            summary = runner.run_once()

            cycle_elapsed = time.time() - cycle_start
            total_elapsed = time.time() - t_start

            # Record per-cycle metrics
            cycle = {
                "cycle": cycle_count,
                "elapsed_total_s": round(total_elapsed, 1),
                "cycle_duration_ms": round(cycle_elapsed * 1000, 0),
                "timestamp": datetime.now().isoformat(),
                "speed_rank": summary.get("speed_rank", 0),
                "shortline": summary.get("shortline", 0),
                "shortline_skipped": summary.get("shortline_skipped", 0),
                "pre_candidate": summary.get("pre_candidate", 0),
                "candidates": summary.get("candidates", 0),
                "core_states": summary.get("core_states", 0),
                "core_transitions": summary.get("core_transitions", 0),
                "open_transitions": summary.get("open_transitions", 0),
                "volume_spikes": summary.get("volume_spikes", 0),
                "limit_pool": summary.get("limit_pool", 0),
                "score_processed": summary.get("score_processed", 0),
                "score_ready": summary.get("score_ready", 0),
                "notifiable": summary.get("notifiable", 0),
                "errors": summary.get("errors", []),
            }
            cycles.append(cycle)

            for err in summary.get("errors", []):
                src = err.split(":")[0] if ":" in err else err
                errors_by_source[src] = errors_by_source.get(src, 0) + 1

            # Print progress every 10 cycles
            if cycle_count % 10 == 0:
                print(
                    f"[{total_elapsed:6.1f}s] cycle #{cycle_count:3d} "
                    f"({cycle_elapsed*1000:5.0f}ms) "
                    f"| sr={summary.get('speed_rank',0)} "
                    f"sl={summary.get('shortline',0)} "
                    f"lp={summary.get('limit_pool',0)} "
                    f"pre={summary.get('pre_candidate',0)} "
                    f"core={summary.get('core_states',0)} "
                    f"scores={summary.get('score_ready',0)} "
                    f"errs={len(summary.get('errors',[]))}"
                )

    except KeyboardInterrupt:
        print("\nInterrupted by user")

    elapsed_total = time.time() - t_start

    # ── Final Report ──
    if cycles:
        durations = [c["cycle_duration_ms"] for c in cycles]
        durations.sort()
        p50 = durations[len(durations) // 2]
        p95 = durations[int(len(durations) * 0.95)]
        p99 = durations[int(len(durations) * 0.99)]
        max_dur = max(durations)
        min_dur = min(durations)
        avg_dur = sum(durations) / len(durations)
    else:
        p50 = p95 = p99 = max_dur = min_dur = avg_dur = 0

    # DB stats
    db_stats = {}
    if TEST_DB.exists():
        db = sqlite3.connect(f"file:{TEST_DB.resolve()}?mode=ro", uri=True)
        db.row_factory = sqlite3.Row
        for table in [
            "monitoring_stock_states", "monitoring_events",
            "score_snapshots", "score_task_current",
            "limit_pool_rows", "scoring_contexts",
        ]:
            try:
                c = db.execute(f"SELECT count(*) as cnt FROM {table}").fetchone()["cnt"]
                db_stats[table] = c
            except Exception:
                db_stats[table] = "error"
        db.close()

    report = {
        "test_start": datetime.fromtimestamp(t_start).isoformat(),
        "test_end": datetime.now().isoformat(),
        "duration_seconds": round(elapsed_total, 1),
        "total_cycles": cycle_count,
        "cycles_per_minute": round(cycle_count / elapsed_total * 60, 1),
        "latency_ms": {
            "min": round(min_dur, 0),
            "avg": round(avg_dur, 0),
            "p50": round(p50, 0),
            "p95": round(p95, 0),
            "p99": round(p99, 0),
            "max": round(max_dur, 0),
        },
        "api_errors_by_source": errors_by_source,
        "db_table_counts": db_stats,
        "db_size_mb": round(TEST_DB.stat().st_size / 1024 / 1024, 2) if TEST_DB.exists() else 0,
        "first_cycle": cycles[0] if cycles else None,
        "last_cycle": cycles[-1] if cycles else None,
    }

    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(REPORT_PATH, "w") as f:
        json.dump(report, f, indent=2, ensure_ascii=False, default=str)

    # ── Console Report ──
    print()
    print(f"{'='*60}")
    print(f"  STRESS TEST RESULTS")
    print(f"{'='*60}")
    print(f"  Duration:       {elapsed_total:.1f}s ({cycle_count} cycles, {cycle_count/elapsed_total*60:.1f}/min)")
    print(f"  Latency (ms):   min={min_dur:.0f} avg={avg_dur:.0f} p50={p50:.0f} p95={p95:.0f} p99={p99:.0f} max={max_dur:.0f}")
    print(f"  DB size:        {report['db_size_mb']:.1f} MB")
    print(f"  DB tables:      {json.dumps(db_stats)}")
    print(f"  API errors:     {json.dumps(errors_by_source)}")
    print(f"  Report:         {REPORT_PATH}")

    # Stability checks
    issues = []
    if p99 > 5000:
        issues.append(f"P99 latency {p99:.0f}ms > 5000ms — may block scan loop")
    if max_dur > 30000:
        issues.append(f"MAX latency {max_dur:.0f}ms > 30s — single scan blocked")
    if errors_by_source:
        for src, cnt in errors_by_source.items():
            if cnt > cycle_count * 0.5:
                issues.append(f"{src}: {cnt}/{cycle_count} errors — source >50% failure rate")
    if report["db_size_mb"] > 50:
        issues.append(f"DB {report['db_size_mb']:.0f}MB — excessive growth in {elapsed_total:.0f}s")

    if issues:
        print(f"\n  ⚠️  ISSUES FOUND ({len(issues)}):")
        for i in issues:
            print(f"    - {i}")
    else:
        print(f"\n  ✅ No critical issues found")

    print(f"{'='*60}")


if __name__ == "__main__":
    main()
