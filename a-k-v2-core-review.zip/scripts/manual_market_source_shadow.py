"""
Manual shadow script: probes old system for speed_rank / shortline / quote providers.

This script is NOT part of verify_v2_stack.py because it depends on:
  1. The old system's code at ../a-k
  2. The old system's dependencies
  3. External network access (for real providers)

Usage:
  cd ~/Documents/Codex/2026-04-26/a-k-v2
  uv run --directory backend python3 scripts/manual_market_source_shadow.py
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OLD_ROOT = ROOT.parent / "a-k"
sys.path.insert(0, str(OLD_ROOT))

PROBES = [
    ("astock_guard.providers.speed_rank", ["SpeedRankProvider", "fetch_speed_rank", "get_speed_rank"]),
    ("astock_guard.providers.intraday", ["EastmoneyIntradayProvider", "CompositeIntradayProvider", "get_minute_bars"]),
    ("astock_guard.providers.history", ["DailyHistoryProvider", "get_kline_score", "get_daily_history"]),
    ("astock_guard.providers.stock_boards", ["StockBoardProvider", "get_boards", "summary"]),
]

found_count = 0
for mod_path, func_names in PROBES:
    try:
        mod = __import__(mod_path, fromlist=func_names)
        for fn in func_names:
            obj = getattr(mod, fn, None)
            if obj is not None and callable(obj):
                found_count += 1
                print(f"  Found: {mod_path}.{fn}")
                break
        else:
            print(f"  No callable found in {mod_path}")
    except ImportError as exc:
        print(f"  {mod_path}: ImportError - {exc}")
    except Exception as exc:
        print(f"  {mod_path}: {type(exc).__name__} - {exc}")

if found_count > 0:
    print(f"\nManual market source shadow: {found_count} old providers detected.")
    print("Not executing real providers in shadow mode (no clear triggering scenario).")
    print("To run against real providers, invoke them from a context that knows")
    print("the expected trading date and market session.")
else:
    print("\nNo old providers detected. This is expected if old system dependencies are not installed.")
    print("Manual market source shadow skipped.")

print("\nManual market source shadow OK (detection only)")
