from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import MonitoringStateTransition  # noqa: E402
from app.domain.time_scope import MarketSession  # noqa: E402
from app.repositories import MonitoringRepository  # noqa: E402
from app.runtime import EventProcessor, RuntimeInputEvent, RuntimeState  # noqa: E402


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "runtime.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()

        # ============================================================
        # 场景 1: fresh 首次封板 → promote_core
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            processor = EventProcessor(session, runtime)

            r1 = processor.process_event(
                RuntimeInputEvent(
                    trading_date="2026-05-09",
                    source_trading_date="2026-05-09",
                    code="000001",
                    name="平安银行",
                    event_type="LIMIT_UP_SEALED",
                    event_source="limit_pool",
                    event_time="10:01:00",
                    price=10.5,
                    change_pct=10.01,
                    is_sealed=True,
                    is_first_seal=True,
                    at_limit=True,
                    open_count=0,
                    raw_json='{"mock": true}',
                    as_of=now,
                    seq=1,
                    market_session=MarketSession.TRADING,
                )
            )
            session.commit()

            assert r1.action == "promote_core", f"1: expected promote_core, got {r1.action}"
            assert r1.stage == "CORE"
            assert r1.transition_id is not None

            s1 = MonitoringRepository(session).get_stock_state("2026-05-09", "000001")
            assert s1 is not None and s1.stage == "CORE"
            assert s1.active_monitoring is True
            assert s1.inactive_reason is None
            assert s1.inactive_at is None
            rs1 = runtime.get_stock_state("2026-05-09", "000001")
            assert rs1 is not None and rs1.stage == "CORE"
            assert rs1.active_monitoring is True
            assert rs1.inactive_reason is None

            t_all = list(
                session.execute(
                    select(MonitoringStateTransition).where(
                        MonitoringStateTransition.trading_date == "2026-05-09",
                        MonitoringStateTransition.code == "000001",
                    )
                ).scalars()
            )
            assert len(t_all) == 1
            assert t_all[0].to_stage == "CORE"

        # ============================================================
        # 场景 2: fresh 重复封板，已经是 CORE → already_core
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            processor = EventProcessor(session, runtime)

            # 先触发首次封板
            r1 = processor.process_event(
                RuntimeInputEvent(
                    trading_date="2026-05-09",
                    source_trading_date="2026-05-09",
                    code="000002",
                    name="深发展A",
                    event_type="LIMIT_UP_SEALED",
                    event_source="limit_pool",
                    event_time="10:02:00",
                    price=12.0,
                    change_pct=9.98,
                    is_sealed=True,
                    is_first_seal=True,
                    at_limit=True,
                    open_count=0,
                    raw_json='{"mock": true}',
                    as_of=now,
                    seq=10,
                    market_session=MarketSession.TRADING,
                )
            )
            assert r1.action == "promote_core"
            assert r1.transition_id is not None
            session.commit()

            # 重复封板
            r2 = processor.process_event(
                RuntimeInputEvent(
                    trading_date="2026-05-09",
                    source_trading_date="2026-05-09",
                    code="000002",
                    name="深发展A",
                    event_type="LIMIT_UP_SEALED",
                    event_source="limit_pool",
                    event_time="10:05:00",
                    price=12.5,
                    change_pct=10.0,
                    is_sealed=True,
                    at_limit=True,
                    open_count=1,
                    raw_json='{"mock": true}',
                    as_of=now,
                    seq=11,
                    market_session=MarketSession.TRADING,
                )
            )
            session.commit()

            assert r2.action == "already_core", f"2: expected already_core, got {r2.action}"
            assert r2.stage == "CORE"
            assert r2.transition_id is None

            s2 = MonitoringRepository(session).get_stock_state("2026-05-09", "000002")
            assert s2 is not None
            assert s2.stage == "CORE"
            assert s2.seq == 11
            assert s2.price == 12.5
            assert s2.open_count == 1
            assert s2.active_monitoring is True

            rs2 = runtime.get_stock_state("2026-05-09", "000002")
            assert rs2 is not None
            assert rs2.stage == "CORE"
            assert rs2.seq == 11
            assert rs2.price == 12.5
            assert rs2.active_monitoring is True

            # 验证没有新增迁移
            t_all = list(
                session.execute(
                    select(MonitoringStateTransition).where(
                        MonitoringStateTransition.trading_date == "2026-05-09",
                        MonitoringStateTransition.code == "000002",
                    )
                ).scalars()
            )
            assert len(t_all) == 1, f"expected 1 transition, got {len(t_all)}"

        # ============================================================
        # 场景 3: fresh 开板，CORE 回退 CANDIDATE
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            processor = EventProcessor(session, runtime)

            # 先触发封板
            r1 = processor.process_event(
                RuntimeInputEvent(
                    trading_date="2026-05-09",
                    source_trading_date="2026-05-09",
                    code="000003",
                    name="浦发银行",
                    event_type="LIMIT_UP_SEALED",
                    event_source="limit_pool",
                    event_time="10:03:00",
                    price=15.0,
                    change_pct=10.01,
                    is_sealed=True,
                    is_first_seal=True,
                    at_limit=True,
                    open_count=0,
                    raw_json='{"mock": true}',
                    as_of=now,
                    seq=20,
                    market_session=MarketSession.TRADING,
                )
            )
            assert r1.action == "promote_core"
            session.commit()

            # 开板
            r2 = processor.process_event(
                RuntimeInputEvent(
                    trading_date="2026-05-09",
                    source_trading_date="2026-05-09",
                    code="000003",
                    name="浦发银行",
                    event_type="LIMIT_UP_OPENED",
                    event_source="limit_pool",
                    event_time="10:10:00",
                    price=14.2,
                    change_pct=5.0,
                    is_sealed=False,
                    at_limit=False,
                    open_count=1,
                    raw_json='{"mock": true}',
                    as_of=now,
                    seq=21,
                    market_session=MarketSession.TRADING,
                )
            )
            session.commit()

            assert r2.action == "core_opened_to_candidate", (
                f"3: expected core_opened_to_candidate, got {r2.action}"
            )
            assert r2.stage == "CANDIDATE"
            assert r2.transition_id is not None

            s3 = MonitoringRepository(session).get_stock_state("2026-05-09", "000003")
            assert s3 is not None
            assert s3.stage == "CANDIDATE"
            assert s3.is_sealed is False
            assert s3.active_monitoring is True
            assert s3.inactive_reason is None

            rs3 = runtime.get_stock_state("2026-05-09", "000003")
            assert rs3 is not None
            assert rs3.stage == "CANDIDATE"
            assert rs3.is_sealed is False
            assert rs3.active_monitoring is True

            # 验证有两条迁移：CANDIDATE -> CORE, CORE -> CANDIDATE
            t_all = list(
                session.execute(
                    select(MonitoringStateTransition).where(
                        MonitoringStateTransition.trading_date == "2026-05-09",
                        MonitoringStateTransition.code == "000003",
                    ).order_by(MonitoringStateTransition.id.asc())
                ).scalars()
            )
            assert len(t_all) == 2, f"expected 2 transitions, got {len(t_all)}"
            assert t_all[0].to_stage == "CORE"
            assert t_all[1].from_stage == "CORE"
            assert t_all[1].to_stage == "CANDIDATE"

        # ============================================================
        # 场景 4: mismatch 封板 → record_event_only
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            processor = EventProcessor(session, runtime)

            r3 = processor.process_event(
                RuntimeInputEvent(
                    trading_date="2026-05-10",
                    source_trading_date="2026-05-09",
                    code="600002",
                    name="mock mismatch",
                    event_type="LIMIT_UP_SEALED",
                    event_source="limit_pool",
                    event_time="10:02:00",
                    price=8.8,
                    change_pct=10.02,
                    is_sealed=True,
                    is_first_seal=True,
                    at_limit=True,
                    open_count=0,
                    raw_json='{"mock": "mismatch"}',
                    as_of=now,
                    seq=2,
                    market_session=MarketSession.CLOSED,
                )
            )
            session.commit()

            assert r3.action == "record_event_only", f"4: expected record_event_only, got {r3.action}"
            assert r3.stage is None
            assert r3.transition_id is None
            assert r3.freshness_status == "mismatch"

            monitoring = MonitoringRepository(session)
            events = monitoring.list_events_since("2026-05-10", since_seq=0)
            assert len(events) == 1
            assert events[0].freshness_status == "mismatch"

            state = monitoring.get_stock_state("2026-05-10", "600002")
            assert state is None

            runtime_state = runtime.get_stock_state("2026-05-10", "600002")
            assert runtime_state is None

            transitions = list(
                session.execute(
                    select(MonitoringStateTransition).where(
                        MonitoringStateTransition.trading_date == "2026-05-10",
                        MonitoringStateTransition.code == "600002",
                    )
                ).scalars()
            )
            assert transitions == []

        # ============================================================
        # 场景 5: 回封（CANDIDATE → CORE after open）
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            processor = EventProcessor(session, runtime)

            # 封板 → CORE
            r1 = processor.process_event(
                RuntimeInputEvent(
                    trading_date="2026-05-09",
                    source_trading_date="2026-05-09",
                    code="000004",
                    name="招商银行",
                    event_type="LIMIT_UP_SEALED",
                    event_source="limit_pool",
                    event_time="10:04:00",
                    price=20.0,
                    change_pct=10.0,
                    is_sealed=True,
                    is_first_seal=True,
                    at_limit=True,
                    open_count=0,
                    raw_json='{"mock": true}',
                    as_of=now,
                    seq=30,
                    market_session=MarketSession.TRADING,
                )
            )
            assert r1.action == "promote_core"
            session.commit()

            # 开板 → CANDIDATE
            r2 = processor.process_event(
                RuntimeInputEvent(
                    trading_date="2026-05-09",
                    source_trading_date="2026-05-09",
                    code="000004",
                    name="招商银行",
                    event_type="LIMIT_UP_OPENED",
                    event_source="limit_pool",
                    event_time="10:15:00",
                    price=18.5,
                    change_pct=2.0,
                    is_sealed=False,
                    at_limit=False,
                    open_count=1,
                    raw_json='{"mock": true}',
                    as_of=now,
                    seq=31,
                    market_session=MarketSession.TRADING,
                )
            )
            assert r2.action == "core_opened_to_candidate"
            session.commit()

            # 回封 → promote_core again (CANDIDATE -> CORE)
            r3 = processor.process_event(
                RuntimeInputEvent(
                    trading_date="2026-05-09",
                    source_trading_date="2026-05-09",
                    code="000004",
                    name="招商银行",
                    event_type="LIMIT_UP_SEALED",
                    event_source="limit_pool",
                    event_time="10:30:00",
                    price=20.5,
                    change_pct=10.1,
                    is_sealed=True,
                    is_first_seal=False,
                    at_limit=True,
                    open_count=2,
                    raw_json='{"mock": true}',
                    as_of=now,
                    seq=32,
                    market_session=MarketSession.TRADING,
                )
            )
            session.commit()

            assert r3.action == "promote_core", f"5: expected promote_core on reseal, got {r3.action}"
            assert r3.stage == "CORE"
            assert r3.transition_id is not None

            s5 = MonitoringRepository(session).get_stock_state("2026-05-09", "000004")
            assert s5 is not None
            assert s5.stage == "CORE"
            assert s5.seq == 32
            assert s5.is_sealed is True
            assert s5.open_count == 2
            assert s5.active_monitoring is True
            assert s5.inactive_reason is None

            rs5 = runtime.get_stock_state("2026-05-09", "000004")
            assert rs5 is not None
            assert rs5.stage == "CORE"
            assert rs5.seq == 32
            assert rs5.active_monitoring is True

            # 验证三条迁移：CANDIDATE→CORE, CORE→CANDIDATE, CANDIDATE→CORE
            t_all = list(
                session.execute(
                    select(MonitoringStateTransition).where(
                        MonitoringStateTransition.trading_date == "2026-05-09",
                        MonitoringStateTransition.code == "000004",
                    ).order_by(MonitoringStateTransition.id.asc())
                ).scalars()
            )
            assert len(t_all) == 3, f"expected 3 transitions, got {len(t_all)}"
            assert t_all[0].to_stage == "CORE"
            assert t_all[1].to_stage == "CANDIDATE"
            assert t_all[2].to_stage == "CORE"
            assert t_all[2].from_stage == "CANDIDATE"

    print("Runtime event processor smoke test OK")


if __name__ == "__main__":
    main()
