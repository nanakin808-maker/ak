from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import (  # noqa: E402
    LimitPoolRow,
    LimitPoolSnapshot,
    MonitoringStateTransition,
    MonitoringStockState,
    ScoreSnapshot,
)
from app.domain.time_scope import MarketSession  # noqa: E402
from app.services.limit_pool_provider_service import (  # noqa: E402
    LimitPoolProviderIngestionService,
    LimitPoolProviderRunResult,
)
from app.services.provider_bridge_service import ProviderFetchResult  # noqa: E402


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "limit_pool_provider.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()

        # === A: fresh mock provider -> ingestion ===
        call_tracker_a: list[int] = []

        class MockFreshFetcher:
            def fetch(self, *, requested_trading_date: str) -> ProviderFetchResult:
                call_tracker_a.append(1)
                return ProviderFetchResult(
                    data={
                        "rows": [
                            {"pool": "limit_up", "code": "000001", "name": "平安银行",
                             "source": "mock", "price": 10.5, "change_pct": 10.01,
                             "first_limit_time": "10:01:00"},
                            {"pool": "open_board", "code": "600002", "name": "mock open",
                             "source": "mock", "price": 8.8, "change_pct": 8.85,
                             "open_count": 3, "first_limit_time": "10:30:00"},
                        ],
                        "source_counts": {"limit_up": 1, "open_board": 1},
                    },
                    source_trading_date="2026-05-09",
                    source_updated_at=now,
                )

        with Session() as session:
            service = LimitPoolProviderIngestionService(session, MockFreshFetcher())
            result_a = service.fetch_and_ingest(
                requested_trading_date="2026-05-09",
                as_of=now, seq=1,
                market_session=MarketSession.TRADING,
                primary_source="mock_limit_pool",
            )
            session.commit()

            assert result_a.provider_ok is True, f"A: {result_a.error}"
            assert result_a.ingested is True
            assert result_a.row_count == 2, f"A: expected 2 rows, got {result_a.row_count}"
            assert result_a.freshness_status == "fresh"

            assert count_(session, LimitPoolSnapshot) == 1
            assert count_(session, LimitPoolRow) == 2
            assert count_(session, ScoreSnapshot) == 0
            assert count_(session, MonitoringStockState) == 0
            assert count_(session, MonitoringStateTransition) == 0

        # === B: mismatch provider -> source input only ===
        with Session() as session:
            service = LimitPoolProviderIngestionService(session, MockFreshFetcher())
            result_b = service.fetch_and_ingest(
                requested_trading_date="2026-05-10",
                as_of=now, seq=2,
                market_session=MarketSession.TRADING,
                primary_source="mock_limit_pool",
            )
            session.commit()

            assert result_b.provider_ok is True, f"B: {result_b.error}"
            assert result_b.ingested is True
            assert result_b.freshness_status == "mismatch", f"B: {result_b.freshness_status}"

            mismatch_rows = list(
                session.execute(
                    select(LimitPoolRow).where(LimitPoolRow.trading_date == "2026-05-10")
                ).scalars()
            )
            assert len(mismatch_rows) == 2
            for row in mismatch_rows:
                assert row.freshness_status == "mismatch"

            assert count_(session, ScoreSnapshot) == 0
            assert count_(session, MonitoringStockState) == 0

        # === C: provider exception -> no ingestion ===
        class FailingFetcher:
            def fetch(self, *, requested_trading_date: str) -> ProviderFetchResult:
                raise RuntimeError("mock provider network error")

        lp_before = count_(session, LimitPoolSnapshot)
        with Session() as session:
            service = LimitPoolProviderIngestionService(session, FailingFetcher())
            result_c = service.fetch_and_ingest(
                requested_trading_date="2026-05-09",
                as_of=now, seq=3,
                market_session=MarketSession.TRADING,
                primary_source="mock_limit_pool",
            )
            session.commit()

            assert result_c.provider_ok is False
            assert result_c.ingested is False
            assert "network error" in result_c.error
            assert count_(session, LimitPoolSnapshot) == lp_before  # unchanged

        # === D: cache hit ===
        call_tracker_d: list[int] = []

        class TrackedFetcher:
            def fetch(self, *, requested_trading_date: str) -> ProviderFetchResult:
                call_tracker_d.append(1)
                return ProviderFetchResult(
                    data=[{"pool": "limit_up", "code": "000001", "name": "cache test",
                           "source": "mock", "price": 10.0}],
                    source_trading_date="2026-05-09",
                )

        snap_before_d = count_(session, LimitPoolSnapshot)
        with Session() as session:
            service = LimitPoolProviderIngestionService(session, TrackedFetcher())
            # first call
            r1 = service.fetch_and_ingest(
                requested_trading_date="2026-05-09",
                as_of=now, seq=10,
                market_session=MarketSession.TRADING,
                cache_key="lp_cache_001",
                ttl_seconds=30,
                primary_source="mock_limit_pool",
            )
            session.commit()
            assert r1.row_count == 1
            assert len(call_tracker_d) == 1  # one real call

            # second call with same cache_key
            r2 = service.fetch_and_ingest(
                requested_trading_date="2026-05-09",
                as_of=now, seq=11,
                market_session=MarketSession.TRADING,
                cache_key="lp_cache_001",
                ttl_seconds=30,
                primary_source="mock_limit_pool",
            )
            session.commit()
            assert r2.row_count == 1
            # fetcher should NOT be called again
            assert len(call_tracker_d) == 1, f"D: expected 1 call, got {len(call_tracker_d)}"

    print("Limit pool provider service smoke test OK")


if __name__ == "__main__":
    main()
