from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.repositories import (  # noqa: E402
    LimitPoolRepository,
    MonitoringRepository,
    QuoteRepository,
    ScoreSnapshotRepository,
)


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "simulation.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()

        # ============================================================
        # 场景 1：fresh 封板事件
        # ============================================================
        fresh_date = "2026-05-10"
        fresh_source_date = "2026-05-10"

        with Session() as session:
            monitoring = MonitoringRepository(session)
            limit_pool = LimitPoolRepository(session)
            scores = ScoreSnapshotRepository(session)
            quotes = QuoteRepository(session)

            # 写入 LIMIT_UP_SEALED 事件
            event = monitoring.add_event(
                trading_date=fresh_date,
                source_trading_date=fresh_source_date,
                code="600001",
                name="测试A",
                event_type="LIMIT_UP_SEALED",
                event_source="limit_pool",
                event_time="09:45:00",
                price=15.2,
                change_pct=10.0,
                is_sealed=True,
                is_first_seal=True,
                as_of=now,
                seq=1,
                freshness_status="fresh",
                raw_json='{"source": "composite_limit_pool"}',
            )
            session.flush()

            # 写入 CORE 状态
            state = monitoring.upsert_stock_state(
                trading_date=fresh_date,
                source_trading_date=fresh_source_date,
                code="600001",
                name="测试A",
                stage="CORE",
                price=15.2,
                change_pct=10.0,
                is_sealed=True,
                at_limit=True,
                as_of=now,
                seq=2,
                freshness_status="fresh",
                config_version="test-v1",
            )

            # 写入 CANDIDATE -> CORE 迁移
            monitoring.add_transition(
                trading_date=fresh_date,
                source_trading_date=fresh_source_date,
                code="600001",
                from_stage="CANDIDATE",
                to_stage="CORE",
                reason="sealed",
                event_id=event.id,
                as_of=now,
                seq=3,
                freshness_status="fresh",
                config_version="test-v1",
            )

            # 写入 limit pool snapshot (fresh)
            snapshot = limit_pool.add_snapshot(
                trading_date=fresh_date,
                source_trading_date=fresh_source_date,
                source="composite_limit_pool",
                primary_source="eastmoney_limit_pool",
                source_counts_json='{"eastmoney_limit_pool": {"limit_up": 1, "open_board": 0}}',
                as_of=now,
                seq=4,
                freshness_status="fresh",
                market_session="trading",
                raw_json='{"mock": true}',
            )
            session.flush()

            # 写入 limit pool source row（不含评分列）
            row = limit_pool.add_row(
                snapshot_id=snapshot.id,
                trading_date=fresh_date,
                source_trading_date=fresh_source_date,
                pool="limit_up",
                code="600001",
                name="测试A",
                source="eastmoney_limit_pool",
                price=15.2,
                change_pct=10.0,
                first_limit_time="09:45:00",
                last_limit_time="09:45:00",
                open_count=0,
                seal_amount=50000000.0,
                streak=1,
                industry="科技",
                reason="mock",
                as_of=now,
                seq=5,
                freshness_status="fresh",
                raw_json='{"mock": true}',
            )
            session.flush()

            # 写入 score snapshot 引用 limit_pool source row
            scores.add_snapshot(
                trading_date=fresh_date,
                source_trading_date=fresh_source_date,
                code="600001",
                name="测试A",
                score_type="COMPOSITE",
                score_stage="limit_pool_first_score",
                score=88,
                technical_score=80,
                sentiment_score=90,
                volume_score=70,
                main_logic="mock",
                board_rank=1,
                source_type="limit_pool_row",
                source_snapshot_id=snapshot.id,
                source_row_id=row.id,
                score_json='{"total": 88}',
                input_refs_json=f'{{"limit_pool_snapshot_id": {snapshot.id}, "limit_pool_row_id": {row.id}}}',
                as_of=now,
                seq=6,
                freshness_status="fresh",
                status="ready",
                passed=True,
                config_version="test-v1",
            )

            # 写入两条连续 quote samples
            quotes.add_sample(
                trading_date=fresh_date,
                source_trading_date=fresh_source_date,
                code="600001",
                timestamp=now - timedelta(seconds=8),
                price=14.8,
                change_pct=6.5,
                amount=15_000_000,
                volume=80_000,
                bid_vol1=800,
                ask_vol1=600,
                source="mock_quote",
                as_of=now - timedelta(seconds=8),
                seq=7,
                freshness_status="fresh",
            )
            quotes.add_sample(
                trading_date=fresh_date,
                source_trading_date=fresh_source_date,
                code="600001",
                timestamp=now,
                price=15.2,
                change_pct=10.0,
                amount=30_000_000,
                volume=120_000,
                bid_vol1=1200,
                ask_vol1=400,
                source="mock_quote",
                as_of=now,
                seq=8,
                freshness_status="fresh",
            )

            session.commit()

        # 场景 1 断言
        with Session() as session:
            monitoring = MonitoringRepository(session)
            limit_pool = LimitPoolRepository(session)
            scores = ScoreSnapshotRepository(session)
            quotes = QuoteRepository(session)

            # stock state 可读回
            loaded_state = monitoring.get_stock_state(fresh_date, "600001")
            assert loaded_state is not None, "fresh stock state not found"
            assert loaded_state.stage == "CORE", f"expected CORE, got {loaded_state.stage}"
            assert loaded_state.change_pct == 10.0

            # 事件可读回
            events = monitoring.list_events_since(fresh_date, since_seq=0)
            assert len(events) >= 1
            assert any(e.event_type == "LIMIT_UP_SEALED" for e in events)

            # transition 可读回
            all_events = monitoring.list_events_since(fresh_date, since_seq=0, limit=100)
            assert any(e.event_type == "LIMIT_UP_SEALED" for e in all_events)

            # latest limit pool snapshot 可读回
            latest = limit_pool.latest_snapshot(fresh_date)
            assert latest is not None
            assert latest.freshness_status == "fresh"

            # score snapshot 能通过 source row 查回
            rows = limit_pool.list_rows(latest.id)
            assert len(rows) >= 1
            score = scores.latest_for_source(
                source_type="limit_pool_row",
                source_snapshot_id=latest.id,
                source_row_id=rows[0].id,
            )
            assert score is not None, "score snapshot by source not found"
            assert score.score == 88
            assert score.input_refs_json

            # quote window 能按最近 30 秒读回两条
            window = quotes.list_recent_seconds(fresh_date, "600001", now=now, seconds=30)
            assert len(window) == 2, f"expected 2 quote samples, got {len(window)}"
            assert window[0].amount == 15_000_000
            assert window[1].amount == 30_000_000

        # ============================================================
        # 场景 2：stale/mismatch 数据
        # ============================================================
        stale_date = "2026-05-10"
        stale_source_date = "2026-05-09"

        with Session() as session:
            monitoring = MonitoringRepository(session)
            limit_pool = LimitPoolRepository(session)

            # 允许记录 mismatch source event
            mismatch_event = monitoring.add_event(
                trading_date=stale_date,
                source_trading_date=stale_source_date,
                code="600002",
                name="测试B",
                event_type="LIMIT_UP_SEALED",
                event_source="limit_pool",
                event_time="09:30:00",
                price=20.0,
                change_pct=10.0,
                is_sealed=True,
                is_first_seal=True,
                as_of=now,
                seq=1,
                freshness_status="mismatch",
                raw_json='{"note": "stale source data from previous trading day"}',
            )

            # 允许记录 mismatch limit pool snapshot
            mismatch_snapshot = limit_pool.add_snapshot(
                trading_date=stale_date,
                source_trading_date=stale_source_date,
                source="composite_limit_pool",
                primary_source="eastmoney_limit_pool",
                source_counts_json='{"eastmoney_limit_pool": {"limit_up": 0, "open_board": 0}}',
                as_of=now,
                seq=2,
                freshness_status="mismatch",
                market_session="pre_open",
                raw_json='{"note": "pre-market stale snapshot"}',
            )

            # 不写 CORE 状态或迁移 —— 仅记录事件和源快照
            session.commit()

        # 场景 2 断言
        with Session() as session:
            monitoring = MonitoringRepository(session)
            limit_pool = LimitPoolRepository(session)

            # mismatch event 可读回
            mismatch_events = monitoring.list_events_since(stale_date, since_seq=0)
            mismatch_source_events = [e for e in mismatch_events if e.freshness_status == "mismatch"]
            assert len(mismatch_source_events) >= 1, "mismatch event not found"
            assert mismatch_source_events[0].code == "600002"

            # mismatch limit pool snapshot 可读回（使用直接查询，
            # 因为 latest_snapshot() 会返回同一交易日最新 seq 的快照）
            from app.db.models import LimitPoolSnapshot as LPS
            mismatch_snapshots = list(
                session.execute(
                    select(LPS).where(
                        LPS.trading_date == stale_date,
                        LPS.freshness_status == "mismatch",
                    )
                ).scalars()
            )
            assert len(mismatch_snapshots) >= 1, "mismatch snapshot not found"
            assert mismatch_snapshots[0].source_trading_date == stale_source_date

            # stock state 应为 None 或不是 CORE
            state_600002 = monitoring.get_stock_state(stale_date, "600002")
            assert state_600002 is None, (
                f"expected no state for mismatch code, got stage={state_600002.stage}"
            )

            # 没有 CORE 迁移
            all_stale_events = monitoring.list_events_since(stale_date, since_seq=0, limit=200)
            core_transitions = [
                t for t in all_stale_events if getattr(t, "event_type", "") == "TRANSITION" and hasattr(t, "to_stage") and t.to_stage == "CORE"
            ]
            # Since events table doesn't have a to_stage field (transitions are separate),
            # we just verify that the mismatch code has no stock_state at all.
            # The important assertion is state_600002 is None.

    print("DB-backed simulation smoke test OK")


if __name__ == "__main__":
    main()
