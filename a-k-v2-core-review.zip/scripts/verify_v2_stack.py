from __future__ import annotations

import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"


def run(command: list[str], cwd: Path = ROOT) -> None:
    print(f"$ {' '.join(command)}")
    result = subprocess.run(command, cwd=cwd, text=True)
    if result.returncode != 0:
        raise SystemExit(result.returncode)


def check_routes() -> None:
    expected = [
        ("/api/health", {"GET"}),
        ("/api/opportunities", {"GET"}),
        ("/api/events/realtime", {"GET"}),
        ("/api/engine/status", {"GET"}),
        ("/api/engine/start", {"POST"}),
        ("/api/engine/stop", {"POST"}),
        ("/api/engine/reset", {"POST"}),
        ("/api/limit-pool", {"GET"}),
        ("/api/speed-rank", {"GET"}),
        ("/api/boards", {"GET"}),
        ("/api/monitoring/shadow/overview", {"GET"}),
        ("/api/monitoring/shadow/stocks", {"GET"}),
        ("/api/monitoring/shadow/limit-pool", {"GET"}),
        ("/api/monitoring/shadow/scores", {"GET"}),
        ("/api/monitoring/shadow/interface-health", {"GET"}),
    ]

    script_lines = [
        "import sys",
        'sys.path.insert(0, "backend")',
        "from app.main import app",
    ]
    for path, methods in expected:
        methods_repr = repr(methods)
        script_lines.append(
            f'assert any(getattr(r,"path","")=={path!r} and {methods_repr}.issubset(set(getattr(r,"methods",set()))) for r in app.routes), f"Missing: {methods_repr} {path!r}"'
        )
    script = "; ".join(script_lines)

    result = subprocess.run(
        ["uv", "run", "--directory", str(BACKEND), "python3", "-c", script],
        cwd=ROOT, capture_output=True, text=True
    )
    if result.returncode != 0:
        print(result.stdout, result.stderr, sep="", end="")
        raise SystemExit("Route check failed")

    for path, methods in expected:
        print(f"  OK {methods} {path}")


def main() -> None:
    run(["python3", "scripts/check_file_size.py"])
    run(["python3", "-m", "compileall", "backend"])
    run(["npm", "run", "typecheck"], cwd=ROOT / "frontend")

    print("Checking FastAPI routes...")
    check_routes()

    print("Checking API contract smoke tests...")
    run([
        "uv", "run", "--directory", str(BACKEND),
        "python3", str(ROOT / "scripts" / "smoke_api_contracts.py"),
    ])

    print("Checking domain notification gate smoke tests...")
    run(["python3", str(ROOT / "scripts" / "smoke_domain_notification_gate.py")])

    print("Checking domain monitoring lifecycle smoke tests...")
    run(["python3", str(ROOT / "scripts" / "smoke_domain_monitoring_lifecycle.py")])

    print("Checking domain external action smoke tests...")
    run(["python3", str(ROOT / "scripts" / "smoke_domain_external_actions.py")])

    print("Checking domain gate config smoke tests...")
    run(["python3", str(ROOT / "scripts" / "smoke_domain_gates.py")])

    print("Checking domain model smoke tests...")
    run(["python3", str(ROOT / "scripts" / "smoke_domain_models.py")])

    print("Checking domain scoring smoke tests...")
    run(["python3", str(ROOT / "scripts" / "smoke_domain_scoring.py")])

    print("Checking domain time_scope smoke tests...")
    run(["python3", str(ROOT / "scripts" / "smoke_domain_time_scope.py")])

    print("Checking DB schema smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_db_schema.py")])

    print("Checking repository smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_repositories.py")])

    print("Checking DB-backed simulation smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_db_simulation.py")])

    print("Checking limit pool ingestion smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_limit_pool_ingestion.py")])

    print("Checking score task framework smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_score_task_framework.py")])

    print("Checking score worker framework smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_score_worker_framework.py")])

    print("Checking provider bridge smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_provider_bridge.py")])

    print("Checking limit pool provider service smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_limit_pool_provider_service.py")])

    print("Checking market source adapter smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_market_source_adapter.py")])

    print("Checking external source registry smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_external_source_registry.py")])

    print("Checking external source runtime smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_external_source_runtime.py")])

    print("Checking external source activation smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_external_source_activation.py")])

    print("Checking seal source adapter smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_seal_source_adapter.py")])

    print("Checking monitoring shadow API smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_monitoring_shadow_api.py")])

    print("Checking realtime WebSocket smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_realtime_websocket.py")])

    print("Checking legacy scoring executor smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_legacy_scoring_executor.py")])

    print("Checking runtime event processor smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_runtime_event_processor.py")])

    print("Checking runtime restore smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_runtime_restore.py")])

    print("Checking runtime candidate lifecycle smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_runtime_candidate_lifecycle.py")])

    print("Checking monitoring engine v1 smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_monitoring_engine_v1.py")])

    print("Checking monitoring backend v1 smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_monitoring_backend_v1.py")])

    print("Checking legacy scoring facade smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_legacy_scoring_facade.py")])

    print("Checking legacy score components smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_legacy_score_components.py")])

    print("Checking legacy full scoring executor smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_legacy_full_scoring_executor.py")])

    print("Checking realtime dev scan smoke test...")
    run(["uv", "run", "--directory", str(BACKEND), "python3", str(ROOT / "scripts" / "smoke_realtime_dev_scan.py")])

    print("\nV2 stack verification passed.")


if __name__ == "__main__":
    main()
