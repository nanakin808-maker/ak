from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.domain.decisions import CandidateStage, CandidateState  # noqa: E402
from app.domain.external_actions import (  # noqa: E402
    ExternalActionType,
    SelfStockAction,
    SelfStockDecision,
    SelfStockFilterReason,
    SelfStockProviderResult,
    SelfStockState,
    SelfStockStatus,
)
from app.domain.gates import MonitoringGateConfig  # noqa: E402
from app.domain.scores import StockScoreBundle  # noqa: E402
from app.domain.stocks import StockSnapshot  # noqa: E402


def main() -> None:
    config = MonitoringGateConfig()
    assert config.self_stock_gate.enabled is True
    assert config.self_stock_gate.require_main_board is True
    assert config.self_stock_gate.not_first_board_filter is True
    assert config.self_stock_gate.near_limit_pct == 9.0
    assert config.self_stock_gate.max_open_change_pct == 3.0

    assert ExternalActionType.SELF_STOCK.value == "self_stock"
    assert SelfStockAction.ADD.value == "add"
    assert SelfStockStatus.ADDED.value == "added"
    assert SelfStockStatus.FILTERED.value == "filtered"
    assert SelfStockStatus.WAITING.value == "waiting"
    assert SelfStockFilterReason.NOT_FIRST_BOARD.value == "not_first_board"
    assert SelfStockFilterReason.NOT_MAIN_BOARD.value == "not_main_board"

    decision = SelfStockDecision(
        action=SelfStockAction.SKIP,
        status=SelfStockStatus.FILTERED,
        reason=SelfStockFilterReason.NOT_FIRST_BOARD,
        message="连板票不加入同花顺自选",
    )
    assert decision.reason is SelfStockFilterReason.NOT_FIRST_BOARD

    provider_result = SelfStockProviderResult(ok=True, already_exists=True, message="already exists")
    assert provider_result.ok is True
    assert provider_result.already_exists is True

    self_stock_state = SelfStockState(
        status=SelfStockStatus.ADDED,
        board_score=78,
        kline_score=82,
        change_pct=9.3,
        message="added",
    )

    candidate_state = CandidateState(
        stock=StockSnapshot(code="600000", name="浦发银行"),
        stage=CandidateStage.CANDIDATE,
        scores=StockScoreBundle(),
        self_stock_state=self_stock_state,
    )
    assert candidate_state.self_stock_state is self_stock_state

    print("Domain external action smoke tests passed.")


if __name__ == "__main__":
    main()
