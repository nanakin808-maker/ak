"""
Subprocess worker: calls old DailyHistoryProvider.get_kline_score from old
project Python environment.  Outputs JSON to stdout.

Design:
- Runs under old project python (../a-k/.venv/bin/python).
- Imports and instantiates DailyHistoryProvider from old codebase.
- Catches all exceptions; never modifies old DB.
- Signature validation before calling get_kline_score to avoid silent breakage.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


def main() -> None:
    args = _parse_args()

    old_root = Path(args.get("old_project_root", "../a-k")).resolve()
    old_db_path = args.get("old_db_path", str(old_root / "data" / "astock_guard.db"))
    code = args.get("code", "")
    name = args.get("name") or code
    current_price = args.get("current_price")

    if not code:
        _fail("missing_code", detail={"code": code})

    sys.path.insert(0, str(old_root))

    try:
        from astock_guard.providers.history import DailyHistoryProvider
    except ImportError as exc:
        _fail("import_failed", error=f"Cannot import DailyHistoryProvider: {exc}", detail={"old_root": str(old_root)})

    try:
        provider = DailyHistoryProvider(db_path=old_db_path)
    except Exception as exc:
        _fail("init_failed", error=f"DailyHistoryProvider.__init__ failed: {exc}", detail={"old_db_path": str(old_db_path)})

    try:
        price = float(current_price) if current_price else None
        result = provider.get_kline_score(code=code, current_price=price)
    except Exception as exc:
        _fail("get_kline_score_failed", error=f"{type(exc).__name__}: {exc}", detail={"code": code, "current_price": current_price})

    if not isinstance(result, dict):
        _fail("invalid_result", error=f"get_kline_score returned non-dict: {type(result).__name__}", detail={"code": code})

    technical = result.get("technical_score") or result.get("score") or result.get("legacy_score")
    score = result.get("score") or result.get("legacy_score") or result.get("technical_score", {}).get("total")

    _ok(
        technical_score=technical,
        score=score,
        raw=result,
        detail={
            "code": code,
            "name": name,
            "old_db_path": str(old_db_path),
            "status": result.get("status"),
            "score_delta": result.get("score_delta"),
            "current_price": result.get("current_price"),
            "last_trade_date": result.get("last_trade_date"),
            "message": result.get("message"),
        },
    )


def _parse_args() -> dict[str, Any]:
    args: dict[str, Any] = {}
    i = 1
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg.startswith("--"):
            key = arg.lstrip("-").replace("-", "_")
            i += 1
            value: Any = sys.argv[i] if i < len(sys.argv) else ""
            if value.startswith("--"):
                value = ""
                i -= 1
            args[key] = value
        i += 1
    return args


def _ok(*, technical_score: Any, score: Any, raw: dict[str, Any], detail: dict[str, Any]) -> None:
    payload: dict[str, Any] = {
        "ok": True,
        "technical_score": technical_score,
        "score": score,
        "raw": raw,
        "detail": detail,
    }
    sys.stdout.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")
    sys.exit(0)


def _fail(reason: str, *, error: str = "", detail: dict[str, Any] | None = None) -> None:
    payload: dict[str, Any] = {
        "ok": False,
        "error": error or reason,
        "reason": reason,
        "detail": detail or {},
    }
    sys.stdout.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")
    sys.exit(0)


if __name__ == "__main__":
    main()
