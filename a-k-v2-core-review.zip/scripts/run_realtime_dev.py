"""
Run realtime dev scan.  Writes to data/astock_guard_v2.db.
Usage:
  uv run --directory backend python3 scripts/run_realtime_dev.py --trading-date 2026-05-09 --once
  uv run --directory backend python3 scripts/run_realtime_dev.py --trading-date auto --interval 10
"""

import argparse
import sys
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.runtime.realtime_dev_scan import RealtimeDevScanRunner
from app.services.legacy_full_scoring_executor import LegacyFullScoringExecutor


def resolve_trading_date(raw: str) -> str:
    if raw in ("auto", "today"):
        return datetime.now().strftime("%Y%m%d")
    return raw.replace("-", "")


def print_summary(s: dict) -> None:
    print(f"  scan: {s.get('scan_started_at','')[:19]} → {s.get('scan_ended_at','')[:19]}")
    print(f"  speed_rank: {s['speed_rank_rows']} rows, pre_candidate={s['pre_candidate']}, rejected={s['rejected']}")
    print(f"  quote: {s['quote_rows']} rows, core_transitions={s['core_transitions']}")
    print(f"  limit_pool: {s['limit_pool_rows']} rows")
    print(f"  score_tasks: scheduled={s['score_tasks_scheduled']} processed={s['score_tasks_processed']} ready={s['score_tasks_ready']} failed={s['score_tasks_failed']}")
    print(f"  score_snapshots: {s['score_snapshots']}  interface_health: {s['interface_health']}")
    print(f"  core_states: {s.get('core_states',0)}  transitions: {s.get('transitions',0)}")
    if s.get("errors"):
        for e in s["errors"][:5]:
            print(f"  ERROR: {e}")
    if s.get("core_states", 0) > 0:
        print("  WARNING: CORE states found — should be 0 in v1 realtime")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trading-date", default="auto")
    parser.add_argument("--interval", type=int, default=0, help="scan interval seconds (0=once)")
    parser.add_argument("--once", action="store_true", help="run once then exit")
    parser.add_argument("--db-path", default="data/astock_guard_v2.db")
    parser.add_argument("--no-scoring", action="store_true", help="skip scoring tasks")
    args = parser.parse_args()

    td = resolve_trading_date(args.trading_date)
    one_shot = args.once or args.interval <= 0
    interval = max(10, args.interval) if not one_shot else 0

    scoring_executor = None if args.no_scoring else LegacyFullScoringExecutor()

    runner = RealtimeDevScanRunner(
        db_path=args.db_path,
        trading_date=td,
        scoring_executor=scoring_executor,
    )

    print(f"Realtime dev scan — DB: {args.db_path}  trading_date: {td}")

    cycle = 0
    while True:
        cycle += 1
        print(f"\n=== Cycle {cycle} ===")
        try:
            s = runner.run_once()
            print_summary(s)
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            print(f"  SCAN ERROR: {type(exc).__name__}: {exc}")
            import traceback
            traceback.print_exc()

        if one_shot:
            break

        try:
            time.sleep(interval)
        except KeyboardInterrupt:
            break

    print("\nDone.")


if __name__ == "__main__":
    main()
