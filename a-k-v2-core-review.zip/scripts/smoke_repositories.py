from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path
import tempfile

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.repositories import (  # noqa: E402
    LimitPoolRepository,
    MonitoringRepository,
    QuoteRepository,
    ScoreSnapshotRepository,
)


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "repo.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()
        trading_date = "2026-05-09"
        source_trading_date = "2026-05-09"

        with Session() as session:
            monitoring = MonitoringRepository(session)
            limit_pool = LimitPoolRepository(session)
            scores = ScoreSnapshotRepository(session)
            quotes = QuoteRepository(session)

            # 1. Write monitoring event
            event = monitoring.add_event(
                trading_date=trading_date,
                source_trading_date=source_trading_date,
                code="000001",
                name="平安银行",
                event_type="LIMIT_UP_SEALED",
                event_source="limit_pool",
                event_time="10:01:00",
                price=10.5,
                change_pct=10.01,
                is_sealed=True,
                is_first_seal=True,
                as_of=now,
                seq=1,
                freshness_status="fresh",
                raw_json='{"mock": true}',
            )
            session.flush()

            # 2. Write monitoring stock state
            state = monitoring.upsert_stock_state(
                trading_date=trading_date,
                source_trading_date=source_trading_date,
                code="000001",
                name="平安银行",
                stage="CORE",
                price=10.5,
                change_pct=10.01,
                is_sealed=True,
                at_limit=True,
                as_of=now,
                seq=2,
                freshness_status="fresh",
                config_version="test-v1",
            )

            # 3. Write state transition referencing event
            transition = monitoring.add_transition(
                trading_date=trading_date,
                source_trading_date=source_trading_date,
                code="000001",
                from_stage="CANDIDATE",
                to_stage="CORE",
                reason="sealed",
                event_id=event.id,
                as_of=now,
                seq=3,
                freshness_status="fresh",
                config_version="test-v1",
            )

            # 4. Write limit pool snapshot
            snapshot = limit_pool.add_snapshot(
                trading_date=trading_date,
                source_trading_date=source_trading_date,
                source="composite_limit_pool",
                primary_source="eastmoney_limit_pool",
                source_counts_json='{"eastmoney_limit_pool": {"limit_up": 1, "open_board": 0}}',
                as_of=now,
                seq=4,
                freshness_status="fresh",
                market_session="trading",
                raw_json='{"mock": true}',
            )
            session.flush()

            # 5. Write limit pool row (no score columns)
            row = limit_pool.add_row(
                snapshot_id=snapshot.id,
                trading_date=trading_date,
                source_trading_date=source_trading_date,
                pool="limit_up",
                code="000001",
                name="平安银行",
                source="eastmoney_limit_pool",
                price=10.5,
                change_pct=10.01,
                first_limit_time="10:01:00",
                last_limit_time="10:01:00",
                open_count=0,
                seal_amount=123456789.0,
                streak=1,
                industry="银行",
                reason="mock",
                as_of=now,
                seq=5,
                freshness_status="fresh",
                raw_json='{"mock": true}',
            )
            session.flush()

            # 6. Write score snapshot referencing limit pool row
            score = scores.add_snapshot(
                trading_date=trading_date,
                source_trading_date=source_trading_date,
                code="000001",
                name="平安银行",
                score_type="COMPOSITE",
                score_stage="limit_pool_first_score",
                score=88,
                technical_score=80,
                sentiment_score=90,
                volume_score=70,
                main_logic="mock",
                board_rank=1,
                source_type="limit_pool_row",
                source_snapshot_id=snapshot.id,
                source_row_id=row.id,
                score_json='{"total": 88}',
                input_refs_json=f'{{"limit_pool_snapshot_id": {snapshot.id}, "limit_pool_row_id": {row.id}}}',
                as_of=now,
                seq=6,
                freshness_status="fresh",
                status="ready",
                passed=True,
                config_version="test-v1",
            )

            # 7. Write quote samples
            quotes.add_sample(
                trading_date=trading_date,
                source_trading_date=source_trading_date,
                code="000001",
                timestamp=now - timedelta(seconds=8),
                price=10.3,
                change_pct=8.9,
                amount=20_000_000,
                volume=100_000,
                bid_vol1=1000,
                ask_vol1=800,
                source="mock_quote",
                as_of=now - timedelta(seconds=8),
                seq=7,
                freshness_status="fresh",
            )
            quotes.add_sample(
                trading_date=trading_date,
                source_trading_date=source_trading_date,
                code="000001",
                timestamp=now,
                price=10.5,
                change_pct=10.01,
                amount=35_000_000,
                volume=150_000,
                bid_vol1=1500,
                ask_vol1=500,
                source="mock_quote",
                as_of=now,
                seq=8,
                freshness_status="fresh",
            )

            session.commit()

        # 8. Read back and verify all writes
        with Session() as session:
            monitoring = MonitoringRepository(session)
            limit_pool = LimitPoolRepository(session)
            scores = ScoreSnapshotRepository(session)
            quotes = QuoteRepository(session)

            # monitoring state read-back
            loaded_state = monitoring.get_stock_state(trading_date, "000001")
            assert loaded_state is not None
            assert loaded_state.stage == "CORE"
            assert loaded_state.source_trading_date == source_trading_date

            # events read-back
            loaded_events = monitoring.list_events_since(trading_date, since_seq=0)
            assert len(loaded_events) == 1
            assert loaded_events[0].event_type == "LIMIT_UP_SEALED"

            # limit pool snapshot read-back
            latest_snapshot = limit_pool.latest_snapshot(trading_date)
            assert latest_snapshot is not None
            assert latest_snapshot.freshness_status == "fresh"

            # limit pool rows read-back, verify NO score columns
            rows = limit_pool.list_rows(latest_snapshot.id)
            assert len(rows) == 1
            assert rows[0].code == "000001"
            assert not hasattr(rows[0], "technical_score")
            assert not hasattr(rows[0], "sentiment_score")
            assert not hasattr(rows[0], "volume_score")

            # score snapshot read-back with source reference
            loaded_scores = scores.list_for_code(trading_date, "000001")
            assert len(loaded_scores) == 1
            assert loaded_scores[0].source_type == "limit_pool_row"
            assert loaded_scores[0].source_row_id == rows[0].id
            assert loaded_scores[0].input_refs_json

            # score snapshot lookup by source
            latest_for_source = scores.latest_for_source(
                source_type="limit_pool_row",
                source_snapshot_id=latest_snapshot.id,
                source_row_id=rows[0].id,
            )
            assert latest_for_source is not None
            assert latest_for_source.score == 88

            # quote samples window read-back
            window = quotes.list_recent_seconds(trading_date, "000001", now=now, seconds=30)
            assert len(window) == 2
            assert window[0].amount == 20_000_000
            assert window[1].amount == 35_000_000

    print("Repository smoke test OK")


if __name__ == "__main__":
    main()
