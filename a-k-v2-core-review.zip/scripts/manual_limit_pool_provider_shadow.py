"""
Manual shadow script: fetches real limit_pool data from the old system
and writes it to a temporary v2 SQLite database via LimitPoolProviderIngestionService.

This script is NOT part of verify_v2_stack.py because it depends on:
  1. The old system's code at ../a-k
  2. The old system's running state (or at least its provider modules)
  3. External network access

Usage:
  cd ~/Documents/Codex/2026-04-26/a-k-v2
  uv run --directory backend python3 scripts/manual_limit_pool_provider_shadow.py
"""

from __future__ import annotations

import sys
import tempfile
from datetime import datetime
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
OLD_ROOT = ROOT.parent / "a-k"
sys.path.insert(0, str(BACKEND))
sys.path.insert(0, str(OLD_ROOT))

from app.db.init_db import init_db  # noqa: E402
from app.domain.time_scope import MarketSession  # noqa: E402
from app.services.limit_pool_provider_service import (  # noqa: E402
    LimitPoolProviderIngestionService,
)
from app.services.provider_bridge_service import ProviderFetchResult  # noqa: E402


def probe_old_provider() -> object | None:
    """Try to import the old limit_pool provider. Return a callable or None."""
    candidates = [
        ("astock_guard.providers.limit_pool", "get_limit_pool"),
        ("astock_guard.providers.limit_pool", "fetch_limit_pool"),
        ("astock_guard.providers.limit_pool", "fetch_limit_pool_snapshot"),
        ("astock_guard.limit_pool", "get_limit_pool_rows"),
    ]
    for mod_path, func_name in candidates:
        try:
            mod = __import__(mod_path, fromlist=[func_name])
            func = getattr(mod, func_name, None)
            if func is not None and callable(func):
                print(f"Found old provider: {mod_path}.{func_name}")
                return func
        except (ImportError, AttributeError) as exc:
            print(f"  Skipping {mod_path}.{func_name}: {type(exc).__name__}: {exc}")
    return None


def main() -> None:
    provider_func = probe_old_provider()
    if provider_func is None:
        print("Old limit_pool provider import found, but callable not recognized.")
        print("Manual limit_pool provider shadow skipped.")
        sys.exit(0)

    # Try calling the old provider
    try:
        raw = provider_func()
        print(f"Raw provider response type: {type(raw).__name__}")
    except Exception as exc:
        print(f"Provider call failed: {type(exc).__name__}: {exc}")
        print("Manual limit_pool provider shadow skipped (provider error).")
        sys.exit(0)

    # Convert raw data to ProviderFetchResult
    if isinstance(raw, dict):
        fetch_result = ProviderFetchResult(
            data=raw,
            source_trading_date=None,
            source_updated_at=None,
            detail={"provider_func": str(provider_func)},
        )
    elif isinstance(raw, list):
        fetch_result = ProviderFetchResult(
            data={"rows": raw},
            source_trading_date=None,
            source_updated_at=None,
            detail={"provider_func": str(provider_func)},
        )
    else:
        print(f"Unrecognized provider response type: {type(raw).__name__}, skipping.")
        sys.exit(0)

    # Write to temporary v2 SQLite
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "manual_shadow.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()
        requested_date = now.strftime("%Y-%m-%d")

        # Build a fetcher that returns the already-fetched data
        class ShadowFetcher:
            def fetch(self, *, requested_trading_date: str) -> ProviderFetchResult:
                return fetch_result

        with Session() as session:
            service = LimitPoolProviderIngestionService(session, ShadowFetcher())
            result = service.fetch_and_ingest(
                requested_trading_date=requested_date,
                as_of=now,
                seq=1,
                market_session=MarketSession.UNKNOWN,
                primary_source="old_limit_pool_shadow",
            )
            session.commit()

            print(f"Manual limit_pool provider shadow OK")
            print(f"  snapshot_id={result.snapshot_id}")
            print(f"  row_count={result.row_count}")
            print(f"  freshness_status={result.freshness_status}")
            if result.error:
                print(f"  error={result.error}")


if __name__ == "__main__":
    main()
