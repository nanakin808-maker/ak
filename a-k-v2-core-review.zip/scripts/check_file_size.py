#!/usr/bin/env python3
"""Check source files do not exceed size limits.

Limits (lines):
  backend/app/**/*.py   ≤ 300
  frontend/src/**/*.vue  ≤ 250
  frontend/src/**/*.ts   ≤ 200
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

LIMITS: list[tuple[str, str, int]] = [
    ("backend/app", "*.py", 300),
    ("frontend/src", "*.vue", 250),
    ("frontend/src", "*.ts", 200),
]


def count_lines(path: Path) -> int:
    try:
        return len(path.read_text().splitlines())
    except Exception:
        return 0


def main() -> int:
    violations: list[tuple[Path, int, int]] = []

    for rel_dir, pattern, limit in LIMITS:
        target = ROOT / rel_dir
        if not target.exists():
            continue
        for f in target.rglob(pattern):
            lines = count_lines(f)
            if lines > limit:
                violations.append((f, lines, limit))

    if violations:
        violations.sort(key=lambda x: x[1], reverse=True)
        for path, lines, limit in violations:
            print(f"OVER LIMIT: {path.relative_to(ROOT)}  ({lines} > {limit})")
        return 1

    print("ALL FILES WITHIN LIMITS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
