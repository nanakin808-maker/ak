"""
Manual script: calls real old system providers and writes shadow results
to a fixed dev database for API/frontend consumption.

Usage:
  cd ~/Documents/Codex/2026-04-26/a-k-v2
  python3 scripts/manual_real_shadow_to_dev_db.py --trading-date 2026-05-09
"""

from __future__ import annotations

import json
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
OLD_PROJECT = ROOT.parent / "a-k"
OLD_PYTHON = OLD_PROJECT / ".venv" / "bin" / "python3"
DB_DIR = ROOT / "data"
DB_PATH = DB_DIR / "astock_guard_v2_shadow.db"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db
from app.db.models import LimitPoolRow
from app.domain.time_scope import MarketSession
from app.runtime import RuntimeState
from app.runtime.monitoring_engine import MonitoringEngine
from app.services.limit_pool_provider_service import LimitPoolProviderIngestionService
from app.services.market_source_adapter_service import MarketSourceAdapterService
from app.services.provider_bridge_service import ProviderBridgeService, ProviderFetchResult
from app.services.real_source_normalizers import (
    normalize_limit_pool_rows,
    normalize_quote_rows,
    normalize_speed_rank_rows,
)
from app.services.score_worker_service import ScoreWorkerService
from app.services.seal_source_adapter_service import SealSourceAdapterService as SSAS

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker


def _call_old(source: str, trading_date: str, codes: str | None = None) -> dict[str, Any]:
    script, _ = _build_script(source, trading_date, codes)
    if not OLD_PYTHON.exists():
        return {"ok": False, "error": f"old python not found: {OLD_PYTHON}"}
    try:
        cp = subprocess.run([str(OLD_PYTHON), "-c", script], check=False, capture_output=True, text=True, timeout=30)
        if cp.returncode != 0:
            return {"ok": False, "error": cp.stderr.strip()[:500]}
        return json.loads(cp.stdout)
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


def _build_script(source: str, trading_date: str, codes: str | None) -> tuple[str, str]:
    old_root = str(OLD_PROJECT)
    td = trading_date
    if source == "limit_pool":
        body = (
            'import json,sys,datetime as dt\n'
            f'sys.path.insert(0,{old_root!r})\n'
            'from astock_guard.providers.limit_pool import EastmoneyLimitPoolProvider\n'
            'p = EastmoneyLimitPoolProvider()\n'
            f'result = p.snapshot({td!r})\n'
            "for r in result.get('limit_up',[]): r['pool']='limit_up'\n"
            "for r in result.get('open_board',[]): r['pool']='open_board'\n"
            'rows = [r.to_dict() if hasattr(r,"to_dict") else r for r in result.get("limit_up",[])+result.get("open_board",[])]\n'
            f'print(json.dumps(dict(ok=True,rows=rows,source_trading_date={td!r}),ensure_ascii=False,default=str))\n'
        )
        return body, "EastmoneyLimitPoolProvider.snapshot()"
    if source == "speed_rank":
        body = (
            'import json,sys\n'
            f'sys.path.insert(0,{old_root!r})\n'
            'from astock_guard.providers.eastmoney_rank import EastmoneyRankProvider\n'
            'p = EastmoneyRankProvider()\n'
            'rows = p.speed_rank(limit=30)\n'
            f'print(json.dumps(dict(ok=True,rows=rows,source_trading_date={td!r}),ensure_ascii=False,default=str))\n'
        )
        return body, "EastmoneyRankProvider.speed_rank()"
    if source == "quote_batch":
        code_list = [c.strip() for c in (codes or "002885,000001").split(",")]
        body = (
            'import json,sys\n'
            f'sys.path.insert(0,{old_root!r})\n'
            'from astock_guard.providers.eastmoney import EastmoneyProvider\n'
            'p = EastmoneyProvider()\n'
            f'quotes = p.get_quotes({code_list!r})\n'
            'rows = [dict(code=q.code,name=getattr(q,"name",str(q.code)),price=q.price,'
            'change_pct=q.change_pct,bid_vol1=q.bid_vol1,ask_vol1=q.ask_vol1,bid1=getattr(q,"bid1",None)) for q in quotes]\n'
            f'print(json.dumps(dict(ok=True,rows=rows,source_trading_date={td!r}),ensure_ascii=False,default=str))\n'
        )
        return body, "EastmoneyProvider.get_quotes()"
    return ('print(json.dumps(dict(ok=False,error="unknown source")))', "noop")


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--trading-date", default="2026-05-09")
    parser.add_argument("--scoring-mode", default="static_mock", choices=["static_mock", "legacy_component", "legacy_full"])
    args = parser.parse_args()

    td = args.trading_date.replace("-", "")
    print(f"Shadow DB: {DB_PATH}")
    print(f"Trading date: {td}")
    print(f"Scoring mode: {args.scoring_mode}")

    DB_DIR.mkdir(parents=True, exist_ok=True)
    engine = create_engine(f"sqlite:///{DB_PATH}", future=True)
    init_db(engine)
    Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

    now = datetime.utcnow()
    seq = 0

    # ── limit_pool ────────────────────────────────────────────────
    print("\n--- limit_pool ---")
    raw_lp = _call_old("limit_pool", td)
    lp_rows = normalize_limit_pool_rows(raw_lp.get("rows", []))
    print(f"  raw: {len(raw_lp.get('rows',[]))} normalized: {len(lp_rows)}")

    with Session() as session:
        # Subprocess timing
        t0 = time.perf_counter()
        # (the data is already fetched above, bridge latency is measured separately)
        bridge = ProviderBridgeService(session)
        seq += 1
        _lp_data = {"rows": lp_rows, "source_counts": {"limit_up": sum(1 for r in lp_rows if r.get("pool") == "limit_up"), "open_board": sum(1 for r in lp_rows if r.get("pool") == "open_board")}}
        bridge.call(name="shadow_limit_pool_fetch", category="limit_pool",
                    requested_trading_date=td,
                    fetcher=lambda data=_lp_data, std=td, sno=now: ProviderFetchResult(data=data, source_trading_date=std, source_updated_at=sno),
                    market_session=MarketSession.TRADING)

        _lp_fetch_data = {"rows": lp_rows}
        class _LPFetcher:
            def fetch(self, *, requested_trading_date: str):
                return ProviderFetchResult(data=_lp_fetch_data, source_trading_date=td, source_updated_at=now)
        ingestion = LimitPoolProviderIngestionService(session, _LPFetcher())
        result = ingestion.fetch_and_ingest(requested_trading_date=td, as_of=now, seq=seq, market_session=MarketSession.TRADING, provider_name="shadow_limit_pool", primary_source="eastmoney_limit_pool")
        print(f"  ingested: {result.ingested} snapshot_id={result.snapshot_id} rows={result.row_count}")

        if result.ingested:
            db_rows = list(session.execute(select(LimitPoolRow).where(LimitPoolRow.snapshot_id == result.snapshot_id)).scalars())
            print(f"  seal facts ({len(db_rows)} rows):")
            for row in db_rows[:5]:
                fact = SSAS.from_limit_pool_row(row)
                print(f"    {row.code} {row.name}: pool={row.pool} sealed={fact.is_sealed} opened={fact.opened} confidence={fact.confidence}")

            # score tasks for limit_pool rows
            engine_mg = MonitoringEngine(session, RuntimeState())
            for row in db_rows:
                engine_mg.schedule_score_for_limit_pool_row(row)
            session.flush()
            scheduled = len(db_rows)
            if args.scoring_mode == "legacy_component":
                from app.services.legacy_scoring_facade_executor import LegacyScoringFacadeExecutor
                executor = LegacyScoringFacadeExecutor(
                    old_project_root=str(OLD_PROJECT),
                )
                worker = ScoreWorkerService(session, executor=executor).process_pending(
                    trading_date=td, limit=scheduled,
                )
            elif args.scoring_mode == "legacy_full":
                from app.services.legacy_full_scoring_executor import LegacyFullScoringExecutor
                executor = LegacyFullScoringExecutor(
                    old_project_root=str(OLD_PROJECT),
                )
                worker = ScoreWorkerService(session, executor=executor).process_pending(
                    trading_date=td, limit=scheduled,
                )
            else:
                worker = engine_mg.process_pending_score_tasks(trading_date=td, limit=scheduled)
            print(f"  score_tasks: scheduled={scheduled} processed={worker.processed} ready={worker.ready} failed={worker.failed}")

        session.commit()

    # ── speed_rank ────────────────────────────────────────────────
    print("\n--- speed_rank ---")
    raw_sr = _call_old("speed_rank", td)
    sr_rows = normalize_speed_rank_rows(raw_sr.get("rows", []))
    print(f"  raw: {len(raw_sr.get('rows',[]))} normalized: {len(sr_rows)}")

    with Session() as session:
        bridge = ProviderBridgeService(session)
        seq += 1
        _sr_data = {"rows": sr_rows}
        bridge.call(name="shadow_speed_rank_fetch", category="speed_rank",
                    requested_trading_date=td,
                    fetcher=lambda data=_sr_data, std=td, sno=now: ProviderFetchResult(data=data, source_trading_date=std, source_updated_at=sno),
                    market_session=MarketSession.TRADING)

        rt = RuntimeState()
        eng = MonitoringEngine(session, rt)
        adapter = MarketSourceAdapterService(session, rt, eng)
        sr_result = adapter.ingest_event_source(
            source_type="speed_rank", provider_name="shadow_speed_rank",
            requested_trading_date=td,
            fetcher=lambda data=_sr_data, std=td, sno=now: ProviderFetchResult(data=data, source_trading_date=std, source_updated_at=sno),
            as_of=now, seq_start=seq, market_session=MarketSession.TRADING,
        )
        print(f"  events: {sr_result.processed} pre_candidate: {sum(1 for a in sr_result.actions if a == 'enter_pre_candidate')}")
        seq += max(sr_result.processed, 1)
        session.commit()

    # ── quote_batch ───────────────────────────────────────────────
    print("\n--- quote_batch ---")
    raw_q = _call_old("quote_batch", td, codes="002885,000001,600001")
    q_rows = normalize_quote_rows(raw_q.get("rows", []))
    print(f"  raw: {len(raw_q.get('rows',[]))} normalized: {len(q_rows)}")
    has_seal_data = any(r.get("seal_confidence") == "explicit" for r in q_rows)
    print(f"  has reliable seal data: {has_seal_data}")
    print(f"  seal_confidence values: {list(set(r['seal_confidence'] for r in q_rows))}")

    with Session() as session:
        bridge = ProviderBridgeService(session)
        seq += 1
        _q_data = {"rows": q_rows}
        bridge.call(name="shadow_quote_batch_fetch", category="quote_batch",
                    requested_trading_date=td,
                    fetcher=lambda data=_q_data, std=td, sno=now: ProviderFetchResult(data=data, source_trading_date=std, source_updated_at=sno),
                    market_session=MarketSession.TRADING)

        rt2 = RuntimeState()
        eng2 = MonitoringEngine(session, rt2)
        adapter2 = MarketSourceAdapterService(session, rt2, eng2)
        q_result = adapter2.ingest_quote_batch(
            provider_name="shadow_quote_batch",
            requested_trading_date=td,
            fetcher=lambda data=_q_data, std=td, sno=now: ProviderFetchResult(data=data, source_trading_date=std, source_updated_at=sno),
            as_of=now, seq_start=seq, market_session=MarketSession.TRADING,
        )
        print(f"  quotes: {q_result.processed}")
        print(f"  lifecycle actions: {q_result.actions[:5]}")
        promote_count = sum(1 for a in q_result.actions if "promote" in a)
        print(f"  promote_core actions: {promote_count}")

        # SealSourceFact summaries
        for row_data in q_rows:
            from app.runtime.candidate_base import CandidateQuoteInput as CQI
            q_in = CQI(
                trading_date=td, source_trading_date=td,
                code=row_data["code"], name=row_data.get("name",""),
                as_of=now, seq=seq, freshness_status="fresh",
                price=row_data["price"], change_pct=row_data.get("change_pct",0.0),
                is_sealed=False, at_limit=False,
                bid1=row_data.get("bid1"), bid_vol1=row_data.get("bid_vol1"),
                seal_confidence=row_data.get("seal_confidence","insufficient"),
            )
            fact = SSAS.from_quote_input(q_in)
            print(f"    {row_data['code']}: price={q_in.price} pct={q_in.change_pct:.2f}% confidence={fact.confidence} sealed={fact.is_sealed}")

        session.commit()

    # ── summary ──────────────────────────────────────────────────
    with Session() as session:
        from app.db.models import InterfaceHealth, MonitoringStockState, MonitoringStateTransition, ScoreSnapshot, ScoreTaskCurrent
        ih = len(list(session.execute(select(InterfaceHealth)).scalars()))
        ss = len(list(session.execute(select(ScoreSnapshot)).scalars()))
        st = len(list(session.execute(select(ScoreTaskCurrent)).scalars()))
        ms = len(list(session.execute(select(MonitoringStockState)).scalars()))
        tr = len(list(session.execute(select(MonitoringStateTransition)).scalars()))
        print(f"\n=== Summary ===")
        print(f"  scoring_mode:              {args.scoring_mode}")
        print(f"  interface_health:          {ih}")
        print(f"  score_snapshots:           {ss}")
        print(f"  score_task_current:        {st}")
        print(f"  monitoring_stock_states:   {ms}")
        print(f"  monitoring_transitions:    {tr}")

    print("\nManual shadow to dev DB OK")


if __name__ == "__main__":
    main()
