"""
External Source Validation v1.
Validates candidate free API sources for availability, latency, field coverage.
Does NOT upgrade any source to primary. Does NOT modify business logic.

For orderbook/seal-open validation, use --market-session TRADING during
trading hours.  Non-trading sessions produce non_trading_unverified
for orderbook sources.

Usage:
  python3 scripts/validate_external_sources.py \
    --trading-date 2026-05-09 --codes 002885,605369,000001 --runs 3
"""

from __future__ import annotations

import json
import subprocess
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
OLD_ROOT = ROOT.parent / "a-k"
OLD_PYTHON = OLD_ROOT / ".venv" / "bin" / "python3"
OLD_DB = OLD_ROOT / "data" / "astock_guard.db"
BACKEND = ROOT / "backend"


# ── data structures ─────────────────────────────────────────────

@dataclass
class SourceResult:
    source_key: str
    candidate_name: str
    dependency: str
    category: str
    ok_count: int = 0
    fail_count: int = 0
    latency_ms: list[float] = field(default_factory=list)
    row_count: int = 0
    field_coverage: dict[str, bool] = field(default_factory=dict)
    sample_fields: dict[str, Any] = field(default_factory=dict)
    requires_token: bool = False
    dependency_missing: str = ""
    errors: list[str] = field(default_factory=list)
    business_fit: dict[str, bool] = field(default_factory=lambda: {
        "price_change_fit": False,
        "orderbook_fit": False,
        "limit_pool_fit": False,
        "kline_fit": False,
        "board_fit": False,
        "fund_flow_fit": False,
    })
    recommended_status: str = "undecided"
    reason: str = ""
    trading_time_required: bool = False
    validation_status: str = ""  # ok / failed / dependency_missing / non_trading_unverified / inconclusive_sample


# ── subprocess helpers ──────────────────────────────────────────

def _old_script(body: str) -> dict[str, Any]:
    """Run an inline Python script under old system's Python and return parsed JSON."""
    if not OLD_PYTHON.exists():
        return {"ok": False, "error": f"old python not found: {OLD_PYTHON}"}
    try:
        cp = subprocess.run(
            [str(OLD_PYTHON), "-c", body],
            check=False, capture_output=True, text=True, timeout=30,
        )
        if cp.returncode != 0:
            return {"ok": False, "error": cp.stderr.strip()[:500]}
        return json.loads(cp.stdout)
    except json.JSONDecodeError as exc:
        return {"ok": False, "error": f"json_decode:{exc}"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout"}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}:{exc}"}


def _build_sdk_script(imports: str, call_line: str, output_var: str = "result") -> str:
    """Build an inline script that imports, calls an SDK, and prints JSON result."""
    return (
        'import json,sys\n'
        f'{imports}\n'
        'try:\n'
        f'  {call_line}\n'
        f'  print(json.dumps(dict(ok=True,row_count=len({output_var}) if hasattr({output_var},"__len__") else 1,'
        f'rows=list({output_var}) if hasattr({output_var},"__iter__") and not isinstance({output_var},dict) else {output_var},'
        f'fields=list({output_var}.columns) if hasattr({output_var},"columns") else list({output_var}.keys()) if isinstance({output_var},dict) else []),ensure_ascii=False,default=str))\n'
        'except Exception as e:\n'
        '  print(json.dumps(dict(ok=False,error=f"{type(e).__name__}:{e}"),ensure_ascii=False,default=str))\n'
    )


# ── validators ──────────────────────────────────────────────────

def validate_stock_basic(runs: int, codes: list[str]) -> list[SourceResult]:
    results: list[SourceResult] = []

    # AKShare stock list
    sr = SourceResult(
        source_key="akshare_stock_list",
        candidate_name="akshare stock_zh_a_spot_em",
        dependency="akshare",
        category="stock_basic",
    )
    for _ in range(runs):
        t0 = time.perf_counter()
        body = _build_sdk_script(
            'import akshare as ak',
            f'result = ak.stock_zh_a_spot_em().head(5).to_dict(orient="records")',
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr, resp, lat, expected_fields=["代码", "名称", "最新价", "涨跌幅", "总市值", "流通市值"])
    results.append(sr)

    # BaoStock query_all_stock (check if available)
    sr2 = SourceResult(
        source_key="baostock_query_all_stock",
        candidate_name="baostock query_all_stock",
        dependency="baostock",
        category="stock_basic",
        dependency_missing="baostock not installed in old venv",
    )
    results.append(sr2)

    # Old stock_meta provider
    sr3 = SourceResult(
        source_key="old_stock_meta",
        candidate_name="StockMetaProvider.get_meta",
        dependency="StockMetaProvider (akshare+requests)",
        category="stock_basic",
    )
    for code in codes[:runs]:
        t0 = time.perf_counter()
        body = (
            'import json,sys\n'
            f'sys.path.insert(0,{str(OLD_ROOT)!r})\n'
            'from astock_guard.providers.stock_meta import StockMetaProvider\n'
            'p = StockMetaProvider()\n'
            f'result = p.get_meta({code!r})\n'
            'print(json.dumps(dict(ok=True,row_count=1,rows=[result],fields=list(result.keys())),ensure_ascii=False,default=str))\n'
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr3, resp, lat, expected_fields=["float_share", "float_market_value", "industry", "name"])
    results.append(sr3)

    return results


def validate_calendar(runs: int) -> list[SourceResult]:
    results: list[SourceResult] = []

    # AKShare trade calendar
    sr = SourceResult(
        source_key="akshare_trade_calendar",
        candidate_name="akshare tool_trade_date_hist_sina",
        dependency="akshare",
        category="calendar",
    )
    for _ in range(runs):
        t0 = time.perf_counter()
        body = _build_sdk_script(
            'import akshare as ak',
            'result = ak.tool_trade_date_hist_sina().tail(10).to_dict(orient="records")',
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr, resp, lat, expected_fields=["trade_date", "day_week"])
    results.append(sr)

    # BaoStock
    sr2 = SourceResult(
        source_key="baostock_trade_dates",
        candidate_name="baostock query_trade_dates",
        dependency="baostock",
        category="calendar",
        dependency_missing="baostock not installed in old venv",
    )
    results.append(sr2)

    # bitefu.net
    sr3 = SourceResult(
        source_key="bitefu_calendar",
        candidate_name="tool.bitefu.net calendar",
        dependency="urllib (http://tool.bitefu.net)",
        category="calendar",
    )
    for _ in range(runs):
        t0 = time.perf_counter()
        try:
            import urllib.request, json
            resp_r = urllib.request.urlopen("http://tool.bitefu.net/jiari/", timeout=5)
            data = json.loads(resp_r.read().decode())
            lat = (time.perf_counter() - t0) * 1000
            _record(sr3, {"ok": True, "row_count": 1, "rows": [data], "fields": list(data.keys())}, lat)
        except Exception as e:
            lat = (time.perf_counter() - t0) * 1000
            _record(sr3, {"ok": False, "error": f"{type(e).__name__}:{e}"}, lat)
    results.append(sr3)

    return results


def validate_quote_price(runs: int, codes: list[str]) -> list[SourceResult]:
    results: list[SourceResult] = []

    # Eastmoney quote (via old provider)
    sr = SourceResult(
        source_key="eastmoney_quote",
        candidate_name="EastmoneyProvider.get_quotes",
        dependency="requests (push2.eastmoney.com)",
        category="quote_price",
    )
    for code in codes[:runs]:
        t0 = time.perf_counter()
        body = (
            'import json,sys\n'
            f'sys.path.insert(0,{str(OLD_ROOT)!r})\n'
            'from astock_guard.providers.eastmoney import EastmoneyProvider\n'
            'p = EastmoneyProvider()\n'
            f'quotes = p.get_quotes([{code!r}])\n'
            'rows = [dict(code=q.code,price=q.price,pre_close=q.pre_close,open=q.open,high=q.high,low=q.low,'
            'change_pct=q.change_pct,volume=q.volume,amount=q.amount,bid1=q.bid1,ask1=q.ask1,'
            'bid_vol1=q.bid_vol1,ask_vol1=q.ask_vol1) for q in quotes]\n'
            'print(json.dumps(dict(ok=True,row_count=len(rows),rows=rows,fields=list(rows[0].keys()) if rows else []),ensure_ascii=False,default=str))\n'
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr, resp, lat, expected_fields=["price", "change_pct", "pre_close"])
    results.append(sr)

    # AKShare spot
    sr2 = SourceResult(
        source_key="akshare_spot",
        candidate_name="akshare stock_zh_a_spot_em",
        dependency="akshare",
        category="quote_price",
    )
    for _ in range(runs):
        t0 = time.perf_counter()
        body = _build_sdk_script(
            'import akshare as ak',
            'result = ak.stock_zh_a_spot_em().head(3).to_dict(orient="records")',
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr2, resp, lat, expected_fields=["代码", "最新价", "涨跌幅", "名称"])
    results.append(sr2)

    # efinance realtime
    sr3 = SourceResult(
        source_key="efinance_realtime",
        candidate_name="efinance get_realtime_quotes",
        dependency="efinance",
        category="quote_price",
    )
    for _ in range(runs):
        t0 = time.perf_counter()
        body = (
            'import json,sys\n'
            'import efinance as ef\n'
            f'codes = [{",".join(repr(c) for c in codes[:2])}]\n'
            'df = ef.stock.get_realtime_quotes(codes)\n'
            'rows = df.to_dict(orient="records") if hasattr(df,"to_dict") else []\n'
            'fields = list(df.columns) if hasattr(df,"columns") else []\n'
            'print(json.dumps(dict(ok=True,row_count=len(rows),rows=rows[:5],fields=fields),ensure_ascii=False,default=str))\n'
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr3, resp, lat, expected_fields=["股票代码", "股票名称", "最新价", "涨跌幅"])
    results.append(sr3)

    # Tencent quote
    sr4 = SourceResult(
        source_key="tencent_quote",
        candidate_name="TencentProvider.get_quotes",
        dependency="requests (qt.gtimg.cn)",
        category="quote_price",
    )
    for code in codes[:runs]:
        t0 = time.perf_counter()
        body = (
            'import json,sys\n'
            f'sys.path.insert(0,{str(OLD_ROOT)!r})\n'
            'from astock_guard.providers.tencent import TencentProvider\n'
            'p = TencentProvider()\n'
            f'quotes = p.get_quotes([{code!r}])\n'
            'rows = [dict(code=q.code,price=q.price,pre_close=q.pre_close,change_pct=q.change_pct,'
            'bid1=q.bid1,ask1=q.ask1,volume=q.volume) for q in quotes]\n'
            'print(json.dumps(dict(ok=True,row_count=len(rows),rows=rows,fields=list(rows[0].keys()) if rows else []),ensure_ascii=False,default=str))\n'
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr4, resp, lat, expected_fields=["price", "change_pct", "bid1"])
    results.append(sr4)

    # Sina quote
    sr5 = SourceResult(
        source_key="sina_quote",
        candidate_name="SinaProvider.get_quotes",
        dependency="requests (hq.sinajs.cn)",
        category="quote_price",
    )
    for code in codes[:runs]:
        t0 = time.perf_counter()
        body = (
            'import json,sys\n'
            f'sys.path.insert(0,{str(OLD_ROOT)!r})\n'
            'from astock_guard.providers.sina import SinaProvider\n'
            'p = SinaProvider()\n'
            f'quotes = p.get_quotes([{code!r}])\n'
            'rows = [dict(code=q.code,price=q.price,pre_close=q.pre_close,change_pct=q.change_pct,'
            'bid1=q.bid1,ask1=q.ask1,bid_vol1=q.bid_vol1,volume=q.volume) for q in quotes]\n'
            'print(json.dumps(dict(ok=True,row_count=len(rows),rows=rows,fields=list(rows[0].keys()) if rows else []),ensure_ascii=False,default=str))\n'
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr5, resp, lat, expected_fields=["price", "change_pct", "bid1", "bid_vol1"])
    results.append(sr5)

    return results


def validate_orderbook(runs: int, codes: list[str]) -> list[SourceResult]:
    results: list[SourceResult] = []

    # PyTDX get_security_quotes
    sr = SourceResult(
        source_key="pytdx_quote",
        candidate_name="PytdxProvider.get_quotes",
        dependency="pytdx SDK",
        category="orderbook",
    )
    for code in codes[:runs]:
        t0 = time.perf_counter()
        body = (
            'import json,sys\n'
            f'sys.path.insert(0,{str(OLD_ROOT)!r})\n'
            'from astock_guard.providers.pytdx_provider import PytdxProvider\n'
            'p = PytdxProvider()\n'
            f'quotes = p.get_quotes([{code!r}])\n'
            'rows = [dict(code=q.code,price=q.price,pre_close=q.pre_close,change_pct=q.change_pct,'
            'bid1=q.bid1,ask1=q.ask1,bid_vol1=q.bid_vol1,ask_vol1=q.ask_vol1,'
            'bid2=q.bid2,ask2=q.ask2,volume=q.volume,amount=q.amount) for q in quotes]\n'
            'print(json.dumps(dict(ok=True,row_count=len(rows),rows=rows,fields=list(rows[0].keys()) if rows else []),ensure_ascii=False,default=str))\n'
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr, resp, lat, expected_fields=["bid1", "ask1", "bid_vol1", "ask_vol1"])
        # Check if bid_vol1 is actually populated
        if resp.get("ok") and resp.get("rows"):
            row = resp["rows"][0]
            if row.get("bid_vol1") is not None and float(row["bid_vol1"]) > 0:
                sr.business_fit["orderbook_fit"] = True
    results.append(sr)

    # Sina orderbook check
    sr2 = SourceResult(
        source_key="sina_orderbook",
        candidate_name="SinaProvider bid/ask check",
        dependency="requests (hq.sinajs.cn)",
        category="orderbook",
    )
    for code in codes[:runs]:
        t0 = time.perf_counter()
        body = (
            'import json,sys\n'
            f'sys.path.insert(0,{str(OLD_ROOT)!r})\n'
            'from astock_guard.providers.sina import SinaProvider\n'
            'p = SinaProvider()\n'
            f'quotes = p.get_quotes([{code!r}])\n'
            'rows = [dict(code=q.code,price=q.price,bid1=q.bid1,ask1=q.ask1,'
            'bid_vol1=getattr(q,"bid_vol1",None),ask_vol1=getattr(q,"ask_vol1",None)) for q in quotes]\n'
            'print(json.dumps(dict(ok=True,row_count=len(rows),rows=rows),ensure_ascii=False,default=str))\n'
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr2, resp, lat, expected_fields=["bid1", "ask1", "bid_vol1"])
        if resp.get("ok") and resp.get("rows"):
            row = resp["rows"][0]
            if row.get("bid1") is not None:
                sr2.business_fit["orderbook_fit"] = True
    results.append(sr2)

    # Eastmoney negative control (verify bid_vol1 empty)
    sr3 = SourceResult(
        source_key="eastmoney_orderbook_negative",
        candidate_name="EastmoneyProvider bid/ask (negative control)",
        dependency="requests (push2.eastmoney.com)",
        category="orderbook",
    )
    for code in codes[:runs]:
        t0 = time.perf_counter()
        body = (
            'import json,sys\n'
            f'sys.path.insert(0,{str(OLD_ROOT)!r})\n'
            'from astock_guard.providers.eastmoney import EastmoneyProvider\n'
            'p = EastmoneyProvider()\n'
            f'quotes = p.get_quotes([{code!r}])\n'
            'rows = [dict(code=q.code,price=q.price,bid1=q.bid1,ask1=q.ask1,'
            'bid_vol1=getattr(q,"bid_vol1",None),ask_vol1=getattr(q,"ask_vol1",None)) for q in quotes]\n'
            'print(json.dumps(dict(ok=True,row_count=len(rows),rows=rows),ensure_ascii=False,default=str))\n'
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr3, resp, lat, expected_fields=["price"])
        # Verify bid_vol1 is empty (negative control)
        if resp.get("ok") and resp.get("rows"):
            row = resp["rows"][0]
            bid_v = row.get("bid_vol1")
            if bid_v is None or bid_v == "" or (isinstance(bid_v, (int, float)) and bid_v == 0):
                sr3.business_fit["orderbook_fit"] = False
                sr3.reason = "Confirmed: bid_vol1 empty — not usable for orderbook/seal"
    results.append(sr3)

    return results


def validate_limit_pool(runs: int, codes: list[str], trading_date: str) -> list[SourceResult]:
    results: list[SourceResult] = []

    # Eastmoney limit_pool
    sr = SourceResult(
        source_key="eastmoney_limit_pool",
        candidate_name="EastmoneyLimitPoolProvider.snapshot",
        dependency="requests (push2ex.eastmoney.com)",
        category="limit_pool",
    )
    for _ in range(min(runs, 2)):
        t0 = time.perf_counter()
        body = (
            'import json,sys\n'
            f'sys.path.insert(0,{str(OLD_ROOT)!r})\n'
            'from astock_guard.providers.limit_pool import EastmoneyLimitPoolProvider\n'
            'p = EastmoneyLimitPoolProvider()\n'
            f'result = p.snapshot({trading_date!r})\n'
            'rows = result.get("limit_up",[]) + result.get("open_board",[])\n'
            'print(json.dumps(dict(ok=True,row_count=len(rows),rows=rows[:5],'
            'fields=list(rows[0].keys()) if rows else []),ensure_ascii=False,default=str))\n'
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr, resp, lat, expected_fields=["code", "name", "pool", "first_limit_time"])
        if resp.get("ok") and resp.get("row_count", 0) > 0:
            sr.business_fit["limit_pool_fit"] = True
    results.append(sr)

    # AKShare limit/block pool
    sr2 = SourceResult(
        source_key="akshare_limit_pool",
        candidate_name="akshare stock_zt_pool_em",
        dependency="akshare",
        category="limit_pool",
    )
    for _ in range(runs):
        t0 = time.perf_counter()
        body = _build_sdk_script(
            'import akshare as ak',
            f'result = ak.stock_zt_pool_em(date={trading_date!r}).head(5).to_dict(orient="records")',
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr2, resp, lat, expected_fields=["代码", "名称", "涨停价", "涨停原因"])
        if resp.get("ok") and resp.get("row_count", 0) > 0:
            sr2.business_fit["limit_pool_fit"] = True
    results.append(sr2)

    # THS limit_pool (if callable)
    sr3 = SourceResult(
        source_key="ths_limit_pool",
        candidate_name="ThsLimitPoolProvider.snapshot",
        dependency="requests (同花顺 cookie)",
        category="limit_pool",
    )
    # Probe if callable exists
    probe = _old_script(
        'import json,sys\n'
        f'sys.path.insert(0,{str(OLD_ROOT)!r})\n'
        'try:\n'
        '  from astock_guard.providers.limit_pool import ThsLimitPoolProvider\n'
        '  print(json.dumps(dict(ok=True,message="ThsLimitPoolProvider importable")))\n'
        'except Exception as e:\n'
        '  print(json.dumps(dict(ok=False,error=f"{type(e).__name__}:{e}")))\n'
    )
    if probe.get("ok"):
        sr3.reason = "Probe OK — requires cookie, not tested without"
    else:
        sr3.dependency_missing = "ThsLimitPoolProvider not importable or missing dependencies"
    results.append(sr3)

    return results


def validate_daily_kline(runs: int, codes: list[str], trading_date: str) -> list[SourceResult]:
    results: list[SourceResult] = []

    # Old DailyHistoryProvider
    sr = SourceResult(
        source_key="old_daily_history_kline",
        candidate_name="DailyHistoryProvider.get_kline_score",
        dependency="DailyHistoryProvider (THS+efinance+akshare+SQLite)",
        category="daily_kline",
    )
    t0 = time.perf_counter()
    body = (
        'import json,sys\n'
        f'sys.path.insert(0,{str(OLD_ROOT)!r})\n'
        f'sys.path.insert(0,{str(OLD_ROOT / "data")!r})\n'
        'from astock_guard.providers.history import DailyHistoryProvider\n'
        f'p = DailyHistoryProvider(db_path={str(OLD_DB)!r})\n'
        f'result = p.get_kline_score(code={codes[0]!r}, current_price=None, cached_only=True)\n'
        'print(json.dumps(dict(ok=True,row_count=1,rows=[result],'
        'fields=list(result.keys())),ensure_ascii=False,default=str))\n'
    )
    resp = _old_script(body)
    lat = (time.perf_counter() - t0) * 1000
    _record(sr, resp, lat, expected_fields=["score", "status"])
    if resp.get("ok") and resp.get("rows"):
        sr.business_fit["kline_fit"] = True
    results.append(sr)

    # BaoStock daily kline (check if available)
    sr2 = SourceResult(
        source_key="baostock_daily_kline",
        candidate_name="baostock query_history_k_data_plus",
        dependency="baostock",
        category="daily_kline",
        dependency_missing="baostock not installed in old venv",
    )
    results.append(sr2)

    # AKShare daily kline
    sr3 = SourceResult(
        source_key="akshare_daily_kline",
        candidate_name="akshare stock_zh_a_hist",
        dependency="akshare",
        category="daily_kline",
    )
    for _ in range(min(runs, 2)):
        t0 = time.perf_counter()
        body = _build_sdk_script(
            'import akshare as ak',
            f'result = ak.stock_zh_a_hist(symbol={codes[0]!r}, period="daily", '
            f'start_date="20250101", end_date="20250110", adjust="").to_dict(orient="records")',
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr3, resp, lat, expected_fields=["日期", "开盘", "收盘", "最高", "最低", "成交量"])
        if resp.get("ok") and resp.get("row_count", 0) > 0:
            sr3.business_fit["kline_fit"] = True
    results.append(sr3)

    # efinance daily kline
    sr4 = SourceResult(
        source_key="efinance_daily_kline",
        candidate_name="efinance stock.get_quote_history",
        dependency="efinance",
        category="daily_kline",
    )
    for _ in range(min(runs, 2)):
        t0 = time.perf_counter()
        body = _build_sdk_script(
            'import efinance as ef',
            f'result = ef.stock.get_quote_history({codes[0]!r}, beg="20250101", end="20250110", klt=101).to_dict(orient="records")',
        )
        resp = _old_script(body)
        lat = (time.perf_counter() - t0) * 1000
        _record(sr4, resp, lat, expected_fields=["日期", "开盘", "收盘", "最高", "最低"])
        if resp.get("ok") and resp.get("row_count", 0) > 0:
            sr4.business_fit["kline_fit"] = True
    results.append(sr4)

    return results


# ── recording helpers ───────────────────────────────────────────

def _record(sr: SourceResult, resp: dict[str, Any], latency: float,
            expected_fields: list[str] | None = None) -> None:
    sr.latency_ms.append(round(latency, 1))
    if resp.get("ok") and resp.get("error") is None:
        sr.ok_count += 1
        rows = resp.get("rows") or []
        sr.row_count = max(sr.row_count, len(rows) if isinstance(rows, list) else len(resp.get("rows", [])))
        if resp.get("fields"):
            for f in resp["fields"]:
                sr.field_coverage[f] = True
        if expected_fields:
            for f in expected_fields:
                if f not in sr.field_coverage:
                    sr.field_coverage[f] = False
        if rows and isinstance(rows, list) and rows:
            sr.sample_fields = rows[0] if isinstance(rows[0], dict) else {"value": str(rows[0])}
    else:
        sr.fail_count += 1
        err = resp.get("error") or "unknown_error"
        sr.errors.append(err)


# ── main ────────────────────────────────────────────────────────

def main() -> None:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--trading-date", default="2026-05-09")
    parser.add_argument("--codes", default="002885,605369,000001")
    parser.add_argument("--runs", type=int, default=3)
    parser.add_argument("--market-session", default="unknown",
                        choices=["TRADING", "PRE_TRADING", "AFTERNOON", "CLOSED", "unknown"])
    args = parser.parse_args()

    td = args.trading_date.replace("-", "")
    codes = [c.strip() for c in args.codes.split(",") if c.strip()]
    runs = min(args.runs, 3)

    print(f"Trading date: {td}  Codes: {codes}  Runs: {runs}")
    print(f"Market session: {args.market_session}")
    print(f"Old Python: {OLD_PYTHON}")
    if not OLD_PYTHON.exists():
        print("ERROR: old python not found. Exiting.")
        return
    if not OLD_DB.exists():
        print(f"WARN: old DB not found at {OLD_DB} — some kline tests may fail")

    all_results: list[SourceResult] = []

    print("\n=== stock_basic ===")
    all_results.extend(validate_stock_basic(runs, codes))

    print("\n=== calendar ===")
    all_results.extend(validate_calendar(runs))

    print("\n=== quote_price ===")
    all_results.extend(validate_quote_price(runs, codes))

    print("\n=== orderbook/seal ===")
    all_results.extend(validate_orderbook(runs, codes))

    print("\n=== limit_pool ===")
    all_results.extend(validate_limit_pool(runs, codes, td))

    print("\n=== daily_kline ===")
    all_results.extend(validate_daily_kline(runs, codes, td))

    # ── post-process: tag orderbook sources for trading session ─
    is_trading = args.market_session == "TRADING"
    for sr in all_results:
        if sr.category in ("orderbook", "seal"):
            sr.trading_time_required = True
            if not is_trading and sr.ok_count == 0:
                sr.validation_status = "non_trading_unverified"
            elif sr.ok_count > 0:
                sr.validation_status = "ok"
            elif sr.dependency_missing:
                sr.validation_status = "dependency_missing"
            else:
                sr.validation_status = "non_trading_unverified"
        elif sr.dependency_missing:
            sr.validation_status = "dependency_missing"
        elif sr.requires_token:
            sr.validation_status = "requires_token"
        elif sr.ok_count > 0:
            sr.validation_status = "ok"
        elif sr.ok_count == 0 and sr.fail_count > 0:
            if sr.category in ("orderbook", "seal") and not is_trading:
                sr.validation_status = "non_trading_unverified"
            else:
                sr.validation_status = "failed"
        else:
            sr.validation_status = "failed"

    # ── summary ────────────────────────────────────────────────
    print("\n" + "=" * 80)
    print("VALIDATION RESULTS")
    print("=" * 80)
    successful = []
    failed = []
    non_trading_unverified = []
    for sr in all_results:
        total = sr.ok_count + sr.fail_count
        ok_pct = f"{sr.ok_count}/{total}" if total else "0/0"
        lat_summary = ""
        if sr.latency_ms:
            lat_summary = f"lat={min(sr.latency_ms):.0f}/{sum(sr.latency_ms)/len(sr.latency_ms):.0f}/{max(sr.latency_ms):.0f}ms"
        dep_note = ""
        if sr.dependency_missing:
            dep_note = f" [DEP MISSING: {sr.dependency_missing}]"
        elif sr.requires_token:
            dep_note = " [REQUIRES TOKEN]"
        status = sr.validation_status.upper() if sr.validation_status else ("OK" if sr.ok_count > 0 else "FAIL")
        label = f"  {sr.source_key:40s} {status:20s} {ok_pct:5s} rows={sr.row_count} {lat_summary}{dep_note}"
        print(label)
        if sr.errors:
            for e in sr.errors[:2]:
                print(f"    error: {e[:120]}")
        if sr.business_fit.get("orderbook_fit") is False and sr.source_key == "eastmoney_orderbook_negative":
            print(f"    negative control CONFIRMED: bid_vol1 empty")
        if sr.validation_status == "ok":
            successful.append(sr.source_key)
        elif sr.validation_status == "non_trading_unverified":
            non_trading_unverified.append(sr.source_key)
        else:
            failed.append(sr.source_key)

    print(f"\nSuccessful: {len(successful)}  Failed: {len(failed)}  Non-trading unverified: {len(non_trading_unverified)}")
    print(f"Requires token: {sum(1 for sr in all_results if sr.requires_token)}")
    print(f"Dependency missing: {sum(1 for sr in all_results if sr.dependency_missing)}")
    if non_trading_unverified:
        print(f"Orderbook sources require TRADING session re-validation")
        for s in non_trading_unverified:
            print(f"  - {s}")

    # ── write reports ──────────────────────────────────────────
    reports_dir = ROOT / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)

    report_md_path = reports_dir / "external_source_validation_latest.md"
    report_json_path = reports_dir / "external_source_validation_latest.json"

    _write_md_report(report_md_path, all_results, successful, failed, non_trading_unverified, td, codes, runs, args.market_session)
    _write_json_report(report_json_path, all_results, td, codes, runs, args.market_session)

    print(f"\nReports written:")
    print(f"  {report_md_path}")
    print(f"  {report_json_path}")
    print("\nExternal source validation complete.")


def _write_md_report(path: Path, results: list[SourceResult], successful: list[str],
                     failed: list[str], non_trading_unverified: list[str],
                     td: str, codes: list[str], runs: int,
                     market_session: str = "unknown") -> None:
    is_trading = market_session == "TRADING"
    lines = [
        "# External Source Validation Report",
        "",
        f"Generated: {datetime.now().isoformat(timespec='seconds')}",
        f"Trading date: {td}  Codes: {codes}  Runs per source: {runs}",
        f"Market session: {market_session}",
        f"Old Python: {OLD_PYTHON}",
        f"Old DB: {OLD_DB} ({'exists' if OLD_DB.exists() else 'not found'})",
        "",
        "## Summary",
        "",
        f"Sources tested: {len(results)}",
        f"Successful: {len(successful)}",
        f"Failed: {len(failed)}",
        f"Non-trading unverified: {len(non_trading_unverified)}",
        f"Requires token: {sum(1 for sr in results if sr.requires_token)}",
        f"Dependency missing: {sum(1 for sr in results if sr.dependency_missing)}",
        "",
        "## Per-Source Details",
        "",
        "| source_key | validation_status | ok/total | rows | latency(ms) | dep_missing | field_coverage | business_fit |",
        "|-----------|-------------------|----------|------|-------------|-------------|---------------|--------------|",
    ]
    for sr in sorted(results, key=lambda x: x.source_key):
        total = sr.ok_count + sr.fail_count
        status = sr.validation_status or ("OK" if sr.ok_count > 0 else ("DEP_MISS" if sr.dependency_missing else "FAIL"))
        lat_s = f"{min(sr.latency_ms):.0f}/{sum(sr.latency_ms)/max(len(sr.latency_ms),1):.0f}/{max(sr.latency_ms):.0f}" if sr.latency_ms else "-"
        fields = ", ".join(sorted(sr.field_coverage.keys())[:8])
        fit = ", ".join(f"{k}={v}" for k, v in sr.business_fit.items() if v)
        lines.append(f"| {sr.source_key} | {status} | {sr.ok_count}/{total} | {sr.row_count} | {lat_s} | {sr.dependency_missing[:40] or '-'} | {fields} | {fit} |")

    lines.extend(["", "## Key Findings", ""])

    # Quote price
    price_sources = [sr for sr in results if sr.category == "quote_price"]
    ok_price = [sr for sr in price_sources if sr.ok_count > 0]
    lines.append("### Quote price/change")
    for sr in ok_price:
        lat = f"{sum(sr.latency_ms)/len(sr.latency_ms):.0f}ms" if sr.latency_ms else "?"
        lines.append(f"- {sr.source_key}: OK ({sr.ok_count}/{sr.ok_count+sr.fail_count}), avg {lat}")
    for sr in price_sources:
        if sr.ok_count == 0 and not sr.dependency_missing:
            lines.append(f"- {sr.source_key}: FAIL — {sr.errors[:1]}")

    # Orderbook
    ob_sources = [sr for sr in results if sr.category == "orderbook"]
    lines.append("### Orderbook/seal-open")
    if not is_trading:
        lines.append(f"NOTE: validated during {market_session} session — orderbook data is session-dependent.")
        lines.append("Orderbook sources show non_trading_unverified. Re-run during TRADING session.")
    for sr in ob_sources:
        vs = sr.validation_status
        if sr.ok_count > 0:
            ob_fit = "fit=YES" if sr.business_fit.get("orderbook_fit") else "fit=NO"
            lines.append(f"- {sr.source_key}: OK ({vs}), {ob_fit}")
            if sr.sample_fields:
                bid1 = sr.sample_fields.get("bid1")
                bidv = sr.sample_fields.get("bid_vol1")
                lines.append(f"  bid1={bid1} bid_vol1={bidv}")
        elif sr.dependency_missing:
            lines.append(f"- {sr.source_key}: dependency missing")
        elif vs == "non_trading_unverified":
            lines.append(f"- {sr.source_key}: NON-TRADING UNVERIFIED — requires TRADING session re-validation")
            if sr.errors:
                for e in sr.errors[:1]:
                    lines.append(f"  (error during non-trading: {e[:100]})")
        else:
            lines.append(f"- {sr.source_key}: FAIL ({vs})")

    # Limit pool
    lp_sources = [sr for sr in results if sr.category == "limit_pool"]
    lines.append("### Limit pool")
    ok_lp = [sr for sr in lp_sources if sr.ok_count > 0]
    for sr in ok_lp:
        lines.append(f"- {sr.source_key}: OK, {sr.row_count} rows")
        if sr.sample_fields:
            sample = sr.sample_fields
            lines.append(f"  code={sample.get('code') or sample.get('代码')} name={sample.get('name') or sample.get('名称')}")

    # Daily kline
    kline_sources = [sr for sr in results if sr.category == "daily_kline"]
    lines.append("### Daily kline")
    for sr in kline_sources:
        if sr.ok_count > 0:
            lines.append(f"- {sr.source_key}: OK, kline_fit={sr.business_fit.get('kline_fit')}")
        elif sr.dependency_missing:
            lines.append(f"- {sr.source_key}: dependency missing")

    # Business fit summary
    lines.extend(["", "## Business Fit Summary", "", "| source_key | price_fit | orderbook_fit | limit_pool_fit | kline_fit |", "|-----------|-----------|---------------|----------------|-----------|"])
    for sr in sorted(results, key=lambda x: x.source_key):
        lines.append(f"| {sr.source_key} | {sr.business_fit.get('price_change_fit','')} | {sr.business_fit.get('orderbook_fit','')} | {sr.business_fit.get('limit_pool_fit','')} | {sr.business_fit.get('kline_fit','')} |")

    path.write_text("\n".join(lines), encoding="utf-8")


def _write_json_report(path: Path, results: list[SourceResult], td: str, codes: list[str], runs: int,
                       market_session: str = "unknown") -> None:
    is_trading = market_session == "TRADING"
    payload: dict[str, Any] = {
        "meta": {
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "trading_date": td,
            "codes": codes,
            "runs_per_source": runs,
            "market_session": market_session,
            "old_python": str(OLD_PYTHON),
            "old_db_exists": OLD_DB.exists(),
        },
        "summary": {
            "total_sources": len(results),
            "successful": sum(1 for sr in results if sr.validation_status == "ok"),
            "failed": sum(1 for sr in results if sr.validation_status in ("failed",)),
            "non_trading_unverified": sum(1 for sr in results if sr.validation_status == "non_trading_unverified"),
            "requires_token": sum(1 for sr in results if sr.requires_token),
            "dependency_missing": sum(1 for sr in results if sr.dependency_missing),
        },
        "sources": [],
    }
    for sr in sorted(results, key=lambda x: x.source_key):
        payload["sources"].append({
            "source_key": sr.source_key,
            "candidate_name": sr.candidate_name,
            "dependency": sr.dependency,
            "category": sr.category,
            "ok_count": sr.ok_count,
            "fail_count": sr.fail_count,
            "total_calls": sr.ok_count + sr.fail_count,
            "latency_ms": {"min": min(sr.latency_ms) if sr.latency_ms else None, "avg": round(sum(sr.latency_ms) / len(sr.latency_ms), 1) if sr.latency_ms else None, "max": max(sr.latency_ms) if sr.latency_ms else None},
            "row_count": sr.row_count,
            "field_coverage": dict(sorted(sr.field_coverage.items())),
            "sample_fields": sr.sample_fields,
            "requires_token": sr.requires_token,
            "dependency_missing": sr.dependency_missing,
            "trading_time_required": sr.trading_time_required,
            "validation_status": sr.validation_status,
            "errors": sr.errors[:3],
            "business_fit": sr.business_fit,
            "recommended_status": sr.recommended_status,
            "reason": sr.reason,
        })
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
