from __future__ import annotations

import sys
import tempfile
from pathlib import Path

from sqlalchemy import create_engine, inspect

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402


EXPECTED_TABLES = {
    "monitoring_stock_states",
    "monitoring_events",
    "monitoring_state_transitions",
    "score_snapshots",
    "notification_records",
    "self_stock_records",
    "gate_config_versions",
    "interface_health",
    "limit_pool_snapshots",
    "limit_pool_rows",
    "daily_bars",
    "daily_bar_coverage",
    "quote_samples",
    "stock_meta_cache",
}

TIME_SCOPE_TABLES = {
    "monitoring_stock_states",
    "monitoring_events",
    "monitoring_state_transitions",
    "score_snapshots",
    "notification_records",
    "self_stock_records",
    "limit_pool_snapshots",
    "limit_pool_rows",
    "quote_samples",
}

TIME_SCOPE_COLUMNS = {
    "trading_date",
    "source_trading_date",
    "as_of",
    "seq",
    "freshness_status",
}

FORBIDDEN_LIMIT_POOL_SCORE_COLUMNS = {
    "technical_score",
    "sentiment_score",
    "volume_score",
    "trigger_sentiment_score",
    "seal_sentiment_score",
    "open_sentiment_score",
    "realtime_sentiment_score",
}


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "schema.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)

        inspector = inspect(engine)
        tables = set(inspector.get_table_names())

        missing = EXPECTED_TABLES - tables
        assert not missing, f"missing tables: {sorted(missing)}"

        for table in TIME_SCOPE_TABLES:
            columns = {column["name"] for column in inspector.get_columns(table)}
            missing_columns = TIME_SCOPE_COLUMNS - columns
            assert not missing_columns, f"{table} missing time scope columns: {sorted(missing_columns)}"

        limit_pool_columns = {column["name"] for column in inspector.get_columns("limit_pool_rows")}
        forbidden = FORBIDDEN_LIMIT_POOL_SCORE_COLUMNS & limit_pool_columns
        assert not forbidden, f"limit_pool_rows must not contain score result columns: {sorted(forbidden)}"

        score_columns = {column["name"] for column in inspector.get_columns("score_snapshots")}
        for required in ["technical_score", "sentiment_score", "volume_score", "score_json", "input_refs_json"]:
            assert required in score_columns, f"score_snapshots missing {required}"

        monitoring_cols = {column["name"] for column in inspector.get_columns("monitoring_stock_states")}
        for required in ["active_monitoring", "inactive_reason", "inactive_at"]:
            assert required in monitoring_cols, f"monitoring_stock_states missing {required}"

        assert "score_task_current" in tables, "score_task_current table missing"
        st_cols = {column["name"] for column in inspector.get_columns("score_task_current")}
        for required in ["trading_date", "source_trading_date", "as_of", "seq", "freshness_status", "status", "task_type", "score_stage", "source_type", "source_snapshot_id", "source_row_id"]:
            assert required in st_cols, f"score_task_current missing {required}"

        assert "external_source_activation_current" in tables, "external_source_activation_current table missing"
        act_cols = {column["name"] for column in inspector.get_columns("external_source_activation_current")}
        for required in ["source_key", "trading_date", "state", "business_enabled", "shadow_only", "consecutive_failures", "circuit_open_until"]:
            assert required in act_cols, f"external_source_activation_current missing {required}"

    print("DB schema smoke test OK")


if __name__ == "__main__":
    main()
