from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, inspect, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import (  # noqa: E402
    LimitPoolRow,
    LimitPoolSnapshot,
    MonitoringStateTransition,
    MonitoringStockState,
    ScoreSnapshot,
)
from app.services.limit_pool_ingestion_service import (  # noqa: E402
    LimitPoolIngestionService,
    LimitPoolInputRow,
    LimitPoolInputSnapshot,
)


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "limit_pool_ingestion.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()

        with Session() as session:
            service = LimitPoolIngestionService(session)

            fresh = service.ingest_snapshot(
                LimitPoolInputSnapshot(
                    trading_date="2026-05-09",
                    source_trading_date="2026-05-09",
                    source="composite_limit_pool",
                    primary_source="eastmoney_limit_pool",
                    as_of=now,
                    seq=1,
                    freshness_status="fresh",
                    market_session="trading",
                    source_counts_json='{"limit_up":1,"open_board":1}',
                    rows=[
                        LimitPoolInputRow(
                            pool="limit_up",
                            code="000001",
                            name="平安银行",
                            source="eastmoney_limit_pool",
                            price=10.5,
                            change_pct=10.01,
                            first_limit_time="10:01:00",
                            last_limit_time="10:01:00",
                            open_count=0,
                            seal_amount=123456789.0,
                            streak=1,
                            industry="银行",
                            reason="mock limit up",
                            raw_json='{"mock": true}',
                        ),
                        LimitPoolInputRow(
                            pool="open_board",
                            code="600002",
                            name="mock open",
                            source="eastmoney_limit_pool",
                            price=8.8,
                            change_pct=8.85,
                            first_limit_time="10:30:00",
                            open_count=3,
                            industry="测试",
                            reason="mock open board",
                            raw_json='{"mock": true}',
                        ),
                    ],
                )
            )
            session.commit()

            assert fresh.row_count == 2

            snapshots = list(session.execute(select(LimitPoolSnapshot)).scalars())
            rows = list(session.execute(select(LimitPoolRow)).scalars())
            assert len(snapshots) == 1
            assert len(rows) == 2
            assert all(row.snapshot_id == fresh.snapshot_id for row in rows)
            assert {row.pool for row in rows} == {"limit_up", "open_board"}
            assert all(row.freshness_status == "fresh" for row in rows)

            inspector = inspect(engine)
            lp_columns = {column["name"] for column in inspector.get_columns("limit_pool_rows")}
            assert "technical_score" not in lp_columns
            assert "sentiment_score" not in lp_columns
            assert "volume_score" not in lp_columns

            assert count_(session, ScoreSnapshot) == 0
            assert count_(session, MonitoringStockState) == 0
            assert count_(session, MonitoringStateTransition) == 0

        with Session() as session:
            service = LimitPoolIngestionService(session)
            mismatch = service.ingest_snapshot(
                LimitPoolInputSnapshot(
                    trading_date="2026-05-10",
                    source_trading_date="2026-05-09",
                    source="composite_limit_pool",
                    primary_source="eastmoney_limit_pool",
                    as_of=now,
                    seq=2,
                    freshness_status="mismatch",
                    market_session="closed",
                    rows=[
                        LimitPoolInputRow(
                            pool="limit_up",
                            code="000003",
                            name="mock mismatch",
                            source="eastmoney_limit_pool",
                            price=11.0,
                            change_pct=10.02,
                            first_limit_time="11:00:00",
                            raw_json='{"mock": "mismatch"}',
                        )
                    ],
                )
            )
            session.commit()

            assert mismatch.row_count == 1

            mismatch_rows = list(
                session.execute(
                    select(LimitPoolRow).where(LimitPoolRow.trading_date == "2026-05-10")
                ).scalars()
            )
            assert len(mismatch_rows) == 1
            assert mismatch_rows[0].source_trading_date == "2026-05-09"
            assert mismatch_rows[0].freshness_status == "mismatch"

            assert count_(session, ScoreSnapshot) == 0
            assert count_(session, MonitoringStockState) == 0
            assert count_(session, MonitoringStateTransition) == 0

    print("Limit pool ingestion smoke test OK")


if __name__ == "__main__":
    main()
