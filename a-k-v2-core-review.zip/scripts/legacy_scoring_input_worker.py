"""
Subprocess worker that calls old providers for a single stock's scoring inputs.

Fetches: board_summary, board_members, fund_flow, stock_meta,
          intraday_quality, strategy/kline_structure_score

Usage:
  ../a-k/.venv/bin/python scripts/legacy_scoring_input_worker.py \
    --code 600519 --name "贵州茅台" \
    --old-project-root ../a-k --old-db-path ../a-k/data/astock_guard.db

Returns JSON on stdout:
  {"ok": true, "data": {"board_summary": {...}, "board_members": {...}, ...}}
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--code", required=True)
    p.add_argument("--name", default="")
    p.add_argument("--old-project-root", required=True)
    p.add_argument("--old-db-path", required=True)
    p.add_argument("--timeout", type=float, default=8.0)
    return p.parse_args()


def _iso(value: Any) -> str | None:
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value) if value else None


def _to_dict(obj: Any) -> Any:
    if hasattr(obj, "to_dict"):
        return obj.to_dict()
    if hasattr(obj, "__dataclass_fields__"):
        from dataclasses import asdict
        return asdict(obj)
    return obj


def _summarize_boards(boards: list, primary: dict | None) -> dict[str, Any]:
    changes = []
    for b in boards:
        d = b if isinstance(b, dict) else _to_dict(b)
        pct = d.get("board_change_pct")
        if pct is not None:
            try:
                changes.append(float(pct))
            except (TypeError, ValueError):
                pass

    return {
        "count": len(boards),
        "primary_board": primary,
        "average_change_pct": round(sum(changes) / len(changes), 3) if changes else None,
        "positive_count": sum(1 for v in changes if v > 0),
        "strong_count": sum(1 for v in changes if v >= 2.0),
        "boards": boards,
    }


def main() -> None:
    args = parse_args()
    old_root = str(Path(args.old_project_root).resolve())

    if old_root not in sys.path:
        sys.path.insert(0, old_root)

    code = args.code
    name = args.name or ""
    db_path = str(Path(args.old_db_path).resolve())

    try:
        # ── 1. board_summary ──
        from astock_guard.providers.stock_boards import StockBoardProvider

        board_provider = StockBoardProvider(db_path=db_path, cache_ttl_seconds=30)
        boards_raw = board_provider.get_boards(code, name=name, refresh=False)
        boards = [_to_dict(b) for b in boards_raw]
        summary = board_provider.summary(code, name=name, refresh=False)
        board_summary = {
            "status": "ready" if boards else "empty",
            "source": "stock_board_provider",
            "updated_at": _iso(datetime.now()),
            "primary_board": summary.get("primary_board"),
            "strong_concepts": summary.get("strong_concepts"),
            "board_count": len(boards),
            "boards": boards,
        }

        # ── 2. board_members (for each board the stock belongs to) ──
        from astock_guard.providers.em_board_members import EastmoneyBoardMemberProvider

        member_provider = EastmoneyBoardMemberProvider(timeout=args.timeout)
        board_members_result: dict[str, Any] = {
            "status": "ready",
            "source": "eastmoney_board_member_provider",
            "boards": [],
        }
        for board in boards:
            board_code = board.get("board_code")
            board_name = board.get("board_name") or ""
            board_kind = board.get("board_kind") or ""
            board_change_pct = board.get("board_change_pct")
            if not board_code:
                continue
            try:
                members = member_provider.get_members(board_code, limit=20, with_quote=True)
            except Exception:
                continue
            member_dicts = [_to_dict(m) for m in members]
            if member_dicts:
                codes = [str(m.get("code", "")).strip().zfill(6)[-6:] for m in member_dicts]
                current_idx = next((i for i, c in enumerate(codes) if c == code.zfill(6)[-6:]), None)
                rank = (current_idx + 1) if current_idx is not None else None
            else:
                rank = None

            changes = []
            for m in member_dicts:
                v = m.get("change_pct")
                if v is not None:
                    try:
                        changes.append(float(v))
                    except (TypeError, ValueError):
                        pass
            avg_change = round(sum(changes) / len(changes), 3) if changes else 0.0
            red_ratio = round(sum(1 for v in changes if v > 0) / len(changes), 3) if changes else 0.0
            strong_count = sum(1 for v in changes if v >= 5.0)

            board_members_result["boards"].append({
                "board_code": board_code,
                "board_name": board_name,
                "board_kind": board_kind,
                "board_change_pct": float(board_change_pct) if board_change_pct is not None else None,
                "rank": rank,
                "members": member_dicts,
                "avg_change_pct": avg_change,
                "red_ratio": red_ratio,
                "strong_count": strong_count,
            })

        # ── 3. fund_flow ──
        from astock_guard.providers.fund_flow import EastmoneyFundFlowProvider

        fund_provider = EastmoneyFundFlowProvider(
            db_path=db_path, timeout=args.timeout, cache_ttl_seconds=300
        )
        fund_flow = fund_provider.get_flow(code, limit=20, refresh=False)

        # ── 4. stock_meta ──
        from astock_guard.providers.stock_meta import StockMetaProvider

        meta_provider = StockMetaProvider(db_path=db_path, cache_ttl_seconds=21600)
        stock_meta = meta_provider.get_meta(code, refresh=False)

        # ── 5. intraday_quality (try) ──
        intraday_quality: dict[str, Any] = {"status": "not_requested"}
        try:
            from astock_guard.providers.intraday import CompositeIntradayProvider
            intraday_provider = CompositeIntradayProvider(db_path=db_path)
            quality = intraday_provider.request_quality(code)
            if quality:
                intraday_quality = {"status": "ready", **(_to_dict(quality) if hasattr(quality, "to_dict") else quality)}
        except Exception:
            intraday_quality = {"status": "unavailable"}

        # ── 6. strategy/kline_structure_score ──
        strategy: dict[str, Any] = {"status": "not_requested"}
        try:
            from astock_guard.server import strategy_engine as old_strategy_engine
            if old_strategy_engine is not None:
                result = old_strategy_engine.evaluate_code(code)
                strategy = _to_dict(result) if result else {"status": "empty"}
        except Exception:
            strategy = {"status": "unavailable"}

        payload = {
            "board_summary": board_summary,
            "board_members": board_members_result,
            "fund_flow": fund_flow,
            "stock_meta": stock_meta,
            "intraday_quality": intraday_quality,
            "strategy": strategy,
        }

        print(json.dumps({
            "ok": True,
            "code": code,
            "data": payload,
        }, ensure_ascii=False, default=str))

    except Exception as exc:
        print(json.dumps({
            "ok": False,
            "code": code,
            "error": str(exc),
            "exception_type": exc.__class__.__name__,
        }, ensure_ascii=False, default=str))
        raise SystemExit(0)
    finally:
        if old_root in sys.path:
            sys.path.remove(old_root)


if __name__ == "__main__":
    main()
