from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import (  # noqa: E402
    LimitPoolRow,
    LimitPoolSnapshot,
    MonitoringStateTransition,
    MonitoringStockState,
    ScoreSnapshot,
    ScoreTaskCurrent,
)
from app.repositories import ScoreTaskRepository  # noqa: E402
from app.services.limit_pool_ingestion_service import (  # noqa: E402
    LimitPoolIngestionService,
    LimitPoolInputRow,
    LimitPoolInputSnapshot,
)
from app.services.score_task_service import ScoreTaskService  # noqa: E402


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "score_task.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()

        with Session() as session:
            ingestion = LimitPoolIngestionService(session)
            tasks = ScoreTaskService(session)

            # ingest a fresh snapshot with 2 rows
            fresh = ingestion.ingest_snapshot(
                LimitPoolInputSnapshot(
                    trading_date="2026-05-09", source_trading_date="2026-05-09",
                    source="composite_limit_pool", primary_source="eastmoney_limit_pool",
                    as_of=now, seq=1, freshness_status="fresh", market_session="trading",
                    source_counts_json='{"limit_up":1,"open_board":1}',
                    rows=[
                        LimitPoolInputRow(pool="limit_up", code="000001", name="平安银行",
                            source="eastmoney_limit_pool", price=10.5, change_pct=10.01,
                            first_limit_time="10:01:00"),
                        LimitPoolInputRow(pool="open_board", code="600002", name="mock open",
                            source="eastmoney_limit_pool", price=8.8, change_pct=8.85,
                            first_limit_time="10:30:00"),
                    ],
                )
            )

            # get DB rows
            db_rows = list(session.execute(select(LimitPoolRow)).scalars())
            assert len(db_rows) == 2

            score_before = count_(session, ScoreSnapshot)
            ls_before = count_(session, MonitoringStockState)

            # schedule tasks for both rows
            r1 = tasks.schedule_for_limit_pool_row(db_rows[0])
            r2 = tasks.schedule_for_limit_pool_row(db_rows[1])

            assert r1.task_id is not None
            assert r2.task_id is not None

            # idempotent: same row again should not create new task
            r1_dup = tasks.schedule_for_limit_pool_row(db_rows[0])
            assert r1_dup.task_id == r1.task_id  # upsert returned the same task

            # assert task count
            all_tasks = list(session.execute(select(ScoreTaskCurrent)).scalars())
            assert len(all_tasks) == 2

            # task fields
            t1 = all_tasks[0]
            assert t1.status == "pending"
            assert t1.source_type == "limit_pool_row"
            assert t1.source_row_id == db_rows[0].id
            assert t1.source_snapshot_id == fresh.snapshot_id
            assert t1.task_type == "limit_pool_score"
            assert t1.score_stage == "limit_pool_first_score"
            assert 'limit_pool_row_id' in (t1.input_refs_json or "")

            # no side effects
            assert count_(session, ScoreSnapshot) == score_before
            assert count_(session, MonitoringStockState) == ls_before
            assert count_(session, MonitoringStateTransition) == 0

            # list_pending
            repo = ScoreTaskRepository(session)
            pending = repo.list_pending(trading_date="2026-05-09")
            assert len(pending) == 2
            assert pending[0].priority == 100

            # status flow: running
            repo.mark_running(t1.id, started_at=now)
            session.flush()
            running = session.get(ScoreTaskCurrent, t1.id)
            assert running is not None
            assert running.status == "running"
            assert running.attempts == 1

            # status flow: failed (attempts < max -> back to pending)
            repo.mark_failed(t1.id, error="mock provider error", next_run_at=now + timedelta(minutes=2))
            session.flush()
            failed = session.get(ScoreTaskCurrent, t1.id)
            assert failed is not None
            assert failed.status == "pending"  # back to pending (attempts=1 < max=3)
            assert failed.last_error == "mock provider error"

            # status flow: running -> ready
            repo.mark_running(r2.task_id, started_at=now)
            repo.mark_ready(r2.task_id, finished_at=now + timedelta(seconds=30))
            session.flush()
            ready = session.get(ScoreTaskCurrent, r2.task_id)
            assert ready is not None
            assert ready.status == "ready"

            session.commit()

    print("Score task framework smoke test OK")


if __name__ == "__main__":
    main()
