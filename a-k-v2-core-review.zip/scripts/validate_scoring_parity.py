"""
Scoring parity validation: compares v2 LegacyFullScoringExecutor scores
against v1 daily_stock_state scores for recent stocks.

Usage:
  python3 scripts/validate_scoring_parity.py [--limit 20] [--tolerance 5.0]
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
OLD_ROOT = ROOT.parent / "a-k"
OLD_PYTHON = OLD_ROOT / ".venv" / "bin" / "python"
OLD_DB = OLD_ROOT / "data" / "astock_guard.db"
KLINE_WORKER = ROOT / "scripts" / "legacy_kline_worker.py"
SCORING_INPUT_WORKER = ROOT / "scripts" / "legacy_scoring_input_worker.py"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--limit", type=int, default=10)
    p.add_argument("--tolerance", type=float, default=5.0,
                   help="max acceptable absolute difference (default 5.0)")
    p.add_argument("--output-json", help="write results JSON to this path")
    return p.parse_args()


def fetch_old_scores(limit: int) -> list[dict[str, Any]]:
    """Get recent stocks with scores from v1 daily_stock_state."""
    import sqlite3
    db = sqlite3.connect(str(OLD_DB))
    rows = db.execute(
        """SELECT trade_date, code, name, technical_score, entry_sentiment_score,
                  first_seal_sentiment_score, volume_score, price, change_pct
           FROM daily_stock_state
           WHERE technical_score IS NOT NULL
             AND trade_date >= '2026-05-06'
           ORDER BY trade_date DESC, technical_score DESC
           LIMIT ?""",
        (limit,),
    ).fetchall()
    return [
        {
            "trade_date": r[0], "code": r[1], "name": r[2],
            "old_technical": r[3], "old_entry_sentiment": r[4],
            "old_seal_sentiment": r[5], "old_volume": r[6],
            "old_price": r[7], "old_change_pct": r[8],
        }
        for r in rows
    ]


def run_kline_worker(code: str, name: str, price: float | None = None) -> dict[str, Any]:
    cmd = [
        str(OLD_PYTHON), str(KLINE_WORKER),
        "--old-project-root", str(OLD_ROOT),
        "--old-db-path", str(OLD_DB),
        "--code", code, "--name", name,
    ]
    if price:
        cmd.extend(["--current-price", str(price)])
    cp = subprocess.run(cmd, check=False, capture_output=True, text=True, timeout=30)
    if cp.returncode != 0:
        return {"status": "failed", "error": cp.stderr.strip()[:500]}
    try:
        return json.loads(cp.stdout)
    except json.JSONDecodeError:
        return {"status": "invalid_json", "raw": cp.stdout[:500]}


def run_scoring_input_worker(code: str, name: str) -> dict[str, Any]:
    cmd = [
        str(OLD_PYTHON), str(SCORING_INPUT_WORKER),
        "--code", code, "--name", name,
        "--old-project-root", str(OLD_ROOT),
        "--old-db-path", str(OLD_DB),
    ]
    cp = subprocess.run(cmd, check=False, capture_output=True, text=True, timeout=30)
    if cp.returncode != 0:
        return {"status": "failed", "error": cp.stderr.strip()[:500]}
    try:
        return json.loads(cp.stdout)
    except json.JSONDecodeError:
        return {"status": "invalid_json"}


def compare_one(stock: dict[str, Any]) -> dict[str, Any]:
    code = stock["code"]
    name = stock["name"]
    result = {
        "code": code, "name": name, "trade_date": stock["trade_date"],
        "old_technical": stock["old_technical"],
        "new_technical": None, "technical_diff": None,
        "status": "unknown", "errors": [],
    }

    # technical — pass old_price to match v1's scoring conditions
    tech = run_kline_worker(code, name, price=stock.get("old_price"))
    if tech.get("ok"):
        ts = tech.get("technical_score") or tech.get("score")
        if isinstance(ts, dict):
            result["new_technical"] = ts.get("total") or ts.get("score")
        else:
            result["new_technical"] = ts
        if result["new_technical"] is not None and stock["old_technical"] is not None:
            result["technical_diff"] = round(result["new_technical"] - stock["old_technical"], 1)
    else:
        result["errors"].append(f"kline: {tech.get('status') or tech.get('error')}")
        result["status"] = "failed"

    # board + sentiment inputs (just verify they load)
    inputs = run_scoring_input_worker(code, name)
    if inputs.get("ok"):
        data = inputs.get("data", {})
        bs = data.get("board_summary", {})
        bm = data.get("board_members", {})
        ff = data.get("fund_flow", {})
        result["board_count"] = bs.get("board_count", 0)
        result["board_member_boards"] = len(bm.get("boards", []))
        result["fund_flow_status"] = ff.get("status")
    else:
        result["errors"].append(f"scoring_inputs: {inputs.get('error')}")

    if result["status"] != "failed":
        result["status"] = "ok"
    return result


def main() -> None:
    args = parse_args()

    print(f"=== Scoring Parity Validation ===")
    print(f"  old_root: {OLD_ROOT}")
    print(f"  limit: {args.limit}, tolerance: {args.tolerance}")
    print(f"  time: {datetime.now().isoformat()}")
    print()

    stocks = fetch_old_scores(args.limit)
    print(f"Loaded {len(stocks)} stocks from old daily_stock_state\n")

    results = []
    passed = 0
    failed = 0
    for i, s in enumerate(stocks, 1):
        print(f"[{i}/{len(stocks)}] {s['code']} {s['name']} ... ", end="", flush=True)
        r = compare_one(s)
        results.append(r)

        if r["status"] == "failed":
            print(f"FAIL ({'; '.join(r['errors'])})")
            failed += 1
        else:
            td = r["technical_diff"]
            if td is not None and abs(td) <= args.tolerance:
                print(f"OK  tech={r['new_technical']} (diff={td:+.1f}, Δ within {args.tolerance})")
                passed += 1
            elif td is not None:
                print(f"WARN tech={r['new_technical']} (diff={td:+.1f}, Δ exceeds {args.tolerance})")
                failed += 1
            else:
                print(f"OK  tech={r['new_technical']}")

    print(f"\n=== Summary ===")
    print(f"  passed: {passed}/{len(stocks)}")
    print(f"  failed/warn: {failed}/{len(stocks)}")

    if args.output_json:
        with open(args.output_json, "w") as f:
            json.dump(results, f, ensure_ascii=False, indent=2, default=str)
        print(f"  results written to {args.output_json}")


if __name__ == "__main__":
    main()
