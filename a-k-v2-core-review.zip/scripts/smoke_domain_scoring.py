from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.domain.events import EventType  # noqa: E402
from app.domain.scoring import (  # noqa: E402
    SealSnapshotSignal,
    SentimentSignal,
    TechnicalSignal,
    VolumeSignal,
    score_seal_snapshot,
    score_sentiment,
    score_technical,
    score_volume,
)
from app.domain.scores import ScoreType  # noqa: E402
from app.domain.stocks import StockSnapshot  # noqa: E402


def assert_score(value: float | None, low: float, high: float, label: str) -> None:
    if value is None or not (low <= value <= high):
        raise SystemExit(f"{label} score out of range: {value}")


def main() -> None:
    stock = StockSnapshot(code="300750", name="宁德时代", price=214.28)

    technical = score_technical(
        stock,
        TechnicalSignal(
            ma_aligned_up=True,
            price_above_ma5=True,
            price_above_ma20=True,
            breakout_recent_high=True,
            intraday_strength_pct=3.2,
        ),
    )
    assert technical.score_type is ScoreType.TECHNICAL
    assert_score(technical.score, 40, 100, "technical")

    sentiment = score_sentiment(
        SentimentSignal(
            event_type=EventType.LIMIT_UP,
            board_rank=1,
            board_change_pct=3.8,
            is_board_leader=True,
            limit_up_count=8,
        )
    )
    assert sentiment.score_type is ScoreType.REALTIME_SENTIMENT
    assert_score(sentiment.score, 70, 100, "sentiment")

    volume = score_volume(
        VolumeSignal(
            volume_ratio=2.1,
            amount_rank_pct=8,
            net_inflow_positive=True,
            turnover_fit=True,
        )
    )
    assert volume.score_type is ScoreType.VOLUME
    assert_score(volume.score, 40, 100, "volume")

    pending_seal = score_seal_snapshot(SealSnapshotSignal())
    if pending_seal.score is not None:
        raise SystemExit("pending seal snapshot should have None score")

    seal = score_seal_snapshot(
        SealSnapshotSignal(
            is_first_seal=True,
            seal_time="09:40:11",
            seal_amount=2.4,
            open_count=0,
            board_sentiment_score=88,
        )
    )
    assert seal.score_type is ScoreType.SEAL_SENTIMENT
    assert seal.is_snapshot
    assert_score(seal.score, 60, 100, "seal snapshot")

    print("Domain scoring smoke tests passed.")


if __name__ == "__main__":
    main()
