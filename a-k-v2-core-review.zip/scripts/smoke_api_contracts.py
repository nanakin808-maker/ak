from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402


client = TestClient(app)


def assert_keys(data: dict[str, Any], keys: set[str], path: str) -> None:
    missing = keys - set(data.keys())
    if missing:
        raise SystemExit(f"{path} missing keys: {sorted(missing)}")


def request(method: str, path: str) -> dict[str, Any]:
    response = client.request(method, path)

    if response.status_code != 200:
        raise SystemExit(f"{method} {path} returned HTTP {response.status_code}: {response.text}")

    data = response.json()

    if not isinstance(data, dict):
        raise SystemExit(f"{method} {path} did not return JSON object")

    return data


def main() -> None:
    expectations = [
        ("GET", "/api/health", {"ok", "service", "status", "updatedAt", "legacyConfigured"}),
        ("GET", "/api/opportunities", {"ok", "source", "updatedAt", "rows", "error"}),
        ("GET", "/api/events/realtime", {"ok", "source", "updatedAt", "events", "error"}),
        ("GET", "/api/engine/status", {"ok", "state"}),
        ("POST", "/api/engine/start", {"ok", "state"}),
        ("POST", "/api/engine/stop", {"ok", "state"}),
        ("POST", "/api/engine/reset", {"ok", "state"}),
        ("GET", "/api/limit-pool", {"ok", "source", "updatedAt", "rows", "error"}),
        ("GET", "/api/speed-rank", {"ok", "source", "updatedAt", "rows", "error"}),
        ("GET", "/api/boards", {"ok", "source", "updatedAt", "rows", "error"}),
    ]

    for method, path, keys in expectations:
        data = request(method, path)
        assert_keys(data, keys, path)

    print("API contract smoke tests passed.")


if __name__ == "__main__":
    main()
