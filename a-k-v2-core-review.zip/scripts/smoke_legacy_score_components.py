"""
Smoke test: legacy scoring components (copied pure functions).
Tests each component module in isolation with fake input data.
No old project, no old DB, no network.

Verifies:
- technical: fake daily_bars -> score computed
- technical: insufficient bars -> partial_missing_daily_bars
- volume: fake quote_window -> ready or warming
- volume: no samples -> warming
- board: no board_summary -> partial
- sentiment: no board_scores -> partial
"""

from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.scoring.legacy_technical import compute_technical_score
from app.scoring.legacy_volume import compute_volume_score
from app.scoring.legacy_board import compute_board_score
from app.scoring.legacy_sentiment import compute_sentiment_score
from app.scoring.legacy_score_composer import compose_score


def _make_bars(days: int = 800) -> list[dict]:
    """Generate fake daily bars covering > 365 calendar days."""
    bars = []
    base_date = datetime(2026, 5, 1)
    price = 12.0
    for i in range(days):
        d = base_date - timedelta(days=i)
        if d.weekday() >= 5:
            continue  # skip weekends
        price *= (1 + (i % 7 - 3) / 200)  # oscillating price
        bars.append({
            "日期": d.strftime("%Y-%m-%d"),
            "开盘": round(price * 0.99, 2),
            "收盘": round(price, 2),
            "最高": round(price * 1.03, 2),
            "最低": round(price * 0.97, 2),
            "成交额": round(price * 1_000_000, 0),
            "涨跌幅": round((i % 7 - 3) / 100, 4),
            "成交量": int(price * 100_000),
            "换手率": round(2 + (i % 10) * 0.3, 2),
        })
    bars.reverse()
    return bars


def _make_quote_window(count: int = 10) -> list[dict]:
    now = datetime.now().timestamp()
    return [
        {"timestamp": now - (count - i) * 2, "price": 12.5 + i * 0.05, "change_pct": -0.2 + i * 0.15,
         "amount": 5_000_000 + i * 500_000, "volume": 400_000 + i * 50_000,
         "bid_vol1": 100_000, "ask_vol1": 80_000}
        for i in range(count)
    ]


def test_technical_success() -> None:
    bars = _make_bars(260)
    result = compute_technical_score(code="000001", current_price=12.5, daily_bars=bars)
    assert result["status"] == "ready", f"status={result['status']}"
    assert result["score"] is not None, "score should not be None"
    assert result["technical_score"] is not None
    assert isinstance(result["technical_score"], dict)
    print(f"  technical success: score={result['score']} style={result['technical_score'].get('style')}")


def test_technical_insufficient_bars() -> None:
    bars = _make_bars(5)
    result = compute_technical_score(code="000001", current_price=12.5, daily_bars=bars)
    assert result["status"] == "partial_missing_daily_bars", f"status={result['status']}"
    assert result["score"] is None
    print(f"  technical insufficient bars: {result['status']}")


def test_technical_no_bars() -> None:
    result = compute_technical_score(code="000001", current_price=12.5, daily_bars=None)
    assert "partial_missing" in result["status"]
    assert result["score"] is None
    print(f"  technical no bars: {result['status']}")


def test_volume_success() -> None:
    window = _make_quote_window(10)
    result = compute_volume_score(
        code="000001", quote_window=window, latest_quote=window[-1],
        stock_meta={"float_share": 500_000_000, "float_market_value": 6_000_000_000},
        technical_metrics={"amount_ratio20": 1.5, "amount_std20": 45},
    )
    print(f"  volume success: status={result['status']} total={result['total']}")


def test_volume_warming() -> None:
    window = _make_quote_window(1)  # only 1 sample
    result = compute_volume_score(
        code="000001", quote_window=window, latest_quote=window[-1] if window else None,
        stock_meta={"float_share": 500_000_000},
    )
    assert result["status"] == "warming", f"status={result['status']}"
    assert result["total"] is None
    print(f"  volume warming: {result['status']}")


def test_board_partial() -> None:
    result = compute_board_score(code="000001", change_pct=5.0, board_summary=None, board_members=None, fund_flow=None, intraday_quality=None, strategy=None, stock_meta=None)
    assert "partial" in result["status"], f"status={result['status']}"
    assert result["score"] is None
    print(f"  board partial: {result['status']}")


def test_sentiment_partial() -> None:
    result = compute_sentiment_score(code="000001", board_scores=None)
    assert "partial" in result["status"], f"status={result['status']}"
    assert result["total"] is None
    print(f"  sentiment partial: {result['status']}")


def test_composer_partial() -> None:
    # Only technical ready, others missing -> partial
    tech = {"status": "ready", "score": 82, "technical_score": {"total": 82, "style": "flat_breakout", "level": "pass"}}
    composed = compose_score(code="000001", trading_date="2026-05-09", technical_result=tech, volume_result={"status": "missing", "total": None}, board_result=None, sentiment_result=None)
    assert composed["status"] == "partial", f"status={composed['status']}"
    assert composed["passed"] is False, "passed should be False when partial"
    assert composed["technical_score"] == 82.0
    assert composed["sentiment_score"] is None
    assert composed["volume_score"] is None
    assert "missing" in (composed.get("reject_reason") or "")
    import json
    sj = json.loads(composed["score_json"])
    assert sj["scoring_mode"] == "legacy_full"
    assert sj["is_full_legacy_score"] is False
    print(f"  composer partial: status={composed['status']} technical={composed['technical_score']}")


def test_composer_full() -> None:
    # All components ready -> ready
    tech = {"status": "ready", "score": 82, "technical_score": {"total": 82}}
    vol = {"status": "ready", "total": 75}
    board = {"status": "ready", "score": 80}
    sent = {"status": "ready", "total": 85}
    composed = compose_score(code="000001", trading_date="2026-05-09", technical_result=tech, volume_result=vol, board_result=board, sentiment_result=sent)
    assert composed["status"] == "ready"
    assert composed["passed"] is True
    import json
    sj = json.loads(composed["score_json"])
    assert sj["is_full_legacy_score"] is True
    print(f"  composer full: status={composed['status']} score={composed['score']}")


def main() -> None:
    print("=== technical ===")
    test_technical_success()
    test_technical_insufficient_bars()
    test_technical_no_bars()

    print("\n=== volume ===")
    test_volume_success()
    test_volume_warming()

    print("\n=== board ===")
    test_board_partial()

    print("\n=== sentiment ===")
    test_sentiment_partial()

    print("\n=== composer ===")
    test_composer_partial()
    test_composer_full()

    print("\nLegacy score components smoke test OK")


if __name__ == "__main__":
    main()
