"""
Smoke test: LegacyScoringFacadeExecutor with fake old DailyHistoryProvider.

Does NOT access real old project, real old DB, or external network.
Uses a temp fake old project tree with a minimal DailyHistoryProvider stub.

Verifies:
- Success path: technical_score from fake provider, status=partial, passed=False
- Failure path: fake provider raises RuntimeError, status=failed
- No lifecycle side effects (monitoring_stock_states, transitions)
"""

from __future__ import annotations

import sys
import tempfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db
from app.db.models import (
    LimitPoolRow,
    MonitoringStateTransition,
    MonitoringStockState,
    ScoreSnapshot,
    ScoreTaskCurrent,
)
from app.services.legacy_scoring_facade_executor import LegacyScoringFacadeExecutor
from app.services.limit_pool_ingestion_service import (
    LimitPoolIngestionService,
    LimitPoolInputRow,
    LimitPoolInputSnapshot,
)
from app.services.score_task_service import ScoreTaskService
from app.services.score_worker_service import ScoreWorkerService
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker


FAKE_DAILY_HISTORY_PROVIDER = """
from __future__ import annotations

import json
import sys


class DailyHistoryProvider:
    name = "fake_history"

    def __init__(self, db_path: str = "data/astock_guard.db"):
        self.db_path = db_path

    def get_kline_score(self, code, start="20250101", end="20500101",
                        current_price=None, cached_only=False):
        return {
            "status": "ready",
            "score": 82,
            "legacy_score": 78,
            "score_delta": -8,
            "technical_score": {
                "total": 82,
                "style": "flat_breakout",
                "style_label": "平铺爆发",
                "level": "pass",
                "flat_breakout": 72,
                "trend_acceleration": 60,
            },
            "current_price": current_price or 10.5,
            "last_trade_date": "2026-05-09",
            "message": "技术评分 82 分，平铺爆发",
            "factors": [
                {"name": "历史高点压力", "score_delta": -4, "message": "fake factor"}
            ],
        }
"""


FAILING_DAILY_HISTORY_PROVIDER = """
from __future__ import annotations


class DailyHistoryProvider:
    name = "fake_failing_history"

    def __init__(self, db_path: str = "data/astock_guard.db"):
        pass

    def get_kline_score(self, code, start="20250101", end="20500101",
                        current_price=None, cached_only=False):
        raise RuntimeError("mock kline scoring failure")
"""


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def _build_fake_old_project(fake_root: Path, provider_source: str) -> Path:
    """Create a fake old project tree under fake_root that looks like
    old_project/astock_guard/providers/history.py with the given provider_source."""
    pkg = fake_root / "astock_guard" / "providers"
    pkg.mkdir(parents=True)
    (fake_root / "astock_guard" / "__init__.py").write_text("")
    (fake_root / "astock_guard" / "providers" / "__init__.py").write_text("")
    (fake_root / "astock_guard" / "providers" / "history.py").write_text(provider_source)
    return fake_root


def test_success_path(base_dir: Path) -> None:
    """Success: LegacyScoringFacadeExecutor via fake old DailyHistoryProvider."""
    fake_old = _build_fake_old_project(base_dir / "fake_old_success", FAKE_DAILY_HISTORY_PROVIDER)

    db_path = base_dir / "success.db"
    engine = create_engine(f"sqlite:///{db_path}", future=True)
    init_db(engine)
    Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

    now = datetime.utcnow()
    base_date = "2026-05-09"

    with Session() as session:
        ingestion = LimitPoolIngestionService(session)
        ingestion.ingest_snapshot(LimitPoolInputSnapshot(
            trading_date=base_date, source_trading_date=base_date,
            source="fake", primary_source="fake",
            as_of=now, seq=1, freshness_status="fresh", market_session="trading",
            rows=[LimitPoolInputRow(pool="limit_up", code="000001", name="平安银行",
                   source="fake", price=10.5, change_pct=10.01,
                   first_limit_time="10:01:00")],
        ))
        session.flush()

        row = list(session.execute(select(LimitPoolRow)).scalars())[0]
        ScoreTaskService(session).schedule_for_limit_pool_row(row)
        session.commit()

    with Session() as session:
        executor = LegacyScoringFacadeExecutor(
            old_project_root=str(fake_old),
            old_python=sys.executable,
            old_db_path=str(db_path),
        )
        worker = ScoreWorkerService(session, executor=executor)
        result = worker.process_pending(trading_date=base_date, limit=100)

        assert result.processed == 1, f"processed={result.processed}"
        assert result.ready == 1, f"ready={result.ready}"
        assert result.failed == 0, f"failed={result.failed}"

        tasks = list(session.execute(select(ScoreTaskCurrent)).scalars())
        assert len(tasks) == 1
        assert tasks[0].status == "ready", f"status={tasks[0].status}"

        snaps = list(session.execute(select(ScoreSnapshot)).scalars())
        assert len(snaps) == 1, f"snapshots={len(snaps)}"
        snap = snaps[0]

        assert snap.status == "partial", f"status={snap.status}"
        assert snap.passed is False, f"passed={snap.passed}"
        assert snap.technical_score == 82.0, f"technical_score={snap.technical_score}"
        assert snap.sentiment_score is None
        assert snap.volume_score is None
        assert snap.main_logic == "legacy_component_facade"

        import json
        sj = json.loads(snap.score_json)
        assert sj["scoring_mode"] == "legacy_component", f"scoring_mode={sj.get('scoring_mode')}"
        assert sj["is_full_legacy_score"] is False, f"is_full_legacy_score={sj.get('is_full_legacy_score')}"
        assert "volume" in sj.get("missing_components", [])
        assert "board" in sj.get("missing_components", [])
        assert "sentiment" in sj.get("missing_components", [])
        assert "fund_flow" in sj.get("missing_components", [])

        assert snap.reject_reason is not None
        assert "partial_components_missing" in snap.reject_reason

        assert count_(session, MonitoringStockState) == 0, "should write no stock states"
        assert count_(session, MonitoringStateTransition) == 0, "should write no transitions"

        print("  success path: PASS")
        print(f"    score_snapshot: status={snap.status} passed={snap.passed} technical_score={snap.technical_score}")
        print(f"    reject_reason: {snap.reject_reason}")
        print(f"    scoring_mode: {sj['scoring_mode']} is_full={sj['is_full_legacy_score']}")
        print(f"    missing_components: {sj['missing_components']}")

        session.commit()


def test_failure_path(base_dir: Path) -> None:
    """Failure: fake DailyHistoryProvider raises RuntimeError."""
    fake_old = _build_fake_old_project(base_dir / "fake_old_fail", FAILING_DAILY_HISTORY_PROVIDER)

    db_path = base_dir / "fail.db"
    engine = create_engine(f"sqlite:///{db_path}", future=True)
    init_db(engine)
    Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

    now = datetime.utcnow()
    fail_date = "2026-05-10"

    with Session() as session:
        ingestion = LimitPoolIngestionService(session)
        ingestion.ingest_snapshot(LimitPoolInputSnapshot(
            trading_date=fail_date, source_trading_date=fail_date,
            source="fake", primary_source="fake",
            as_of=now, seq=2, freshness_status="fresh", market_session="trading",
            rows=[LimitPoolInputRow(pool="limit_up", code="000002", name="fail_test",
                   source="fake", price=12.0, change_pct=10.0,
                   first_limit_time="11:00:00")],
        ))
        session.flush()

        row2 = list(session.execute(select(LimitPoolRow).where(LimitPoolRow.code == "000002")).scalars())[0]
        ScoreTaskService(session).schedule_for_limit_pool_row(row2)
        session.commit()

    with Session() as session:
        executor = LegacyScoringFacadeExecutor(
            old_project_root=str(fake_old),
            old_python=sys.executable,
            old_db_path=str(db_path),
        )
        worker = ScoreWorkerService(session, executor=executor)
        result = worker.process_pending(trading_date=fail_date, limit=100)

        assert result.processed == 1, f"processed={result.processed}"
        assert result.ready == 1, f"ready={result.ready} (executor didn't throw, task is 'ready')"
        assert result.failed == 0, f"failed={result.failed}"

        snaps = list(
            session.execute(
                select(ScoreSnapshot).where(ScoreSnapshot.trading_date == fail_date)
            ).scalars()
        )
        assert len(snaps) == 1, f"snapshots={len(snaps)}"
        snap = snaps[0]

        assert snap.status == "failed", f"status={snap.status}"
        assert snap.technical_score is None, f"technical_score={snap.technical_score}"
        assert snap.passed is False, f"passed={snap.passed}"
        assert snap.reject_reason is not None
        assert "kline_failed" in snap.reject_reason, f"reject_reason={snap.reject_reason}"

        print("  failure path: PASS")
        print(f"    snapshot status={snap.status} technical_score={snap.technical_score} passed={snap.passed}")
        print(f"    reject_reason: {snap.reject_reason}")

        session.commit()


def main() -> None:
    import tempfile
    base_dir = Path(tempfile.mkdtemp(prefix="legacy_facade_smoke_"))
    print(f"Temp base: {base_dir}")
    test_success_path(base_dir)
    test_failure_path(base_dir)
    print("\nLegacy scoring facade smoke test OK")


if __name__ == "__main__":
    main()
