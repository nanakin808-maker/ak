"""
Smoke test: RealtimeDevScanRunner with monkeypatched sources.
No external network. No old project.

Verifies:
- speed_rank → PRE_CANDIDATE
- quote → price/change_pct update, no CORE
- limit_pool → rows ingested
- score_tasks → partial snapshots
- No CORE transitions
"""

from __future__ import annotations

import sys
import tempfile
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.models import MonitoringStockState, MonitoringStateTransition, ScoreSnapshot
from app.runtime.realtime_dev_scan import RealtimeDevScanRunner
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker


def _mock_speed_rank() -> list[dict]:
    return [
        {"code": "002885", "name": "京泉华", "price": 18.5, "change_pct": 9.5, "speed_pct": 2.1, "source": "mock_sr"},
        {"code": "605369", "name": "N/A", "price": 12.0, "change_pct": 2.0, "speed_pct": 0.5, "source": "mock_sr"},
    ]


def _mock_quote_batch(codes: list[str]) -> list[dict]:
    if not codes:
        return []
    return [{"code": c, "price": 18.6, "change_pct": 9.8, "bid1": 18.6, "bid_vol1": 5000,
             "ask1": 0.0, "ask_vol1": 0, "limit_up": 18.5, "source": "mock"} for c in codes]


def _mock_limit_pool() -> list[dict]:
    return [
        {"code": "002885", "name": "京泉华", "pool": "limit_up", "price": 18.5, "change_pct": 10.01,
         "first_limit_time": "09:35:00", "open_count": 0, "seal_amount": 5000000, "industry": "电子", "source": "mock"},
        {"code": "000001", "name": "平安银行", "pool": "limit_up", "price": 11.3, "change_pct": 10.0,
         "first_limit_time": "10:00:00", "open_count": 0, "seal_amount": None, "industry": "银行", "source": "mock"},
    ]


def main() -> None:
    base_dir = Path(tempfile.mkdtemp(prefix="realtime_dev_"))
    db_path = base_dir / "test_realtime.db"
    td = "20260509"

    class FakeScoringExecutor:
        def execute(self, task):
            from app.services.score_worker_service import ScoreExecutionResult
            import json
            return ScoreExecutionResult(
                score=70.0, technical_score=70.0, sentiment_score=None,
                volume_score=None, passed=False, status="partial",
                reject_reason="smoke_test:partial",
                main_logic="legacy_component_facade",
                score_json=json.dumps({"scoring_mode": "legacy_full", "is_full_legacy_score": False}),
                input_refs_json=task.input_refs_json,
            )

    runner = RealtimeDevScanRunner(
        db_path=str(db_path),
        trading_date=td,
        scoring_executor=FakeScoringExecutor(),
    )

    # Monkeypatch at both source and consumer modules
    import app.sources.scan_fetchers as sf
    import app.sources.eastmoney_shortline as sl
    orig_sr = sf._fetch_speed_rank
    orig_lp = sf._fetch_limit_pool
    orig_qt = sf._fetch_quote_via_tencent
    orig_sl = sl.fetch_shortline_events
    sf._fetch_speed_rank = _mock_speed_rank
    sf._fetch_limit_pool = _mock_limit_pool
    sf._fetch_quote_via_tencent = _mock_quote_batch
    sl.fetch_shortline_events = lambda: []

    # Also patch at the consumer module's namespace
    import app.runtime.realtime_dev_scan as rds
    rds._fetch_speed_rank = _mock_speed_rank
    rds._fetch_limit_pool = _mock_limit_pool
    rds._fetch_quote_via_tencent = _mock_quote_batch

    try:
        summary = runner.run_once()
    finally:
        sf._fetch_speed_rank = orig_sr
        sf._fetch_limit_pool = orig_lp
        sf._fetch_quote_via_tencent = orig_qt
        sl.fetch_shortline_events = orig_sl

    # Asserts
    assert summary["speed_rank"] == 2, f"speed_rank={summary['speed_rank']}"
    assert summary["pre_candidate"] >= 1, f"pre_candidate={summary['pre_candidate']}"
    assert summary["limit_pool"] == 2, f"limit_pool={summary['limit_pool']}"
    assert summary["score_processed"] >= 1, f"processed={summary['score_processed']}"
    assert summary["core_states"] == 0, f"core_states={summary['core_states']}"
    assert summary["core_transitions"] == 0, f"core_transitions={summary['core_transitions']}"
    assert len(summary.get("errors", [])) == 0, f"errors={summary['errors']}"

    # Verify DB directly
    engine = create_engine(f"sqlite:///{db_path}", future=True)
    Session = sessionmaker(bind=engine)
    with Session() as s:
        states = list(s.execute(select(MonitoringStockState)).scalars())
        print(f"  monitoring_stock_states: {len(states)}")
        for st in states:
            print(f"    {st.code} {st.name} stage={st.stage} active={st.active_monitoring}")
            assert st.stage != "CORE", f"CORE found: {st.code}"
        transitions = list(s.execute(select(MonitoringStateTransition)).scalars())
        print(f"  transitions: {len(transitions)} — CORE=0 confirmed")
        snaps = list(s.execute(select(ScoreSnapshot)).scalars())
        print(f"  score_snapshots: {len(snaps)}")
        for sn in snaps:
            print(f"    {sn.code} stage={sn.score_stage} status={sn.status} passed={sn.passed} technical={sn.technical_score}")
            if sn.score_stage == "limit_pool_first_score":
                assert sn.passed is False, f"passed=True on {sn.code}"
                import json
                sj = json.loads(sn.score_json)
                assert sj["scoring_mode"] == "legacy_full"
                assert sj["is_full_legacy_score"] is False

    print("\nRealtime dev scan smoke test OK")


if __name__ == "__main__":
    main()
