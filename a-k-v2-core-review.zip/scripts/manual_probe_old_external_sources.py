"""
Manual probe script: probes the old system for external source providers.

This script is NOT part of verify_v2_stack.py because it depends on
the old system's code at ../a-k and its dependencies.

Usage:
  cd ~/Documents/Codex/2026-04-26/a-k-v2
  uv run --directory backend python3 scripts/manual_probe_old_external_sources.py
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
OLD_ROOT = ROOT.parent / "a-k"
sys.path.insert(0, str(BACKEND))

from app.services.external_source_registry import ExternalSourceRegistry, probe_legacy_sources  # noqa: E402


def main() -> None:
    if not OLD_ROOT.exists():
        print(f"Old project root not found: {OLD_ROOT}")
        print("Manual old external source probe skipped.")
        sys.exit(0)

    if not (OLD_ROOT / "astock_guard").exists():
        print(f"astock_guard module not found in {OLD_ROOT}")
        print("Manual old external source probe skipped.")
        sys.exit(0)

    reg = ExternalSourceRegistry()
    results = probe_legacy_sources(old_project_root=str(OLD_ROOT), registry=reg)

    print("External source probe:")
    for r in results:
        if r.callable_found:
            status = "OK"
        elif r.import_ok:
            status = "IMPORT_OK_NO_CALLABLE"
        else:
            status = "IMPORT_FAILED"
        print(f"  {r.key:30s} {status:25s} module={r.found_module or '-'} callable={r.found_callable or '-'}")
        if r.error:
            print(f"  {'':30s} error={r.error[:120]}")

    found_count = sum(1 for r in results if r.callable_found)
    print(f"\nManual old external source probe: {found_count}/{len(results)} callables found.")
    print("Manual old external source probe OK")


if __name__ == "__main__":
    main()
