from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import (  # noqa: E402
    LimitPoolRow,
    LimitPoolSnapshot,
    MonitoringStateTransition,
    MonitoringStockState,
    ScoreSnapshot,
)
from app.domain.time_scope import MarketSession  # noqa: E402
from app.repositories import MonitoringRepository  # noqa: E402
from app.runtime import RuntimeState  # noqa: E402
from app.runtime.monitoring_engine import MonitoringEngine  # noqa: E402
from app.services.market_source_adapter_service import MarketSourceAdapterService  # noqa: E402
from app.services.provider_bridge_service import ProviderFetchResult  # noqa: E402


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "market_source_adapter.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()
        base_date = "2026-05-09"

        # ============================================================
        # A + B: speed_rank mock -> PRE_CANDIDATE, then duplicate block
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            adapter = MarketSourceAdapterService(session, runtime)

            result_a = adapter.ingest_event_source(
                source_type="speed_rank",
                provider_name="mock_speed_rank",
                requested_trading_date=base_date,
                as_of=now, seq_start=1,
                fetcher=lambda: ProviderFetchResult(
                    data={"rows": [{
                        "code": "002885", "name": "京泉华", "event_type": "RAPID_RISE",
                        "event_title": "快速拉升", "change_pct": 7.326, "price": 20.0,
                    }]},
                    source_trading_date=base_date,
                    source_updated_at=now,
                ),
                market_session=MarketSession.TRADING,
            )
            session.commit()

            assert result_a.processed == 1, f"A: expected 1, got {result_a.processed}"
            assert result_a.provider_ok is True
            assert result_a.actions == ["enter_pre_candidate"], f"A: {result_a.actions}"
            state_a = runtime.get_stock_state(base_date, "002885")
            assert state_a is not None and state_a.stage == "PRE_CANDIDATE"

            # duplicate via shortline -> ignored_existing_active_state
            result_b = adapter.ingest_event_source(
                source_type="shortline", provider_name="mock_shortline",
                requested_trading_date=base_date,
                as_of=now, seq_start=10,
                fetcher=lambda: ProviderFetchResult(
                    data={"rows": [{
                        "code": "002885", "name": "京泉华", "event_type": "SHORTLINE",
                        "event_title": "快速拉升", "change_pct": 7.5, "price": 21.0,
                    }]},
                    source_trading_date=base_date,
                    source_updated_at=now,
                ),
            )
            session.commit()

            state_b = runtime.get_stock_state(base_date, "002885")
            assert state_b is not None and state_b.stage == "PRE_CANDIDATE"

        # ============================================================
        # C: promote -> quote_batch -> CANDIDATE -> CORE
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            engine = MonitoringEngine(session, runtime)
            adapter = MarketSourceAdapterService(session, runtime, engine)

            # promote to CANDIDATE
            engine.promote_pre_candidate(
                trading_date=base_date, source_trading_date=base_date,
                code="002885", name="京泉华",
                as_of=now - timedelta(minutes=10), seq=20,
                freshness_status="fresh", price=22.0, change_pct=8.0,
            )
            session.flush()

            # quote_batch not sealed
            r_c1 = adapter.ingest_quote_batch(
                provider_name="mock_quote",
                requested_trading_date=base_date,
                as_of=now - timedelta(minutes=5), seq_start=21,
                fetcher=lambda: ProviderFetchResult(
                    data={"rows": [{
                        "code": "002885", "name": "京泉华",
                        "price": 23.0, "change_pct": 9.0,
                        "is_sealed": False, "at_limit": False,
                    }]},
                    source_trading_date=base_date, source_updated_at=now,
                ),
            )
            session.flush()
            assert r_c1.processed == 1
            assert "update_candidate_quote" in r_c1.actions, f"C1: {r_c1.actions}"
            assert runtime.get_stock_state(base_date, "002885").stage == "CANDIDATE"

            # quote_batch sealed -> promote_core
            r_c2 = adapter.ingest_quote_batch(
                provider_name="mock_quote",
                requested_trading_date=base_date,
                as_of=now, seq_start=22,
                fetcher=lambda: ProviderFetchResult(
                    data={"rows": [{
                        "code": "002885", "name": "京泉华",
                        "price": 25.0, "change_pct": 10.0,
                        "is_sealed": True, "at_limit": True,
                    }]},
                    source_trading_date=base_date, source_updated_at=now,
                ),
            )
            session.commit()
            assert r_c2.processed == 1
            assert "promote_core" in r_c2.actions, f"C2: {r_c2.actions}"
            assert runtime.get_stock_state(base_date, "002885").stage == "CORE"

        # ============================================================
        # D: quote_batch mismatch -> ignored
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            engine = MonitoringEngine(session, runtime)
            adapter = MarketSourceAdapterService(session, runtime, engine)
            monitoring = engine.monitoring

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600001", name="test mismatch", stage="PRE_CANDIDATE",
                price=14.0, change_pct=5.0,
                as_of=now - timedelta(hours=2), seq=29,
                freshness_status="fresh", active_monitoring=True,
            )
            session.flush()
            engine.candidates.promote_pre_to_candidate(
                trading_date=base_date, source_trading_date=base_date,
                code="600001", name="test mismatch",
                as_of=now - timedelta(hours=1), seq=30,
                freshness_status="fresh",
            )
            session.flush()

            r_d = adapter.ingest_quote_batch(
                provider_name="mock_quote",
                requested_trading_date=base_date,
                as_of=now, seq_start=31,
                fetcher=lambda: ProviderFetchResult(
                    data={"rows": [{
                        "code": "600001", "name": "test mismatch",
                        "price": 15.0, "change_pct": 10.0,
                        "is_sealed": True, "at_limit": True,
                    }]},
                    source_trading_date="2026-05-08",
                ),
            )
            session.commit()
            assert r_d.processed == 1
            assert r_d.freshness_status == "mismatch", f"D: {r_d.freshness_status}"
            # action should be ignored since freshness blocks it
            state_d = runtime.get_stock_state(base_date, "600001")
            assert state_d is not None and state_d.stage == "CANDIDATE"

        # ============================================================
        # E: limit_pool mock via adapter -> source tables only
        # ============================================================
        class MockLimitPoolFetcher:
            def fetch(self, *, requested_trading_date: str) -> ProviderFetchResult:
                return ProviderFetchResult(
                    data={"rows": [
                        {"pool": "limit_up", "code": "000001", "name": "平安银行",
                         "source": "mock", "price": 10.5, "change_pct": 10.01},
                    ]},
                    source_trading_date=base_date, source_updated_at=now,
                )

        with Session() as session:
            runtime = RuntimeState()
            adapter = MarketSourceAdapterService(session, runtime)

            score_before = count_(session, ScoreSnapshot)
            lp_snap_before = count_(session, LimitPoolSnapshot)
            trans_before = count_(session, MonitoringStateTransition)

            result_e = adapter.ingest_limit_pool(
                requested_trading_date=base_date,
                as_of=now, seq=40,
                fetcher=MockLimitPoolFetcher(),
                market_session=MarketSession.TRADING,
                primary_source="mock_test",
            )
            session.commit()

            assert result_e.provider_ok is True
            assert result_e.row_count == 1
            assert count_(session, LimitPoolSnapshot) == lp_snap_before + 1
            assert count_(session, LimitPoolRow) >= 1
            assert count_(session, ScoreSnapshot) == score_before, "E: limit_pool must not write score snapshots"
            assert count_(session, MonitoringStateTransition) == trans_before, "E: limit_pool must not add lifecycle transitions"

    print("Market source adapter smoke test OK")


if __name__ == "__main__":
    main()
