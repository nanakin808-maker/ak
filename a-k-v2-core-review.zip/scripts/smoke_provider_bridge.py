from __future__ import annotations

import json
import sys
import time
from datetime import datetime
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import InterfaceHealth  # noqa: E402
from app.domain.time_scope import MarketSession  # noqa: E402
from app.services.provider_bridge_service import (  # noqa: E402
    ProviderBridgeService,
    ProviderFetchResult,
)


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "provider_bridge.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()

        # === A: fresh successful call ===
        with Session() as session:
            bridge = ProviderBridgeService(session)
            call_count: list[int] = []

            def fresh_fetcher() -> ProviderFetchResult:
                call_count.append(1)
                return ProviderFetchResult(
                    data={"rows": [1, 2]},
                    source_trading_date="2026-05-09",
                    source_updated_at=now,
                    detail={"mock": True},
                )

            result = bridge.call(
                name="mock_board_api",
                category="stock_boards",
                requested_trading_date="2026-05-09",
                fetcher=fresh_fetcher,
            )
            session.commit()

            assert result.ok is True, f"A: expected ok=True, got {result.ok}"
            assert result.freshness_status == "fresh", f"A: expected fresh, got {result.freshness_status}"
            assert result.from_cache is False
            assert result.data is not None and result.data["rows"] == [1, 2]
            assert result.source_trading_date == "2026-05-09"

            health_rows = list(session.execute(select(InterfaceHealth)).scalars())
            ok_records = [h for h in health_rows if h.ok]
            assert len(ok_records) >= 1, "A: expected at least 1 ok health record"

        # === B: cache hit ===
        with Session() as session:
            bridge = ProviderBridgeService(session)

            # first call (cache miss, ttl=30)
            r1 = bridge.call(
                name="mock_board_api",
                category="stock_boards",
                requested_trading_date="2026-05-09",
                fetcher=lambda: ProviderFetchResult(data={"rows": [1, 2]}, source_trading_date="2026-05-09"),
                cache_key="board_000001",
                ttl_seconds=30,
            )
            session.commit()
            assert r1.from_cache is False

            # second call (cache hit)
            r2 = bridge.call(
                name="mock_board_api",
                category="stock_boards",
                requested_trading_date="2026-05-09",
                fetcher=lambda: ProviderFetchResult(data={"rows": [3, 4]}, source_trading_date="2026-05-09"),
                cache_key="board_000001",
                ttl_seconds=30,
            )
            session.commit()
            assert r2.from_cache is True, f"B: expected from_cache=True, got {r2.from_cache}"
            # data should be the cached data, not the second fetcher's data
            assert r2.data is not None and r2.data["rows"] == [1, 2]

        # === C: mismatch successful call ===
        with Session() as session:
            bridge = ProviderBridgeService(session)

            def mismatch_fetcher() -> ProviderFetchResult:
                return ProviderFetchResult(
                    data={"rows": [5, 6]},
                    source_trading_date="2026-05-09",
                )

            result_c = bridge.call(
                name="mock_board_api",
                category="stock_boards",
                requested_trading_date="2026-05-10",
                fetcher=mismatch_fetcher,
            )
            session.commit()

            assert result_c.ok is True, f"C: expected ok=True, got {result_c.ok}"
            assert result_c.freshness_status == "mismatch", f"C: expected mismatch, got {result_c.freshness_status}"
            assert result_c.data is not None

        # === D: provider exception ===
        with Session() as session:
            bridge = ProviderBridgeService(session)

            def failing_fetcher() -> ProviderFetchResult:
                raise RuntimeError("mock provider failed")

            result_d = bridge.call(
                name="failing_api",
                category="fund_flow",
                requested_trading_date="2026-05-09",
                fetcher=failing_fetcher,
            )
            session.commit()

            assert result_d.ok is False, f"D: expected ok=False, got {result_d.ok}"
            assert result_d.data is None
            assert result_d.error is not None and "mock provider failed" in result_d.error

            health_rows = list(session.execute(select(InterfaceHealth)).scalars())
            fail_records = [h for h in health_rows if not h.ok]
            fail_with_error = [h for h in fail_records if "mock provider failed" in (h.error or "")]
            assert len(fail_with_error) >= 1, "D: expected fail record with error"

        # === E: soft timeout / slow ===
        with Session() as session:
            bridge = ProviderBridgeService(session)

            def slow_fetcher() -> ProviderFetchResult:
                time.sleep(0.02)
                return ProviderFetchResult(data={"slow": True}, source_trading_date="2026-05-09")

            result_e = bridge.call(
                name="slow_api",
                category="history_kline",
                requested_trading_date="2026-05-09",
                fetcher=slow_fetcher,
                timeout_ms=1.0,
            )
            session.commit()

            assert result_e.ok is True, f"E: expected ok=True, got {result_e.ok}"
            assert result_e.detail is not None
            assert result_e.detail.get("slow") is True, f"E: expected slow=True, got {result_e.detail}"

            health_rows = list(session.execute(select(InterfaceHealth)).scalars())
            slow_health = [h for h in health_rows if h.name == "slow_api"]
            assert len(slow_health) >= 1
            health_detail = json.loads(slow_health[0].detail_json)
            assert health_detail.get("slow") is True, f"E: health detail slow flag missing: {health_detail}"

    print("Provider bridge smoke test OK")


if __name__ == "__main__":
    main()
