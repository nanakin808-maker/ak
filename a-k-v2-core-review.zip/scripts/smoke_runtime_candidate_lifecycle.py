from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import MonitoringStateTransition  # noqa: E402
from app.domain.time_scope import MarketSession  # noqa: E402
from app.repositories import MonitoringRepository, ScoreSnapshotRepository  # noqa: E402
from app.runtime import (  # noqa: E402
    CandidateEntryInput,
    CandidateLifecycleService,
    CandidateQuoteInput,
    EventProcessor,
    RuntimeInputEvent,
    RuntimeState,
)


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "cand_lifecycle.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()
        base_date = "2026-05-06"

        # ============================================================
        # 场景 A：候选弱势移除
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            candidate_at = now - timedelta(minutes=45)
            # 先写入 CANDIDATE 状态
            monitoring.upsert_stock_state(
                trading_date=base_date,
                source_trading_date=base_date,
                code="002885",
                name="京泉华",
                stage="CANDIDATE",
                price=33.55,
                change_pct=7.326,
                as_of=candidate_at,
                seq=1,
                freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()
            ss = monitoring.get_stock_state(base_date, "002885")
            assert ss is not None, "A: could not read back stock state after upsert"
            ss.candidate_at = candidate_at
            session.flush()

            # 调用 stale check，as_of 距 candidate_at > 30 min，change_pct 低于阈值
            result = lifecycle.drop_stale_candidate(
                CandidateQuoteInput(
                    trading_date=base_date,
                    source_trading_date=base_date,
                    code="002885",
                    name="京泉华",
                    as_of=now,
                    seq=2,
                    freshness_status="fresh",
                    price=32.0,
                    change_pct=2.0,
                    technical_score=65.0,
                    sentiment_score=53.0,
                    volume_score=63.0,
                ),
                candidate_stale_minutes=30.0,
                candidate_min_active_pct=5.0,
            )
            session.commit()

            # 验证
            assert result.action == "candidate_removed", (
                f"A: expected candidate_removed, got {result.action}"
            )
            assert result.stage == "PRE_CANDIDATE"
            assert result.event_id is not None
            assert result.transition_id is not None
            assert result.score_snapshot_id is not None

            # monitoring_events 有 CANDIDATE_REMOVED
            events = monitoring.list_events_since(base_date, since_seq=0)
            candidate_removed_events = [e for e in events if e.event_type == "CANDIDATE_REMOVED"]
            assert len(candidate_removed_events) >= 1

            # state -> PRE_CANDIDATE, active_monitoring=False
            state = monitoring.get_stock_state(base_date, "002885")
            assert state is not None
            assert state.stage == "PRE_CANDIDATE"
            assert state.active_monitoring is False
            assert state.inactive_reason == "candidate_weak_removed"

            # transition CANDIDATE -> PRE_CANDIDATE
            transitions = list(
                session.execute(
                    select(MonitoringStateTransition).where(
                        MonitoringStateTransition.trading_date == base_date,
                        MonitoringStateTransition.code == "002885",
                        MonitoringStateTransition.to_stage == "PRE_CANDIDATE",
                    )
                ).scalars()
            )
            assert len(transitions) >= 1
            assert transitions[0].from_stage == "CANDIDATE"
            assert transitions[0].reason == "candidate_weak_removed"

            # score_snapshots candidate_removed
            scores = ScoreSnapshotRepository(session)
            score_list = scores.list_for_code(base_date, "002885")
            cand_removed_scores = [s for s in score_list if s.score_stage == "candidate_removed"]
            assert len(cand_removed_scores) >= 1
            assert cand_removed_scores[0].passed is False
            assert cand_removed_scores[0].reject_reason == "候选弱势移除"

            # runtime hot cache
            runtime_state = runtime.get_stock_state(base_date, "002885")
            assert runtime_state is not None
            assert runtime_state.stage == "PRE_CANDIDATE"
            assert runtime_state.active_monitoring is False

        # ============================================================
        # 场景 B：仍在窗口内，不移除
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            candidate_at = now - timedelta(minutes=5)
            monitoring.upsert_stock_state(
                trading_date=base_date,
                source_trading_date=base_date,
                code="600001",
                name="窗口内测试",
                stage="CANDIDATE",
                price=15.0,
                change_pct=3.0,
                as_of=candidate_at,
                seq=10,
                freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()
            ss = monitoring.get_stock_state(base_date, "600001")
            assert ss is not None, "B: could not read back stock state"
            ss.candidate_at = candidate_at
            session.flush()

            result = lifecycle.drop_stale_candidate(
                CandidateQuoteInput(
                    trading_date=base_date,
                    source_trading_date=base_date,
                    code="600001",
                    name="窗口内测试",
                    as_of=now,
                    seq=11,
                    freshness_status="fresh",
                    price=15.5,
                    change_pct=3.0,
                ),
                candidate_stale_minutes=30.0,
                candidate_min_active_pct=5.0,
            )
            session.commit()

            assert result.action == "kept_candidate", (
                f"B: expected kept_candidate, got {result.action}"
            )
            assert result.reason == "within_candidate_window"
            assert result.event_id is None

            # 状态仍 CANDIDATE
            state = monitoring.get_stock_state(base_date, "600001")
            assert state is not None
            assert state.stage == "CANDIDATE"

        # ============================================================
        # 场景 C：超过窗口但涨幅仍活跃，不移除
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            candidate_at = now - timedelta(minutes=45)
            monitoring.upsert_stock_state(
                trading_date=base_date,
                source_trading_date=base_date,
                code="600002",
                name="活跃测试",
                stage="CANDIDATE",
                price=20.0,
                change_pct=7.5,
                as_of=candidate_at,
                seq=20,
                freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()
            ss = monitoring.get_stock_state(base_date, "600002")
            assert ss is not None, "C: could not read back stock state"
            ss.candidate_at = candidate_at
            session.flush()

            result = lifecycle.drop_stale_candidate(
                CandidateQuoteInput(
                    trading_date=base_date,
                    source_trading_date=base_date,
                    code="600002",
                    name="活跃测试",
                    as_of=now,
                    seq=21,
                    freshness_status="fresh",
                    price=21.0,
                    change_pct=7.5,
                ),
                candidate_stale_minutes=30.0,
                candidate_min_active_pct=5.0,
            )
            session.commit()

            assert result.action == "kept_candidate", (
                f"C: expected kept_candidate, got {result.action}"
            )
            assert result.reason == "still_active"
            assert result.event_id is None

            state = monitoring.get_stock_state(base_date, "600002")
            assert state is not None
            assert state.stage == "CANDIDATE"

        # ============================================================
        # 场景 D：candidate_removed 后，通过 EventProcessor 重新进入 CORE
        #         必须 active_monitoring=True, inactive_reason/inactive_at 清空
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            monitoring = MonitoringRepository(session)

            # 先写入 candidate_removed 状态
            monitoring.upsert_stock_state(
                trading_date=base_date,
                source_trading_date=base_date,
                code="600003",
                name="重激活测试",
                stage="PRE_CANDIDATE",
                price=10.0,
                change_pct=1.0,
                as_of=now - timedelta(hours=1),
                seq=30,
                freshness_status="fresh",
                active_monitoring=False,
                inactive_reason="candidate_weak_removed",
                inactive_at=now - timedelta(minutes=30),
            )
            session.flush()

            # 通过 EventProcessor promote_core，应清空 inactive 信息
            processor = EventProcessor(session, runtime)
            r = processor.process_event(
                RuntimeInputEvent(
                    trading_date=base_date,
                    source_trading_date=base_date,
                    code="600003",
                    name="重激活测试",
                    event_type="LIMIT_UP_SEALED",
                    event_source="limit_pool",
                    event_time="10:30:00",
                    price=11.0,
                    change_pct=10.0,
                    is_sealed=True,
                    is_first_seal=True,
                    at_limit=True,
                    open_count=0,
                    raw_json='{"mock": true}',
                    as_of=now,
                    seq=31,
                    market_session=MarketSession.TRADING,
                )
            )
            session.commit()

            assert r.action == "promote_core"
            assert r.stage == "CORE"

            s_d = monitoring.get_stock_state(base_date, "600003")
            assert s_d is not None
            assert s_d.stage == "CORE"
            assert s_d.active_monitoring is True
            assert s_d.inactive_reason is None
            assert s_d.inactive_at is None

            rs_d = runtime.get_stock_state(base_date, "600003")
            assert rs_d is not None
            assert rs_d.stage == "CORE"
            assert rs_d.active_monitoring is True
            assert rs_d.inactive_reason is None

        # ============================================================
        # 场景 E：快速拉升进入 PRE_CANDIDATE
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)

            r = lifecycle.enter_pre_candidate(
                CandidateEntryInput(
                    trading_date="2026-05-06",
                    source_trading_date="2026-05-06",
                    code="002885",
                    name="京泉华",
                    event_type="RAPID_RISE",
                    event_source="eastmoney_changes",
                    event_title="快速拉升",
                    event_time="11:18:42",
                    price=33.55,
                    change_pct=7.326,
                    as_of=now,
                    seq=40,
                    freshness_status="fresh",
                    raw_json='{"mock": true}',
                )
            )
            session.commit()

            assert r.action == "enter_pre_candidate", f"E: expected enter_pre_candidate, got {r.action}"
            assert r.stage == "PRE_CANDIDATE"

            s_e = MonitoringRepository(session).get_stock_state("2026-05-06", "002885")
            assert s_e is not None
            assert s_e.stage == "PRE_CANDIDATE"
            assert s_e.active_monitoring is True
            assert s_e.inactive_reason is None

            rs_e = runtime.get_stock_state("2026-05-06", "002885")
            assert rs_e is not None
            assert rs_e.stage == "PRE_CANDIDATE"
            assert rs_e.active_monitoring is True

            score_list = ScoreSnapshotRepository(session).list_for_code("2026-05-06", "002885")
            assert any(s.score_stage == "pre_candidate" for s in score_list)

        # ============================================================
        # 场景 F：PRE_CANDIDATE -> CANDIDATE
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date="2026-05-06",
                source_trading_date="2026-05-06",
                code="002885",
                name="京泉华",
                stage="PRE_CANDIDATE",
                price=33.55,
                change_pct=7.326,
                as_of=now,
                seq=50,
                freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()

            r = lifecycle.promote_pre_to_candidate(
                trading_date="2026-05-06",
                source_trading_date="2026-05-06",
                code="002885",
                name="京泉华",
                as_of=now,
                seq=51,
                freshness_status="fresh",
                price=35.0,
                change_pct=8.0,
            )
            session.commit()

            assert r.action == "promote_candidate", f"F: expected promote_candidate, got {r.action}"
            assert r.stage == "CANDIDATE"

            s_f = monitoring.get_stock_state("2026-05-06", "002885")
            assert s_f is not None
            assert s_f.stage == "CANDIDATE"
            assert s_f.candidate_at is not None
            assert s_f.active_monitoring is True

            rs_f = runtime.get_stock_state("2026-05-06", "002885")
            assert rs_f is not None
            assert rs_f.stage == "CANDIDATE"

            transitions = list(
                session.execute(
                    select(MonitoringStateTransition).where(
                        MonitoringStateTransition.trading_date == "2026-05-06",
                        MonitoringStateTransition.code == "002885",
                        MonitoringStateTransition.from_stage == "PRE_CANDIDATE",
                        MonitoringStateTransition.to_stage == "CANDIDATE",
                    )
                ).scalars()
            )
            assert len(transitions) >= 1

            score_list = ScoreSnapshotRepository(session).list_for_code("2026-05-06", "002885")
            assert any(s.score_stage == "candidate" for s in score_list)

        # ============================================================
        # 场景 G：active CANDIDATE 阻止重复进入
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date="2026-05-06",
                source_trading_date="2026-05-06",
                code="600100",
                name="已候选股",
                stage="CANDIDATE",
                price=20.0,
                change_pct=6.0,
                as_of=now - timedelta(minutes=10),
                seq=60,
                freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()

            r = lifecycle.enter_pre_candidate(
                CandidateEntryInput(
                    trading_date="2026-05-06",
                    source_trading_date="2026-05-06",
                    code="600100",
                    name="已候选股",
                    event_type="RAPID_RISE",
                    event_source="eastmoney_changes",
                    event_title="重复触发",
                    event_time="11:30:00",
                    price=21.0,
                    change_pct=6.5,
                    as_of=now,
                    seq=61,
                    freshness_status="fresh",
                )
            )
            session.commit()

            assert r.action == "ignored_existing_active_state", f"G: expected ignored, got {r.action}"
            assert r.stage == "CANDIDATE"

            s_g = monitoring.get_stock_state("2026-05-06", "600100")
            assert s_g is not None
            assert s_g.stage == "CANDIDATE"

        # ============================================================
        # 场景 H：inactive PRE_CANDIDATE 允许重新进入
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date="2026-05-06",
                source_trading_date="2026-05-06",
                code="600200",
                name="重新进入股",
                stage="PRE_CANDIDATE",
                price=15.0,
                change_pct=1.0,
                as_of=now - timedelta(hours=1),
                seq=70,
                freshness_status="fresh",
                active_monitoring=False,
                inactive_reason="candidate_weak_removed",
                inactive_at=now - timedelta(minutes=30),
            )
            session.flush()

            r = lifecycle.enter_pre_candidate(
                CandidateEntryInput(
                    trading_date="2026-05-06",
                    source_trading_date="2026-05-06",
                    code="600200",
                    name="重新进入股",
                    event_type="RAPID_RISE",
                    event_source="eastmoney_changes",
                    event_title="重新拉升",
                    event_time="14:00:00",
                    price=16.0,
                    change_pct=6.0,
                    as_of=now,
                    seq=71,
                    freshness_status="fresh",
                )
            )
            session.commit()

            assert r.action == "enter_pre_candidate", f"H: expected enter_pre_candidate, got {r.action}"
            assert r.stage == "PRE_CANDIDATE"

            s_h = monitoring.get_stock_state("2026-05-06", "600200")
            assert s_h is not None
            assert s_h.stage == "PRE_CANDIDATE"
            assert s_h.active_monitoring is True
            assert s_h.inactive_reason is None
            assert s_h.inactive_at is None

        # ============================================================
        # 场景 I：ST 过滤 -> REJECTED_TODAY
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            r = lifecycle.enter_pre_candidate(
                CandidateEntryInput(
                    trading_date="2026-05-06",
                    source_trading_date="2026-05-06",
                    code="600300",
                    name="ST测试",
                    event_type="RAPID_RISE",
                    event_source="eastmoney_changes",
                    event_title="ST拉升",
                    event_time="09:30:00",
                    price=5.0,
                    change_pct=5.5,
                    as_of=now,
                    seq=80,
                    freshness_status="fresh",
                )
            )
            session.commit()

            assert r.action == "rejected_today", f"I: expected rejected_today, got {r.action}"
            assert r.stage == "REJECTED_TODAY"
            assert r.reason == "st_filter"

            s_i = monitoring.get_stock_state("2026-05-06", "600300")
            assert s_i is not None
            assert s_i.stage == "REJECTED_TODAY"
            assert s_i.active_monitoring is False
            assert s_i.inactive_reason == "st_filter"

            rs_i = runtime.get_stock_state("2026-05-06", "600300")
            assert rs_i is not None
            assert rs_i.stage == "REJECTED_TODAY"
            assert rs_i.active_monitoring is False

        # ============================================================
        # 场景 J：涨幅低于阈值不进入 PRE_CANDIDATE
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            r = lifecycle.enter_pre_candidate(
                CandidateEntryInput(
                    trading_date="2026-05-06",
                    source_trading_date="2026-05-06",
                    code="600400",
                    name="涨幅不足",
                    event_type="RAPID_RISE",
                    event_source="eastmoney_changes",
                    event_title="小幅拉升",
                    event_time="10:00:00",
                    price=10.0,
                    change_pct=3.0,
                    as_of=now,
                    seq=90,
                    freshness_status="fresh",
                )
            )
            session.commit()

            assert r.action == "entry_gate_failed", f"J: expected entry_gate_failed, got {r.action}"
            assert r.reason == "change_pct_below_threshold"

            s_j = monitoring.get_stock_state("2026-05-06", "600400")
            assert s_j is None

        # ============================================================
        # 场景 K：CANDIDATE 未封板报价 - 只更新状态、不进入 CORE
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600500", name="未封板股", stage="CANDIDATE",
                price=10.0, change_pct=5.0,
                as_of=now - timedelta(hours=1), seq=100, freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()

            r = lifecycle.process_candidate_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="600500", name="未封板股",
                    as_of=now, seq=101, freshness_status="fresh",
                    price=10.5, change_pct=5.5, is_sealed=False, at_limit=False,
                )
            )
            session.commit()

            assert r.action == "update_candidate_quote", f"K: expected update_candidate_quote, got {r.action}"
            assert r.stage == "CANDIDATE"
            s_k = monitoring.get_stock_state(base_date, "600500")
            assert s_k is not None and s_k.stage == "CANDIDATE"
            assert s_k.active_monitoring is True
            rs_k = runtime.get_stock_state(base_date, "600500")
            assert rs_k is not None and rs_k.stage == "CANDIDATE"

        # ============================================================
        # 场景 L：CANDIDATE 封板进入 CORE
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600501", name="封板升core", stage="CANDIDATE",
                price=11.0, change_pct=6.0,
                as_of=now - timedelta(hours=1), seq=110, freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()

            r = lifecycle.process_candidate_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="600501", name="封板升core",
                    as_of=now, seq=111, freshness_status="fresh",
                    price=12.1, change_pct=10.0, is_sealed=True, at_limit=True,
                )
            )
            session.commit()

            assert r.action == "promote_core", f"L: expected promote_core, got {r.action}"
            assert r.stage == "CORE"
            s_l = monitoring.get_stock_state(base_date, "600501")
            assert s_l is not None and s_l.stage == "CORE"
            t_l = list(session.execute(
                select(MonitoringStateTransition).where(
                    MonitoringStateTransition.trading_date == base_date,
                    MonitoringStateTransition.code == "600501",
                    MonitoringStateTransition.from_stage == "CANDIDATE",
                    MonitoringStateTransition.to_stage == "CORE",
                )
            ).scalars())
            assert len(t_l) >= 1
            rs_l = runtime.get_stock_state(base_date, "600501")
            assert rs_l is not None and rs_l.stage == "CORE"

        # ============================================================
        # 场景 M：CORE 仍封板 - 不重复写迁移
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600502", name="仍封板core", stage="CORE",
                price=15.0, change_pct=10.0,
                as_of=now - timedelta(minutes=10), seq=120, freshness_status="fresh",
                is_sealed=True, at_limit=True,
                active_monitoring=True,
            )
            session.flush()

            r = lifecycle.process_core_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="600502", name="仍封板core",
                    as_of=now, seq=121, freshness_status="fresh",
                    price=15.5, change_pct=10.0, is_sealed=True, at_limit=True,
                )
            )
            session.commit()

            assert r.action == "update_core_quote", f"M: expected update_core_quote, got {r.action}"
            assert r.stage == "CORE"
            s_m = monitoring.get_stock_state(base_date, "600502")
            assert s_m is not None and s_m.stage == "CORE"
            assert s_m.seq == 121
            t_all_m = list(session.execute(
                select(MonitoringStateTransition).where(
                    MonitoringStateTransition.trading_date == base_date,
                    MonitoringStateTransition.code == "600502",
                )
            ).scalars())
            assert len(t_all_m) == 0  # no transitions at all (never promoted)
            rs_m = runtime.get_stock_state(base_date, "600502")
            assert rs_m is not None and rs_m.stage == "CORE" and rs_m.seq == 121

        # ============================================================
        # 场景 N：CORE 开板回 CANDIDATE
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600503", name="开板回候选", stage="CORE",
                price=20.0, change_pct=10.0,
                as_of=now - timedelta(minutes=10), seq=130, freshness_status="fresh",
                is_sealed=True, at_limit=True,
                active_monitoring=True,
            )
            session.flush()

            r = lifecycle.process_core_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="600503", name="开板回候选",
                    as_of=now, seq=131, freshness_status="fresh",
                    price=18.5, change_pct=3.0, is_sealed=False, at_limit=False, open_count=1,
                )
            )
            session.commit()

            assert r.action == "demote_core_to_candidate", f"N: expected demote_core_to_candidate, got {r.action}"
            assert r.stage == "CANDIDATE"
            s_n = monitoring.get_stock_state(base_date, "600503")
            assert s_n is not None and s_n.stage == "CANDIDATE"
            assert s_n.is_sealed is False
            t_n = list(session.execute(
                select(MonitoringStateTransition).where(
                    MonitoringStateTransition.trading_date == base_date,
                    MonitoringStateTransition.code == "600503",
                    MonitoringStateTransition.from_stage == "CORE",
                    MonitoringStateTransition.to_stage == "CANDIDATE",
                )
            ).scalars())
            assert len(t_n) >= 1
            rs_n = runtime.get_stock_state(base_date, "600503")
            assert rs_n is not None and rs_n.stage == "CANDIDATE"

        # ============================================================
        # 场景 O：开板后回封
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600504", name="回封股", stage="CANDIDATE",
                price=18.5, change_pct=3.0,
                as_of=now - timedelta(minutes=5), seq=140, freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()

            r = lifecycle.process_candidate_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="600504", name="回封股",
                    as_of=now, seq=141, freshness_status="fresh",
                    price=20.5, change_pct=10.0, is_sealed=True, at_limit=True,
                )
            )
            session.commit()

            assert r.action == "promote_core", f"O: expected promote_core, got {r.action}"
            assert r.stage == "CORE"
            s_o = monitoring.get_stock_state(base_date, "600504")
            assert s_o is not None and s_o.stage == "CORE"
            t_o = list(session.execute(
                select(MonitoringStateTransition).where(
                    MonitoringStateTransition.trading_date == base_date,
                    MonitoringStateTransition.code == "600504",
                    MonitoringStateTransition.from_stage == "CANDIDATE",
                    MonitoringStateTransition.to_stage == "CORE",
                )
            ).scalars())
            assert len(t_o) >= 1
            rs_o = runtime.get_stock_state(base_date, "600504")
            assert rs_o is not None and rs_o.stage == "CORE"

        # ============================================================
        # 场景 P：mismatch 不触发迁移
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600505", name="mismatch测试", stage="CANDIDATE",
                price=10.0, change_pct=5.0,
                as_of=now - timedelta(minutes=30), seq=150, freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()

            # 用 mismatch 的封板报价
            r = lifecycle.process_candidate_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date="2026-05-05",
                    code="600505", name="mismatch测试",
                    as_of=now, seq=151, freshness_status="mismatch",
                    price=11.0, change_pct=10.0, is_sealed=True, at_limit=True,
                )
            )
            session.commit()

            assert r.action == "ignored", f"P: expected ignored, got {r.action}"
            assert r.reason == "freshness_mismatch"
            s_p = monitoring.get_stock_state(base_date, "600505")
            assert s_p is not None and s_p.stage == "CANDIDATE"
            t_p = list(session.execute(
                select(MonitoringStateTransition).where(
                    MonitoringStateTransition.trading_date == base_date,
                    MonitoringStateTransition.code == "600505",
                )
            ).scalars())
            assert len(t_p) == 0
            rs_p = runtime.get_stock_state(base_date, "600505")
            assert rs_p is None  # event processor didn't set it

        # ============================================================
        # 场景 Q: insufficient seal confidence -> 不进入 CORE
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600601", name="insufficient测试", stage="CANDIDATE",
                price=10.0, change_pct=5.0,
                as_of=now - timedelta(minutes=30), seq=160, freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()

            r = lifecycle.process_candidate_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="600601", name="insufficient测试",
                    as_of=now, seq=161, freshness_status="fresh",
                    price=11.0, change_pct=10.01, is_sealed=False, at_limit=False,
                    seal_confidence="insufficient",
                )
            )
            session.commit()

            assert r.action == "update_candidate_quote", f"Q: expected update_candidate_quote, got {r.action}"
            assert r.reason == "insufficient_seal_data", f"Q: {r.reason}"
            s_q = monitoring.get_stock_state(base_date, "600601")
            assert s_q is not None and s_q.stage == "CANDIDATE", f"Q: got {s_q.stage}"
            t_q = list(session.execute(
                select(MonitoringStateTransition).where(
                    MonitoringStateTransition.trading_date == base_date,
                    MonitoringStateTransition.code == "600601",
                )
            ).scalars())
            assert len(t_q) == 0, "Q: no transitions expected"

        # ============================================================
        # 场景 R: insufficient seal confidence -> 不回退 CANDIDATE
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600602", name="insufficient core", stage="CORE",
                price=20.0, change_pct=10.0,
                as_of=now - timedelta(minutes=30), seq=170, freshness_status="fresh",
                is_sealed=True, at_limit=True,
                active_monitoring=True,
            )
            session.flush()

            r = lifecycle.process_core_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="600602", name="insufficient core",
                    as_of=now, seq=171, freshness_status="fresh",
                    price=18.5, change_pct=3.0, is_sealed=False, at_limit=False,
                    seal_confidence="insufficient",
                )
            )
            session.commit()

            assert r.action == "update_core_quote_no_seal_decision", f"R: expected no_seal_decision, got {r.action}"
            assert r.stage == "CORE", f"R: expected CORE, got {r.stage}"
            s_r = monitoring.get_stock_state(base_date, "600602")
            assert s_r is not None and s_r.stage == "CORE", f"R: stage changed to {s_r.stage}"
            t_r = list(session.execute(
                select(MonitoringStateTransition).where(
                    MonitoringStateTransition.trading_date == base_date,
                    MonitoringStateTransition.code == "600602",
                    MonitoringStateTransition.to_stage == "CANDIDATE",
                )
            ).scalars())
            assert len(t_r) == 0, "R: unexpected CORE->CANDIDATE transition"

        # ============================================================
        # 场景 S: explicit is_sealed=False 仍可 CORE->CANDIDATE
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600603", name="explicit open test", stage="CORE",
                price=25.0, change_pct=10.0,
                as_of=now - timedelta(minutes=30), seq=180, freshness_status="fresh",
                is_sealed=True, at_limit=True,
                active_monitoring=True,
            )
            session.flush()

            r = lifecycle.process_core_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="600603", name="explicit open test",
                    as_of=now, seq=181, freshness_status="fresh",
                    price=22.0, change_pct=2.0, is_sealed=False, at_limit=False,
                    seal_confidence="explicit",
                )
            )
            session.commit()

            assert r.action == "demote_core_to_candidate", f"S: expected demote, got {r.action}"
            assert r.stage == "CANDIDATE"
            s_s = monitoring.get_stock_state(base_date, "600603")
            assert s_s is not None and s_s.stage == "CANDIDATE"

        # ============================================================
        # 场景 T: explicit is_sealed=True 仍可 promote_core
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600604", name="explicit sealed test", stage="CANDIDATE",
                price=30.0, change_pct=6.0,
                as_of=now - timedelta(minutes=30), seq=190, freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()

            r = lifecycle.process_candidate_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="600604", name="explicit sealed test",
                    as_of=now, seq=191, freshness_status="fresh",
                    price=33.0, change_pct=10.0, is_sealed=True, at_limit=True,
                    seal_confidence="explicit",
                )
            )
            session.commit()

            assert r.action == "promote_core", f"T: expected promote_core, got {r.action}"
            assert r.stage == "CORE"
            s_t = monitoring.get_stock_state(base_date, "600604")
            assert s_t is not None and s_t.stage == "CORE"
