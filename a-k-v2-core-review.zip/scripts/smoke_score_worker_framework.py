from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import (  # noqa: E402
    LimitPoolRow,
    MonitoringStateTransition,
    MonitoringStockState,
    ScoreSnapshot,
    ScoreTaskCurrent,
)
from app.services.limit_pool_ingestion_service import (  # noqa: E402
    LimitPoolIngestionService,
    LimitPoolInputRow,
    LimitPoolInputSnapshot,
)
from app.services.score_task_service import ScoreTaskService  # noqa: E402
from app.services.score_worker_service import (  # noqa: E402
    ScoreWorkerService,
    ScoringExecutor,
    ScoreExecutionResult,
)


class FailingExecutor:
    def execute(self, task) -> ScoreExecutionResult:
        raise RuntimeError("mock scoring failed")


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "score_worker.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()

        # === prepare: ingest a limit pool row + schedule a task ===
        with Session() as session:
            ingestion = LimitPoolIngestionService(session)
            fresh = ingestion.ingest_snapshot(
                LimitPoolInputSnapshot(
                    trading_date="2026-05-09", source_trading_date="2026-05-09",
                    source="composite_limit_pool", primary_source="eastmoney_limit_pool",
                    as_of=now, seq=1, freshness_status="fresh", market_session="trading",
                    source_counts_json='{"limit_up":1}',
                    rows=[
                        LimitPoolInputRow(pool="limit_up", code="000001", name="平安银行",
                            source="eastmoney_limit_pool", price=10.5, change_pct=10.01,
                            first_limit_time="10:01:00"),
                    ],
                )
            )

            db_rows = list(session.execute(select(LimitPoolRow)).scalars())
            assert len(db_rows) == 1
            row = db_rows[0]

            # capture row.id before session closes
            row_id = row.id
            tasks_svc = ScoreTaskService(session)
            scheduled = tasks_svc.schedule_for_limit_pool_row(row)
            session.commit()

        # === success path: worker executes task (use Static executor for deterministic test) ===
        with Session() as session:
            from app.services.score_worker_service import StaticScoringExecutor
            worker = ScoreWorkerService(session, executor=StaticScoringExecutor())
            result = worker.process_pending(trading_date="2026-05-09", limit=100)

            assert result.processed == 1, f"expected 1 processed, got {result.processed}"
            assert result.ready == 1, f"expected 1 ready, got {result.ready}"
            assert result.failed == 0, f"expected 0 failed, got {result.failed}"

            # task -> ready
            all_tasks = list(session.execute(select(ScoreTaskCurrent)).scalars())
            assert len(all_tasks) == 1
            t = all_tasks[0]
            assert t.status == "ready", f"expected ready, got {t.status}"
            assert t.attempts == 1

            # score_snapshots written
            all_snaps = list(session.execute(select(ScoreSnapshot)).scalars())
            assert len(all_snaps) == 1, f"expected 1 snapshot, got {len(all_snaps)}"
            snap = all_snaps[0]
            assert snap.source_type == "limit_pool_row"
            assert snap.source_row_id == row_id
            assert snap.score_stage == "limit_pool_first_score"
            assert snap.technical_score == 80.0
            assert snap.sentiment_score == 90.0
            assert snap.volume_score == 70.0
            assert snap.input_refs_json is not None
            assert "limit_pool_row_id" in (snap.input_refs_json or "")

            # no lifecycle side effects
            assert count_(session, MonitoringStockState) == 0
            assert count_(session, MonitoringStateTransition) == 0

            session.commit()

        # === failure path ===
        with Session() as session:
            ingestion = LimitPoolIngestionService(session)
            ingestion.ingest_snapshot(
                LimitPoolInputSnapshot(
                    trading_date="2026-05-10", source_trading_date="2026-05-10",
                    source="composite_limit_pool", primary_source="eastmoney_limit_pool",
                    as_of=now, seq=2, freshness_status="fresh", market_session="trading",
                    rows=[
                        LimitPoolInputRow(pool="limit_up", code="000002", name="fail test",
                            source="eastmoney_limit_pool", price=12.0, change_pct=10.0,
                            first_limit_time="11:00:00"),
                    ],
                )
            )
            row2 = list(
                session.execute(
                    select(LimitPoolRow).where(LimitPoolRow.trading_date == "2026-05-10")
                ).scalars()
            )[0]

            tasks_svc = ScoreTaskService(session)
            tasks_svc.schedule_for_limit_pool_row(row2)
            session.commit()

        with Session() as session:
            snaps_before = count_(session, ScoreSnapshot)
            worker = ScoreWorkerService(session, executor=FailingExecutor())
            result2 = worker.process_pending(trading_date="2026-05-10", limit=100)

            assert result2.processed == 1, f"fail: expected 1 processed, got {result2.processed}"
            assert result2.ready == 0, f"fail: expected 0 ready, got {result2.ready}"
            assert result2.failed == 1, f"fail: expected 1 failed, got {result2.failed}"

            fail_task = list(
                session.execute(
                    select(ScoreTaskCurrent).where(ScoreTaskCurrent.trading_date == "2026-05-10")
                ).scalars()
            )[0]
            assert fail_task.status in ("pending", "failed"), f"fail: expected pending/failed, got {fail_task.status}"
            assert fail_task.last_error is not None
            assert "mock scoring failed" in fail_task.last_error

            # no new score_snapshot
            assert count_(session, ScoreSnapshot) == snaps_before, "fail: should not write snapshot"

            session.commit()

    print("Score worker framework smoke test OK")


if __name__ == "__main__":
    main()
