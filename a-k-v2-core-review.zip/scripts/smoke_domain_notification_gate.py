from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.domain.decisions import CandidateStage, CandidateState  # noqa: E402
from app.domain.external_actions import SelfStockState, SelfStockStatus  # noqa: E402
from app.domain.gates import NotificationAction, NotificationGateConfig  # noqa: E402
from app.domain.notification_gate import (  # noqa: E402
    NotificationBypassReason,
    NotificationGateInput,
    NotificationGateStatus,
    NotificationLevel,
    check_notification_gate,
    select_notification_sentiment,
)
from app.domain.scores import ScoreResult, ScoreType, StockScoreBundle  # noqa: E402
from app.domain.stocks import StockSnapshot  # noqa: E402


def stock() -> StockSnapshot:
    return StockSnapshot(code="300750", name="宁德时代", price=214.28, change_pct=4.2)


def sr(score_type: ScoreType, value: float | None) -> ScoreResult:
    return ScoreResult(score_type=score_type, score=value)


def bundle(
    *,
    technical: float | None = None,
    realtime_sentiment: float | None = None,
    entry_sentiment: float | None = None,
    seal_sentiment: float | None = None,
    open_board_sentiment: float | None = None,
    reseal_sentiment: float | None = None,
    volume: float | None = None,
) -> StockScoreBundle:
    return StockScoreBundle(
        technical=sr(ScoreType.TECHNICAL, technical) if technical is not None else None,
        realtime_sentiment=sr(ScoreType.REALTIME_SENTIMENT, realtime_sentiment) if realtime_sentiment is not None else None,
        entry_sentiment=sr(ScoreType.ENTRY_SENTIMENT, entry_sentiment) if entry_sentiment is not None else None,
        seal_sentiment=sr(ScoreType.SEAL_SENTIMENT, seal_sentiment) if seal_sentiment is not None else None,
        open_board_sentiment=sr(ScoreType.OPEN_BOARD_SENTIMENT, open_board_sentiment) if open_board_sentiment is not None else None,
        reseal_sentiment=sr(ScoreType.RESEAL_SENTIMENT, reseal_sentiment) if reseal_sentiment is not None else None,
        volume=sr(ScoreType.VOLUME, volume) if volume is not None else None,
    )


def self_stock_state(*, added: bool = True) -> SelfStockState:
    return SelfStockState(
        status=SelfStockStatus.ADDED if added else SelfStockStatus.FILTERED,
        board_score=85,
        kline_score=80,
        change_pct=9.8,
        message="ths_added" if added else "filtered",
    )


def candidate_state(*, with_self_stock: bool = True) -> CandidateState:
    return CandidateState(
        stock=stock(),
        stage=CandidateStage.CORE,
        scores=StockScoreBundle(),
        self_stock_state=self_stock_state(added=with_self_stock),
    )


def test_buyable_score_pass() -> None:
    """封板通知，全部分数通过 -> BUYABLE"""
    result = check_notification_gate(NotificationGateInput(
        stock=stock(),
        action=NotificationAction.LIMIT_UP,
        scores=bundle(technical=85, seal_sentiment=80, volume=75),
    ))
    assert result.status is NotificationGateStatus.PASS
    assert result.should_notify is True
    assert result.level is NotificationLevel.BUYABLE
    assert "buyable" in result.tags
    assert "score_pass" in result.tags
    print("  OK test_buyable_score_pass")


def test_suppressed_score_block() -> None:
    """封板通知，分数未达标，无自选豁免 -> SUPPRESSED"""
    result = check_notification_gate(NotificationGateInput(
        stock=stock(),
        action=NotificationAction.LIMIT_UP,
        scores=bundle(technical=40, seal_sentiment=30, volume=20),
    ))
    assert result.status is NotificationGateStatus.BLOCK
    assert result.should_notify is False
    assert result.level is NotificationLevel.SUPPRESSED
    assert "score_block" in result.tags
    print("  OK test_suppressed_score_block")


def test_self_stock_warning_bypass() -> None:
    """封板通知，分数未达标，已加自选，实时情绪未达标 -> PASS/WARNING"""
    result = check_notification_gate(NotificationGateInput(
        stock=stock(),
        action=NotificationAction.LIMIT_UP,
        scores=bundle(technical=40, realtime_sentiment=30, volume=20),
        current_state=candidate_state(with_self_stock=True),
    ))
    assert result.status is NotificationGateStatus.PASS
    assert result.should_notify is True
    assert result.level is NotificationLevel.WARNING
    assert result.bypass_reason is NotificationBypassReason.SELF_STOCK_LIMIT_UP
    assert "self_stock_bypass" in result.tags
    print("  OK test_self_stock_warning_bypass")


def test_self_stock_buyable_bypass() -> None:
    """封板通知，分数未达标，已加自选，实时情绪达标 -> PASS/BUYABLE"""
    result = check_notification_gate(NotificationGateInput(
        stock=stock(),
        action=NotificationAction.LIMIT_UP,
        scores=bundle(technical=40, realtime_sentiment=85, volume=20),
        current_state=candidate_state(with_self_stock=True),
    ))
    assert result.status is NotificationGateStatus.PASS
    assert result.should_notify is True
    assert result.level is NotificationLevel.BUYABLE
    assert result.bypass_reason is NotificationBypassReason.SELF_STOCK_LIMIT_UP
    assert "self_stock_bypass" in result.tags
    print("  OK test_self_stock_buyable_bypass")


def test_open_board_warning_bypass() -> None:
    """开板通知，已发送封板通知 -> PASS/WARNING（豁免）"""
    result = check_notification_gate(NotificationGateInput(
        stock=stock(),
        action=NotificationAction.OPEN_BOARD,
        scores=bundle(technical=40, realtime_sentiment=30, volume=20),
        limit_up_notice_sent=True,
    ))
    assert result.status is NotificationGateStatus.PASS
    assert result.should_notify is True
    assert result.level is NotificationLevel.WARNING
    assert result.bypass_reason is NotificationBypassReason.CORE_OPEN_BOARD
    assert "open_board_bypass" in result.tags
    print("  OK test_open_board_warning_bypass")


def test_open_board_suppressed_volume() -> None:
    """开板通知，分数未达标，无豁免 -> SUPPRESSED"""
    result = check_notification_gate(NotificationGateInput(
        stock=stock(),
        action=NotificationAction.OPEN_BOARD,
        scores=bundle(technical=40, realtime_sentiment=30, volume=20),
    ))
    assert result.status is NotificationGateStatus.BLOCK
    assert result.should_notify is False
    assert result.level is NotificationLevel.SUPPRESSED
    assert "open_board_suppressed" in result.tags
    print("  OK test_open_board_suppressed_volume")


def test_self_stock_info_notice() -> None:
    """自选通知，分数达标 -> PASS/INFO"""
    result = check_notification_gate(NotificationGateInput(
        stock=stock(),
        action=NotificationAction.SELF_STOCK,
        scores=bundle(technical=85, realtime_sentiment=80, volume=75),
    ))
    assert result.status is NotificationGateStatus.PASS
    assert result.should_notify is True
    assert result.level is NotificationLevel.INFO
    assert "self_stock_notice" in result.tags
    print("  OK test_self_stock_info_notice")


def test_disabled_skip() -> None:
    """门禁关闭 -> SKIP/SUPPRESSED"""
    result = check_notification_gate(NotificationGateInput(
        stock=stock(),
        action=NotificationAction.LIMIT_UP,
        scores=bundle(technical=85, seal_sentiment=80, volume=75),
        config=NotificationGateConfig(enabled=False),
    ))
    assert result.status is NotificationGateStatus.SKIP
    assert result.should_notify is False
    assert result.level is NotificationLevel.SUPPRESSED
    assert "notification_disabled" in result.tags
    print("  OK test_disabled_skip")


def test_select_notification_sentiment() -> None:
    """情绪选择函数验证"""
    scores = bundle(
        realtime_sentiment=85,
        entry_sentiment=80,
        seal_sentiment=90,
        open_board_sentiment=70,
        reseal_sentiment=75,
    )
    # LIMIT_UP -> seal > entry > realtime
    source, value = select_notification_sentiment(NotificationAction.LIMIT_UP, scores)
    assert source == "seal" and value == 90

    # OPEN_BOARD -> realtime > open_board > seal
    source, value = select_notification_sentiment(NotificationAction.OPEN_BOARD, scores)
    assert source == "realtime" and value == 85

    # RESEAL -> realtime > reseal > seal
    source, value = select_notification_sentiment(NotificationAction.RESEAL, scores)
    assert source == "realtime" and value == 85

    # RESEAL via is_reseal flag
    source, value = select_notification_sentiment(NotificationAction.LIMIT_UP, scores, is_reseal=True)
    assert source == "realtime" and value == 85

    # SELF_STOCK -> realtime > entry > seal
    source, value = select_notification_sentiment(NotificationAction.SELF_STOCK, scores)
    assert source == "realtime" and value == 85

    print("  OK test_select_notification_sentiment")


def main() -> None:
    test_buyable_score_pass()
    test_suppressed_score_block()
    test_self_stock_warning_bypass()
    test_self_stock_buyable_bypass()
    test_open_board_warning_bypass()
    test_open_board_suppressed_volume()
    test_self_stock_info_notice()
    test_disabled_skip()
    test_select_notification_sentiment()
    print("Domain notification gate smoke tests passed.")


if __name__ == "__main__":
    main()
