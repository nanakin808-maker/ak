from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
import tempfile

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.repositories import MonitoringRepository  # noqa: E402
from app.runtime import RuntimeRestoreService, RuntimeState  # noqa: E402


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "restore.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()

        # 写入三条测试状态
        with Session() as session:
            repo = MonitoringRepository(session)
            # fresh CORE
            repo.upsert_stock_state(
                trading_date="2026-05-09",
                source_trading_date="2026-05-09",
                code="000001",
                name="平安银行",
                stage="CORE",
                price=10.5,
                change_pct=10.01,
                is_sealed=True,
                at_limit=True,
                as_of=now,
                seq=1,
                freshness_status="fresh",
            )
            # fresh CANDIDATE
            repo.upsert_stock_state(
                trading_date="2026-05-09",
                source_trading_date="2026-05-09",
                code="000002",
                name="万科A",
                stage="CANDIDATE",
                price=8.2,
                change_pct=5.5,
                as_of=now,
                seq=2,
                freshness_status="fresh",
            )
            # mismatch CORE (source_trading_date != trading_date)
            repo.upsert_stock_state(
                trading_date="2026-05-10",
                source_trading_date="2026-05-09",
                code="600002",
                name="mock mismatch",
                stage="CORE",
                price=8.8,
                change_pct=10.02,
                is_sealed=True,
                at_limit=True,
                as_of=now,
                seq=3,
                freshness_status="mismatch",
            )
            session.commit()

        # 恢复并验证
        with Session() as session:
            runtime = RuntimeState()
            restore = RuntimeRestoreService(session, runtime)

            # 恢复 2026-05-09（两条 fresh 数据）
            result = restore.restore_trading_date("2026-05-09")
            assert result.restored_stock_count == 2, (
                f"expected 2 restored, got {result.restored_stock_count}"
            )
            assert result.trading_date == "2026-05-09"

            # runtime 有 (2026-05-09, 000001) CORE
            s1 = runtime.get_stock_state("2026-05-09", "000001")
            assert s1 is not None
            assert s1.stage == "CORE"
            assert s1.freshness_status == "fresh"

            # runtime 有 (2026-05-09, 000002) CANDIDATE
            s2 = runtime.get_stock_state("2026-05-09", "000002")
            assert s2 is not None
            assert s2.stage == "CANDIDATE"

            # runtime 没有 (2026-05-10, 600002) — 不同交易日
            s3 = runtime.get_stock_state("2026-05-10", "600002")
            assert s3 is None

            # 恢复 2026-05-10（默认 require_fresh=True，mismatch 不恢复）
            result2 = restore.restore_trading_date("2026-05-10")
            assert result2.restored_stock_count == 0, (
                f"expected 0 mismatch restored, got {result2.restored_stock_count}"
            )
            s4 = runtime.get_stock_state("2026-05-10", "600002")
            assert s4 is None

            # 设置 require_fresh=False 时可以恢复 mismatch
            runtime2 = RuntimeState()
            restore2 = RuntimeRestoreService(session, runtime2)
            result3 = restore2.restore_trading_date("2026-05-10", require_fresh=False)
            assert result3.restored_stock_count == 1, (
                f"expected 1 restored without fresh filter, got {result3.restored_stock_count}"
            )
            s5 = runtime2.get_stock_state("2026-05-10", "600002")
            assert s5 is not None
            assert s5.stage == "CORE"
            assert s5.freshness_status == "mismatch"

        # === inactive PRE_CANDIDATE restore scenario ===
        with Session() as session:
            repo = MonitoringRepository(session)
            repo.upsert_stock_state(
                trading_date="2026-05-09",
                source_trading_date="2026-05-09",
                code="002885",
                name="京泉华",
                stage="PRE_CANDIDATE",
                price=32.0,
                change_pct=2.0,
                as_of=now,
                seq=10,
                freshness_status="fresh",
                active_monitoring=False,
                inactive_reason="candidate_weak_removed",
                inactive_at=now,
            )
            session.commit()

        with Session() as session:
            runtime3 = RuntimeState()
            restore3 = RuntimeRestoreService(session, runtime3)
            result4 = restore3.restore_trading_date("2026-05-09")
            assert result4.restored_stock_count >= 3

            s6 = runtime3.get_stock_state("2026-05-09", "002885")
            assert s6 is not None
            assert s6.stage == "PRE_CANDIDATE"
            assert s6.active_monitoring is False
            assert s6.inactive_reason == "candidate_weak_removed"
            assert s6.inactive_at is not None

    print("Runtime restore smoke test OK")


if __name__ == "__main__":
    main()
