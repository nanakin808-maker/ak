"""
Manual shadow script: calls real old system providers via subprocess (old venv python),
normalizes results through v2 ProviderBridge, and writes to temporary SQLite.

Usage:
  python3 scripts/manual_real_source_shadow.py --source limit_pool --trading-date 2026-05-09
  python3 scripts/manual_real_source_shadow.py --source speed_rank --trading-date 2026-05-09
  python3 scripts/manual_real_source_shadow.py --source quote_batch --trading-date 2026-05-09 --codes 002885,600001
"""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
OLD_PROJECT = ROOT.parent / "a-k"
OLD_PYTHON = OLD_PROJECT / ".venv" / "bin" / "python3"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.domain.time_scope import MarketSession  # noqa: E402
from app.runtime import RuntimeState  # noqa: E402
from app.runtime.monitoring_engine import MonitoringEngine  # noqa: E402
from app.services.limit_pool_provider_service import (  # noqa: E402
    LimitPoolProviderIngestionService,
)
from app.services.market_source_adapter_service import (  # noqa: E402
    MarketSourceAdapterService,
)
from app.services.provider_bridge_service import (  # noqa: E402
    ProviderBridgeService,
    ProviderFetchResult,
)
from app.services.real_source_normalizers import (  # noqa: E402
    normalize_limit_pool_rows,
    normalize_quote_rows,
    normalize_speed_rank_rows,
)

# ── Subprocess calls ─────────────────────────────────────────────


def build_call_script(source: str, trading_date: str, codes: str | None) -> tuple[str, str]:
    """Return (script_body, summary_label)."""
    if source == "limit_pool":
        return f"""
import json, sys
from datetime import datetime
sys.path.insert(0, r"{OLD_PROJECT}")
from astock_guard.providers.limit_pool import EastmoneyLimitPoolProvider
p = EastmoneyLimitPoolProvider()
result = p.snapshot("{trading_date}")
limit_up = [r.to_dict() if hasattr(r, 'to_dict') else r for r in result.get('limit_up', [])]
open_board = [r.to_dict() if hasattr(r, 'to_dict') else r for r in result.get('open_board', [])]
for r in limit_up: r['pool'] = 'limit_up'
for r in open_board: r['pool'] = 'open_board'
rows = limit_up + open_board
print(json.dumps({{
    "ok": True, "rows": rows,
    "source_trading_date": "{trading_date}",
    "detail": {{"limit_up_count": len(limit_up), "open_board_count": len(open_board)}}
}}, ensure_ascii=False, default=str))
""", "EastmoneyLimitPoolProvider.snapshot()"

    if source == "speed_rank":
        return f"""
import json, sys
sys.path.insert(0, r"{OLD_PROJECT}")
from astock_guard.providers.eastmoney_rank import EastmoneyRankProvider
p = EastmoneyRankProvider()
rows = p.speed_rank(limit=30)
print(json.dumps({{
    "ok": True, "rows": rows,
    "source_trading_date": "{trading_date}",
    "detail": {{"count": len(rows)}}
}}, ensure_ascii=False, default=str))
""", "EastmoneyRankProvider.speed_rank()"

    if source == "quote_batch":
        if not codes:
            return 'print(json.dumps({"ok":false,"rows":[],"error":"--codes required"}))', "noop"
        code_list = [c.strip() for c in codes.split(",")]
        return f"""
import json, sys
sys.path.insert(0, r"{OLD_PROJECT}")
from astock_guard.providers.eastmoney import EastmoneyProvider
p = EastmoneyProvider()
quotes = p.get_quotes({code_list})
rows = [{{"code":q.code,"name":getattr(q,'name',str(q.code)),"price":q.price,"change_pct":q.change_pct,
         "bid_vol1":q.bid_vol1,"ask_vol1":q.ask_vol1,"amount":q.amount,"volume":q.volume}} for q in quotes]
print(json.dumps({{
    "ok": True, "rows": rows,
    "source_trading_date": "{trading_date}",
    "detail": {{"codes": {code_list}}}
}}, ensure_ascii=False, default=str))
""", "EastmoneyProvider.get_quotes()"

    return 'print(json.dumps({"ok":false,"error":"unknown source"}))', "noop"


def call_old_provider(source: str, trading_date: str, codes: str | None) -> dict[str, Any]:
    script, label = build_call_script(source, trading_date, codes)
    result: dict[str, Any] = {"ok": False, "rows": [], "label": label}

    if script.startswith("print(json.dumps"):
        return {"ok": False, "rows": [], "label": label, "blocker": script}
        return {"ok": False, "rows": [], "label": label, "blocker": script}

    t0 = time.perf_counter()
    try:
        cp = subprocess.run(
            [str(OLD_PYTHON), "-c", script],
            check=False, capture_output=True, text=True, timeout=30,
        )
        subprocess_latency = (time.perf_counter() - t0) * 1000.0
        result["subprocess_latency_ms"] = round(subprocess_latency, 1)

        if cp.returncode != 0:
            result["error"] = cp.stderr.strip()[:500]
            return result

        payload = json.loads(cp.stdout)
        payload["label"] = label
        payload["subprocess_latency_ms"] = result["subprocess_latency_ms"]
        return payload

    except subprocess.TimeoutExpired:
        result["error"] = "subprocess timeout (30s)"
        result["subprocess_latency_ms"] = round((time.perf_counter() - t0) * 1000.0, 1)
        return result
    except json.JSONDecodeError as exc:
        result["error"] = f"JSON decode: {exc}"
        return result
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result


# ── Shadow runner ────────────────────────────────────────────────


def run_shadow(source: str, trading_date: str, codes: str | None) -> dict[str, Any]:
    report: dict[str, Any] = {
        "source": source, "status": "running", "rows": 0, "freshness": "?",
        "latency_ms": 0.0, "normalized_rows": 0, "blockers": [],
    }

    raw = call_old_provider(source, trading_date, codes)
    report["latency_ms"] = raw.get("subprocess_latency_ms", 0.0)
    report["provider_label"] = raw.get("label", "?")

    if not raw.get("ok"):
        report["status"] = "FAIL"
        report["error"] = raw.get("error", "unknown")
        if raw.get("blocker"):
            report["blockers"].append(raw["blocker"])
        return report

    raw_rows = raw.get("rows", [])
    report["raw_rows"] = len(raw_rows)

    # Normalize
    if source == "limit_pool":
        norm = normalize_limit_pool_rows(raw_rows)
    elif source == "speed_rank":
        norm = normalize_speed_rank_rows(raw_rows)
    elif source == "quote_batch":
        norm = normalize_quote_rows(raw_rows)
    else:
        norm = []

    report["normalized_rows"] = len(norm)
    report["samples"] = norm[:3]

    if not norm:
        report["status"] = "FAIL"
        report["error"] = "all rows failed normalization"
        report["blockers"].append("all rows failed normalization; check field naming")
        return report

    report["status"] = "SUCCESS"
    report["freshness"] = "fresh" if raw.get("source_trading_date") == trading_date else "mismatch"

    # Write to temporary v2 SQLite
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "shadow.db"
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()
        fetch_result = ProviderFetchResult(
            data={"rows": norm},
            source_trading_date=raw.get("source_trading_date"),
            source_updated_at=datetime.utcnow(),
            detail=raw.get("detail", {}),
        )

        with Session() as session:
            bridge = ProviderBridgeService(session)
            call_result = bridge.call(
                name=f"manual_shadow_{source}",
                category=source,
                requested_trading_date=trading_date,
                fetcher=lambda: fetch_result,
                market_session=MarketSession.TRADING,
            )
            report["bridge_ok"] = call_result.ok
            report["bridge_freshness"] = call_result.freshness_status

            if source == "limit_pool":
                class _ShadowFetcher:
                    def fetch(self, *, requested_trading_date: str) -> ProviderFetchResult:
                        return fetch_result
                ingestion = LimitPoolProviderIngestionService(session, _ShadowFetcher())
                result = ingestion.fetch_and_ingest(
                    requested_trading_date=trading_date,
                    as_of=now, seq=1,
                    market_session=MarketSession.TRADING,
                    provider_name="manual_shadow_limit_pool",
                    primary_source="eastmoney_limit_pool",
                )
                report["ingested"] = result.ingested
                report["snapshot_id"] = result.snapshot_id
                report["row_count"] = result.row_count

            elif source == "speed_rank":
                rt = RuntimeState()
                engine_mg = MonitoringEngine(session, rt)
                adapter = MarketSourceAdapterService(session, rt, engine_mg)
                sr_result = adapter.ingest_event_source(
                    source_type="speed_rank",
                    provider_name="manual_shadow_speed_rank",
                    requested_trading_date=trading_date,
                    fetcher=lambda: fetch_result,
                    as_of=now, seq_start=1,
                    market_session=MarketSession.TRADING,
                )
                report["events_processed"] = sr_result.processed
                report["actions"] = sr_result.actions[:5]
                enter_count = sum(1 for a in sr_result.actions if a == "enter_pre_candidate")
                report["pre_candidate_entries"] = enter_count
                if sr_result.error:
                    report["errors"] = [sr_result.error]

            elif source == "quote_batch":
                report["code_count"] = len(norm)

            session.commit()

    return report


# ── Main ─────────────────────────────────────────────────────────


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, choices=["limit_pool", "speed_rank", "quote_batch"])
    parser.add_argument("--trading-date", default=datetime.utcnow().strftime("%Y%m%d"))
    parser.add_argument("--codes", help="comma-separated codes for quote_batch")
    args = parser.parse_args()

    report = run_shadow(args.source, args.trading_date, args.codes)

    print(f"source:       {report.get('source','?')}")
    print(f"status:       {report.get('status','?')}")
    print(f"provider:     {report.get('provider_label','?')}")
    print(f"latency_ms:   {report.get('latency_ms','?')}")
    print(f"raw_rows:     {report.get('raw_rows',0)}")
    print(f"normalized:   {report.get('normalized_rows',0)}")
    print(f"freshness:    {report.get('freshness','?')}")
    print(f"bridge_ok:    {report.get('bridge_ok','?')}")

    if report.get("ingested") is not None:
        print(f"ingested:     {report['ingested']}")
        print(f"row_count:    {report.get('row_count',0)}")
    if report.get("events_processed") is not None:
        print(f"events:       {report['events_processed']}")
        print(f"pre_cand:     {report.get('pre_candidate_entries',0)}")
        print(f"actions:      {report.get('actions',[])}")
    if report.get("code_count") is not None:
        print(f"codes:        {report['code_count']}")

    if report.get("samples"):
        for i, s in enumerate(report["samples"]):
            print(f"sample[{i}]:    {s}")
    if report.get("errors"):
        for e in report["errors"]:
            print(f"error:        {e}")
    if report.get("error"):
        print(f"fail:         {report.get('error','')}")
    if report.get("blockers"):
        for b in report["blockers"]:
            print(f"blocker:      {b}")


if __name__ == "__main__":
    main()
