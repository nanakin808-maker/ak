"""
Subprocess worker for LegacyScoringExecutor.

Called as a subprocess by LegacyScoringExecutor.execute().
Imports an old project module/callable and calls it safely.
"""

from __future__ import annotations

import argparse
import importlib
import inspect
import json
import sys
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--code", required=True)
    parser.add_argument("--name", default="")
    parser.add_argument("--trading-date", default="")
    parser.add_argument("--source-type", default="")
    parser.add_argument("--source-row-id", type=int, default=None)
    parser.add_argument("--score-stage", default="")
    parser.add_argument("--input-refs-json", default="{}")
    parser.add_argument("--module", default=None)
    parser.add_argument("--callable", default=None, dest="callable_name")
    parser.add_argument("--old-project-root", default=None)
    return parser.parse_args()


def safe_call(fn: Any, code: str, name: str, trading_date: str, input_refs: dict[str, Any]) -> dict[str, Any]:
    sig = inspect.signature(fn)
    params = set(sig.parameters.keys())
    has_var_kw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())

    kwargs: dict[str, Any] = {}

    if "code" in params or has_var_kw:
        kwargs["code"] = code
    if "name" in params or has_var_kw:
        kwargs["name"] = name
    if "trading_date" in params or has_var_kw:
        kwargs["trading_date"] = trading_date
    elif "date" in params or has_var_kw:
        kwargs["date"] = trading_date
    if "input_refs" in params or has_var_kw:
        kwargs["input_refs"] = input_refs
    if "stock" in params or has_var_kw:
        kwargs["stock"] = {"code": code, "name": name}
    if "task" in params or has_var_kw:
        kwargs["task"] = {"code": code, "name": name, "trading_date": trading_date}

    if not kwargs:
        raise TypeError("no supported parameter pattern found in callable signature")

    result = fn(**kwargs)
    if isinstance(result, dict):
        return result
    if hasattr(result, "to_dict"):
        return result.to_dict()
    return {"score": None, "data": result}


def main() -> None:
    args = parse_args()
    original_path = list(sys.path)

    try:
        if args.old_project_root:
            root = str(Path(args.old_project_root).resolve())
            if root not in sys.path:
                sys.path.insert(0, root)

        module_name = args.module
        callable_name = args.callable_name

        if not module_name or not callable_name:
            print(json.dumps({"ok": False, "error": "module and callable required"}))
            return

        module = importlib.import_module(module_name)
        fn = getattr(module, callable_name, None)
        if fn is None:
            print(json.dumps({"ok": False, "error": f"callable {callable_name} not found in {module_name}"}))
            return

        input_refs = {}
        if args.input_refs_json:
            try:
                input_refs = json.loads(args.input_refs_json)
            except json.JSONDecodeError:
                pass

        try:
            result = safe_call(fn, args.code, args.name, args.trading_date, input_refs)
        except TypeError as exc:
            print(json.dumps({"ok": False, "error": f"unsupported_legacy_scoring_signature: {exc}"}))
            return

        print(json.dumps({
            "ok": True,
            "score": result.get("score"),
            "technical_score": result.get("technical_score"),
            "sentiment_score": result.get("sentiment_score"),
            "volume_score": result.get("volume_score"),
            "passed": result.get("passed", False),
            "status": result.get("status", "ready"),
            "reject_reason": result.get("reject_reason", ""),
            "main_logic": result.get("main_logic") or f"{module_name}.{callable_name}",
            "score_json": result.get("score_json") or {},
            "input_refs_json": input_refs,
        }, ensure_ascii=False, default=str))

    except Exception as exc:
        print(json.dumps({
            "ok": False,
            "error": f"{type(exc).__name__}: {exc}",
            "detail": {"module": args.module, "callable": args.callable_name},
        }, ensure_ascii=False, default=str))
    finally:
        sys.path[:] = original_path


if __name__ == "__main__":
    main()
