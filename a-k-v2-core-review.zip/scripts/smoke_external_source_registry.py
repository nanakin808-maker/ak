from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.services.external_source_registry import (
    BlockingMode,
    ExternalSourceKind,
    ExternalSourceRegistration,
    ExternalSourceRegistry,
    SourceChain,
    SourceRequirement,
    default_external_source_registrations,
    probe_legacy_sources,
)


def main() -> None:
    reg = ExternalSourceRegistry()

    # 1. all keys present
    keys = {item.key for item in reg.all()}
    expected = {
        "stock_basic_st", "quote_batch", "speed_rank", "shortline_event",
        "limit_pool", "daily_kline", "intraday", "board_mapping",
        "board_members", "fund_flow", "feishu", "tonghuashun_self_stock",
    }
    missing = expected - keys
    assert not missing, f"missing expected keys: {missing}"

    # 2. required_for_initial_backend
    initial = reg.required_for_initial_backend()
    initial_keys = {item.key for item in initial}
    expected_initial = {
        "stock_basic_st", "quote_batch", "speed_rank", "shortline_event",
        "limit_pool", "daily_kline", "intraday", "board_mapping",
        "board_members", "fund_flow",
    }
    assert initial_keys == expected_initial, f"initial mismatch: {initial_keys - expected_initial} vs {expected_initial - initial_keys}"

    # 3. key constraints
    lp = reg.get("limit_pool")
    assert lp is not None
    assert lp.chain == SourceChain.LIMIT_POOL_SOURCE, f"limit_pool chain: {lp.chain}"
    assert "limit_pool_snapshots" in lp.v2_target or "limit_pool" in lp.v2_target
    assert lp.blocking_mode == BlockingMode.NEVER_BLOCK_LIFECYCLE, f"limit_pool blocking: {lp.blocking_mode}"

    qb = reg.get("quote_batch")
    assert qb is not None
    assert qb.chain == SourceChain.LIFECYCLE, f"quote_batch chain: {qb.chain}"
    assert qb.requirement == SourceRequirement.REQUIRED, f"quote_batch req: {qb.requirement}"

    ff = reg.get("fund_flow")
    assert ff is not None
    assert ff.chain == SourceChain.SCORING, f"fund_flow chain: {ff.chain}"
    assert ff.requirement == SourceRequirement.REQUIRED
    assert ff.blocking_mode != BlockingMode.BLOCKING_ALLOWED, "fund_flow must not be blocking_allowed"

    feishu = reg.get("feishu")
    assert feishu is not None
    assert feishu.requirement == SourceRequirement.EXTERNAL_ACTION

    ths = reg.get("tonghuashun_self_stock")
    assert ths is not None
    assert ths.requirement == SourceRequirement.EXTERNAL_ACTION

    # 4. probe_legacy_sources runs without exception
    old_root = str(ROOT.parent / "a-k")
    if Path(old_root).exists():
        results = probe_legacy_sources(old_project_root=old_root, registry=reg)
        assert len(results) == len(expected), f"probe returned {len(results)}, expected {len(expected)}"
        # check no crash - missing deps are acceptable
        for r in results:
            assert isinstance(r.import_ok, bool)
            assert isinstance(r.callable_found, bool)
    else:
        # old project doesn't exist, probe should still not crash
        probe_legacy_sources(old_project_root=old_root, registry=reg)

    print("External source registry smoke test OK")


if __name__ == "__main__":
    main()
