from __future__ import annotations

import sys
import tempfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.domain.time_scope import MarketSession  # noqa: E402
from app.runtime import RuntimeState  # noqa: E402
from app.services.external_source_runtime import (  # noqa: E402
    ExternalSourceExecutionMode,
    ExternalSourceRuntime,
    ExternalSourceRuntimeFetcher,
    ExternalSourceRuntimeRequest,
)
from app.services.market_source_adapter_service import MarketSourceAdapterService  # noqa: E402
from app.services.provider_bridge_service import ProviderBridgeService  # noqa: E402

FAKE_MODULE = """
from __future__ import annotations
from datetime import datetime

def fetch_speed_rank(requested_trading_date: str):
    return {
        "data": {
            "rows": [
                {
                    "code": "002885",
                    "name": "京泉华",
                    "event_type": "RAPID_RISE",
                    "event_title": "快速拉升",
                    "change_pct": 7.326,
                    "price": 20.0,
                }
            ]
        },
        "source_trading_date": requested_trading_date,
        "source_updated_at": datetime.utcnow().isoformat(),
        "detail": {"fake_old_provider": True},
    }
"""


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        # create fake old module
        provider_dir = Path(tmp) / "astock_guard" / "providers"
        provider_dir.mkdir(parents=True)
        mod_file = provider_dir / "mock_source.py"
        mod_file.write_text(FAKE_MODULE)
        init_file = provider_dir.parent / "__init__.py"
        init_file.write_text("")
        pkg_init = provider_dir.parents[1] / "__init__.py"
        if not pkg_init.exists():
            pkg_init.write_text("")

        now = datetime.utcnow()
        runtime = ExternalSourceRuntime()
        fake_root = str(Path(tmp).resolve())

        # 1. IN_PROCESS
        r1 = runtime.call(ExternalSourceRuntimeRequest(
            source_key="speed_rank", requested_trading_date="2026-05-09",
            module_name="astock_guard.providers.mock_source", callable_name="fetch_speed_rank",
            old_project_root=fake_root, execution_mode=ExternalSourceExecutionMode.IN_PROCESS,
        ))
        assert r1.ok, f"in_process: {r1.error}"
        assert r1.fetch_result is not None
        assert r1.fetch_result.data is not None
        rows = r1.fetch_result.data.get("rows", []) if isinstance(r1.fetch_result.data, dict) else []
        assert len(rows) == 1
        assert rows[0]["code"] == "002885"
        assert r1.fetch_result.source_trading_date == "2026-05-09"

        # 2. SUBPROCESS
        r2 = runtime.call(ExternalSourceRuntimeRequest(
            source_key="speed_rank", requested_trading_date="2026-05-09",
            module_name="astock_guard.providers.mock_source", callable_name="fetch_speed_rank",
            old_project_root=fake_root, execution_mode=ExternalSourceExecutionMode.SUBPROCESS,
        ))
        assert r2.ok, f"subprocess: {r2.error}"
        assert r2.fetch_result is not None
        rows2 = r2.fetch_result.data.get("rows", []) if isinstance(r2.fetch_result.data, dict) else []
        assert len(rows2) == 1
        assert rows2[0]["code"] == "002885"

        # 3. MISSING MODULE
        r3 = runtime.call(ExternalSourceRuntimeRequest(
            source_key="missing", requested_trading_date="2026-05-09",
            module_name="does.not.exist", callable_name="foo",
            execution_mode=ExternalSourceExecutionMode.IN_PROCESS,
        ))
        assert not r3.ok, "missing module should fail"
        assert r3.error != ""

        # 4. DISABLED
        r4 = runtime.call(ExternalSourceRuntimeRequest(
            source_key="test", requested_trading_date="2026-05-09",
            module_name="any", callable_name="any",
            execution_mode=ExternalSourceExecutionMode.DISABLED,
        ))
        assert not r4.ok
        assert r4.error == "external_source_disabled"

        # 5. RuntimeFetcher -> ProviderBridge
        import tempfile as _tmpmod
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        from app.db.init_db import init_db as idb

        with _tmpmod.TemporaryDirectory() as tmp2:
            db = Path(tmp2) / "rt.db"
            eng = create_engine(f"sqlite:///{db}", future=True)
            idb(eng)
            Session = sessionmaker(bind=eng, autoflush=False, autocommit=False, future=True)
            with Session() as session:
                bridge = ProviderBridgeService(session)
                fetcher = ExternalSourceRuntimeFetcher(runtime, ExternalSourceRuntimeRequest(
                    source_key="speed_rank", requested_trading_date="2026-05-09",
                    module_name="astock_guard.providers.mock_source", callable_name="fetch_speed_rank",
                    old_project_root=fake_root, execution_mode=ExternalSourceExecutionMode.IN_PROCESS,
                ))
                r5 = bridge.call(
                    name="mock_old_speed_rank", category="speed_rank",
                    requested_trading_date="2026-05-09",
                    fetcher=lambda: fetcher.fetch(requested_trading_date="2026-05-09"),
                )
                assert r5.ok, f"bridge: {r5.error}"
                assert r5.freshness_status == "fresh"

        # 6. RuntimeFetcher -> MarketSourceAdapter -> PRE_CANDIDATE
        with _tmpmod.TemporaryDirectory() as tmp3:
            db3 = Path(tmp3) / "rt3.db"
            eng3 = create_engine(f"sqlite:///{db3}", future=True)
            idb(eng3)
            Session3 = sessionmaker(bind=eng3, autoflush=False, autocommit=False, future=True)
            with Session3() as session:
                rt = RuntimeState()
                adapter = MarketSourceAdapterService(session, rt)
                r6 = adapter.ingest_event_source(
                    source_type="speed_rank", provider_name="mock_old_speed_rank",
                    requested_trading_date="2026-05-09",
                    fetcher=lambda: fetcher.fetch(requested_trading_date="2026-05-09"),
                    as_of=now, seq_start=1,
                    market_session=MarketSession.TRADING,
                )
                session.commit()
                assert r6.processed == 1, f"adapter: {r6.actions}"
                assert "enter_pre_candidate" in r6.actions, f"adapter actions: {r6.actions}"
                state = rt.get_stock_state("2026-05-09", "002885")
                assert state is not None
                assert state.stage == "PRE_CANDIDATE"

    print("External source runtime smoke test OK")


if __name__ == "__main__":
    main()
