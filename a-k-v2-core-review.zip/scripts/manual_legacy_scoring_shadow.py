"""
Manual script: attempts to run LegacyScoringExecutor against the real old system
on the fixed shadow DB (data/astock_guard_v2_shadow.db).

Usage:
  cd ~/Documents/Codex/2026-04-26/a-k-v2
  uv run --directory backend python3 scripts/manual_legacy_scoring_shadow.py --trading-date 2026-05-09 --limit 5
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
OLD_PROJECT = ROOT.parent / "a-k"
SHADOW_DB = ROOT / "data" / "astock_guard_v2_shadow.db"
OLD_PYTHON = OLD_PROJECT / ".venv" / "bin" / "python3"
sys.path.insert(0, str(BACKEND))

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from app.db.init_db import init_db
from app.db.models import LimitPoolRow, ScoreTaskCurrent, ScoreSnapshot, ScoreTaskCurrent
from app.services.legacy_scoring_executor import LegacyScoringExecutor
from app.services.score_task_service import ScoreTaskService
from app.services.score_worker_service import ScoreWorkerService

PROBE_CONFIGS = [
    ("astock_guard.alerts", "evaluate_stock_score"),
    ("astock_guard.alerts", "AlertEngine.evaluate_stock_score"),
    ("astock_guard.providers.history", "get_kline_score"),
    ("astock_guard.providers.history", "DailyHistoryProvider.get_kline_score"),
]


def probe_old_callable() -> tuple[str, str] | None:
    for mod_name, call in PROBE_CONFIGS:
        parts = call.split(".")
        call_name = parts[-1]
        try:
            mod = __import__(mod_name, fromlist=[call_name])
            fn = getattr(mod, call_name, None)
            if fn is not None and callable(fn):
                return mod_name, call_name
        except Exception:
            continue
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trading-date", default="2026-05-09")
    parser.add_argument("--limit", type=int, default=5)
    args = parser.parse_args()

    if not SHADOW_DB.exists():
        print(f"Shadow DB not found: {SHADOW_DB}")
        print("Run scripts/manual_real_shadow_to_dev_db.py first.")
        return

    if not OLD_PYTHON.exists():
        print(f"Old python not found: {OLD_PYTHON}")
        print("Cannot call old scoring entry point.")
        return

    callable_config = probe_old_callable()
    if callable_config is None:
        print(f"Old python: {OLD_PYTHON}")
        print("Probed configs:")
        for m, c in PROBE_CONFIGS:
            print(f"  {m}.{c}")
        print("Blocker: no old scoring callable is directly importable.")
        print("evaluate_stock_score requires AlertEngine instantiation with many providers.")
        print("get_kline_score requires DailyHistoryProvider with DB path.")
        print("Manual legacy scoring shadow blocked.")
        return

    mod_name, call_name = callable_config
    print(f"Old python:      {OLD_PYTHON}")
    print(f"Callable:        {mod_name}.{call_name}")

    engine = create_engine(f"sqlite:///{SHADOW_DB.resolve()}", future=True)
    Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

    with Session() as session:
        rows = list(session.execute(
            select(LimitPoolRow).where(LimitPoolRow.trading_date == args.trading_date)
            .limit(args.limit)
        ).scalars())

        if not rows:
            print(f"No limit_pool rows found for {args.trading_date}")
            return

        print(f"\nFound {len(rows)} limit_pool rows. Scheduling score tasks...")
        for row in rows:
            ScoreTaskService(session).schedule_for_limit_pool_row(row)
        session.commit()

        pending = list(session.execute(
            select(ScoreTaskCurrent).where(
                ScoreTaskCurrent.trading_date == args.trading_date,
                ScoreTaskCurrent.status == "pending",
            )
        ).scalars())
        print(f"Pending tasks: {len(pending)}")

        executor = LegacyScoringExecutor(
            old_project_root=str(OLD_PROJECT),
            old_python=str(OLD_PYTHON),
            module_name=mod_name,
            callable_name=call_name,
        )
        worker = ScoreWorkerService(session, executor=executor)
        result = worker.process_pending(trading_date=args.trading_date, limit=args.limit)
        session.commit()

        print(f"\nResult: attempted={result.processed} ready={result.ready} failed={result.failed}")

        snaps = list(session.execute(
            select(ScoreSnapshot).where(ScoreSnapshot.trading_date == args.trading_date)
        ).scalars())
        legacy_snaps = [s for s in snaps if s.score_stage == "limit_pool_first_score"]
        print(f"Total score_snapshots: {len(snaps)}")
        print(f"legacy_scoring snapshots: {len(legacy_snaps)}")

        if legacy_snaps:
            s = legacy_snaps[0]
            print(f"  sample: score={s.score} technical={s.technical_score} sentiment={s.sentiment_score}")

        if result.failed > 0:
            failed_tasks = list(session.execute(
                select(ScoreTaskCurrent).where(
                    ScoreTaskCurrent.trading_date == args.trading_date,
                    ScoreTaskCurrent.status == "failed",
                )
            ).scalars())
            for ft in failed_tasks[:3]:
                print(f"  failed: {ft.code} error={ft.last_error[:200]}")


if __name__ == "__main__":
    main()
