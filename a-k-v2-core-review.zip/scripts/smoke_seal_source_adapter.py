from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import (  # noqa: E402
    LimitPoolRow,
    MonitoringStateTransition,
    MonitoringStockState,
    ScoreSnapshot,
)
from app.runtime.candidate_base import CandidateQuoteInput  # noqa: E402
from app.services.limit_pool_ingestion_service import (  # noqa: E402
    LimitPoolIngestionService,
    LimitPoolInputRow,
    LimitPoolInputSnapshot,
)
from app.services.seal_source_adapter_service import SealSourceAdapterService  # noqa: E402


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "seal_source_adapter.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()
        base_date = "2026-05-09"

        # A: quote with reliable 盘口
        q_a = CandidateQuoteInput(
            trading_date=base_date, source_trading_date=base_date,
            code="000001", name="平安银行",
            as_of=now, seq=1, freshness_status="fresh",
            price=11.0, change_pct=10.0,
            is_sealed=False, at_limit=False,
            pre_close=10.0, bid1=11.0, bid_vol1=50000,
            seal_confidence="reliable",
        )
        fact_a = SealSourceAdapterService.from_quote_input(q_a)
        assert fact_a.confidence in ("reliable", "explicit"), f"A: {fact_a.confidence}"
        assert fact_a.is_sealed is True, f"A: expected sealed, got {fact_a.is_sealed}"
        assert fact_a.at_limit is True
        assert fact_a.source_type == "quote_input"
        assert fact_a.limit_price == 11.0, f"A: limit_price={fact_a.limit_price}"

        # B: quote insufficient (no bid fields)
        q_b = CandidateQuoteInput(
            trading_date=base_date, source_trading_date=base_date,
            code="000001", name="平安银行",
            as_of=now, seq=2, freshness_status="fresh",
            price=11.0, change_pct=10.0,
            is_sealed=False, at_limit=False,
            seal_confidence="insufficient",
        )
        fact_b = SealSourceAdapterService.from_quote_input(q_b)
        assert fact_b.confidence == "insufficient", f"B: {fact_b.confidence}"
        assert fact_b.is_sealed is False
        assert fact_b.at_limit is False

        # C + D + E: limit_pool rows via ingestion
        with Session() as session:
            ingestion = LimitPoolIngestionService(session)
            ingestion.ingest_snapshot(
                LimitPoolInputSnapshot(
                    trading_date=base_date, source_trading_date=base_date,
                    source="composite", primary_source="test",
                    as_of=now, seq=10, freshness_status="fresh",
                    market_session="trading",
                    rows=[
                        LimitPoolInputRow(
                            pool="limit_up", code="000001", name="平安银行",
                            source="test", price=11.0, change_pct=10.01,
                            first_limit_time="09:30:00", seal_amount=50000000.0,
                            open_count=0,
                        ),
                        LimitPoolInputRow(
                            pool="open_board", code="600001", name="测试开板",
                            source="test", price=10.5, change_pct=8.5,
                            first_limit_time="10:00:00", open_count=3,
                        ),
                    ],
                )
            )
            # ingest mismatch row
            ingestion.ingest_snapshot(
                LimitPoolInputSnapshot(
                    trading_date="2026-05-10", source_trading_date="2026-05-09",
                    source="composite", primary_source="test",
                    as_of=now, seq=11, freshness_status="mismatch",
                    market_session="closed",
                    rows=[
                        LimitPoolInputRow(
                            pool="limit_up", code="000003", name="mismatch stock",
                            source="test", price=12.0, change_pct=10.02,
                            first_limit_time="11:00:00",
                        ),
                    ],
                )
            )
            session.commit()

            # C: limit_up row
            rows = list(session.execute(
                select(LimitPoolRow).where(LimitPoolRow.pool == "limit_up",
                                           LimitPoolRow.trading_date == base_date)
            ).scalars())
            assert len(rows) >= 1
            fact_c = SealSourceAdapterService.from_limit_pool_row(rows[0])
            assert fact_c.is_sealed is True, f"C: expected sealed"
            assert fact_c.opened is False
            assert fact_c.confidence == "source_fact"
            assert fact_c.reason == "limit_pool_limit_up"
            assert fact_c.seal_volume == 50000000.0

            # D: open_board row
            open_rows = list(session.execute(
                select(LimitPoolRow).where(LimitPoolRow.pool == "open_board",
                                           LimitPoolRow.trading_date == base_date)
            ).scalars())
            assert len(open_rows) >= 1
            fact_d = SealSourceAdapterService.from_limit_pool_row(open_rows[0])
            assert fact_d.is_sealed is False, f"D: expected not sealed"
            assert fact_d.opened is True
            assert fact_d.open_count == 3
            assert fact_d.confidence == "source_fact"
            assert fact_d.reason == "limit_pool_open_board"

            # E: mismatch row
            mismatch_rows = list(session.execute(
                select(LimitPoolRow).where(LimitPoolRow.trading_date == "2026-05-10")
            ).scalars())
            assert len(mismatch_rows) >= 1
            fact_e = SealSourceAdapterService.from_limit_pool_row(mismatch_rows[0])
            assert fact_e.freshness_status == "mismatch", f"E: {fact_e.freshness_status}"
            assert fact_e.is_sealed is True  # limit_up row
            assert fact_e.confidence == "source_fact"

    # no lifecycle side effects from fact creation
    assert True  # fact creation does not write DB

    print("Seal source adapter smoke test OK")


if __name__ == "__main__":
    main()
