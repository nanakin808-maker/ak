#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LOG_DIR="$ROOT/logs/dev_stack"
BACKEND_PID=""
FRONTEND_PID=""
REALTIME_PID=""
BACKEND_PORT="${AG_BACKEND_PORT:-8000}"
FRONTEND_PORT="${AG_FRONTEND_PORT:-5173}"
HOST="${AG_HOST:-127.0.0.1}"
BACKEND_ONLY=false
FRONTEND_ONLY=false
WITH_REALTIME_SCAN=false
REALTIME_DATE="auto"
REALTIME_INTERVAL=10

usage() {
  cat <<EOF
Usage: $0 [options]

Start local dev stack (backend + frontend).

Options:
  --backend-port PORT   Backend port (default: 8000)
  --frontend-port PORT  Frontend port (default: 5173)
  --host HOST           Listen host (default: 127.0.0.1)
  --backend-only        Start only the backend
  --frontend-only       Start only the frontend
  --with-realtime-scan  Start realtime dev scan (default: off)
  --trading-date DATE   Trading date for realtime scan (default: auto)
  --scan-interval N     Scan interval seconds (default: 10)
  --help                Show this help and exit
EOF
  exit 0
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --backend-port) BACKEND_PORT="$2"; shift 2 ;;
    --frontend-port) FRONTEND_PORT="$2"; shift 2 ;;
    --host) HOST="$2"; shift 2 ;;
    --backend-only) BACKEND_ONLY=true; shift ;;
    --frontend-only) FRONTEND_ONLY=true; shift ;;
    --with-realtime-scan) WITH_REALTIME_SCAN=true; shift ;;
    --trading-date) REALTIME_DATE="$2"; shift 2 ;;
    --scan-interval) REALTIME_INTERVAL="$2"; shift 2 ;;
    --help) usage ;;
    *) echo "Unknown option: $1"; usage ;;
  esac
done

cleanup() {
  echo ""
  echo "Shutting down..."
  if [ -n "$BACKEND_PID" ] && kill -0 "$BACKEND_PID" 2>/dev/null; then
    kill "$BACKEND_PID" 2>/dev/null || true
    wait "$BACKEND_PID" 2>/dev/null || true
  fi
  if [ -n "$FRONTEND_PID" ] && kill -0 "$FRONTEND_PID" 2>/dev/null; then
    kill "$FRONTEND_PID" 2>/dev/null || true
    wait "$FRONTEND_PID" 2>/dev/null || true
  fi
  if [ -n "$REALTIME_PID" ] && kill -0 "$REALTIME_PID" 2>/dev/null; then
    kill "$REALTIME_PID" 2>/dev/null || true
    wait "$REALTIME_PID" 2>/dev/null || true
  fi
  echo "Stopped."
}
trap cleanup EXIT INT TERM

check_port() {
  local port="$1" label="$2"
  if lsof -iTCP:"$port" -sTCP:LISTEN -P 2>/dev/null | grep -q .; then
    echo "ERROR: Port $port is already in use ($label). Cannot start."
    exit 1
  fi
}

detect_backend_cmd() {
  if [ -f "$ROOT/backend/.venv/bin/python" ]; then
    echo "$ROOT/backend/.venv/bin/python"
  elif command -v python3 &>/dev/null; then
    echo "python3"
  else
    echo "python"
  fi
}

detect_pkg_manager() {
  if [ -f "$ROOT/frontend/pnpm-lock.yaml" ]; then
    echo "pnpm"
  elif [ -f "$ROOT/frontend/yarn.lock" ]; then
    echo "yarn"
  elif [ -f "$ROOT/frontend/package-lock.json" ] || [ -f "$ROOT/frontend/package.json" ]; then
    echo "npm"
  else
    echo "npm"
  fi
}

FRONTEND_PKG=$(detect_pkg_manager)

PYTHON_CMD=$(detect_backend_cmd)

if [ "$BACKEND_ONLY" = false ] && [ "$FRONTEND_ONLY" = false ]; then
  check_port "$BACKEND_PORT" "backend"
  check_port "$FRONTEND_PORT" "frontend"
elif [ "$BACKEND_ONLY" = true ]; then
  check_port "$BACKEND_PORT" "backend"
elif [ "$FRONTEND_ONLY" = true ]; then
  check_port "$FRONTEND_PORT" "frontend"
fi

mkdir -p "$LOG_DIR"

# ── Backend ──
if [ "$FRONTEND_ONLY" = false ]; then
  echo "Starting backend on $HOST:$BACKEND_PORT (log: $LOG_DIR/backend.log)..."
  cd "$ROOT/backend"
  $PYTHON_CMD -m uvicorn app.main:app \
    --host "$HOST" --port "$BACKEND_PORT" \
    --reload --log-level info \
    > "$LOG_DIR/backend.log" 2>&1 &
  BACKEND_PID=$!
  cd "$ROOT"
fi

# ── Frontend ──
if [ "$BACKEND_ONLY" = false ]; then
  echo "Starting frontend on $HOST:$FRONTEND_PORT (log: $LOG_DIR/frontend.log)..."
  cd "$ROOT/frontend"
  case "$FRONTEND_PKG" in
    pnpm) $FRONTEND_PKG run dev --port "$FRONTEND_PORT" > "$LOG_DIR/frontend.log" 2>&1 & ;;
    yarn) $FRONTEND_PKG run dev --port "$FRONTEND_PORT" > "$LOG_DIR/frontend.log" 2>&1 & ;;
    npm) $FRONTEND_PKG run dev -- --port "$FRONTEND_PORT" > "$LOG_DIR/frontend.log" 2>&1 & ;;
  esac
  FRONTEND_PID=$!
  cd "$ROOT"
fi

# ── Realtime Scan ──
if [ "$WITH_REALTIME_SCAN" = true ] && [ "$FRONTEND_ONLY" = false ]; then
  echo "Starting realtime dev scan (interval: ${REALTIME_INTERVAL}s, date: ${REALTIME_DATE})..."
  echo "  Log: $LOG_DIR/realtime_scan.log"
  cd "$ROOT"
  uv run --directory backend python3 scripts/run_realtime_dev.py \
    --trading-date "$REALTIME_DATE" \
    --interval "$REALTIME_INTERVAL" \
    > "$LOG_DIR/realtime_scan.log" 2>&1 &
  REALTIME_PID=$!
  cd "$ROOT"
fi

# verify backend port is listening
if [ "$FRONTEND_ONLY" = false ]; then
  for _ in $(seq 1 15); do
    if lsof -iTCP:"$BACKEND_PORT" -sTCP:LISTEN -P 2>/dev/null | grep -q .; then
      break
    fi
    sleep 0.5
  done
fi

echo ""
echo "Dev stack started:"
[ "$FRONTEND_ONLY" = false ] && echo "  Backend:  http://$HOST:$BACKEND_PORT"
[ "$WITH_REALTIME_SCAN" = true ] && echo "  Realtime: active (pid $REALTIME_PID)"
[ "$BACKEND_ONLY" = false ] && echo "  Frontend: http://$HOST:$FRONTEND_PORT"
echo "  Logs:     $LOG_DIR"
echo "  PID:      backend=$BACKEND_PID frontend=$FRONTEND_PID"
echo ""
echo "Press Ctrl+C to stop."

wait
