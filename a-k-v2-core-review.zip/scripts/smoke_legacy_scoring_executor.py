from __future__ import annotations

import sys
import tempfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db
from app.db.models import (
    LimitPoolRow,
    MonitoringStateTransition,
    MonitoringStockState,
    ScoreSnapshot,
    ScoreTaskCurrent,
)
from app.services.legacy_scoring_executor import LegacyScoringExecutor
from app.services.limit_pool_ingestion_service import (
    LimitPoolIngestionService,
    LimitPoolInputRow,
    LimitPoolInputSnapshot,
)
from app.services.score_task_service import ScoreTaskService
from app.services.score_worker_service import ScoreWorkerService
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

FAKE_SCORER = """
def evaluate_stock_score(code=None, name=None, trading_date=None, input_refs=None):
    return {
        "score": 87,
        "technical_score": 80,
        "sentiment_score": 90,
        "volume_score": 75,
        "passed": True,
        "reject_reason": "",
        "score_json": {"fake": True, "from": "fake_old_scorer"},
        "main_logic": "fake_old_scorer"
    }
"""


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        # Create fake old module
        fake_root = Path(tmp)
        fake_pkg = fake_root / "fake_old"
        fake_pkg.mkdir(parents=True)
        (fake_pkg / "__init__.py").write_text("")
        (fake_pkg / "scoring.py").write_text(FAKE_SCORER)

        db_path = Path(tmp) / "legacy_exec.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()
        base_date = "2026-05-09"

        # ── Prepare: ingest limit_pool row + schedule task ──
        with Session() as session:
            ingestion = LimitPoolIngestionService(session)
            ingestion.ingest_snapshot(LimitPoolInputSnapshot(
                trading_date=base_date, source_trading_date=base_date,
                source="fake", primary_source="fake",
                as_of=now, seq=1, freshness_status="fresh", market_session="trading",
                rows=[LimitPoolInputRow(pool="limit_up", code="000001", name="平安银行",
                       source="fake", price=10.5, change_pct=10.01,
                       first_limit_time="10:01:00")],
            ))
            session.flush()

            row = list(session.execute(select(LimitPoolRow)).scalars())[0]
            ScoreTaskService(session).schedule_for_limit_pool_row(row)
            session.commit()

        # ── Success path: LegacyScoringExecutor with fake old module ──
        with Session() as session:
            executor = LegacyScoringExecutor(
                old_project_root=str(fake_root),
                old_python=sys.executable,
                module_name="fake_old.scoring",
                callable_name="evaluate_stock_score",
            )
            worker = ScoreWorkerService(session, executor=executor)
            result = worker.process_pending(trading_date=base_date, limit=100)

            assert result.processed == 1, f"processed={result.processed}"
            assert result.ready == 1, f"ready={result.ready}"
            assert result.failed == 0, f"failed={result.failed}"

            # task -> ready
            tasks = list(session.execute(select(ScoreTaskCurrent)).scalars())
            assert len(tasks) == 1
            assert tasks[0].status == "ready", f"status={tasks[0].status}"

            # score_snapshot written
            snaps = list(session.execute(select(ScoreSnapshot)).scalars())
            assert len(snaps) == 1, f"snapshots={len(snaps)}"
            snap = snaps[0]
            assert snap.score == 87, f"score={snap.score}"
            assert snap.technical_score == 80
            assert snap.sentiment_score == 90
            assert snap.volume_score == 75
            assert snap.source_type == "limit_pool_row"
            assert snap.source_row_id is not None

            # No lifecycle side effects
            assert count_(session, MonitoringStockState) == 0
            assert count_(session, MonitoringStateTransition) == 0

            session.commit()

        # ── Failure path: fake callable raises RuntimeError ──
        FAILING_SCORER = """
def evaluate_stock_score(**kwargs):
    raise RuntimeError("mock legacy scoring failure")
"""
        failing_root = Path(tmp)
        failing_pkg = failing_root / "failing_old"
        failing_pkg.mkdir(parents=True)
        (failing_pkg / "__init__.py").write_text("")
        (failing_pkg / "scoring.py").write_text(FAILING_SCORER)

        fail_date = "2026-05-10"
        with Session() as session:
            ingestion = LimitPoolIngestionService(session)
            ingestion.ingest_snapshot(LimitPoolInputSnapshot(
                trading_date=fail_date, source_trading_date=fail_date,
                source="fake", primary_source="fake",
                as_of=now, seq=2, freshness_status="fresh", market_session="trading",
                rows=[LimitPoolInputRow(pool="limit_up", code="000002", name="fail test",
                       source="fake", price=12.0, change_pct=10.0,
                       first_limit_time="11:00:00")],
            ))
            session.flush()
            row2 = list(session.execute(select(LimitPoolRow).where(LimitPoolRow.code == "000002")).scalars())[0]
            ScoreTaskService(session).schedule_for_limit_pool_row(row2)
            session.commit()

        with Session() as session:
            snaps_before = count_(session, ScoreSnapshot)
            failing_exec = LegacyScoringExecutor(
                old_project_root=str(failing_root),
                old_python=sys.executable,
                module_name="failing_old.scoring",
                callable_name="evaluate_stock_score",
            )
            worker2 = ScoreWorkerService(session, executor=failing_exec)
            result2 = worker2.process_pending(trading_date=fail_date, limit=100)

            assert result2.failed == 1, f"failed={result2.failed}"

            fail_tasks = list(
                session.execute(select(ScoreTaskCurrent).where(ScoreTaskCurrent.trading_date == fail_date, ScoreTaskCurrent.code == "000002")).scalars()
            )
            assert len(fail_tasks) == 1
            assert fail_tasks[0].status in ("pending", "failed"), f"status={fail_tasks[0].status}"
            assert fail_tasks[0].last_error is not None
            assert "mock legacy scoring failure" in fail_tasks[0].last_error

            # No new score_snapshot written
            assert count_(session, ScoreSnapshot) == snaps_before

            session.commit()

    print("Legacy scoring executor smoke test OK")


if __name__ == "__main__":
    main()
