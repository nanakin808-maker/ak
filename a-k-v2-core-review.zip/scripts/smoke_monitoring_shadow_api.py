"""
Smoke test for monitoring shadow API.
Skips if data/astock_guard_v2_shadow.db does not exist.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
SHADOW_DB = ROOT / "data" / "astock_guard_v2_shadow.db"
sys.path.insert(0, str(BACKEND))

from app.main import app
from fastapi.testclient import TestClient


def main() -> None:
    if not SHADOW_DB.exists():
        print("Shadow DB not found, skip smoke.")
        return

    client = TestClient(app)

    # overview
    r = client.get("/api/monitoring/shadow/overview")
    assert r.status_code == 200
    data = r.json()
    assert data["data_mode"] == "shadow"
    assert data["scoring_mode"] in ("static_mock", "legacy_full")
    assert data["quote_can_drive_seal"] in (True, False)  # True when orderbook available
    assert "counts" in data
    assert data["counts"]["monitoring_stock_states"] >= 0
    assert data["counts"]["limit_pool_rows"] >= 0
    assert data["counts"]["score_snapshots"] >= 0
    assert data["counts"]["interface_health"] >= 0
    print(f"  overview OK: MSS={data['counts']['monitoring_stock_states']} LP={data['counts']['limit_pool_rows']} SS={data['counts']['score_snapshots']} IH={data['counts']['interface_health']}")

    # stocks
    r = client.get("/api/monitoring/shadow/stocks")
    assert r.status_code == 200
    stocks = r.json()
    assert stocks["data_mode"] == "shadow"
    assert len(stocks["stocks"]) >= 0
    for s in stocks["stocks"]:
        assert "code" in s
        assert "stage" in s
        assert "active_monitoring" in s
        assert "latest_score_snapshot" in s or "latest_score_snapshot" in s
    print(f"  stocks OK: {len(stocks['stocks'])} rows")

    # limit-pool
    r = client.get("/api/monitoring/shadow/limit-pool")
    assert r.status_code == 200
    lp = r.json()
    assert lp["data_mode"] == "shadow"
    assert lp["snapshot"] is not None
    assert len(lp["rows"]) >= 1
    print(f"  limit-pool OK: snapshot_id={lp['snapshot']['id']} rows={len(lp['rows'])}")

    # scores
    r = client.get("/api/monitoring/shadow/scores")
    assert r.status_code == 200
    scores = r.json()
    assert scores["data_mode"] == "shadow"
    assert len(scores["scores"]) >= 1
    limit_pool_scores = [s for s in scores["scores"] if s["scoring_mode"] == "static_mock"]
    assert len(limit_pool_scores) >= 1
    for sc in limit_pool_scores:
        assert sc["technical_score"] == 80.0
        assert sc["sentiment_score"] == 90.0
    print(f"  scores OK: {len(scores['scores'])} total, {len(limit_pool_scores)} static_mock")

    # interface-health
    r = client.get("/api/monitoring/shadow/interface-health")
    assert r.status_code == 200
    ih = r.json()
    assert ih["data_mode"] == "shadow"
    assert len(ih["records"]) >= 0
    print(f"  interface-health OK: {len(ih['records'])} records")

    print("Monitoring shadow API smoke test OK")


if __name__ == "__main__":
    main()
