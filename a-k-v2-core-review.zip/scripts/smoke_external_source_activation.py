from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import ExternalSourceActivationCurrent  # noqa: E402
from app.services.external_source_activation_service import (  # noqa: E402
    ExternalSourceActivationService,
    SourceActivationState,
)
from app.services.provider_bridge_service import ProviderCallResult  # noqa: E402


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "activation.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        base_date = "2026-05-09"
        now = datetime.utcnow()

        # A: default shadow state
        with Session() as session:
            svc = ExternalSourceActivationService(session)
            row = svc.repo.get_or_create(source_key="speed_rank", trading_date=base_date)
            session.flush()
            assert row.state == "shadow"
            assert row.business_enabled is False
            assert row.shadow_only is True

            dec = svc.can_call(source_key="speed_rank", trading_date=base_date)
            assert dec.allowed_to_call is True, f"A: {dec.reason}"
            assert dec.allowed_for_business is False

            biz = svc.can_use_for_business(source_key="speed_rank", trading_date=base_date, freshness_status="fresh", data={"rows": [1]})
            assert biz.allowed_for_business is False, "shadow must not allow business"

            session.commit()

        # B: probe_only prevents real calls
        with Session() as session:
            svc = ExternalSourceActivationService(session)
            svc.set_state(source_key="test_probe", trading_date=base_date, state=SourceActivationState.PROBE_ONLY, reason="under_investigation")
            session.commit()

            dec = svc.can_call(source_key="test_probe", trading_date=base_date)
            assert dec.allowed_to_call is False, f"B: {dec.reason}"
            assert dec.reason == "probe_only_no_real_call"

        # C: candidate/active unlock business, subject to fresh + non-empty
        with Session() as session:
            svc = ExternalSourceActivationService(session)

            # candidate state
            svc.set_state(source_key="test_candidate", trading_date=base_date, state=SourceActivationState.CANDIDATE, reason="promoted")
            session.flush()

            # fresh + non-empty -> allowed
            session.flush()
            biz1 = svc.can_use_for_business(source_key="test_candidate", trading_date=base_date, freshness_status="fresh", data={"rows": [1]})
            assert biz1.allowed_for_business is True, f"C1: {biz1.reason}"

            # mismatch + non-empty -> not allowed
            biz2 = svc.can_use_for_business(source_key="test_candidate", trading_date=base_date, freshness_status="mismatch", data={"rows": [1]})
            assert biz2.allowed_for_business is False, f"C2: {biz2.reason}"
            assert biz2.reason == "freshness_not_fresh"

            # fresh + empty -> not allowed
            biz3 = svc.can_use_for_business(source_key="test_candidate", trading_date=base_date, freshness_status="fresh", data={})
            assert biz3.allowed_for_business is False, f"C3: {biz3.reason}"
            assert biz3.reason == "empty_data"

            session.commit()

        # D: consecutive failures trigger circuit_open
        with Session() as session:
            svc = ExternalSourceActivationService(session)

            for _ in range(3):
                svc.record_call_result(
                    source_key="test_circuit", trading_date=base_date,
                    result=ProviderCallResult(name="test", category="test", ok=False, data=None,
                        requested_trading_date=base_date, source_trading_date=base_date,
                        freshness_status="unknown", as_of=now, latency_ms=100.0, error="mock fail"),
                )
            session.commit()

            row = svc.repo.get(source_key="test_circuit", trading_date=base_date)
            assert row is not None
            assert row.state == SourceActivationState.CIRCUIT_OPEN.value, f"D: state={row.state}"
            assert row.business_enabled is False
            assert row.shadow_only is True
            assert row.consecutive_failures == 3
            assert row.circuit_open_until is not None

            dec = svc.can_call(source_key="test_circuit", trading_date=base_date)
            assert dec.allowed_to_call is False, f"D: {dec.reason}"

            session.commit()

        # E: circuit expires -> degraded
        with Session() as session:
            svc = ExternalSourceActivationService(session)
            future = now + timedelta(hours=1)  # after circuit_open_until

            dec = svc.can_call(source_key="test_circuit", trading_date=base_date, now=future)
            assert dec.allowed_to_call is True, f"E: {dec.reason}"
            assert dec.state == SourceActivationState.DEGRADED.value, f"E: state={dec.state}"

            biz = svc.can_use_for_business(source_key="test_circuit", trading_date=base_date, freshness_status="fresh", data={"rows": [1]})
            assert biz.allowed_for_business is False, "E: degraded must not allow business"

            session.commit()

        # F: successful call records stats
        with Session() as session:
            svc = ExternalSourceActivationService(session)
            svc.set_state(source_key="test_stats", trading_date=base_date, state=SourceActivationState.CANDIDATE, reason="test")
            session.flush()

            for _ in range(5):
                svc.record_call_result(
                    source_key="test_stats", trading_date=base_date,
                    result=ProviderCallResult(name="stats_test", category="test", ok=True, data={"rows": [1]},
                        requested_trading_date=base_date, source_trading_date=base_date,
                        freshness_status="fresh", as_of=now, latency_ms=50.0, detail={"mock": True}),
                )
            session.commit()

            row = svc.repo.get(source_key="test_stats", trading_date=base_date)
            assert row is not None
            assert row.total_calls == 5
            assert row.ok_calls == 5
            assert row.fail_calls == 0
            assert row.last_freshness_status == "fresh"
            assert row.last_latency_ms == 50.0
            assert row.consecutive_failures == 0

    print("External source activation smoke test OK")


if __name__ == "__main__":
    main()
