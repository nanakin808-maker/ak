"""
Comprehensive A-stock orderbook API test.

Tests all known free real-time quote sources for bid_vol/ask_vol data.
Safe: read-only HTTP GET + TCP connect, no writes, no auth required.

Usage:
  python3 scripts/test_orderbook_sources.py [--codes 000001,600519] [--timeout 5]
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any

# ── stock codes for testing ──────────────────────────────
# Mix of main board (0/6), growth/STAR (3/688)
DEFAULT_CODES = [
    "000001",  # 平安银行 — main board
    "600519",  # 贵州茅台 — main board, always active
    "300750",  # 宁德时代 — ChiNext
    "002108",  # 沧州明珠 — main board (has limit-up events)
    "688981",  # 中芯国际 — STAR
]

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"


@dataclass
class TestResult:
    source: str
    url_template: str = ""
    ok: bool = False
    latency_ms: float = 0
    codes_tested: int = 0
    codes_with_price: int = 0
    codes_with_bid_vol1: int = 0
    codes_with_ask_vol1: int = 0
    error: str = ""
    sample: dict[str, Any] = field(default_factory=dict)
    notes: str = ""


# ═══════════════════════════════════════════════════════════
# 1. Sina (新浪)
# ═══════════════════════════════════════════════════════════

def _sina_symbol(code: str) -> str:
    c = code.strip().zfill(6)[-6:]
    if c.startswith("6"):
        return f"sh{c}"
    if c.startswith("8") or c.startswith("4"):
        return f"bj{c}"
    return f"sz{c}"


def test_sina(codes: list[str], timeout: float) -> TestResult:
    r = TestResult(source="sina", url_template="https://hq.sinajs.cn/list={symbols}")
    symbols = [_sina_symbol(c) for c in codes]
    url = "https://hq.sinajs.cn/list=" + ",".join(symbols)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": "https://finance.sina.com.cn/"})
    try:
        t0 = time.perf_counter()
        resp = urllib.request.urlopen(req, timeout=timeout)
        body = resp.read().decode("gbk", errors="replace")
        r.latency_ms = (time.perf_counter() - t0) * 1000
    except Exception as exc:
        r.error = str(exc)
        return r

    r.ok = True
    for code in codes:
        sym = _sina_symbol(code)
        prefix = f'var hq_str_{sym}="'
        if prefix not in body:
            continue
        r.codes_tested += 1
        start = body.index(prefix) + len(prefix)
        end = body.index('"', start)
        parts = body[start:end].split(",")
        if len(parts) < 32:
            continue
        price = _float(parts[3])
        if not price:
            continue
        r.codes_with_price += 1
        bid_vol1 = _float(parts[10]) // 100 if len(parts) > 10 else 0
        ask_vol1 = _float(parts[20]) // 100 if len(parts) > 20 else 0
        if bid_vol1 > 0:
            r.codes_with_bid_vol1 += 1
        if ask_vol1 > 0:
            r.codes_with_ask_vol1 += 1
        if code == codes[0]:
            r.sample = {
                "code": parts[0],
                "name": parts[0],
                "price": price,
                "bid1": _float(parts[6]),
                "bid_vol1": bid_vol1,
                "ask1": _float(parts[7]),
                "ask_vol1": ask_vol1,
            }
    return r


# ═══════════════════════════════════════════════════════════
# 2. Tencent (腾讯)
# ═══════════════════════════════════════════════════════════

def _tencent_symbol(code: str) -> str:
    c = code.strip().zfill(6)[-6:]
    if c.startswith("6"):
        return f"sh{c}"
    if c.startswith("8") or c.startswith("4"):
        return f"bj{c}"
    return f"sz{c}"


def test_tencent(codes: list[str], timeout: float) -> TestResult:
    r = TestResult(source="tencent", url_template="https://qt.gtimg.cn/q={symbols}")
    symbols = [_tencent_symbol(c) for c in codes]
    url = "https://qt.gtimg.cn/q=" + ",".join(symbols)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        t0 = time.perf_counter()
        resp = urllib.request.urlopen(req, timeout=timeout)
        body = resp.read().decode("gbk", errors="replace")
        r.latency_ms = (time.perf_counter() - t0) * 1000
    except Exception as exc:
        r.error = str(exc)
        return r

    r.ok = True
    lines = body.strip().split(";")
    for line in lines:
        if '="' not in line:
            continue
        raw = line.split('="', 1)[1].rstrip('"')
        parts = raw.split("~")
        if len(parts) < 50:
            continue
        code = parts[2]
        if code not in codes:
            continue
        r.codes_tested += 1
        price = _float(parts[3])
        if not price:
            continue
        r.codes_with_price += 1
        bid_vol1 = _float(parts[10]) if len(parts) > 10 else 0
        ask_vol1 = _float(parts[20]) if len(parts) > 20 else 0
        if bid_vol1 > 0:
            r.codes_with_bid_vol1 += 1
        if ask_vol1 > 0:
            r.codes_with_ask_vol1 += 1
        if code == codes[0]:
            r.sample = {
                "code": code,
                "name": parts[1],
                "price": price,
                "bid1": _float(parts[9]) if len(parts) > 9 else None,
                "bid_vol1": bid_vol1,
                "ask1": _float(parts[19]) if len(parts) > 19 else None,
                "ask_vol1": ask_vol1,
            }
    return r


# ═══════════════════════════════════════════════════════════
# 3. Eastmoney (东方财富) — for comparison
# ═══════════════════════════════════════════════════════════

def _em_secid(code: str) -> str:
    c = code.strip().zfill(6)[-6:]
    if c.startswith("6"):
        return f"1.{c}"
    return f"0.{c}"


def test_eastmoney(codes: list[str], timeout: float) -> TestResult:
    r = TestResult(source="eastmoney", url_template="https://push2.eastmoney.com/api/qt/stock/get?secid={secid}&fields=f43,f60,f46,f51")
    for code in codes:
        secid = _em_secid(code)
        url = (
            f"https://push2.eastmoney.com/api/qt/stock/get?"
            f"ut=fa5fd1943c7b386f172d6893dbfb2dc6"
            f"&invt=2&fltt=2&fields=f43,f57,f58,f46,f51,f47,f48,f60,f169,f170"
            f"&secid={secid}"
        )
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": "https://quote.eastmoney.com/"})
        try:
            t0 = time.perf_counter()
            resp = urllib.request.urlopen(req, timeout=timeout)
            data = json.loads(resp.read().decode())
            r.latency_ms += (time.perf_counter() - t0) * 1000
        except Exception as exc:
            if not r.error:
                r.error = str(exc)
            continue

        d = (data.get("data") or {})
        if not d:
            continue
        r.codes_tested += 1
        price = _float(d.get("f43"))
        if not price:
            continue
        r.codes_with_price += 1
        bid_vol1 = _float(d.get("f46"))
        ask_vol1 = _float(d.get("f51"))
        if bid_vol1 and bid_vol1 > 0:
            r.codes_with_bid_vol1 += 1
        if ask_vol1 and ask_vol1 > 0:
            r.codes_with_ask_vol1 += 1
        if code == codes[0]:
            r.sample = {
                "code": str(d.get("f57", "")),
                "name": str(d.get("f58", "")),
                "price": price,
                "bid1": None,
                "bid_vol1": bid_vol1,
                "ask1": None,
                "ask_vol1": ask_vol1,
            }
    if r.codes_tested > 1:
        r.latency_ms = r.latency_ms / r.codes_tested
    r.ok = r.codes_tested > 0
    return r


# ═══════════════════════════════════════════════════════════
# 4. Netease/163 — alternate source
# ═══════════════════════════════════════════════════════════

def _163_symbol(code: str) -> str:
    c = code.strip().zfill(6)[-6:]
    if c.startswith("6"):
        return f"0{c}"
    if c.startswith("3") or c.startswith("0"):
        return f"1{c}"
    return f"0{c}"


def test_163(codes: list[str], timeout: float) -> TestResult:
    r = TestResult(source="163", url_template="https://api.money.126.net/data/feed/{symbol}")
    for code in codes:
        sym = _163_symbol(code)
        url = f"https://api.money.126.net/data/feed/{sym}"
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        try:
            t0 = time.perf_counter()
            resp = urllib.request.urlopen(req, timeout=timeout)
            raw = resp.read().decode("utf-8", errors="replace")
            r.latency_ms += (time.perf_counter() - t0) * 1000
        except Exception as exc:
            if not r.error:
                r.error = str(exc)
            continue

        # Format: _ntes_quote_callback1234({...});
        raw = raw.strip()
        if raw.startswith("_ntes_quote_callback"):
            raw = raw[raw.index("(") + 1 : raw.rindex(")")]
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            continue

        item = data.get(sym) or {}
        if not item:
            continue
        r.codes_tested += 1
        price = _float(item.get("price"))
        if not price:
            continue
        r.codes_with_price += 1
        bid_vol1 = _float(item.get("bid_vol1")) or _float(item.get("bidvol1"))
        ask_vol1 = _float(item.get("ask_vol1")) or _float(item.get("askvol1"))
        if bid_vol1 and bid_vol1 > 0:
            r.codes_with_bid_vol1 += 1
        if ask_vol1 and ask_vol1 > 0:
            r.codes_with_ask_vol1 += 1
        if code == codes[0]:
            r.sample = {
                "code": item.get("code") or item.get("symbol", ""),
                "name": item.get("name", ""),
                "price": price,
                "bid1": _float(item.get("bid1")) or _float(item.get("buy1")),
                "bid_vol1": bid_vol1,
                "ask1": _float(item.get("ask1")) or _float(item.get("sell1")),
                "ask_vol1": ask_vol1,
            }
    if r.codes_tested > 1:
        r.latency_ms = r.latency_ms / max(1, r.codes_tested)
    r.ok = r.codes_tested > 0
    return r


# ═══════════════════════════════════════════════════════════
# 5. Sohu — legacy source
# ═══════════════════════════════════════════════════════════

def test_sohu(codes: list[str], timeout: float) -> TestResult:
    r = TestResult(source="sohu", url_template="https://hq.stock.sohu.com/cn/{code}.html")
    # Sohu uses individual page per stock — try API endpoint
    for code in codes:
        c = code.strip().zfill(6)[-6:]
        prefix = "cn_" if not c.startswith("6") else "cn_"
        url = f"https://q.stock.sohu.com/hisHq?code={prefix}{c}&start=20260501&end=20260511"
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        try:
            t0 = time.perf_counter()
            resp = urllib.request.urlopen(req, timeout=timeout)
            data = json.loads(resp.read().decode())
            r.latency_ms += (time.perf_counter() - t0) * 1000
        except Exception as exc:
            if not r.error:
                r.error = str(exc)
            continue
        # This endpoint only gives historical, not realtime orderbook
        r.notes = "historical only, no realtime orderbook"
    if r.codes_tested > 1:
        r.latency_ms = r.latency_ms / max(1, r.codes_tested)
    r.ok = r.codes_tested > 0
    return r


# ═══════════════════════════════════════════════════════════
# 6. PyTDX (通达信 TCP) — requires pytdx package
# ═══════════════════════════════════════════════════════════

def test_pytdx(codes: list[str], timeout: float) -> TestResult:
    r = TestResult(source="pytdx", url_template="TCP: 通达信行情服务器:7709")
    try:
        from pytdx.hq import TdxHq_API
    except ImportError:
        r.error = "pytdx not installed"
        r.notes = "pip install pytdx"
        return r

    servers = [
        ("180.153.18.170", 7709),
        ("115.238.90.165", 7709),
        ("218.75.126.9", 7709),
        ("60.191.117.167", 7709),
    ]

    for host, port in servers:
        api = TdxHq_API(heartbeat=True, auto_retry=False, raise_exception=False)
        try:
            t0 = time.perf_counter()
            if not api.connect(host, port, time_out=timeout):
                r.error = f"{host}:{port} connection refused"
                continue
            r.latency_ms = (time.perf_counter() - t0) * 1000
            r.ok = True

            for code in codes:
                c = code.strip().zfill(6)[-6:]
                market = 1 if c.startswith("6") else 0
                quotes = api.get_security_quotes([(market, c)])
                if not quotes or len(quotes) == 0:
                    continue
                q = quotes[0]
                r.codes_tested += 1
                price = _float(q.get("price"))
                if not price:
                    continue
                r.codes_with_price += 1
                bid_vol1 = _float(q.get("bid_vol1")) or _float(q.get("buy1_vol"))
                ask_vol1 = _float(q.get("ask_vol1")) or _float(q.get("sell1_vol"))
                if bid_vol1 and bid_vol1 > 0:
                    r.codes_with_bid_vol1 += 1
                if ask_vol1 and ask_vol1 > 0:
                    r.codes_with_ask_vol1 += 1
                if code == codes[0]:
                    r.sample = {k: str(v) for k, v in q.items() if v is not None}
            break  # server worked, stop trying
        except Exception as exc:
            r.error = f"{host}:{port} — {exc}"
        finally:
            try:
                api.disconnect()
            except Exception:
                pass

    return r


# ═══════════════════════════════════════════════════════════
# 7. Sina alternate — direct orderbook endpoint
# ═══════════════════════════════════════════════════════════

def test_sina_orderbook(codes: list[str], timeout: float) -> TestResult:
    """Test Sina's dedicated orderbook endpoint (may have more fields)."""
    r = TestResult(source="sina_orderbook", url_template="https://hq.sinajs.cn/list={symbols}")
    # Sina's detailed quote endpoint
    for code in codes:
        sym = _sina_symbol(code)
        # Try the detailed quote endpoint
        url = f"https://hq.sinajs.cn/list={sym}"
        req = urllib.request.Request(url, headers={
            "User-Agent": UA,
            "Referer": "https://finance.sina.com.cn/",
        })
        try:
            t0 = time.perf_counter()
            resp = urllib.request.urlopen(req, timeout=timeout)
            body = resp.read().decode("gbk", errors="replace")
            r.latency_ms += (time.perf_counter() - t0) * 1000
        except Exception as exc:
            if not r.error:
                r.error = str(exc)
            continue

        if '="' not in body:
            continue
        raw = body.split('="', 1)[1].rstrip('"')
        parts = raw.split(",")
        if len(parts) < 32:
            continue
        r.codes_tested += 1
        price = _float(parts[3])
        if not price:
            continue
        r.codes_with_price += 1
        # Sina: parts[10-19] are bid1-bid5 volumes, parts[20-29] are ask1-ask5 volumes
        bid_vol1 = _float(parts[10]) // 100 if len(parts) > 10 else 0
        ask_vol1 = _float(parts[20]) // 100 if len(parts) > 20 else 0
        if bid_vol1 > 0:
            r.codes_with_bid_vol1 += 1
        if ask_vol1 > 0:
            r.codes_with_ask_vol1 += 1
        if code == codes[0]:
            r.sample = {
                "code": code,
                "name": parts[0],
                "price": price,
                "bid_prices": [parts[i] for i in range(6, 16) if i < len(parts)],
                "bid_volumes": [_float(parts[i]) // 100 for i in range(10, 20) if i < len(parts)],
                "ask_prices": [parts[i] for i in range(16, 26) if i < len(parts)],
                "ask_volumes": [_float(parts[i]) // 100 for i in range(20, 30) if i < len(parts)],
            }
    if r.codes_tested > 1:
        r.latency_ms = r.latency_ms / max(1, r.codes_tested)
    r.ok = r.codes_tested > 0
    return r


# ═══════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════

def _float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        v = float(value)
        return v if v > -1e10 else None  # filter sentinel
    except (TypeError, ValueError):
        return None


# ═══════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════

def main() -> None:
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--codes", default="000001,600519,300750,002108,688981")
    p.add_argument("--timeout", type=float, default=5.0)
    args = p.parse_args()

    codes = [c.strip() for c in args.codes.split(",") if c.strip()]

    print(f"=== A-Stock Orderbook Source Test ===")
    print(f"  codes: {codes}")
    print(f"  timeout: {args.timeout}s")
    print(f"  time: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print()

    tests = [
        ("tencent", test_tencent),
        ("sina", test_sina_orderbook),
        ("eastmoney", test_eastmoney),
        ("163", test_163),
        ("sohu", test_sohu),
        ("pytdx", test_pytdx),
    ]

    results: list[TestResult] = []
    for name, fn in tests:
        print(f"Testing {name:15s} ...", end=" ", flush=True)
        r = fn(codes, args.timeout)
        results.append(r)
        if r.ok:
            status = f"OK ({r.latency_ms:.0f}ms, {r.codes_with_price}/{r.codes_tested} price"
            if r.codes_with_bid_vol1 > 0 or r.codes_with_ask_vol1 > 0:
                status += f", bid_vol={r.codes_with_bid_vol1}/{r.codes_tested}, ask_vol={r.codes_with_ask_vol1}/{r.codes_tested}"
            status += ")"
        else:
            status = f"FAIL — {r.error[:80]}"
        print(status)
        if r.notes:
            print(f"                    note: {r.notes}")

    # Summary table
    print(f"\n{'='*80}")
    print(f"{'Source':<16} {'Status':<6} {'Latency':<10} {'Price':<8} {'BidVol':<8} {'AskVol':<8} {'CanSeal?':<10}")
    print(f"{'-'*80}")
    for r in results:
        can_seal = "YES" if (r.codes_with_bid_vol1 >= r.codes_tested * 0.5) else ("MAYBE" if r.codes_with_bid_vol1 > 0 else "NO")
        status = "OK" if r.ok else "FAIL"
        print(f"{r.source:<16} {status:<6} {r.latency_ms:>6.0f}ms   {r.codes_with_price}/{r.codes_tested:<6} {r.codes_with_bid_vol1}/{r.codes_tested:<6} {r.codes_with_ask_vol1}/{r.codes_tested:<6} {can_seal:<10}")
    print(f"{'='*80}")

    # Sample data from best source
    for r in results:
        if r.sample:
            print(f"\n--- {r.source} sample ---")
            for k, v in r.sample.items():
                print(f"  {k}: {v}")
            break

    # Recommendation
    seal_sources = [r for r in results if r.ok and r.codes_with_bid_vol1 >= r.codes_tested * 0.5]
    if seal_sources:
        print(f"\n✅ 可用于封板判断的源: {', '.join(r.source for r in seal_sources)}")
    else:
        print(f"\n⚠️  当前非交易时段，无可用于封板判断的盘口源。需在 TRADING 时段重测。")
        partial = [r for r in results if r.ok and r.codes_with_bid_vol1 > 0]
        if partial:
            print(f"   部分可用的源: {', '.join(r.source for r in partial)}")
        ok_sources = [r for r in results if r.ok and r.codes_with_price > 0]
        if ok_sources:
            print(f"   仅价/涨幅可用的源: {', '.join(r.source for r in ok_sources)}")


if __name__ == "__main__":
    main()
