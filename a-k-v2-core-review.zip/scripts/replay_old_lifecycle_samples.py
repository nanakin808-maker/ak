"""
Replay old DB lifecycle samples against v2 CandidateLifecycleService.

Reads ../a-k/data/astock_guard.db (readonly), replays 002885 lifecycle scenario
into a temporary v2 SQLite database, and verifies 603050 score_snapshot guard.

This script is NOT part of verify_v2_stack.py because it depends on the
old system's SQLite database (../a-k/data/astock_guard.db).
"""

from __future__ import annotations

import sqlite3
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

from sqlalchemy import create_engine, inspect, select
from sqlalchemy.orm import sessionmaker

# ---- v2 imports -------------------------------------------------
ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
OLD_DB = ROOT.parent / "a-k" / "data" / "astock_guard.db"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import (  # noqa: E402
    MonitoringStateTransition,
    MonitoringStockState,
    ScoreSnapshot,
)
from app.runtime import (  # noqa: E402
    CandidateEntryInput,
    CandidateLifecycleService,
    CandidateQuoteInput,
    RuntimeState,
)

# ---- helpers -----------------------------------------------------


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


# ====================================================================
# Sample 1: 002885 京泉华 / 2026-05-06 — full lifecycle replay
# ====================================================================
def replay_sample_002885() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "v2_replay.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()
        base_date = "2026-05-06"

        with Session() as session:
            runtime = RuntimeState()
            lifecycle = CandidateLifecycleService(session, runtime)

            # --- step 1: enter_pre_candidate (11:18:42) ---
            t1 = now - timedelta(hours=12)  # 11:18 UTC offsets
            r1 = lifecycle.enter_pre_candidate(
                CandidateEntryInput(
                    trading_date=base_date,
                    source_trading_date=base_date,
                    code="002885",
                    name="京泉华",
                    event_type="RAPID_RISE",
                    event_source="eastmoney_changes",
                    event_title="快速拉升",
                    event_time="11:18:42",
                    price=33.55,
                    change_pct=7.326,
                    as_of=t1,
                    seq=1,
                    freshness_status="fresh",
                    raw_json='{"mock": "replay_002885"}',
                )
            )
            session.flush()
            assert r1.action == "enter_pre_candidate", f"002885 step1: {r1.action}"
            assert r1.stage == "PRE_CANDIDATE"

            s1 = lifecycle.monitoring.get_stock_state(base_date, "002885")
            assert s1 is not None and s1.stage == "PRE_CANDIDATE"
            assert s1.active_monitoring is True

            # --- step 2: promote_pre_to_candidate (12:21:17) ---
            t2 = now - timedelta(hours=11, minutes=39)
            r2 = lifecycle.promote_pre_to_candidate(
                trading_date=base_date,
                source_trading_date=base_date,
                code="002885",
                name="京泉华",
                as_of=t2,
                seq=2,
                freshness_status="fresh",
                price=33.8,
                change_pct=7.5,
                reason="history_ready",
            )
            session.flush()
            assert r2.action == "promote_candidate", f"002885 step2: {r2.action}"
            assert r2.stage == "CANDIDATE"

            s2 = lifecycle.monitoring.get_stock_state(base_date, "002885")
            assert s2 is not None and s2.stage == "CANDIDATE"
            assert s2.candidate_at is not None
            assert s2.active_monitoring is True
            # manually set candidate_at to match old repo timestamp
            s2.candidate_at = t2
            session.flush()

            # --- step 3: drop_stale_candidate (12:31:18) ---
            t3 = now - timedelta(hours=11, minutes=29)
            r3 = lifecycle.drop_stale_candidate(
                CandidateQuoteInput(
                    trading_date=base_date,
                    source_trading_date=base_date,
                    code="002885",
                    name="京泉华",
                    as_of=t3,
                    seq=3,
                    freshness_status="fresh",
                    price=33.5,
                    change_pct=2.0,  # below candidate_min_active_pct
                    technical_score=65.0,
                    sentiment_score=53.0,
                    volume_score=63.0,
                ),
                candidate_stale_minutes=5.0,
                candidate_min_active_pct=5.0,
            )
            session.flush()
            assert r3.action == "candidate_removed", f"002885 step3: {r3.action}"
            assert r3.stage == "PRE_CANDIDATE"

            session.commit()

        # ---- assertions after full replay ----
        with Session() as session:
            # final state
            final_state = session.execute(
                select(MonitoringStockState).where(
                    MonitoringStockState.trading_date == base_date,
                    MonitoringStockState.code == "002885",
                )
            ).scalar_one_or_none()
            assert final_state is not None, "002885: final state not found"
            assert final_state.stage == "PRE_CANDIDATE", (
                f"002885: expected PRE_CANDIDATE, got {final_state.stage}"
            )
            assert final_state.active_monitoring is False
            assert final_state.inactive_reason == "candidate_weak_removed"

            # no CORE, no REJECTED_TODAY
            core_transitions = list(
                session.execute(
                    select(MonitoringStateTransition).where(
                        MonitoringStateTransition.trading_date == base_date,
                        MonitoringStateTransition.code == "002885",
                        MonitoringStateTransition.to_stage == "CORE",
                    )
                ).scalars()
            )
            assert len(core_transitions) == 0, "002885: must not have CORE transition"

            rejected = session.execute(
                select(MonitoringStockState).where(
                    MonitoringStockState.trading_date == base_date,
                    MonitoringStockState.code == "002885",
                    MonitoringStockState.stage == "REJECTED_TODAY",
                )
            ).scalar_one_or_none()
            assert rejected is None, "002885: must not be REJECTED_TODAY"

            # score_snapshots: pre_candidate, candidate, candidate_removed
            score_stages = {
                row.score_stage
                for row in session.execute(
                    select(ScoreSnapshot).where(
                        ScoreSnapshot.trading_date == base_date,
                        ScoreSnapshot.code == "002885",
                    )
                ).scalars()
            }
            assert "pre_candidate" in score_stages, f"002885: missing pre_candidate, got {score_stages}"
            assert "candidate" in score_stages, f"002885: missing candidate, got {score_stages}"
            assert "candidate_removed" in score_stages, f"002885: missing candidate_removed, got {score_stages}"

            # transitions: PRE_CANDIDATE -> CANDIDATE and CANDIDATE -> PRE_CANDIDATE
            transitions = list(
                session.execute(
                    select(MonitoringStateTransition).where(
                        MonitoringStateTransition.trading_date == base_date,
                        MonitoringStateTransition.code == "002885",
                    )
                ).scalars()
            )
            from_to = {(t.from_stage, t.to_stage) for t in transitions}
            assert ("PRE_CANDIDATE", "CANDIDATE") in from_to, f"002885: missing CANDIDATE promotion, got {from_to}"
            assert ("CANDIDATE", "PRE_CANDIDATE") in from_to, f"002885: missing candidate_removed transition, got {from_to}"

    print("Old lifecycle replay sample 002885 OK")


# ====================================================================
# Sample 2: 603050 科林电气 / 2026-05-06 — score_snapshot lifecycle guard
# ====================================================================
def guard_sample_603050() -> None:
    if not OLD_DB.exists():
        print("Old DB not found at", OLD_DB, "- skip 603050 guard")
        return

    conn = sqlite3.connect(f"file:{OLD_DB.resolve()}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row

    try:
        # read score_snapshots
        ss_rows = conn.execute(
            """
            select stage, source_area, snapshot_time, technical_score, sentiment_score, volume_score
            from score_snapshots
            where code = '603050' and trade_date = '2026-05-06'
            order by snapshot_time
            """
        ).fetchall()

        stages = {r["stage"] for r in ss_rows}
        required_stages = {"candidate", "seal", "open_board", "feishu_notify"}
        missing = required_stages - stages
        assert not missing, f"603050: score_snapshots missing stages: {missing}. Got: {stages}"

        # read daily_stock_state
        ds = conn.execute(
            """
            select in_core, in_candidate, in_pre_candidate
            from daily_stock_state
            where code = '603050' and trade_date = '2026-05-06'
            """
        ).fetchone()

        assert ds is not None, "603050: daily_stock_state not found"
        in_core = int(ds["in_core"] or 0)
        assert in_core == 0, f"603050: in_core must be 0, got {in_core}"

        print(
            f"603050 guard OK: score_snapshots has stages {stages} but daily_stock_state.in_core={in_core}. "
            "score_snapshots.stage must not be used as lifecycle stage."
        )
    finally:
        conn.close()


# ====================================================================
# Main
# ====================================================================
def main() -> None:
    replay_sample_002885()
    guard_sample_603050()
    print("Old lifecycle replay smoke OK")


if __name__ == "__main__":
    main()
