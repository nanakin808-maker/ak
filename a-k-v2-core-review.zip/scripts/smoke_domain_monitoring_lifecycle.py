from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.domain.decisions import CandidateStage, CandidateState, DecisionAction  # noqa: E402
from app.domain.events import EventSource, EventType, StockEvent  # noqa: E402
from app.domain.gates import CoreGateConfig, MonitoringGateConfig  # noqa: E402
from app.domain.monitoring_lifecycle import MonitoringLifecycleInput, decide_monitoring_lifecycle  # noqa: E402
from app.domain.scores import ScoreResult, ScoreType, StockScoreBundle  # noqa: E402
from app.domain.stocks import StockSnapshot  # noqa: E402


def stock() -> StockSnapshot:
    return StockSnapshot(code="300750", name="宁德时代", price=214.28, change_pct=4.2)


def event(
    event_type: EventType,
    *,
    source: EventSource = EventSource.SHORTLINE,
    is_sealed: bool = False,
    change_pct: float | None = 4.2,
) -> StockEvent:
    return StockEvent(
        code="300750",
        name="宁德时代",
        event_type=event_type,
        event_time="09:40:11",
        source=source,
        is_sealed=is_sealed,
        change_pct=change_pct,
    )


def score(score_type: ScoreType, value: float | None) -> ScoreResult:
    return ScoreResult(score_type=score_type, score=value)


def scores(
    *,
    technical: float | None = None,
    sentiment: float | None = None,
    volume: float | None = None,
) -> StockScoreBundle:
    return StockScoreBundle(
        technical=score(ScoreType.TECHNICAL, technical) if technical is not None else None,
        realtime_sentiment=score(ScoreType.REALTIME_SENTIMENT, sentiment) if sentiment is not None else None,
        volume=score(ScoreType.VOLUME, volume) if volume is not None else None,
    )


def state(stage: CandidateStage) -> CandidateState:
    return CandidateState(stock=stock(), stage=stage, scores=StockScoreBundle())


def main() -> None:
    st = decide_monitoring_lifecycle(
        MonitoringLifecycleInput(
            stock=stock(),
            event=event(EventType.FAST_RISE),
            scores=StockScoreBundle(),
            is_st=True,
        )
    )
    assert st.action is DecisionAction.REJECT_TODAY
    assert st.target_stage is CandidateStage.REJECTED_TODAY

    pre = decide_monitoring_lifecycle(
        MonitoringLifecycleInput(
            stock=stock(),
            event=event(EventType.FAST_RISE),
            scores=StockScoreBundle(),
        )
    )
    assert pre.action is DecisionAction.ENTER_PRE_CANDIDATE
    assert pre.target_stage is CandidateStage.PRE_CANDIDATE

    candidate = decide_monitoring_lifecycle(
        MonitoringLifecycleInput(
            stock=stock(),
            event=event(EventType.FAST_RISE, source=EventSource.QUOTE),
            scores=StockScoreBundle(),
            current_state=state(CandidateStage.PRE_CANDIDATE),
            has_valid_quote=True,
        )
    )
    assert candidate.action is DecisionAction.ENTER_CANDIDATE
    assert candidate.target_stage is CandidateStage.CANDIDATE

    no_core = decide_monitoring_lifecycle(
        MonitoringLifecycleInput(
            stock=stock(),
            event=event(EventType.FAST_RISE, is_sealed=False),
            scores=scores(technical=90, sentiment=90, volume=90),
            current_state=state(CandidateStage.CANDIDATE),
        )
    )
    assert no_core.action is DecisionAction.KEEP_CURRENT
    assert no_core.target_stage is CandidateStage.CANDIDATE

    core = decide_monitoring_lifecycle(
        MonitoringLifecycleInput(
            stock=stock(),
            event=event(EventType.LIMIT_UP_SEALED, is_sealed=True),
            scores=scores(technical=90, sentiment=90, volume=90),
            current_state=state(CandidateStage.CANDIDATE),
        )
    )
    assert core.action is DecisionAction.PROMOTE_TO_CORE
    assert core.target_stage is CandidateStage.CORE

    opened = decide_monitoring_lifecycle(
        MonitoringLifecycleInput(
            stock=stock(),
            event=event(EventType.LIMIT_UP_OPENED),
            scores=scores(technical=90, sentiment=90, volume=90),
            current_state=state(CandidateStage.CORE),
        )
    )
    assert opened.action is DecisionAction.DEMOTE_TO_CANDIDATE
    assert opened.target_stage is CandidateStage.CANDIDATE

    custom_core = decide_monitoring_lifecycle(
        MonitoringLifecycleInput(
            stock=stock(),
            event=event(EventType.NEAR_LIMIT, change_pct=9.2),
            scores=scores(technical=80, sentiment=85, volume=75),
            current_state=state(CandidateStage.CANDIDATE),
            config=MonitoringGateConfig(
                core_gate=CoreGateConfig(
                    require_sealed=False,
                    allow_near_limit=True,
                    near_limit_min_pct=9.0,
                    min_technical_score=75,
                    min_realtime_sentiment_score=80,
                    require_volume_confirm=True,
                    min_volume_score=70,
                )
            ),
        )
    )
    assert custom_core.action is DecisionAction.PROMOTE_TO_CORE
    assert custom_core.target_stage is CandidateStage.CORE

    print("Domain monitoring lifecycle smoke tests passed.")


if __name__ == "__main__":
    main()
