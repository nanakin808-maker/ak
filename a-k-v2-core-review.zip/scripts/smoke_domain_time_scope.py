from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.domain.time_scope import (
    FreshnessStatus,
    MarketSession,
    TimeScope,
    assert_action_allowed,
    can_trigger_core,
    can_trigger_notification,
    can_trigger_self_stock,
    evaluate_freshness,
)


def main() -> None:
    now = datetime.utcnow()

    # 1. source_trading_date == trading_date -> FRESH, 所有 trigger 允许
    scope_fresh = TimeScope(
        trading_date="2026-05-10",
        source_trading_date="2026-05-10",
        as_of=now,
        freshness_status=evaluate_freshness("2026-05-10", "2026-05-10"),
        market_session=MarketSession.TRADING.value,
    )
    assert scope_fresh.freshness_status == FreshnessStatus.FRESH.value, (
        f"expected FRESH, got {scope_fresh.freshness_status}"
    )
    assert can_trigger_core(scope_fresh) is True
    assert can_trigger_notification(scope_fresh) is True
    assert can_trigger_self_stock(scope_fresh) is True
    assert assert_action_allowed(scope_fresh) is True

    # 2. source_trading_date != trading_date -> MISMATCH, 所有 trigger 禁止
    scope_mismatch = TimeScope(
        trading_date="2026-05-10",
        source_trading_date="2026-05-09",
        as_of=now,
        freshness_status=evaluate_freshness("2026-05-10", "2026-05-09"),
        market_session=MarketSession.TRADING.value,
    )
    assert scope_mismatch.freshness_status == FreshnessStatus.MISMATCH.value, (
        f"expected MISMATCH, got {scope_mismatch.freshness_status}"
    )
    assert can_trigger_core(scope_mismatch) is False
    assert can_trigger_notification(scope_mismatch) is False
    assert can_trigger_self_stock(scope_mismatch) is False
    assert assert_action_allowed(scope_mismatch) is False

    # 3. source_trading_date is None -> UNKNOWN, 所有 trigger 禁止
    scope_unknown = TimeScope(
        trading_date="2026-05-10",
        source_trading_date=None,
        as_of=now,
        freshness_status=evaluate_freshness("2026-05-10", None),
    )
    assert scope_unknown.freshness_status == FreshnessStatus.UNKNOWN.value, (
        f"expected UNKNOWN, got {scope_unknown.freshness_status}"
    )
    assert can_trigger_core(scope_unknown) is False
    assert can_trigger_notification(scope_unknown) is False
    assert can_trigger_self_stock(scope_unknown) is False
    assert assert_action_allowed(scope_unknown) is False

    # 4. 非交易时段旧数据: source != trading 且 session=CLOSED -> MISMATCH
    scope_stale_closed = TimeScope(
        trading_date="2026-05-10",
        source_trading_date="2026-05-09",
        as_of=now,
        freshness_status=evaluate_freshness("2026-05-10", "2026-05-09", MarketSession.CLOSED.value),
        market_session=MarketSession.CLOSED.value,
    )
    assert scope_stale_closed.freshness_status == FreshnessStatus.MISMATCH.value, (
        f"expected MISMATCH for stale closed, got {scope_stale_closed.freshness_status}"
    )
    assert can_trigger_core(scope_stale_closed) is False
    assert can_trigger_notification(scope_stale_closed) is False
    assert can_trigger_self_stock(scope_stale_closed) is False
    assert assert_action_allowed(scope_stale_closed) is False

    print("Domain time_scope smoke test OK")


if __name__ == "__main__":
    main()
