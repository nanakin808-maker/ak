"""
Manual script: runs an old external source provider via ExternalSourceRuntime.

Usage:
  cd ~/Documents/Codex/2026-04-26/a-k-v2

  # Print usage (no --module given)
  uv run --directory backend python3 scripts/manual_external_source_runtime.py

  # Run a real old provider in subprocess mode
  uv run --directory backend python3 scripts/manual_external_source_runtime.py \
    --source-key limit_pool \
    --module astock_guard.providers.limit_pool \
    --callable fetch_limit_pool_snapshot \
    --old-project-root ../a-k \
    --requested-trading-date 2026-05-09

  # Run in in_process mode (may fail if module has missing deps)
  uv run --directory backend python3 scripts/manual_external_source_runtime.py \
    --source-key test \
    --module some.module \
    --callable some_fn \
    --mode in_process
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.services.external_source_runtime import (  # noqa: E402
    ExternalSourceExecutionMode,
    ExternalSourceRuntime,
    ExternalSourceRuntimeRequest,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run an old external source provider via ExternalSourceRuntime")
    parser.add_argument("--source-key", default="manual")
    parser.add_argument("--module", default=None)
    parser.add_argument("--callable", default=None)
    parser.add_argument("--old-project-root", default=None)
    parser.add_argument("--requested-trading-date", default=datetime.utcnow().strftime("%Y-%m-%d"))
    parser.add_argument("--mode", choices=["subprocess", "in_process"], default="subprocess")
    parser.add_argument("--timeout", type=float, default=10.0)
    args = parser.parse_args()

    if not args.module or not args.callable:
        print("Usage: manual_external_source_runtime.py --module <path> --callable <name> [options]")
        print("  --source-key             (default: manual)")
        print("  --module                 Python module path (required)")
        print("  --callable               Function name (required)")
        print("  --old-project-root       Path to old project root (default: ../a-k)")
        print("  --requested-trading-date (default: today)")
        print("  --mode                   subprocess|in_process (default: subprocess)")
        print("  --timeout                Subprocess timeout seconds (default: 10.0)")
        print("")
        print("Examples:")
        print("  # Use old root default:")
        print("  uv run --directory backend python3 scripts/manual_external_source_runtime.py \\")
        print("    --module astock_guard.providers.some_mod --callable some_func")
        print("")
        print("No --module given, exiting.")
        sys.exit(0)

    old_root = args.old_project_root or str(ROOT.parent / "a-k")
    mode = ExternalSourceExecutionMode.IN_PROCESS if args.mode == "in_process" else ExternalSourceExecutionMode.SUBPROCESS
    mode_label = "IN_PROCESS" if mode == ExternalSourceExecutionMode.IN_PROCESS else "SUBPROCESS"

    runtime = ExternalSourceRuntime()
    request = ExternalSourceRuntimeRequest(
        source_key=args.source_key,
        requested_trading_date=args.requested_trading_date,
        module_name=args.module,
        callable_name=args.callable,
        old_project_root=str(Path(old_root).resolve()) if Path(old_root).exists() else None,
        execution_mode=mode,
        timeout_seconds=args.timeout,
    )

    old_root_display = request.old_project_root or "(not found)"
    print(f"Calling {args.module}.{args.callable} in {mode_label} mode")
    print(f"  old_project_root = {old_root_display}")
    print(f"  requested_trading_date = {args.requested_trading_date}")
    print()

    result = runtime.call(request)

    if result.ok and result.fetch_result is not None:
        fr = result.fetch_result
        row_count = 0
        if isinstance(fr.data, dict):
            rows = fr.data.get("rows", [])
            row_count = len(rows)
        elif isinstance(fr.data, list):
            row_count = len(fr.data)
        print(f"OK")
        print(f"  source_trading_date = {fr.source_trading_date}")
        print(f"  freshness_status    = {fr.freshness_status}")
        print(f"  row_count           = {row_count}")
        print(f"  detail              = {result.detail}")
    else:
        print(f"FAILED")
        print(f"  error   = {result.error}")
        print(f"  detail  = {result.detail}")
        print()
        print("Common causes: old system dependencies not installed in v2 venv.")
        print("This is expected behavior - old providers run in a separate venv.")

    sys.exit(0)


if __name__ == "__main__":
    main()
