"""
Subprocess worker for ExternalSourceRuntime.

Called as a subprocess to run old provider / SDK / HTTP adapters
in an isolated process with the old project root on sys.path.

Usage:
  python3 scripts/external_source_worker.py \
    --source-key speed_rank \
    --requested-trading-date 2026-05-09 \
    --module astock_guard.providers.mock_source \
    --callable fetch_speed_rank \
    --old-project-root ../a-k
"""

from __future__ import annotations

import argparse
import importlib
import inspect
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-key", required=True)
    parser.add_argument("--requested-trading-date", required=True)
    parser.add_argument("--module", required=True)
    parser.add_argument("--callable", required=True, dest="callable_name")
    parser.add_argument("--old-project-root")
    parser.add_argument("--kwargs-json", default="{}")
    return parser.parse_args()


def parse_datetime(value: Any) -> str | None:
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, str):
        return value
    return None


def normalize_result(payload: Any, requested_trading_date: str) -> dict[str, Any]:
    if isinstance(payload, dict) and "data" in payload:
        return {
            "data": payload.get("data"),
            "source_trading_date": payload.get("source_trading_date") or requested_trading_date,
            "source_updated_at": parse_datetime(payload.get("source_updated_at")),
            "detail": payload.get("detail") if isinstance(payload.get("detail"), dict) else {},
        }
    return {"data": payload, "source_trading_date": requested_trading_date, "source_updated_at": None, "detail": {"normalized": True}}


def call_function(fn, requested_trading_date: str, kwargs: dict[str, Any]) -> Any:
    sig = inspect.signature(fn)
    params = sig.parameters
    has_var_kw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values())
    if "requested_trading_date" in params or has_var_kw:
        return fn(requested_trading_date=requested_trading_date, **kwargs)
    if "trading_date" in params:
        return fn(trading_date=requested_trading_date, **kwargs)
    if not params:
        return fn()
    raise TypeError("unsupported callable signature")


def main() -> None:
    args = parse_args()
    original_path = list(sys.path)
    try:
        if args.old_project_root:
            sys.path.insert(0, str(Path(args.old_project_root).resolve()))
        kwargs = json.loads(args.kwargs_json or "{}")
        module = importlib.import_module(args.module)
        fn = getattr(module, args.callable_name)
        payload = call_function(fn, args.requested_trading_date, kwargs)
        normalized = normalize_result(payload, args.requested_trading_date)
        print(json.dumps({
            "ok": True, "source_key": args.source_key, "fetch_result": normalized,
            "detail": {"module": args.module, "callable": args.callable_name, "worker": "external_source_worker"},
        }, ensure_ascii=False, default=str))
    except Exception as exc:
        print(json.dumps({
            "ok": False, "source_key": args.source_key, "error": str(exc),
            "detail": {"module": args.module, "callable": args.callable_name, "exception_type": exc.__class__.__name__},
        }, ensure_ascii=False, default=str))
        raise SystemExit(0)
    finally:
        sys.path[:] = original_path


if __name__ == "__main__":
    main()
