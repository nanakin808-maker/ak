from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import (  # noqa: E402
    InterfaceHealth,
    LimitPoolRow,
    MonitoringStateTransition,
    ScoreSnapshot,
    ScoreTaskCurrent,
)
from app.domain.time_scope import MarketSession  # noqa: E402
from app.runtime import (  # noqa: E402
    MonitoringScanCycle,
    RuntimeState,
)
from app.services.provider_bridge_service import ProviderFetchResult  # noqa: E402


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "monitoring_backend.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()
        base_date = "2026-05-09"

        # === mock fetchers ===
        def speed_rank_fetcher() -> ProviderFetchResult:
            return ProviderFetchResult(
                data={"rows": [{
                    "code": "002885", "name": "京泉华", "event_type": "RAPID_RISE",
                    "event_title": "快速拉升", "change_pct": 7.326, "price": 20.0,
                }]},
                source_trading_date=base_date, source_updated_at=now,
            )

        def shortline_fetcher() -> ProviderFetchResult:
            return ProviderFetchResult(
                data={"rows": [{
                    "code": "600001", "name": "mock短线", "event_type": "SHORTLINE_EVENT",
                    "event_title": "异动", "change_pct": 6.2, "price": 12.0,
                }]},
                source_trading_date=base_date, source_updated_at=now,
            )

        def quote_batch_fetcher() -> ProviderFetchResult:
            return ProviderFetchResult(
                data={"rows": [
                    {"code": "002885", "name": "京泉华", "price": 20.1, "change_pct": 7.5,
                     "is_sealed": False, "at_limit": False},
                    {"code": "002885", "name": "京泉华", "price": 22.0, "change_pct": 10.01,
                     "is_sealed": True, "at_limit": True},
                    {"code": "002885", "name": "京泉华", "price": 21.0, "change_pct": 8.7,
                     "is_sealed": False, "at_limit": False, "open_count": 1},
                    {"code": "600001", "name": "mock短线", "price": 12.5, "change_pct": 6.8,
                     "is_sealed": False, "at_limit": False},
                ]},
                source_trading_date=base_date, source_updated_at=now,
            )

        class MockLimitPoolFetcher:
            def fetch(self, *, requested_trading_date: str) -> ProviderFetchResult:
                return ProviderFetchResult(
                    data={"rows": [
                        {"pool": "limit_up", "code": "000001", "name": "平安银行",
                         "source": "mock", "price": 10.5, "change_pct": 10.01,
                         "first_limit_time": "10:01:00"},
                        {"pool": "open_board", "code": "600002", "name": "mock open",
                         "source": "mock", "price": 8.8, "change_pct": 8.85,
                         "first_limit_time": "10:30:00", "open_count": 3},
                    ]},
                    source_trading_date=requested_trading_date, source_updated_at=now,
                )

        # ============================================================
        # A: 完整主流程
        # ============================================================
        with Session() as session:
            cycle = MonitoringScanCycle(session, RuntimeState())
            result = cycle.run_once(
                trading_date=base_date,
                as_of=now,
                seq_start=1,
                speed_rank_fetcher=speed_rank_fetcher,
                shortline_fetcher=shortline_fetcher,
                quote_batch_fetcher=quote_batch_fetcher,
                limit_pool_fetcher=MockLimitPoolFetcher(),
                market_session=MarketSession.TRADING,
            )
            session.commit()

            # summary
            assert result.source_events_processed == 2, f"A1: {result.source_events_processed}"
            assert result.quotes_processed == 4, f"A2: {result.quotes_processed}"
            assert result.limit_pool_rows_ingested == 2, f"A3: {result.limit_pool_rows_ingested}"
            assert result.score_tasks_scheduled == 2, f"A4: {result.score_tasks_scheduled}"
            assert result.score_tasks_processed == 2, f"A5: {result.score_tasks_processed}"
            assert result.score_tasks_ready == 2, f"A6: {result.score_tasks_ready}"
            assert result.score_tasks_failed == 0, f"A7: {result.score_tasks_failed}"

            # 002885: PRE_CANDIDATE -> CANDIDATE -> CORE -> CANDIDATE
            s_885 = cycle.runtime.get_stock_state(base_date, "002885")
            assert s_885 is not None, "A: 002885 not in runtime"
            assert s_885.stage == "CANDIDATE", f"A: 002885 stage {s_885.stage}"

            # 600001: PRE_CANDIDATE -> CANDIDATE
            s_001 = cycle.runtime.get_stock_state(base_date, "600001")
            assert s_001 is not None, "A: 600001 not in runtime"
            assert s_001.stage == "CANDIDATE", f"A: 600001 stage {s_001.stage}"

            # transitions: PRE_CANDIDATE -> CANDIDATE, CANDIDATE -> CORE, CORE -> CANDIDATE
            transitions = list(
                session.execute(select(MonitoringStateTransition)).scalars()
            )
            from_to = {(t.from_stage, t.to_stage) for t in transitions}
            assert ("PRE_CANDIDATE", "CANDIDATE") in from_to, f"missing PRE_CANDIDATE->CANDIDATE: {from_to}"
            assert ("CANDIDATE", "CORE") in from_to, f"missing CANDIDATE->CORE: {from_to}"
            assert ("CORE", "CANDIDATE") in from_to, f"missing CORE->CANDIDATE: {from_to}"

            # limit_pool_rows
            assert count_(session, LimitPoolRow) == 2

            # score tasks
            tasks = list(session.execute(select(ScoreTaskCurrent)).scalars())
            assert len(tasks) == 2
            assert all(t.status == "ready" for t in tasks), f"tasks not ready: {[(t.code, t.status) for t in tasks]}"

            # score snapshots (from worker)
            snaps = list(session.execute(select(ScoreSnapshot)).scalars())
            assert len(snaps) >= 2
            limit_pool_snaps = [s for s in snaps if s.score_stage == "limit_pool_first_score"]
            assert len(limit_pool_snaps) >= 1

            # life snapshots: pre_candidate, candidate, candidate_removed etc.
            lifecycle_stages = {s.score_stage for s in snaps}
            assert "pre_candidate" in lifecycle_stages, f"missing pre_candidate: {lifecycle_stages}"

            # interface_health recorded
            health = list(session.execute(select(InterfaceHealth)).scalars())
            health_names = {h.name for h in health}
            assert "speed_rank" in health_names, f"missing speed_rank health: {health_names}"
            assert "shortline" in health_names, f"missing shortline health: {health_names}"
            assert "quote_batch" in health_names, f"missing quote_batch health: {health_names}"

        # ============================================================
        # B: mismatch 全链路保护
        # ============================================================
        class MismatchQuoteFetcher:
            def __call__(self) -> ProviderFetchResult:
                return ProviderFetchResult(
                    data={"rows": [{
                        "code": "600001", "name": "mock短线",
                        "price": 13.0, "change_pct": 10.0,
                        "is_sealed": True, "at_limit": True,
                    }]},
                    source_trading_date="2026-05-09",  # mismatch vs requested
                )

        class MismatchLimitPoolFetcher:
            def fetch(self, *, requested_trading_date: str) -> ProviderFetchResult:
                return ProviderFetchResult(
                    data={"rows": [
                        {"pool": "limit_up", "code": "000004", "name": "mismatch stock",
                         "source": "mock", "price": 15.0, "change_pct": 10.02},
                    ]},
                    source_trading_date="2026-05-09",  # mismatch vs requested
                )

        mismatch_date = "2026-05-10"
        with Session() as session:
            cycle_b = MonitoringScanCycle(session, RuntimeState())

            # first get a CANDIDATE in place for mismatch date
            def fresh_speed_fetcher() -> ProviderFetchResult:
                return ProviderFetchResult(
                    data={"rows": [{
                        "code": "600001", "name": "mock短线", "event_type": "SPEED_RISE",
                        "event_title": "快速拉升", "change_pct": 6.5, "price": 12.0,
                    }]},
                    source_trading_date=mismatch_date, source_updated_at=now,
                )

            cycle_b.run_once(
                trading_date=mismatch_date,
                as_of=now, seq_start=100,
                speed_rank_fetcher=fresh_speed_fetcher,
                # promote_pre_candidates will lift to CANDIDATE
                quote_batch_fetcher=None,
                limit_pool_fetcher=None,
                market_session=MarketSession.TRADING,
            )
            session.flush()

            state_before = cycle_b.runtime.get_stock_state(mismatch_date, "600001")
            assert state_before is not None
            assert state_before.stage == "CANDIDATE"

            # now run mismatch quote + mismatch limit_pool
            from app.services.limit_pool_provider_service import LimitPoolProviderIngestionService

            # mismatch quote
            quote_provider = "mismatch_quote"
            from app.services.market_source_adapter_service import MarketSourceAdapterService
            adapter = MarketSourceAdapterService(session, cycle_b.runtime, cycle_b.engine)
            r_quote = adapter.ingest_quote_batch(
                provider_name=quote_provider,
                requested_trading_date=mismatch_date,
                fetcher=MismatchQuoteFetcher(),
                as_of=now, seq_start=200,
                market_session=MarketSession.TRADING,
            )
            session.flush()
            assert r_quote.freshness_status == "mismatch", f"B1: {r_quote.freshness_status}"
            assert "ignored" in r_quote.actions[0] if r_quote.actions else True

            state_after = cycle_b.runtime.get_stock_state(mismatch_date, "600001")
            assert state_after is not None
            assert state_after.stage == "CANDIDATE", f"B2: {state_after.stage}"

            # mismatch limit_pool
            r_lp = adapter.ingest_limit_pool(
                requested_trading_date=mismatch_date,
                as_of=now, seq=300,
                fetcher=MismatchLimitPoolFetcher(),
                market_session=MarketSession.TRADING,
                provider_name="mismatch_limit_pool",
                primary_source="mismatch_test",
            )
            session.commit()

            assert r_lp.ingested is True, "B3: mismatch limit_pool should be ingested"
            assert r_lp.freshness_status == "mismatch", f"B4: {r_lp.freshness_status}"

            # mismatch rows in DB
            mismatch_rows = list(
                session.execute(
                    select(LimitPoolRow).where(LimitPoolRow.trading_date == mismatch_date)
                ).scalars()
            )
            assert len(mismatch_rows) >= 1
            for row in mismatch_rows:
                if row.code == "000004":
                    assert row.freshness_status == "mismatch"
                    break
            else:
                assert False, "B5: mismatch row not found"

    print("Monitoring backend v1 smoke test OK")


if __name__ == "__main__":
    main()
