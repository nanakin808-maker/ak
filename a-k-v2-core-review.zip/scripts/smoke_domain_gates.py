from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.domain.events import EventSource, EventType  # noqa: E402
from app.domain.gates import (  # noqa: E402
    BaseFilterConfig,
    CoreGateConfig,
    GateDecision,
    GateType,
    MonitoringGateConfig,
    NotificationAction,
    NotificationGateConfig,
)


def main() -> None:
    base = BaseFilterConfig()
    assert base.st_filter_required is True
    assert base.allow_st_disable is False

    config = MonitoringGateConfig()
    assert EventSource.SHORTLINE in config.candidate_entry.allowed_sources
    assert EventSource.SPEED_RANK in config.candidate_entry.allowed_sources
    assert EventSource.LIMIT_POOL in config.candidate_entry.allowed_sources
    assert EventSource.QUOTE in config.candidate_entry.allowed_sources
    assert EventSource.GAIN_RANK in config.candidate_entry.allowed_sources

    assert EventType.LIMIT_UP_SEALED in config.candidate_entry.allowed_event_types
    assert EventType.LIMIT_UP_OPENED in config.candidate_entry.allowed_event_types
    assert EventType.NEAR_LIMIT in config.candidate_entry.allowed_event_types

    core = CoreGateConfig(
        require_sealed=True,
        min_technical_score=70,
        min_realtime_sentiment_score=80,
        require_volume_confirm=True,
        min_volume_score=70,
    )
    assert core.require_sealed is True
    assert core.require_volume_confirm is True
    assert core.min_volume_score == 70

    notify = NotificationGateConfig()
    assert notify.enabled is True
    assert notify.min_technical_score == 70.0
    assert notify.min_sentiment_score == 70.0
    assert notify.allow_self_stock_limit_up_bypass is True

    assert GateType.CORE.value == "core"
    assert GateDecision.PASS.value == "pass"
    assert NotificationAction.LIMIT_UP.value == "notify_limit_up"
    assert NotificationAction.OPEN_BOARD.value == "notify_open_board"

    print("Domain gate config smoke tests passed.")


if __name__ == "__main__":
    main()
