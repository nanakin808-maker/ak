from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path
import tempfile

from sqlalchemy import create_engine, inspect, select
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.init_db import init_db  # noqa: E402
from app.db.models import (  # noqa: E402
    LimitPoolRow,
    LimitPoolSnapshot,
    MonitoringStateTransition,
    MonitoringStockState,
    ScoreSnapshot,
)
from app.domain.time_scope import MarketSession  # noqa: E402
from app.repositories import MonitoringRepository  # noqa: E402
from app.runtime import (  # noqa: E402
    CandidateEntryInput,
    CandidateQuoteInput,
    MonitoringEngine,
    RuntimeState,
)
from app.services.limit_pool_ingestion_service import (  # noqa: E402
    LimitPoolInputRow,
    LimitPoolInputSnapshot,
)


def count_(session, model) -> int:
    return len(list(session.execute(select(model)).scalars()))


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "engine_v1.db"
        engine = create_engine(f"sqlite:///{db_path}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

        now = datetime.utcnow()
        base_date = "2026-05-06"

        # ============================================================
        # A. 候选生命周期闭环（通过 MonitoringEngine，不直接调底层）
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            eng = MonitoringEngine(session, runtime)

            # step 1: enter_pre_candidate
            r1 = eng.handle_source_event(
                CandidateEntryInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="002885", name="京泉华",
                    event_type="RAPID_RISE", event_source="eastmoney_changes",
                    event_title="快速拉升", event_time="11:18:42",
                    price=33.55, change_pct=7.326,
                    as_of=now - timedelta(hours=12), seq=1,
                    freshness_status="fresh",
                )
            )
            session.flush()
            assert r1.action == "enter_pre_candidate", f"A1: {r1.action}"
            assert r1.stage == "PRE_CANDIDATE"

            # step 2: promote_pre_candidate
            r2 = eng.promote_pre_candidate(
                trading_date=base_date, source_trading_date=base_date,
                code="002885", name="京泉华",
                as_of=now - timedelta(hours=11, minutes=40), seq=2,
                freshness_status="fresh",
            )
            session.flush()
            assert r2.action == "promote_candidate", f"A2: {r2.action}"
            assert r2.stage == "CANDIDATE"
            # mark candidate_at for stale check
            s2 = eng.monitoring.get_stock_state(base_date, "002885")
            assert s2 is not None
            s2.candidate_at = now - timedelta(hours=11, minutes=40)
            session.flush()

            # step 3: process_quote not sealed -> update_candidate_quote
            r3 = eng.process_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="002885", name="京泉华",
                    as_of=now - timedelta(hours=11, minutes=30), seq=3,
                    freshness_status="fresh", price=34.0, change_pct=8.0,
                    is_sealed=False, at_limit=False,
                )
            )
            session.flush()
            assert r3.action == "update_candidate_quote", f"A3: {r3.action}"
            assert r3.stage == "CANDIDATE"

            # step 4: process_quote sealed -> promote_core
            r4 = eng.process_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="002885", name="京泉华",
                    as_of=now - timedelta(hours=11, minutes=20), seq=4,
                    freshness_status="fresh", price=36.0, change_pct=10.0,
                    is_sealed=True, at_limit=True,
                )
            )
            session.flush()
            assert r4.action == "promote_core", f"A4: {r4.action}"
            assert r4.stage == "CORE"

            # step 5: process_quote still sealed -> update_core_quote (no dup)
            transitions_before = count_(session, MonitoringStateTransition)
            r5 = eng.process_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="002885", name="京泉华",
                    as_of=now - timedelta(hours=11, minutes=10), seq=5,
                    freshness_status="fresh", price=36.5, change_pct=10.0,
                    is_sealed=True, at_limit=True,
                )
            )
            session.flush()
            assert r5.action == "update_core_quote", f"A5: {r5.action}"
            assert r5.stage == "CORE"
            assert count_(session, MonitoringStateTransition) == transitions_before

            # step 6: process_quote opened -> demote_core_to_candidate
            r6 = eng.process_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="002885", name="京泉华",
                    as_of=now - timedelta(hours=11, minutes=0), seq=6,
                    freshness_status="fresh", price=33.0, change_pct=3.0,
                    is_sealed=False, at_limit=False, open_count=1,
                )
            )
            session.flush()
            assert r6.action == "demote_core_to_candidate", f"A6: {r6.action}"
            assert r6.stage == "CANDIDATE"

            # step 7: drop_stale_candidate
            s7 = eng.monitoring.get_stock_state(base_date, "002885")
            assert s7 is not None
            s7.candidate_at = now - timedelta(hours=11, minutes=0)
            session.flush()
            r7 = eng.drop_stale_candidate(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date=base_date,
                    code="002885", name="京泉华",
                    as_of=now - timedelta(hours=10, minutes=50), seq=7,
                    freshness_status="fresh", price=32.0, change_pct=1.0,
                ),
                candidate_stale_minutes=5.0,
                candidate_min_active_pct=5.0,
            )
            session.flush()
            assert r7.action == "candidate_removed", f"A7: {r7.action}"
            assert r7.stage == "PRE_CANDIDATE"

            session.commit()

        # ---- A assertions ----
        with Session() as session:
            final = session.execute(
                select(MonitoringStockState).where(
                    MonitoringStockState.trading_date == base_date,
                    MonitoringStockState.code == "002885",
                )
            ).scalar_one_or_none()
            assert final is not None, "A: final state not found"
            assert final.stage == "PRE_CANDIDATE", f"A: {final.stage}"
            assert final.active_monitoring is False
            assert final.inactive_reason == "candidate_weak_removed"

            transitions = list(
                session.execute(
                    select(MonitoringStateTransition).where(
                        MonitoringStateTransition.trading_date == base_date,
                        MonitoringStateTransition.code == "002885",
                    )
                ).scalars()
            )
            from_to = {(t.from_stage, t.to_stage) for t in transitions}
            assert ("PRE_CANDIDATE", "CANDIDATE") in from_to, f"A: missing CANDIDATE promotion, got {from_to}"
            assert ("CANDIDATE", "CORE") in from_to, f"A: missing CORE promotion, got {from_to}"
            assert ("CORE", "CANDIDATE") in from_to, f"A: missing CANDIDATE demotion, got {from_to}"
            assert ("CANDIDATE", "PRE_CANDIDATE") in from_to, f"A: missing candidate_removed, got {from_to}"

            score_stages = {
                row.score_stage
                for row in session.execute(
                    select(ScoreSnapshot).where(
                        ScoreSnapshot.trading_date == base_date,
                        ScoreSnapshot.code == "002885",
                    )
                ).scalars()
            }
            assert "pre_candidate" in score_stages, f"A: missing pre_candidate, got {score_stages}"
            assert "candidate" in score_stages, f"A: missing candidate, got {score_stages}"
            assert "candidate_removed" in score_stages, f"A: missing candidate_removed, got {score_stages}"

        # ============================================================
        # B. limit_pool 源输入落库（通过 MonitoringEngine）
        # ============================================================
        with Session() as session:
            eng = MonitoringEngine(session, RuntimeState())
            score_before = count_(session, ScoreSnapshot)
            ls_before = count_(session, MonitoringStockState)

            fresh = eng.ingest_limit_pool_snapshot(
                LimitPoolInputSnapshot(
                    trading_date="2026-05-09", source_trading_date="2026-05-09",
                    source="composite_limit_pool", primary_source="eastmoney_limit_pool",
                    as_of=now, seq=10, freshness_status="fresh", market_session="trading",
                    source_counts_json='{"limit_up":1,"open_board":1}',
                    rows=[
                        LimitPoolInputRow(pool="limit_up", code="000001", name="平安银行",
                            source="eastmoney_limit_pool", price=10.5, change_pct=10.01,
                            first_limit_time="10:01:00"),
                        LimitPoolInputRow(pool="open_board", code="600002", name="mock open",
                            source="eastmoney_limit_pool", price=8.8, change_pct=8.85,
                            first_limit_time="10:30:00"),
                    ],
                )
            )
            session.flush()
            assert fresh.row_count == 2

            assert count_(session, ScoreSnapshot) == score_before, "B: score_snapshots should not increase"
            assert count_(session, MonitoringStockState) == ls_before, "B: monitoring_stock_states should not increase"

            mismatch = eng.ingest_limit_pool_snapshot(
                LimitPoolInputSnapshot(
                    trading_date="2026-05-10", source_trading_date="2026-05-09",
                    source="composite_limit_pool", primary_source="eastmoney_limit_pool",
                    as_of=now, seq=11, freshness_status="mismatch", market_session="closed",
                    rows=[
                        LimitPoolInputRow(pool="limit_up", code="000003", name="mock mismatch",
                            source="eastmoney_limit_pool", price=11.0, change_pct=10.02,
                            first_limit_time="11:00:00"),
                    ],
                )
            )
            session.flush()
            assert mismatch.row_count == 1

            mismatch_rows = list(
                session.execute(
                    select(LimitPoolRow).where(LimitPoolRow.trading_date == "2026-05-10")
                ).scalars()
            )
            assert len(mismatch_rows) == 1
            assert mismatch_rows[0].freshness_status == "mismatch"

            # still no side effects from ingestion
            assert count_(session, ScoreSnapshot) == score_before
            assert count_(session, MonitoringStockState) == ls_before

            session.commit()

        # ============================================================
        # C. mismatch quote 不触发生命周期
        # ============================================================
        with Session() as session:
            runtime = RuntimeState()
            eng = MonitoringEngine(session, runtime)
            monitoring = MonitoringRepository(session)

            monitoring.upsert_stock_state(
                trading_date=base_date, source_trading_date=base_date,
                code="600999", name="mismatch quote",
                stage="CANDIDATE", price=15.0, change_pct=5.0,
                as_of=now - timedelta(hours=1), seq=20, freshness_status="fresh",
                active_monitoring=True,
            )
            session.flush()

            r = eng.process_quote(
                CandidateQuoteInput(
                    trading_date=base_date, source_trading_date="2026-05-05",
                    code="600999", name="mismatch quote",
                    as_of=now, seq=21, freshness_status="mismatch",
                    price=16.5, change_pct=10.0, is_sealed=True, at_limit=True,
                )
            )
            session.commit()

            assert r.action == "ignored", f"C: expected ignored, got {r.action}"
            assert "freshness" in r.reason, f"C: reason missing freshness, got {r.reason}"

            s_c = monitoring.get_stock_state(base_date, "600999")
            assert s_c is not None and s_c.stage == "CANDIDATE"

            t_c = list(
                session.execute(
                    select(MonitoringStateTransition).where(
                        MonitoringStateTransition.trading_date == base_date,
                        MonitoringStateTransition.code == "600999",
                    )
                ).scalars()
            )
            assert len(t_c) == 0, f"C: unexpected transitions: {len(t_c)}"

    print("Monitoring engine v1 smoke test OK")


if __name__ == "__main__":
    main()
