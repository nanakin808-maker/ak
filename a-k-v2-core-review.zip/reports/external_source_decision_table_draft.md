# External Source Decision Table v2 — Updated with Validation v1 Findings

Decisions filled per ChatGPT analysis of free API sources, duplicate markings,
and validated by `scripts/validate_external_sources.py --runs 3`.

Decision columns: primary/fallback/disabled, required, v2_target, failure_policy, notes, validation_status.

source_category | candidate_source | old_module | dependency | fields | primary/fallback/disabled | required | v2_target | failure_policy | notes | validation_status
---|---|---|---|---|---|---|---|---|---|---|---
stock_basic | stock_meta | providers/stock_meta.py:StockMetaProvider | akshare + requests | float_share, float_market_value, total_share, industry, market, name | primary | scoring | akshare adapter | cache (6h TTL) then degrade | AKShare breadth source; 6h cache sufficient | VALIDATED: 3/3 OK, avg 670ms
stock_basic | (baostock) | n/a — new source | baostock SDK | total_share, float_share, industry | backup | n/a | baostock adapter | degrade | BaoStock can provide basic stock info as fallback
calendar | market_calendar | market_time.py | requests (tool.bitefu.net) | trading_day, session | fallback | runtime | simple requests adapter | assume non-trading day on failure | bitefu.net lightweight but rate-limited
calendar | (baostock) | n/a — new source | baostock SDK | trading_days, open_days | primary | runtime | baostock query | fallback to bitefu.net | BaoStock has reliable trading calendar; free, no rate limit for local queries
calendar | (akshare) | n/a — new source | akshare | trade_calendar | backup | n/a | akshare fallback | degrade | AKShare also has trade_calendar; not primary
speed_rank | eastmoney_rank_speed | providers/eastmoney_rank.py:EastmoneyRankProvider | requests (push2.eastmoney.com) | code, name, price, change_pct, speed_pct, volume, amount | primary | event source | ExternalSourceAdapter | skip batch on failure; PRE_CANDIDATE only | M1 candidate — eastmoney 涨速榜 reliable
speed_rank | ths_speed_rank | providers/ths_speed_rank.py:ThsSpeedRankProvider | requests (同花顺 cookie) | code, name, price, change_pct | disabled | no | none | none | DUPLICATE — eastmoney sufficient; cookie unreliable
shortline | eastmoney_shortline | providers/shortline.py:EastmoneyShortlineProvider | requests (push2.eastmoney.com) | code, name, price, change_pct, speed, event_type, time | primary | event source | ExternalSourceAdapter | skip batch on failure; PRE_CANDIDATE only | Same lifecycle rule as speed_rank
quote_price | eastmoney_quote | providers/eastmoney.py:EastmoneyProvider | requests (push2.eastmoney.com) | price, pre_close, open, high, low, volume, amount, change_pct, turnover_rate | primary | price/change_pct only | requests adapter (M1) | degrade / skip | NO seal/open — bid_vol1/ask_vol1 empty; price/change_pct only reliable
quote_price | (akshare) | n/a — new source | akshare | price, change_pct, volume, amount | backup | n/a | akshare adapter | fallback for eastmoney | AKShare realtime quote available as backup; not primary for realtime
orderbook | pytdx_quote | providers/pytdx_provider.py:PytdxProvider | pytdx SDK (通达信 TCP) | price, pre_close, open, high, low, volume, amount, bid1-5, ask1-5, change_pct, turnover_rate | primary | orderbook/seal | pytdx adapter (M1) | fallback to sina | Only free source with reliable bid/ask volumes; PRIMARY for seal/open detection
orderbook | sina_quote | providers/sina.py:SinaProvider | requests (hq.sinajs.cn) | price, pre_close, open, high, low, volume, amount, bid1, ask1, change_pct | fallback | orderbook backup | requests adapter (M1) | degrade to price-only | Backup orderbook; has bid1/ask1 but no bid_vol1
orderbook | tencent_quote | providers/tencent.py:TencentProvider | requests (qt.gtimg.cn) | price, pre_close, open, high, low, volume, amount, bid1-5, ask1-5, change_pct | fallback | general quote only | requests adapter | degrade to price-only | DUPLICATE — bid/ask reliability unknown; use pytdx for seal
seal_strength | seal_strength | providers/seal_strength.py:SealStrengthAnalyzer | computed (derived) | seal_amount, float_mv_pct, entry_feasibility | primary | scoring | domain logic after pytdx+sina quote fetch | computed — no external call | Derived from pytdx/sina bid/ask volumes + stock_meta
limit_pool | eastmoney_limit_pool | providers/limit_pool.py:EastmoneyLimitPoolProvider | requests (push2ex.eastmoney.com) | code, name, pool, price, change_pct, first_limit_time, last_limit_time, open_count, seal_amount, streak, industry, reason | primary | limit_pool source | DirectWrite → source table (M1) | retry; no lifecycle | Into source table ONLY; NO lifecycle mutation
limit_pool | (akshare limit_pool) | n/a — new source | akshare | code, name, price, change_pct, limit_status | backup | n/a | akshare fallback | fallback | AKShare has limit/block list API; backup for eastmoney
limit_pool | ths_limit_pool | providers/limit_pool.py:ThsLimitPoolProvider | requests (同花顺 cookie) | code, name, pool | disabled | no | none | none | DUPLICATE — eastmoney + akshare sufficient
limit_pool | composite_limit_pool | providers/limit_pool.py:CompositeLimitPoolProvider | delegates | N/A (wrapper) | disabled | no | none | none | DUPLICATE — v2 single-source; wrapper not needed
daily_kline | daily_history_kline | providers/history.py:DailyHistoryProvider | requests + efinance + akshare + SQLite | date, open, close, high, low, volume, amount, change_pct, turnover_rate | primary | scoring | LegacyScoringFacadeExecutor (subprocess) | THS→efinance→akshare 3-level fallback | Already implemented in v1; not blocking lifecycle
daily_kline | ths_kline | providers/ths_kline.py:ThsKlineProvider | requests (同花顺 HTTP) | date, open, close, high, low, volume, amount, change_pct | primary (via history) | scoring | via DailyHistoryProvider subprocess | fallback to efinance/akshare | Used by DailyHistoryProvider; no direct v2 adapter needed
daily_kline | (baostock) | n/a — new source | baostock SDK | date, open, close, high, low, volume, amount | backup | n/a | baostock adapter | fallback for historical K | BaoStock has daily K since ~1990; free, no rate limit; good historical backup
daily_kline | efinance | providers/history.py (fallback) | efinance | date, open, close, high, low, volume, amount, change_pct | fallback | n/a | used inside DailyHistoryProvider | fallback after THS | NOT primary; fallback tier 2
daily_kline | akshare | providers/history.py (fallback) | akshare | date, open, close, high, low, volume, amount, change_pct | fallback | n/a | used inside DailyHistoryProvider | last resort | NOT primary; fallback tier 3
intraday | eastmoney_intraday | providers/intraday.py:EastmoneyIntradayProvider | requests (push2.eastmoney.com) | time, price, volume, amount, change_pct | primary | scoring | requests adapter | fallback to pytdx | For intraday_quality scoring component
intraday | pytdx_intraday | providers/intraday.py:PytdxIntradayProvider | pytdx SDK (通达信 TCP) | time, price, volume | fallback | scoring backup | pytdx adapter | degrade | First fallback for eastmoney_intraday
intraday | ths_intraday | providers/intraday.py:ThsIntradayProvider | requests (同花顺 cookie) | time, price, volume | disabled | no | none | none | DUPLICATE — eastmoney+pytdx sufficient
intraday | composite_intraday | providers/intraday.py:CompositeIntradayProvider | delegates | N/A (wrapper) | disabled | no | none | none | DUPLICATE — v2 direct adapter; wrapper not needed
board_mapping | ths_board | providers/ths_board.py:ThsBoardProvider | requests + akshare | board_code, board_name, board_kind | primary | board mapping | akshare adapter | degrade; cache mapping | AKShare 同花顺JS data primary for board classification
board_mapping | stock_board_summary | providers/stock_boards.py:StockBoardProvider | efinance | board_code, board_name, board_kind, board_change_pct | fallback | scoring | efinance adapter | cache → degrade | DUPLICATE — efinance board as backup for ths_board
board_members | eastmoney_board_member | providers/em_board_members.py:EastmoneyBoardMemberProvider | requests + efinance | code, name, price, change_pct, rank | primary | scoring | requests+efinance adapter | cache (TTL) → degrade | Board constituent top20 for board_score
fund_flow | eastmoney_fund_flow | providers/fund_flow.py:EastmoneyFundFlowProvider | requests (push2.eastmoney.com) | main_net_inflow, main_net_inflow_pct, retail_net_inflow, 3d/5d_summary, latest | primary | scoring | requests adapter | cache (5min TTL) → degrade | External_adjustments scoring component
fund_flow | (akshare) | n/a — new source | akshare | main_net_inflow, retail_net_inflow, total | backup | n/a | akshare fallback | degrade | AKShare has fund flow API as backup
feishu | feishu_notify | notifiers/feishu.py:FeishuNotifier | requests POST (webhook) | text, card payload | primary | last phase | notification service | skip if webhook unconfigured | External write — last priority
feishu | feishu_inbox | feishu_inbox.py:FeishuInbox | SQLite (local) | event_id, message_id, sender_id, text | primary | last phase | standalone event handler | log and continue | Receives Feishu events; not urgent
ths_self_stock | ths_self_stock_add | providers/ths_self_stock.py:ThsSelfStockProvider | requests POST (同花顺 cookie) | code, ok/error | primary | last phase | external action service | skip on failure | External write — last priority; after scoring+notification stable
ths_self_stock | ths_self_stock_list | providers/ths_self_stock.py:ThsSelfStockProvider | requests (同花顺 cookie) | stock_list | primary | last phase | external action service | skip on failure | Same timing as add

## Free API Source Strategy (v2) — Updated with Validation Findings

| Source | Role | Validation | Notes |
|--------|------|-----------|-------|
| Baostock | 历史K线备源、交易日历 (planned) | NOT VALIDATED — not installed | 免费，无频率限制；需安装 baostock |
| AKShare | 广度数据 (stock_basic, kline, limit_pool, calendar) | ✅ kline OK (485ms), limit_pool OK (721ms), calendar OK (682ms). ❌ spot/stock_list connection error (rate limited) | 广度数据可靠；实时行情有频率限制 |
| efinance | kline 备源 | ⚠️ daily_kline OK but intermittent (1137ms, 1/2 success); ❌ realtime import error | 仅 fallback，不做主源 |
| Tushare | n/a | NOT TESTED | 暂不作为当前免费主源（注册+积分门槛） |
| PyTDX | orderbook/seal-open (planned) | ⏸️ non_trading_unverified — CLOSED 时段 3/3 timeout. 需 TRADING 时段重验 | 通达信服务器可能在非交易时段关闭；暂不判定不可用 |
| Sina | orderbook 备源 | ✅ price/change OK (255ms). bid1/ask1 present. ⚠️ bid_vol1 为空 (CLOSED 时段) | 不满足 sealed 判断（缺 volume）；需 TRADING 时段确认 bid_vol |
| Eastmoney | price/change_pct, speed_rank, limit_pool, fund_flow | ✅ price/change_pct OK (410ms), limit_pool OK (531ms). bid_vol1 confirmed EMPTY (negative control) | quote_batch 不做 seal/open |
| Tencent | 通用报价备源 | ✅ price/change OK (244ms). bid/ask reliability unknown | 不用于 orderbook |

## Validation v1 Key Findings (2026-05-11) — Corrected

```text
注意：验证在 CLOSED 非交易时段执行。盘口/orderbook 结果受交易时段影响。
Orderbook 源 (`trading_time_required=true`) 需在 TRADING 时段重新验证。

1. pytdx_quote: 3/3 timeout (>30s)，在 CLOSED 时段。
   → 标记 non_trading_unverified，需要 TRADING 时段重新验证。
   非结论性：通达信服务器可能在非交易时段关闭或限流。

2. sina_orderbook: 有 bid1/ask1 (CLOSED 时段仍有数据)。
   bid_vol1 为空 (负控制确认)。是否交易时段有数据待验证。
   → 不满足 sealed 判断（需要 volume 算 seal_amount），
   但需 TRADING 时段确认 bid_vol 是否有值。

3. eastmoney negative control: 确认 bid_vol1 为空（非交易时段）。
   即使交易时段也可能为空。→ 不能单独用于 seal/open。

4. eastmoney_quote / tencent_quote / sina_quote:
   均可用于 price/change_pct 更新（avg 200-320ms CLOSED 时段）。

5. eastmoney_limit_pool: OK (432ms)。
   akshare_limit_pool: OK (781ms)。
   ths_limit_pool: 需要 cookie，暂禁用。

6. daily_kline:
   old DailyHistoryProvider: OK (435ms, subprocess, cached_only)
   akshare_daily_kline: OK (485ms previous run)
   efinance_daily_kline: 不稳定 (连接错误)
   baostock: 未安装，dependency missing

7. 正式 realtime v1 可以运行
   PRE_CANDIDATE / CANDIDATE / limit_pool / technical_score，
   但 CORE active 必须禁用或 shadow-only，
   直到 seal/open 源在 TRADING 时段验证通过。
```

## M1 Priority Revised (post-validation)

```text
M1 — Realtime Dev v1 (NO CORE active):
  1. stock_basic/ST          → akshare adapter
  2. calendar                → akshare first + bitefu fallback (baostock not installed)
  3. Eastmoney speed_rank    → ExternalSourceAdapter (PRE_CANDIDATE only)
  4. Eastmoney quote_price   → price/change_pct adapter (no seal/open)
  5. Eastmoney/AKShare limit_pool → source table writer (NO lifecycle)
  6. LegacyScoringFacadeExecutor → technical_score (already working)

  Allowed:     PRE_CANDIDATE entry, limit_pool ingestion, technical scoring,
               price/change_pct update, REST polling frontend
  Not allowed: CORE promotion/demotion (no reliable seal/open source)
               Feishu notify, THS self-stock

M2 — Seal/Open Source Resolution (TRADING session required):
  ☐ Re-validate pytdx_quote during TRADING hours (non_trading_unverified)
  ☐ Re-validate sina bid_vol1 during TRADING hours
  ☐ evaluate alternative Sina/Tencent volume fields
  ☐ evaluate strict limit_pool-derived gate (seal_amount from limit_pool)
  ☐ do NOT activate CORE until validated seal/open source

M3 — Scoring + External Actions:
  ☐ board/fund_flow/intraday adapters → ScoreWorker
  ☐ Feishu notify, THS self-stock
```

## Disabled / Duplicate Sources

| Source | Why |
|--------|-----|
| ths_limit_pool | DUPLICATE — eastmoney + akshare sufficient |
| ths_speed_rank | DUPLICATE — eastmoney sufficient |
| ths_intraday | DUPLICATE — eastmoney + pytdx sufficient |
| ths_kline (direct) | DUPLICATE — used via DailyHistoryProvider; no direct adapter |
| composite_limit_pool | v2 single-source pattern |
| composite_intraday | v2 direct adapter pattern |
| old CompositeProvider (quote) | v2 direct pytdx + fallback sina |
| Tushare (current) | Registration + rate-limit barrier; not free primary |
| efinance (as primary) | Fallback only; not reliable enough for primary |
