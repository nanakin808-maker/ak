# Scoring Input Source Deduplication Analysis

Based on `reports/external_interface_inventory.json`, `reports/legacy_scoring_extract.md`,
and old code call facts. No new external source recommendations.

---

## 1. Technical/Kline

| Role | Source | Status | Reason |
|------|--------|--------|--------|
| Primary | `DailyHistoryProvider.get_kline_score` (THS→efinance→akshare) | **ACTIVE** | Actual scoring entry point via evaluate_stock_score → strategy_engine |
| Primary provider | `ThsKlineProvider` (`providers/ths_kline.py`) | ACTIVE | First in fallback chain of DailyHistoryProvider |
| Fallback | `efinance` (`providers/history.py` imports) | ACTIVE (fallback tier 2) | Used when THS fails |
| Fallback | `akshare` (`providers/history.py` imports) | ACTIVE (fallback tier 3) | Last resort for kline data |
| Duplicate | `Baostock` | **duplicate_candidate** | Not in old code at all; reported from external audit |
| Duplicate | THS direct adapter via kline_worker.py | **duplicate_candidate** | Already covered by DailyHistoryProvider fallback chain |

**Actual scoring inputs in evaluate_stock_score:**
- `daily_bars` DataFrame (from DailyHistoryProvider._normalized_daily_history → SQLite + provider)
- `current_price` (from quote provider or parameter)
- `limit_events` (from DailyHistoryProvider.get_limit_events → SQLite daily_bars)

---

## 2. Volume

| Role | Source | Status | Reason |
|------|--------|--------|--------|
| Primary | Real-time quote samples from `VolumeScoringMixin._record_quote_sample` | **ACTIVE** | Used by _volume_momentum_score, records into runtime.quote_windows deque |
| Quote source | `CompositeProvider` (pytdx→tencent→sina→eastmoney) | ACTIVE | Feeds quote samples for volume scoring |
| Quote source | `EastmoneyProvider` (direct fallback) | ACTIVE | Used as individual provider when quote is None in evaluate_stock_score |
| Derived | `technical_metrics` from kline scoring pipeline | ACTIVE | `amount_ratio20`, `amount_std20` from _technical_score_v1 metrics |
| Derived | `stock_meta.float_share` / `float_market_value` | ACTIVE | For turnover fit scoring |
| Duplicate | `EastmoneyIntradayProvider` (分钟线) | **duplicate_candidate** | Not used in volume scoring; only used for intraday_quality in external_adjustments |
| Disabled | `ThsIntradayProvider` | duplicate_candidate | Cookie-dependent, not used |

**Actual volume fields needed:**
- From quote samples: `amount`, `volume`, `change_pct`, `price`, `timestamp`
- From technical metrics: `amount_ratio20`, `amount_std20`
- From stock_meta: `float_share`, `float_market_value`

---

## 3. Board/Sentiment

| Role | Source | Status | Reason |
|------|--------|--------|--------|
| Board mapping | `StockBoardProvider.summary` (`providers/stock_boards.py`) | **ACTIVE** | Gets stock→board associations (code→concept/industry list) |
| Board mapping backend | `efinance` | ACTIVE | Used by StockBoardProvider |
| Board mapping | `ThsBoardProvider` (`providers/ths_board.py`) | ACTIVE (secondary) | Provides concept/industry/tag classification (via akshare) |
| Board members | `EastmoneyBoardMemberProvider.get_members` (`providers/em_board_members.py`) | **ACTIVE** | Gets board top20 with quotes for board_score |
| Board members backend | `efinance` + `requests` | ACTIVE | Used by EastmoneyBoardMemberProvider |
| Fund flow | `EastmoneyFundFlowProvider.get_flow` (`providers/fund_flow.py`) | **ACTIVE** | Used in _board_external_adjustments |
| Intraday quality | `CompositeIntradayProvider.get_minute_bars` | **ACTIVE** | Used in _board_external_adjustments |
| Duplicate | `EastmoneyIntradayProvider` directly | **duplicate_candidate** | Only used through CompositeIntradayProvider; don't need direct access |
| Duplicate | `PytdxIntradayProvider` | duplicate_candidate | Only as fallback in composite |
| Disabled | `ThsIntradayProvider` | duplicate_candidate | Cookie-dependent; not used in actual scoring |

**Actual scoring inputs in evaluate_stock_score:**
- `board_summary` (from StockBoardProvider.summary → efinance)
- `board_members.boards[].{rank, members, limit_order_rank}` (from EastmoneyBoardMemberProvider)
- `fund_flow` (from EastmoneyFundFlowProvider)
- `intraday_quality` (from CompositeIntradayProvider)
- `stock_meta` (from StockMetaProvider → akshare+requests)

---

## 4. Fund Flow

| Role | Source | Status | Reason |
|------|--------|--------|--------|
| Primary | `EastmoneyFundFlowProvider.get_flow` | **ACTIVE** | Used in _board_external_adjustments |
| Backend | `requests` → `push2.eastmoney.com` (资金流 API) | ACTIVE | HTTP dependency |
| Duplicate | `akshare` 资金流 | **duplicate_candidate** | Not used in old evaluate_stock_score; external audit source |
| Cache | SQLite (fund_flow provider internal) | ACTIVE | 5min TTL cache |

**Actual fields used in scoring:**
- `latest.main_net_inflow_pct`
- `summary.main_net_inflow_3d_yi`
- `summary.positive_main_days_5d`

---

## 5. Duplicate/Disabled Source Summary

| Source | Category | Why |
|--------|----------|-----|
| Baostock | daily_kline | Not in old code; external audit candidate |
| ThsIntradayProvider | intraday | Cookie-dependent; eastmoney+pytdx sufficient |
| ThsLimitPoolProvider | limit_pool | Cookie-dependent; eastmoney+akshare sufficient |
| ThsSpeedRankProvider | speed_rank | Cookie-dependent; eastmoney sufficient |
| CompositeIntradayProvider | intraday wrapper | v2 direct adapter preferred |
| CompositeLimitPoolProvider | limit_pool wrapper | v2 single-source pattern |
| old CompositeProvider | quote wrapper | v2 direct pytdx/sina pattern |
| efinance (as primary) | quote/kline | Fallback only; intermittent failures |
| Tushare | all | Not in old code; registration barrier |

---

## 6. Migration-Relevant Input Table

| Scoring Component | Needs from Provider | Needs from DB | Needs from Runtime |
|------------------|-------------------|---------------|-------------------|
| technical/kline | kline provider (THS/efinance/akshare) | daily_bars cache, limit_events cache | nothing |
| volume | real-time quote samples | stock_meta (float_share/float_mv) | quote_window (TEMP: deque) |
| board/sentiment | board_summary, board_members, fund_flow | stock_meta | board_member_cache (TTL) |
| external/fund_flow | fund_flow API | fund_flow cache | open_board_counts |
| external/intraday | minute bars | nothing | nothing |
