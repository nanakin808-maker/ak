# External Source Validation Report

Generated: 2026-05-11T01:12:51
Trading date: 20260509  Codes: ['002885', '605369', '000001']  Runs per source: 1
Market session: CLOSED
Old Python: /Users/ek/Documents/Codex/2026-04-26/a-k/.venv/bin/python3
Old DB: /Users/ek/Documents/Codex/2026-04-26/a-k/data/astock_guard.db (exists)

## Summary

Sources tested: 21
Successful: 10
Failed: 10
Non-trading unverified: 1
Requires token: 0
Dependency missing: 3

## Per-Source Details

| source_key | validation_status | ok/total | rows | latency(ms) | dep_missing | field_coverage | business_fit |
|-----------|-------------------|----------|------|-------------|-------------|---------------|--------------|
| akshare_daily_kline | failed | 0/1 | 0 | 521/521/521 | - |  |  |
| akshare_limit_pool | ok | 1/1 | 5 | 781/781/781 | - | 代码, 名称, 涨停价, 涨停原因 | limit_pool_fit=True |
| akshare_spot | failed | 0/1 | 0 | 5531/5531/5531 | - |  |  |
| akshare_stock_list | failed | 0/1 | 0 | 6518/6518/6518 | - |  |  |
| akshare_trade_calendar | ok | 1/1 | 10 | 579/579/579 | - | day_week, trade_date |  |
| baostock_daily_kline | dependency_missing | 0/0 | 0 | - | baostock not installed in old venv |  |  |
| baostock_query_all_stock | dependency_missing | 0/0 | 0 | - | baostock not installed in old venv |  |  |
| baostock_trade_dates | dependency_missing | 0/0 | 0 | - | baostock not installed in old venv |  |  |
| bitefu_calendar | failed | 0/1 | 0 | 108/108/108 | - |  |  |
| eastmoney_limit_pool | ok | 1/1 | 5 | 432/432/432 | - | change_pct, code, first_limit_time, industry, last_limit_time, name, open_count, pool | limit_pool_fit=True |
| eastmoney_orderbook_negative | ok | 1/1 | 1 | 200/200/200 | - | price |  |
| eastmoney_quote | ok | 1/1 | 1 | 222/222/222 | - | amount, ask1, ask_vol1, bid1, bid_vol1, change_pct, code, high |  |
| efinance_daily_kline | failed | 0/1 | 0 | 1254/1254/1254 | - |  |  |
| efinance_realtime | failed | 0/1 | 0 | 347/347/347 | - |  |  |
| old_daily_history_kline | ok | 1/1 | 1 | 435/435/435 | - | base_score, current_price, factors, last_trade_date, legacy_score, message, score, score_delta | kline_fit=True |
| old_stock_meta | ok | 1/1 | 1 | 388/388/388 | - | code, float_market_value, float_market_value_yi, float_share, industry, latest_price, listing_date, name |  |
| pytdx_quote | non_trading_unverified | 0/1 | 0 | 30006/30006/30006 | - |  |  |
| sina_orderbook | ok | 1/1 | 1 | 320/320/320 | - | ask1, bid1, bid_vol1 | orderbook_fit=True |
| sina_quote | ok | 1/1 | 1 | 238/238/238 | - | ask1, bid1, bid_vol1, change_pct, code, pre_close, price, volume |  |
| tencent_quote | ok | 1/1 | 1 | 214/214/214 | - | ask1, bid1, change_pct, code, pre_close, price, volume |  |
| ths_limit_pool | failed | 0/0 | 0 | - | - |  |  |

## Key Findings

### Quote price/change
- eastmoney_quote: OK (1/1), avg 222ms
- tencent_quote: OK (1/1), avg 214ms
- sina_quote: OK (1/1), avg 238ms
- akshare_spot: FAIL — ["ConnectionError:('Connection aborted.', RemoteDisconnected('Remote end closed connection without response'))"]
- efinance_realtime: FAIL — ['Traceback (most recent call last):\n  File "<string>", line 4, in <module>\n  File "/Users/ek/Documents/Codex/2026-04-26/a-k/.venv/lib/python3.12/site-packages/efinance/utils/__init__.py", line 336, in wrapper\n    values = func(*args, **kwargs)\n             ^^^^^^^^^^^^^^^^^^^^^\n  File "/Users/ek/Documents/Codex/2026-04-26/a-k/.venv/lib/python3.12/site-packages/efinance/utils/__init__.py", line 48, in run\n    values = func(*args, **kwargs)\n             ^^^^^^^^^^^^^^^^^^^^^\n  File "/Users/ek/Docum']
### Orderbook/seal-open
NOTE: validated during CLOSED session — orderbook data is session-dependent.
Orderbook sources show non_trading_unverified. Re-run during TRADING session.
- pytdx_quote: NON-TRADING UNVERIFIED — requires TRADING session re-validation
  (error during non-trading: timeout)
- sina_orderbook: OK (ok), fit=YES
  bid1=37.13 bid_vol1=5
- eastmoney_orderbook_negative: OK (ok), fit=NO
  bid1=None bid_vol1=None
### Limit pool
- eastmoney_limit_pool: OK, 5 rows
  code=000839 name=国安股份
- akshare_limit_pool: OK, 5 rows
  code=000839 name=国安股份
### Daily kline
- old_daily_history_kline: OK, kline_fit=True
- baostock_daily_kline: dependency missing

## Business Fit Summary

| source_key | price_fit | orderbook_fit | limit_pool_fit | kline_fit |
|-----------|-----------|---------------|----------------|-----------|
| akshare_daily_kline | False | False | False | False |
| akshare_limit_pool | False | False | True | False |
| akshare_spot | False | False | False | False |
| akshare_stock_list | False | False | False | False |
| akshare_trade_calendar | False | False | False | False |
| baostock_daily_kline | False | False | False | False |
| baostock_query_all_stock | False | False | False | False |
| baostock_trade_dates | False | False | False | False |
| bitefu_calendar | False | False | False | False |
| eastmoney_limit_pool | False | False | True | False |
| eastmoney_orderbook_negative | False | False | False | False |
| eastmoney_quote | False | False | False | False |
| efinance_daily_kline | False | False | False | False |
| efinance_realtime | False | False | False | False |
| old_daily_history_kline | False | False | False | True |
| old_stock_meta | False | False | False | False |
| pytdx_quote | False | False | False | False |
| sina_orderbook | False | True | False | False |
| sina_quote | False | False | False | False |
| tencent_quote | False | False | False | False |
| ths_limit_pool | False | False | False | False |