# Legacy Scoring Code Extract

Extracted from: `~/Documents/Codex/2026-04-26/a-k/`
Generated: 2026-05-10
Purpose: Reference for migration planning (ChatGPT context)

---

## 1. AlertEngine.evaluate_stock_score

**source:** `astock_guard/alerts.py`
**class:** `AlertEngine`
**line range:** 250–408

```python
def evaluate_stock_score(
    self,
    code: str,
    *,
    name: str | None = None,
    stage: str = "trigger",
    trade_date: str | None = None,
    item: dict[str, Any] | None = None,
    row: dict[str, Any] | None = None,
    quote: Any | None = None,
    components: str = "all",
    force_refresh: bool = False,
    update_state: bool = True,
) -> dict[str, Any]:
    clean_code = str(code or "").zfill(6)[-6:]
    target = item if item is not None else self._stock_state(clean_code)
    if target is None:
        target = {
            "code": clean_code,
            "name": name or clean_code,
            "state": "score_evaluate",
        }
    else:
        target.setdefault("code", clean_code)
        if name:
            target["name"] = self._remember_stock_name(clean_code, name, target.get("name"))
    if row:
        target.update({
            "price": row.get("price", target.get("price")),
            "change_pct": row.get("change_pct", target.get("change_pct")),
            "event_time": row.get("first_limit_time") or row.get("last_limit_time") or target.get("event_time"),
            "event_title": row.get("pool") or target.get("event_title"),
        })
    if quote is not None:
        limit_state = self._limit_state(quote)
        display_name = self._remember_stock_name(clean_code, getattr(quote, "name", None), target.get("name"))
        target.update({
            "code": clean_code,
            "name": display_name,
            "price": quote.price,
            "pre_close": quote.pre_close,
            "open": quote.open,
            "change_pct": round(quote.change_pct, 3),
            "limit_up_price": limit_state["limit_price"],
            "at_limit": limit_state["at_limit"],
            "sealed": limit_state["sealed"],
            "seal_volume": limit_state["seal_volume"],
            "last_quote_at": quote.timestamp,
            "quote_source": quote.source,
        })
    target["score_stage"] = stage
    self._mark_runtime_item_today(target)
    if not self.runtime.scoring_enabled:
        target["score_status"] = "paused"
        target["score_paused"] = True
        target["score_pause_reason"] = "scoring disabled for step-by-step verification"
        return self._paused_score_payload(clean_code, name=target.get("name"), stage=stage)

    include_all = components == "all"
    include_technical = include_all or "technical" in components
    include_sentiment = include_all or "sentiment" in components
    include_volume = include_all or "volume" in components
    normalized_trade_date = self._normalize_trade_date(trade_date or self._today_key())
    is_today_score = normalized_trade_date == self._today_key()

    if quote is None and include_volume and is_today_score:
        try:
            quotes = self.quote_provider.get_quotes([clean_code])
        except Exception as exc:  # noqa: BLE001
            quotes = []
            target["quote_error"] = f"{type(exc).__name__}: {exc}"
        if quotes:
            quote = quotes[0]
            target.update({
                "name": self._display_name(clean_code, quote.name, target.get("name")),
                "price": quote.price,
                "pre_close": quote.pre_close,
                "open": quote.open,
                "change_pct": round(quote.change_pct, 3),
                "quote_source": quote.source,
            })
    if include_technical and self._kline_score_from_strategy(target.get("strategy") or {}) is None:
        target["strategy"] = self.strategy_engine.evaluate_code(
            clean_code,
            enabled_only=True,
            cached_only=False,
            stock_name=target.get("name"),
            current_price=target.get("price"),
        ).to_dict()
    if include_volume and quote is not None:
        target["volume_momentum_score"] = self._volume_momentum_score(target, quote)
    elif include_volume and is_today_score:
        try:
            quotes = self.quote_provider.get_quotes([clean_code])
        except Exception:
            quotes = []
        if quotes:
            target["volume_momentum_score"] = self._volume_momentum_score(target, quotes[0])

    if include_sentiment:
        if not isinstance(target.get("stock_meta"), dict):
            target["stock_meta"] = self._load_stock_meta(clean_code)
        if not isinstance(target.get("fund_flow"), dict):
            target["fund_flow"] = self.fund_flow_provider.get_flow(clean_code, limit=5, refresh=False)
        target["board_summary"] = self.stock_board_provider.summary(clean_code, name=target.get("name"), refresh=force_refresh)
        previous_snapshot = self.runtime.limit_pool_snapshot
        if trade_date:
            self.runtime.limit_pool_snapshot = {
                **previous_snapshot,
                "date": str(trade_date),
                "limit_up": previous_snapshot.get("limit_up") or [],
                "open_board": previous_snapshot.get("open_board") or [],
                "limit_up_by_code": previous_snapshot.get("limit_up_by_code") or {},
                "open_board_by_code": previous_snapshot.get("open_board_by_code") or {},
            }
        try:
            result_boards: list[dict[str, Any]] = []
            summary = target.get("board_summary") or {}
            if summary.get("status") == "ready":
                near_limit = self._should_refresh_board_members(clean_code, target.get("change_pct"))
                ttl = self.runtime.board_member_near_limit_cache_ttl_seconds if near_limit else self.runtime.board_member_cache_ttl_seconds
                for board in self._board_member_targets(summary)[: self.runtime.board_member_board_limit]:
                    board_code = str(board.get("board_code") or "").strip()
                    if not board_code:
                        continue
                    members = self._get_board_top20_cached(board_code, force_refresh=False, ttl_seconds=ttl)
                    rank = next((index + 1 for index, member in enumerate(members) if member.get("code") == clean_code), None)
                    board_result = {
                        "board_code": board_code,
                        "board_name": board.get("board_name"),
                        "board_kind": board.get("board_kind"),
                        "board_change_pct": board.get("board_change_pct"),
                        "rank": rank,
                        "in_top3": rank is not None and rank <= 3,
                        "in_top20": rank is not None and rank <= 20,
                        "members": members,
                    }
                    self._apply_limit_pool_order_to_board(board_result, clean_code)
                    result_boards.append(board_result)
            target["board_members"] = {"status": "ready" if result_boards else "empty", "updated_at": time.time(), "boards": result_boards}
            target["board_score"] = self._board_score(target)
            if stage in {"trigger", "near_limit", "self_stock"} and not target.get("board_score_trigger_snapshot"):
                target["board_score_trigger_snapshot"] = self._board_score_stage_snapshot(target, "trigger")
            elif stage in {"seal", "first_limit", "limit_pool_first_score"} and not target.get("board_score_seal_snapshot"):
                target["board_score_seal_snapshot"] = self._board_score_stage_snapshot(target, "seal")
                target["old_board_score_snapshot"] = self._old_board_score_snapshot(target)
            elif stage == "open":
                target["board_score_open_snapshot"] = self._board_score_stage_snapshot(target, "open")
            elif stage in {"reseal", "reseal_realtime"}:
                target["board_score_reseal_snapshot"] = self._board_score_stage_snapshot(target, "reseal")
        finally:
            if trade_date:
                self.runtime.limit_pool_snapshot = previous_snapshot

    if update_state:
        state = self._stock_state(clean_code)
        if state is not None and state is not target:
            state.update(target)
    return self._score_payload_from_item(target, stage=stage)
```

---

## 2. DailyHistoryProvider.__init__

**source:** `astock_guard/providers/history.py`
**class:** `DailyHistoryProvider`
**line range:** 55–63

```python
class DailyHistoryProvider:
    name = "efinance_history"

    def __init__(self, db_path: str | Path = "data/astock_guard.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.ths_kline = ThsKlineProvider()
        self.health = InterfaceHealthLogger(db_path=self.db_path)
        self._init_db()
```

---

## 3. DailyHistoryProvider.get_kline_score

**source:** `astock_guard/providers/history.py`
**class:** `DailyHistoryProvider`
**line range:** 156–178

```python
def get_kline_score(
    self,
    code: str,
    start: str = "20250101",
    end: str = "20500101",
    current_price: float | None = None,
    cached_only: bool = False,
) -> dict[str, Any]:
    clean_code = normalize_code(code)
    frame = self._normalized_daily_history(clean_code, start, end, cached_only=cached_only)
    if frame.empty:
        return {
            "status": "unknown",
            "score": None,
            "score_delta": 0,
            "message": "没有可用K线数据",
            "factors": [],
        }
    events = self.get_limit_events(clean_code, start=start, end=end, cached_only=True)
    price = current_price
    if price is None or price <= 0:
        price = float(frame.iloc[-1]["收盘"])
    return self._kline_score(frame, events, float(price))
```

---

## 4. DailyHistoryProvider._kline_score

**source:** `astock_guard/providers/history.py`
**class:** `DailyHistoryProvider`
**line range:** 587–745

```python
def _kline_score(self, frame: pd.DataFrame, events: list[LimitTouchEvent], current_price: float) -> dict[str, Any]:
    factors: list[dict[str, Any]] = []
    if frame.empty or current_price <= 0:
        return {"status": "unknown", "score": None, "score_delta": 0, "message": "没有可用K线数据", "factors": factors}

    recent = frame.copy()
    end_date = recent["日期"].max()
    start_date = end_date - pd.Timedelta(days=365)
    recent = recent[recent["日期"] >= start_date].copy()
    if recent.empty:
        return {"status": "unknown", "score": None, "score_delta": 0, "message": "近一年K线为空", "factors": factors}

    max_row = recent.loc[recent["最高"].idxmax()]
    max_high = float(max_row["最高"])
    peak_ratio = max_high / current_price
    drawdown_pct = (current_price / max_high - 1.0) * 100.0 if max_high > 0 else 0.0
    peak_penalty = 0
    if peak_ratio >= 2.5:
        peak_penalty = -35
    elif peak_ratio >= 2.0:
        peak_penalty = -26
    elif peak_ratio >= 1.6:
        peak_penalty = -18
    elif peak_ratio >= 1.3:
        peak_penalty = -10
    elif peak_ratio >= 1.15:
        peak_penalty = -4
    if peak_penalty:
        factors.append({
            "name": "历史高点压力",
            "score_delta": peak_penalty,
            "message": f"近一年最高价 {max_high:.2f} 是当前价 {current_price:.2f} 的 {peak_ratio:.2f} 倍",
            "data": {
                "max_high": round(max_high, 3),
                "max_high_date": max_row["日期"].date().isoformat(),
                "current_price": round(current_price, 3),
                "ratio": round(peak_ratio, 3),
            },
        })

    drawdown_penalty = 0
    if drawdown_pct <= -50:
        drawdown_penalty = -25
    elif drawdown_pct <= -35:
        drawdown_penalty = -18
    elif drawdown_pct <= -25:
        drawdown_penalty = -12
    elif drawdown_pct <= -15:
        drawdown_penalty = -6
    if drawdown_penalty:
        factors.append({
            "name": "高点后回撤",
            "score_delta": drawdown_penalty,
            "message": f"当前价较近一年高点回撤 {abs(drawdown_pct):.1f}%",
            "data": {"drawdown_pct": round(drawdown_pct, 3)},
        })

    close = recent["收盘"].astype(float)
    if len(recent) >= 40:
        peak_pos = int(recent["最高"].astype(float).to_numpy().argmax())
        days_since_peak = len(recent) - peak_pos - 1
        if days_since_peak >= 20:
            stage_drawdown_pct = drawdown_pct
            if stage_drawdown_pct <= -20:
                factors.append({
                    "name": "阶段高点后走弱",
                    "score_delta": -12,
                    "message": f"近一年高点后已经 {days_since_peak} 个交易日，当前回落 {abs(stage_drawdown_pct):.1f}%",
                    "data": {"days_since_peak": days_since_peak, "drawdown_pct": round(stage_drawdown_pct, 3)},
                })
            elif stage_drawdown_pct <= -12:
                factors.append({
                    "name": "阶段高点后走弱",
                    "score_delta": -6,
                    "message": f"近一年高点后已经 {days_since_peak} 个交易日，当前回落 {abs(stage_drawdown_pct):.1f}%",
                    "data": {"days_since_peak": days_since_peak, "drawdown_pct": round(stage_drawdown_pct, 3)},
                })
    ma20 = close.rolling(20).mean()
    ma60 = close.rolling(60).mean()
    last_close = float(close.iloc[-1])
    below20 = len(ma20.dropna()) > 0 and last_close < float(ma20.iloc[-1])
    below60 = len(ma60.dropna()) > 0 and last_close < float(ma60.iloc[-1])
    if below20 and below60:
        factors.append({
            "name": "均线弱势",
            "score_delta": -10,
            "message": "最近收盘价同时低于20日和60日均线",
            "data": {"close": round(last_close, 3), "ma20": round(float(ma20.iloc[-1]), 3), "ma60": round(float(ma60.iloc[-1]), 3)},
        })
    elif below20:
        factors.append({
            "name": "短线转弱",
            "score_delta": -4,
            "message": "最近收盘价低于20日均线",
            "data": {"close": round(last_close, 3), "ma20": round(float(ma20.iloc[-1]), 3)},
        })
    if len(ma20.dropna()) >= 6:
        ma20_now = float(ma20.iloc[-1])
        ma20_prev = float(ma20.iloc[-6])
        ma20_slope_pct = (ma20_now / ma20_prev - 1.0) * 100.0 if ma20_prev > 0 else 0.0
        if ma20_slope_pct <= -3.0:
            factors.append({
                "name": "20日趋势下行",
                "score_delta": -5,
                "message": f"20日均线近5个交易日下行 {abs(ma20_slope_pct):.1f}%",
                "data": {"ma20_slope_pct": round(ma20_slope_pct, 3)},
            })

    recent_events = [
        event for event in events
        if pd.to_datetime(event.date) >= end_date - pd.Timedelta(days=60)
    ]
    failed_touches = [event for event in recent_events if event.touched_limit and not event.closed_limit]
    if failed_touches:
        penalty = -min(15, len(failed_touches) * 5)
        factors.append({
            "name": "近期触板未封",
            "score_delta": penalty,
            "message": f"近60日有 {len(failed_touches)} 次触及涨停但未收涨停",
            "data": {"failed_touch_count": len(failed_touches), "dates": [event.date for event in failed_touches[-5:]]},
        })

    comparable = self._latest_comparable_limit(frame, [event for event in events if event.closed_limit])
    premium = self._next_day_premium(frame, comparable) if comparable else None
    if premium and premium.premium_pct is not None:
        premium_pct = float(premium.premium_pct)
        if premium_pct >= 1.0:
            delta = 8
        elif premium_pct >= 0.1:
            delta = 4
        elif premium_pct < 0:
            delta = -8
        else:
            delta = 0
        if delta:
            factors.append({
                "name": "涨停次日承接",
                "score_delta": delta,
                "message": f"{premium.limit_event.date} 涨停后次日收盘溢价 {premium_pct:.2f}%",
                "data": premium.to_dict(),
            })

    score_delta = sum(int(item["score_delta"]) for item in factors)
    base_score = 90
    legacy_score = max(0, min(100, base_score + score_delta))
    technical_score = self._technical_score_v1(recent, frame, events, current_price, premium)
    score = technical_score["total"]
    return {
        "status": "ready",
        "score": score,
        "legacy_score": legacy_score,
        "technical_score": technical_score,
        "score_delta": score_delta,
        "base_score": base_score,
        "current_price": round(current_price, 3),
        "last_trade_date": end_date.date().isoformat(),
        "message": f"技术评分 {score} 分，{technical_score['style_label']}，旧技术分 {legacy_score}",
        "factors": factors,
    }
```

---

## 5. DailyHistoryProvider._technical_score_v1 and direct helpers

**source:** `astock_guard/providers/history.py`
**class:** `DailyHistoryProvider`
**line range:** 747–1023

```python
def _technical_score_v1(
    self,
    recent: pd.DataFrame,
    frame: pd.DataFrame,
    events: list[LimitTouchEvent],
    current_price: float,
    premium: NextDayPremium | None,
) -> dict[str, Any]:
    end_date = recent["日期"].max()
    recent_for_shape = recent
    close_all = recent["收盘"].astype(float)
    last_close = float(close_all.iloc[-1])
    previous_close = float(close_all.iloc[-2]) if len(close_all) >= 2 else last_close
    latest_bar_change_pct = (last_close / previous_close - 1.0) * 100.0 if previous_close > 0 else 0.0
    if len(recent) >= 61 and abs(last_close / current_price - 1.0) <= 0.003 and latest_bar_change_pct >= 5.0:
        recent_for_shape = recent.iloc[:-1].copy()
    close = recent_for_shape["收盘"].astype(float)
    current_change_pct = (current_price / float(close.iloc[-1]) - 1.0) * 100.0 if len(close) and float(close.iloc[-1]) > 0 else 0.0

    def tail(days: int) -> pd.DataFrame:
        return recent_for_shape.tail(min(days, len(recent_for_shape))).copy()

    def amplitude(window: pd.DataFrame) -> float:
        if window.empty:
            return 999.0
        lo = float(window["最低"].astype(float).min())
        hi = float(window["最高"].astype(float).max())
        return (hi / lo - 1.0) * 100.0 if lo > 0 else 999.0

    def pct_return(window: pd.DataFrame) -> float:
        if len(window) < 2:
            return 0.0
        first = float(window.iloc[0]["收盘"])
        last = float(window.iloc[-1]["收盘"])
        return (last / first - 1.0) * 100.0 if first > 0 else 0.0

    w20 = tail(20)
    w40 = tail(40)
    w60 = tail(60)
    amp20 = amplitude(w20)
    amp40 = amplitude(w40)
    amp60 = amplitude(w60)
    ret20 = pct_return(w20)
    ret60 = pct_return(w60)
    high20 = float(w20["最高"].astype(float).max()) if not w20.empty else current_price
    high60 = float(w60["最高"].astype(float).max()) if not w60.empty else current_price
    close20 = w20["收盘"].astype(float)
    close_std20 = float(close20.std() / close20.mean() * 100.0) if len(close20) > 1 and close20.mean() > 0 else 999.0
    amount20 = pd.to_numeric(w20["成交额"], errors="coerce").dropna() if "成交额" in w20.columns else pd.Series(dtype=float)
    amount_mean20 = float(amount20.mean()) if len(amount20) else 0.0
    amount_std20 = float(amount20.std() / amount_mean20 * 100.0) if len(amount20) > 1 and amount_mean20 > 0 else 999.0
    today_amount = self._finite_float(recent.iloc[-1].get("成交额"), 0.0)
    amount_ratio20 = today_amount / amount_mean20 if amount_mean20 > 0 else None

    max_row = recent_for_shape.loc[recent_for_shape["最高"].idxmax()]
    max_high = float(max_row["最高"])
    peak_ratio = max_high / current_price if current_price > 0 else 999.0
    ma20 = close.rolling(20).mean()
    ma60 = close.rolling(60).mean()
    ma20_now = float(ma20.iloc[-1]) if len(ma20.dropna()) else None
    ma60_now = float(ma60.iloc[-1]) if len(ma60.dropna()) else None
    ma20_prev = float(ma20.iloc[-6]) if len(ma20.dropna()) >= 6 else None
    ma20_slope_pct = (ma20_now / ma20_prev - 1.0) * 100.0 if ma20_now and ma20_prev and ma20_prev > 0 else None

    recent_events = [event for event in events if pd.to_datetime(event.date) >= end_date - pd.Timedelta(days=60)]
    failed_touch_60 = len([event for event in recent_events if event.touched_limit and not event.closed_limit])
    premium_pct = None if premium is None or premium.premium_pct is None else float(premium.premium_pct)

    flat_components = {
        "structure": self._flat_structure_score(amp60, amp40, amp20, close_std20, amount_std20),
        "pressure": self._pressure_score(peak_ratio),
        "breakout": self._flat_breakout_score(current_price, current_change_pct, high20, high60, ma60_now),
        "volume_confirm": self._technical_volume_confirm_score(amount_ratio20, today_amount),
        "memory": self._technical_memory_score(failed_touch_60, premium_pct, strict_failed_zero=True),
    }
    trend_components = {
        "trend_strength": self._trend_strength_score(ma20_now, ma60_now, ma20_slope_pct, ret60, ret20),
        "position": self._trend_position_score(current_price, high60, ma20_now, peak_ratio),
        "breakout": self._trend_breakout_score(current_price, current_change_pct, high20, high60),
        "memory": self._technical_memory_score(failed_touch_60, premium_pct, strict_failed_zero=False),
        "risk_control": self._trend_risk_control_score(peak_ratio, ret60, amount_ratio20),
    }
    flat_score = sum(flat_components.values())
    trend_score = sum(trend_components.values())
    risk_penalty, risk_flags, veto = self._technical_common_risk(
        peak_ratio=peak_ratio,
        failed_touch_60=failed_touch_60,
        current_price=current_price,
        ma20=ma20_now,
        ma60=ma60_now,
        ret60=ret60,
        today_amount=today_amount,
    )
    raw_score = max(flat_score, trend_score)
    total = 0 if veto else max(0, min(100, raw_score + risk_penalty))
    if flat_score >= 70 and trend_score >= 70:
        style = "mixed"
    elif raw_score < 55:
        style = "weak"
    elif flat_score >= trend_score:
        style = "flat_breakout"
    else:
        style = "trend_acceleration"
    label_map = {
        "flat_breakout": "平铺爆发",
        "trend_acceleration": "趋势加速",
        "mixed": "平铺+趋势",
        "weak": "技术弱",
    }
    return {
        "status": "ready",
        "total": int(total),
        "style": style,
        "style_label": label_map[style],
        "level": self._technical_level(total),
        "flat_breakout": int(flat_score),
        "trend_acceleration": int(trend_score),
        "risk_penalty": int(risk_penalty),
        "veto": bool(veto),
        "components": {"flat": flat_components, "trend": trend_components},
        "risk_flags": risk_flags,
        "metrics": {
            "amp20": round(amp20, 3),
            "amp40": round(amp40, 3),
            "amp60": round(amp60, 3),
            "ret20": round(ret20, 3),
            "ret60": round(ret60, 3),
            "close_std20": round(close_std20, 3),
            "amount_std20": round(amount_std20, 3),
            "amount_ratio20": None if amount_ratio20 is None else round(amount_ratio20, 3),
            "today_amount_yi": None if not math.isfinite(today_amount) else round(today_amount / 100_000_000, 3),
            "peak_ratio": round(peak_ratio, 3),
            "ma20_slope_pct": None if ma20_slope_pct is None else round(ma20_slope_pct, 3),
            "failed_touch_60": failed_touch_60,
            "premium_pct": None if premium_pct is None else round(premium_pct, 3),
        },
    }
```

### Helper: _flat_structure_score (line 885)

```python
@staticmethod
def _flat_structure_score(amp60: float, amp40: float, amp20: float, close_std20: float, amount_std20: float) -> int:
    score = 0
    if amp60 <= 35:
        score += 10
    if amp40 <= 28:
        score += 8
    if amp20 <= 18:
        score += 7
    if close_std20 <= 6:
        score += 5
    if amount_std20 <= 60:
        score += 5
    return min(35, score)
```

### Helper: _pressure_score (line 900)

```python
@staticmethod
def _pressure_score(peak_ratio: float) -> int:
    if peak_ratio < 1.2:
        return 25
    if peak_ratio < 1.5:
        return 18
    if peak_ratio < 2.0:
        return 10
    if peak_ratio < 2.5:
        return 4
    return 0
```

### Helper: _flat_breakout_score (line 912)

```python
@staticmethod
def _flat_breakout_score(current_price: float, current_change_pct: float, high20: float, high60: float, ma60: float | None) -> int:
    score = 0
    if high60 > 0 and current_price >= high60 * 1.005:
        score += 8
    if high20 > 0 and current_price >= high20 * 1.005:
        score += 5
    if current_change_pct >= 7:
        score += 4
    if ma60 and current_price >= ma60:
        score += 3
    return min(20, score)
```

### Helper: _technical_volume_confirm_score (line 925)

```python
@staticmethod
def _technical_volume_confirm_score(amount_ratio20: float | None, today_amount: float) -> int:
    score = 0
    if amount_ratio20 is not None and amount_ratio20 >= 1.2:
        score += 5
    if amount_ratio20 is not None and amount_ratio20 <= 4.0:
        score += 3
    if today_amount >= 50_000_000:
        score += 2
    return min(10, score)
```

### Helper: _technical_memory_score (line 936)

```python
@staticmethod
def _technical_memory_score(failed_touch_60: int, premium_pct: float | None, strict_failed_zero: bool) -> int:
    score = 0
    if (failed_touch_60 == 0 if strict_failed_zero else failed_touch_60 <= 1):
        score += 5
    if premium_pct is not None and premium_pct >= 0.1:
        score += 5
    return min(10, score)
```

### Helper: _trend_strength_score (line 945)

```python
@staticmethod
def _trend_strength_score(ma20: float | None, ma60: float | None, ma20_slope_pct: float | None, ret60: float, ret20: float) -> int:
    score = 0
    if ma20 and ma60 and ma20 > ma60:
        score += 10
    if ma20_slope_pct is not None and ma20_slope_pct > 0:
        score += 8
    if 15 <= ret60 <= 60:
        score += 10
    if 5 <= ret20 <= 25:
        score += 7
    return min(35, score)
```

### Helper: _trend_position_score (line 958)

```python
@staticmethod
def _trend_position_score(current_price: float, high60: float, ma20: float | None, peak_ratio: float) -> int:
    score = 0
    if high60 > 0 and current_price >= high60 * 0.95:
        score += 8
    if ma20 and current_price <= ma20 * 1.25:
        score += 6
    if peak_ratio < 1.8:
        score += 6
    return min(20, score)
```

### Helper: _trend_breakout_score (line 969)

```python
@staticmethod
def _trend_breakout_score(current_price: float, current_change_pct: float, high20: float, high60: float) -> int:
    score = 0
    if high20 > 0 and current_price >= high20 * 1.005:
        score += 8
    if high60 > 0 and current_price >= high60 * 1.005:
        score += 8
    if current_change_pct >= 7:
        score += 4
    return min(20, score)
```

### Helper: _trend_risk_control_score (line 980)

```python
@staticmethod
def _trend_risk_control_score(peak_ratio: float, ret60: float, amount_ratio20: float | None) -> int:
    score = 0
    if peak_ratio < 2.0:
        score += 8
    if ret60 < 100 and (amount_ratio20 is None or amount_ratio20 <= 4.0):
        score += 7
    return min(15, score)
```

### Helper: _technical_common_risk (line 989)

```python
@staticmethod
def _technical_common_risk(
    *,
    peak_ratio: float,
    failed_touch_60: int,
    current_price: float,
    ma20: float | None,
    ma60: float | None,
    ret60: float,
    today_amount: float,
) -> tuple[int, list[dict[str, Any]], bool]:
    penalty = 0
    flags: list[dict[str, Any]] = []
    veto = peak_ratio >= 3.0
    if veto:
        flags.append({"name": "三倍周期风险", "message": f"近一年高点/当前价 {peak_ratio:.2f}，触发一票否决"})
    if peak_ratio >= 2.5:
        penalty -= 20
        flags.append({"name": "高点压力过重", "score_delta": -20})
    elif peak_ratio >= 2.0:
        penalty -= 12
        flags.append({"name": "高点压力偏重", "score_delta": -12})
    if failed_touch_60 >= 2:
        penalty -= 10
        flags.append({"name": "近期多次触板失败", "score_delta": -10, "count": failed_touch_60})
    if ma20 and ma60 and current_price < ma20 and current_price < ma60:
        penalty -= 10
        flags.append({"name": "均线下方弱势", "score_delta": -10})
    if ret60 >= 100:
        penalty -= 15
        flags.append({"name": "前期已翻倍", "score_delta": -15, "ret60": round(ret60, 3)})
    if today_amount and today_amount < 20_000_000:
        penalty -= 10
        flags.append({"name": "成交额过低", "score_delta": -10})
    return max(-40, penalty), flags, veto
```

### Helper: _technical_level (line 1025)

```python
@staticmethod
def _technical_level(total: float | int) -> str:
    value = float(total)
    if value >= 85:
        return "strong"
    if value >= 70:
        return "pass"
    if value >= 55:
        return "watch"
    return "weak"
```

### Helper: _finite_float (line 1037)

```python
@staticmethod
def _finite_float(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if math.isfinite(result) else default
```

---

## 6. VolumeScoringMixin

**source:** `astock_guard/engine/scoring/volume.py`
**class:** `VolumeScoringMixin`
**line range:** 1–342

```python
class VolumeScoringMixin:
    """Mixin for AlertEngine: volume and price-volume scoring methods."""

    def _volume_momentum_score(self, state: dict[str, Any], quote: Any) -> dict[str, Any]:
        window = self._record_quote_sample(quote)
        samples = list(window)
        technical = self._technical_score_from_strategy(state.get("strategy") or {}) or {}
        metrics = technical.get("metrics") if isinstance(technical.get("metrics"), dict) else {}
        meta = state.get("stock_meta") if isinstance(state.get("stock_meta"), dict) else {}

        short_window = self._volume_short_window_score(samples, quote)
        amount_confirm = self._volume_amount_confirm_score(quote, metrics)
        turnover_fit = self._volume_turnover_fit_score(quote, meta)
        history_compare = self._volume_history_compare_score(metrics)
        risk = self._volume_momentum_risk_penalty(samples, quote, metrics, meta)

        component_values = [
            short_window.get("score"),
            amount_confirm.get("score"),
            turnover_fit.get("score"),
            history_compare.get("score"),
        ]
        ready_components = [value for value in component_values if value is not None]
        status = "ready" if len(samples) >= 2 and ready_components else "warming"
        if quote.amount is None and quote.volume is None:
            status = "missing_quote_volume"
        total = sum(int(value or 0) for value in component_values) - int(risk.get("penalty") or 0)
        total = max(0, min(100, total))
        if status != "ready":
            level = "warming"
            label = "等待短窗口"
        elif total >= 85:
            level = "strong"
            label = "放量上推"
        elif total >= 70:
            level = "pass"
            label = "量能合格"
        elif total >= 55:
            level = "watch"
            label = "量能观察"
        else:
            level = "weak"
            label = "量能不足"

        return {
            "version": "volume_momentum_score_v1",
            "status": status,
            "total": total,
            "level": level,
            "label": label,
            "short_window": short_window,
            "amount_confirm": amount_confirm,
            "turnover_fit": turnover_fit,
            "history_compare": history_compare,
            "risk_penalty": risk,
            "metrics": {
                "sample_count": len(samples),
                "window_seconds": round(samples[-1]["timestamp"] - samples[0]["timestamp"], 3) if len(samples) >= 2 else 0,
                "price": self._round_or_none(quote.price, 3),
                "change_pct": self._round_or_none(quote.change_pct, 3),
                "amount_yi": self._round_or_none(None if quote.amount is None else quote.amount / 100_000_000, 3),
                "volume": quote.volume,
                "bid_vol1": quote.bid_vol1,
                "ask_vol1": quote.ask_vol1,
                "quote_source": quote.source,
            },
            "updated_at": time.time(),
        }

    def _record_quote_sample(self, quote: Any) -> deque[dict[str, Any]]:
        code = str(getattr(quote, "code", "") or "")
        window = self.runtime.quote_windows.setdefault(code, deque())
        timestamp = self._finite_or_none(getattr(quote, "timestamp", None)) or time.time()
        sample = {
            "timestamp": timestamp,
            "price": self._finite_or_none(getattr(quote, "price", None)),
            "change_pct": self._finite_or_none(getattr(quote, "change_pct", None)),
            "amount": self._finite_or_none(getattr(quote, "amount", None)),
            "volume": self._finite_or_none(getattr(quote, "volume", None)),
            "bid_vol1": self._finite_or_none(getattr(quote, "bid_vol1", None)),
            "ask_vol1": self._finite_or_none(getattr(quote, "ask_vol1", None)),
        }
        if not window or timestamp >= float(window[-1].get("timestamp") or 0):
            window.append(sample)
        else:
            window.clear()
            window.append(sample)
        cutoff = timestamp - self.runtime.quote_window_seconds
        while window and float(window[0].get("timestamp") or 0) < cutoff:
            window.popleft()
        return window

    def _volume_short_window_score(self, samples: list[dict[str, Any]], quote: Any) -> dict[str, Any]:
        if len(samples) < 2:
            return {"status": "warming", "score": 0, "message": "等待至少2个报价样本"}
        first = samples[0]
        last = samples[-1]
        seconds = max(0.001, float(last.get("timestamp") or 0) - float(first.get("timestamp") or 0))
        pct_delta = (self._finite_or_none(last.get("change_pct")) or 0) - (self._finite_or_none(first.get("change_pct")) or 0)
        price_delta_pct = 0.0
        first_price = self._finite_or_none(first.get("price"))
        last_price = self._finite_or_none(last.get("price"))
        if first_price and last_price:
            price_delta_pct = (last_price / first_price - 1.0) * 100.0
        amount_delta = self._positive_delta(first.get("amount"), last.get("amount"))
        volume_delta = self._positive_delta(first.get("volume"), last.get("volume"))
        changes = [self._finite_or_none(item.get("change_pct")) for item in samples]
        checked_changes = [value for value in changes if value is not None]
        monotonic_hits = sum(
            1 for prev, cur in zip(checked_changes, checked_changes[1:])
            if cur >= prev
        )
        monotonic_ratio = monotonic_hits / max(1, len(checked_changes) - 1)
        max_change = max(checked_changes) if checked_changes else None
        drawdown = 0.0 if max_change is None else max(0.0, max_change - (self._finite_or_none(last.get("change_pct")) or 0))

        score = 0
        reasons: list[str] = []
        if seconds >= 3:
            if pct_delta >= 0.8:
                score += 12
                reasons.append("短窗口涨幅推进强")
            elif pct_delta >= 0.4:
                score += 8
                reasons.append("短窗口涨幅推进")
            elif pct_delta >= 0.15:
                score += 4
                reasons.append("短窗口小幅推进")
        if monotonic_ratio >= 0.8:
            score += 8
            reasons.append("报价连续上推")
        elif monotonic_ratio >= 0.6:
            score += 5
            reasons.append("报价偏上行")
        if drawdown <= 0.15:
            score += 5
            reasons.append("短窗口回撤小")
        elif drawdown >= 0.5:
            reasons.append("短窗口有回落")
        if quote.change_pct >= self._near_limit_refresh_threshold_pct(str(quote.code or "")):
            score += 5
            reasons.append("接近涨停区")
        if amount_delta is not None and amount_delta >= 10_000_000:
            score += 5
            reasons.append("短窗口成交额增加")
        elif volume_delta is not None and volume_delta >= 10_000:
            score += 3
            reasons.append("短窗口成交量增加")
        score = max(0, min(35, score))
        return {
            "status": "ready",
            "score": score,
            "window_seconds": round(seconds, 3),
            "change_pct_delta": round(pct_delta, 3),
            "price_delta_pct": round(price_delta_pct, 3),
            "amount_delta_yi": self._round_or_none(None if amount_delta is None else amount_delta / 100_000_000, 4),
            "volume_delta": volume_delta,
            "monotonic_ratio": round(monotonic_ratio, 3),
            "drawdown_pct": round(drawdown, 3),
            "reasons": reasons,
        }

    def _volume_amount_confirm_score(self, quote: Any, metrics: dict[str, Any]) -> dict[str, Any]:
        amount = self._finite_or_none(getattr(quote, "amount", None))
        amount_ratio20 = self._finite_or_none(metrics.get("amount_ratio20"))
        if amount is not None and amount_ratio20 is not None:
            today_amount = self._finite_or_none(metrics.get("today_amount_yi"))
            if today_amount and today_amount > 0:
                amount_ratio20 = amount / (today_amount * 100_000_000) * amount_ratio20
        score = 0
        reasons: list[str] = []
        if amount_ratio20 is not None:
            if 1.2 <= amount_ratio20 <= 3.5:
                score += 14
                reasons.append("日内成交额相对20日均量健康放大")
            elif 0.8 <= amount_ratio20 < 1.2:
                score += 8
                reasons.append("日内成交额相对20日均量持平")
            elif 3.5 < amount_ratio20 <= 6.0:
                score += 8
                reasons.append("日内成交额相对20日均量显著放大")
            else:
                score += 3
                reasons.append("日内成交额相对20日均量异常放大")
        return {
            "status": "ready" if amount is not None else "missing",
            "score": score,
            "amount_ratio20": round(amount_ratio20, 3) if amount_ratio20 is not None else None,
            "reasons": reasons,
        }

    def _volume_turnover_fit_score(self, quote: Any, meta: dict[str, Any]) -> dict[str, Any]:
        volume = self._finite_or_none(getattr(quote, "volume", None))
        float_share = self._finite_or_none(meta.get("float_share"))
        float_mv = self._finite_or_none(meta.get("float_market_value"))
        if volume is None or not float_share:
            return {
                "status": "missing",
                "score": 0,
                "turnover_pct": None,
                "float_market_value_yi": self._round_or_none(None if float_mv is None else float_mv / 100_000_000, 3),
                "message": "缺少实时成交量或流通股本",
            }
        traded_shares = self._quote_volume_shares(quote)
        if traded_shares is None:
            return {
                "status": "missing",
                "score": 0,
                "turnover_pct": None,
                "float_market_value_yi": self._round_or_none(None if float_mv is None else float_mv / 100_000_000, 3),
                "message": "无法判断实时成交量单位",
            }
        turnover = traded_shares / float_share * 100.0
        low, high = 2.0, 12.0
        if float_mv is not None:
            if float_mv < 5_000_000_000:
                low, high = 5.0, 18.0
            elif float_mv < 15_000_000_000:
                low, high = 3.0, 12.0
            else:
                low, high = 1.5, 8.0
        score = 0
        if low <= turnover <= high:
            score = 20
            message = "换手与流通市值匹配"
        elif turnover < low:
            score = 8 if turnover >= low * 0.6 else 3
            message = "换手偏低，承接确认不足"
        else:
            score = 10 if turnover <= high * 1.4 else 4
            message = "换手偏高，分歧消耗偏大"
        return {
            "status": "ready",
            "score": score,
            "turnover_pct": round(turnover, 3),
            "fit_range_pct": [low, high],
            "message": message,
            "float_market_value_yi": self._round_or_none(None if float_mv is None else float_mv / 100_000_000, 3),
        }

    def _volume_history_compare_score(self, metrics: dict[str, Any]) -> dict[str, Any]:
        amount_ratio20 = self._finite_or_none(metrics.get("amount_ratio20"))
        amount_std20 = self._finite_or_none(metrics.get("amount_std20"))
        if amount_ratio20 is None and amount_std20 is None:
            return {"status": "missing", "score": 0, "message": "缺少历史成交额对比"}
        score = 0
        reasons: list[str] = []
        if amount_ratio20 is not None:
            if 1.2 <= amount_ratio20 <= 2.8:
                score += 12
                reasons.append("相对20日成交额温和放量")
            elif 2.8 < amount_ratio20 <= 4.5:
                score += 8
                reasons.append("相对20日成交额明显放量")
            elif 0.8 <= amount_ratio20 < 1.2:
                score += 6
                reasons.append("相对20日成交额略放大")
            elif amount_ratio20 > 4.5:
                score += 3
                reasons.append("相对20日成交额过大")
        if amount_std20 is not None:
            if amount_std20 <= 80:
                score += 8
                reasons.append("前期量能波动可控")
            elif amount_std20 <= 140:
                score += 5
                reasons.append("前期量能波动一般")
            else:
                reasons.append("前期量能波动偏大")
        return {
            "status": "ready",
            "score": max(0, min(20, score)),
            "amount_ratio20": self._round_or_none(amount_ratio20, 3),
            "amount_std20": self._round_or_none(amount_std20, 3),
            "reasons": reasons,
        }

    def _volume_momentum_risk_penalty(
        self,
        samples: list[dict[str, Any]],
        quote: Any,
        metrics: dict[str, Any],
        meta: dict[str, Any],
    ) -> dict[str, Any]:
        penalty = 0
        flags: list[str] = []
        if len(samples) >= 2:
            first = samples[0]
            last = samples[-1]
            pct_delta = (self._finite_or_none(last.get("change_pct")) or 0) - (self._finite_or_none(first.get("change_pct")) or 0)
            amount_delta = self._positive_delta(first.get("amount"), last.get("amount"))
            changes = [self._finite_or_none(item.get("change_pct")) for item in samples]
            checked = [value for value in changes if value is not None]
            if pct_delta >= 0.3 and (amount_delta is None or amount_delta < 2_000_000):
                penalty += 10
                flags.append("价格上推但短窗口成交额确认弱")
            if checked:
                drawdown = max(checked) - checked[-1]
                if drawdown >= 0.6:
                    penalty += 8
                    flags.append("短窗口冲高回落")
        amount = self._finite_or_none(getattr(quote, "amount", None))
        amount_ratio20 = self._finite_or_none(metrics.get("amount_ratio20"))
        if amount_ratio20 is not None and amount_ratio20 > 6.0:
            penalty += 12
            flags.append("历史对比爆量过高")
        if amount is not None and quote.change_pct >= 7 and amount < 20_000_000:
            penalty += 8
            flags.append("高涨幅但成交额偏低")
        volume = self._finite_or_none(getattr(quote, "volume", None))
        float_share = self._finite_or_none(meta.get("float_share"))
        if volume is not None and float_share:
            traded_shares = self._quote_volume_shares(quote)
            turnover = None if traded_shares is None else traded_shares / float_share * 100.0
            if turnover is not None and turnover >= 25:
                penalty += 10
                flags.append("换手过高")
        return {"penalty": max(0, min(35, penalty)), "flags": flags}

    def _quote_volume_shares(self, quote: Any) -> float | None:
        volume = self._finite_or_none(getattr(quote, "volume", None))
        if volume is None:
            return None
        amount = self._finite_or_none(getattr(quote, "amount", None))
        price = self._finite_or_none(getattr(quote, "price", None))
        if amount and price and price > 0:
            implied_shares = amount / price
            direct_error = abs(volume - implied_shares)
            hand_error = abs(volume * 100.0 - implied_shares)
            return volume if direct_error <= hand_error else volume * 100.0
        source = str(getattr(quote, "source", "") or "").lower()
        if source == "sina":
            return volume
        return volume * 100.0
```

---

## 7. AlertEngine._board_score

**source:** `astock_guard/alerts.py`
**class:** `AlertEngine`
**line range:** 3432–4046

Full source included in extract file. (Very long – calls `_sentiment_score`, `_board_external_adjustments`, `_board_specificity_delta`, `_board_member_market_stats`, `_board_component_scores`, `_main_logic_payload`, and cap logic.)

```python
def _board_score(self, item: dict[str, Any]) -> dict[str, Any]:
    board_summary = item.get("board_summary") or {}
    if board_summary.get("status") != "ready":
        return {"status": board_summary.get("status") or "unknown", "score": None, "factors": []}
    factors: list[dict[str, Any]] = []
    score = 40
    factors.append({"name": "板块基础分", "score_delta": 40, "message": "基础分 40，新算法优先看当前票是否是板块前排"})
    boards = self._board_member_targets(board_summary)
    changes = [self._float_or_none(board.get("board_change_pct")) for board in boards]
    changes = [value for value in changes if value is not None]
    if boards:
        breadth_delta = 2 if len(boards) >= 3 else 0
        score += breadth_delta
        if breadth_delta:
            factors.append({"name": "关联板块数量", "score_delta": breadth_delta, "message": f"有效参考板块 {len(boards)} 个，只给弱加分"})
    members_summary = item.get("board_members") or {}
    if changes and members_summary.get("status") != "ready":
        best = max(changes)
        avg_top3 = sum(changes[:3]) / min(len(changes), 3)
        delta = 0
        if best >= 5:
            delta += 6
        elif best >= 3:
            delta += 4
        elif best >= 1.5:
            delta += 2
        elif best <= 0:
            delta -= 5
        if avg_top3 >= 3:
            delta += 3
        elif avg_top3 < 0.5:
            delta -= 4
        if delta:
            score += delta
            factors.append({
                "name": "板块涨幅强度",
                "score_delta": delta,
                "message": f"尚未拿到成分股前20，先按板块涨幅弱评分：最强 {best:.2f}%，前三均值 {avg_top3:.2f}%",
                "data": {"best_change_pct": round(best, 3), "avg_top3_change_pct": round(avg_top3, 3)},
            })
    if members_summary.get("status") == "ready":
        current_code = str(item.get("code") or "")
        current_change = self._float_or_none(item.get("change_pct")) or 0.0
        current_streak = self._limit_streak_cached(current_code, current_change >= self._limit_like_threshold_pct(current_code))
        board_scores: list[dict[str, Any]] = []
        for board in members_summary.get("boards") or []:
            board_delta = 0
            board_factors: list[dict[str, Any]] = []
            logic_confidence = 0
            logic_reasons: list[str] = []
            board_name = str(board.get("board_name") or "")
            board_kind = str(board.get("board_kind") or "")
            specificity_delta = self._board_specificity_delta(board_name, board_kind)
            logic_confidence += specificity_delta
            if specificity_delta:
                board_delta += int(round(specificity_delta * 0.35))
                board_factors.append({
                    "name": "板块精准度",
                    "score_delta": int(round(specificity_delta * 0.35)),
                    "message": self._board_specificity_message(board_name, board_kind, specificity_delta),
                    "data": {"board_name": board_name, "board_kind": board_kind, "logic_delta": specificity_delta},
                })
                logic_reasons.append(self._board_specificity_message(board_name, board_kind, specificity_delta))
            rank = board.get("rank")
            if isinstance(rank, int):
                if rank == 1:
                    rank_delta = 28
                    logic_confidence += 25
                elif rank == 2:
                    rank_delta = 18
                    logic_confidence += 18
                elif rank == 3:
                    rank_delta = 8
                    logic_confidence += 10
                elif rank <= 5:
                    rank_delta = -4
                    logic_confidence -= 8
                elif rank <= 10:
                    rank_delta = -14
                    logic_confidence -= 16
                elif rank <= 20:
                    rank_delta = -24
                    logic_confidence -= 24
                else:
                    rank_delta = -28
                    logic_confidence -= 28
            else:
                rank_delta = -28
                logic_confidence -= 28
            board_delta += rank_delta
            if isinstance(rank, int):
                logic_reasons.append(f"涨幅排名第{rank}")
            board_factors.append({
                "name": "当前票板块地位",
                "score_delta": rank_delta,
                "message": f"{board.get('board_name') or '参考板块'}内涨幅排名第 {rank}" if isinstance(rank, int) else f"{board.get('board_name') or '参考板块'}未进前20，按后排处理",
                "data": {"rank": rank, "board_name": board.get("board_name")},
            })

            members = board.get("members") or []
            member_stats = self._board_member_market_stats(members, current_code)
            main_board_rank = member_stats.get("current_main_board_rank")
            growth_star_ahead = int(member_stats.get("growth_star_ahead_count") or 0)
            if self._is_main_board_stock(current_code):
                main_rank_delta = 0
                if isinstance(main_board_rank, int):
                    if main_board_rank == 1:
                        main_rank_delta = 10
                        logic_confidence += 12
                    elif main_board_rank == 2:
                        main_rank_delta = 6
                        logic_confidence += 8
                    elif main_board_rank == 3:
                        main_rank_delta = 2
                        logic_confidence += 3
                    elif main_board_rank > 5:
                        main_rank_delta = -8
                        logic_confidence -= 8
                else:
                    main_rank_delta = -6
                    logic_confidence -= 6
                if isinstance(rank, int) and rank > 3 and isinstance(main_board_rank, int) and main_board_rank <= 2:
                    main_rank_delta += 4
                    logic_confidence += 5
                    logic_reasons.append(f"全市场第{rank}但主板第{main_board_rank}")
                if growth_star_ahead >= 2 and (not isinstance(main_board_rank, int) or main_board_rank > 2):
                    main_rank_delta -= 6
                    logic_confidence -= 6
                if main_rank_delta:
                    board_delta += main_rank_delta
                    board_factors.append({
                        "name": "主板可交易地位",
                        "score_delta": main_rank_delta,
                        "message": (
                            f"全市场排名第 {rank if isinstance(rank, int) else '-'}，主板内排名第 {main_board_rank if isinstance(main_board_rank, int) else '-'}；"
                            f"创业板/科创板领先 {growth_star_ahead} 只"
                        ),
                        "data": member_stats,
                    })

            order_rank = board.get("limit_order_rank")
            order_count = board.get("limit_order_count")
            if isinstance(order_rank, int):
                order_total = order_count if isinstance(order_count, int) else 0
                if order_total <= 1:
                    order_delta = -4
                    logic_confidence -= 8
                elif order_total == 2:
                    order_delta = 8 if order_rank == 1 else -4
                    logic_confidence += 18 if order_rank == 1 else -6
                elif order_total == 3:
                    if order_rank == 1:
                        order_delta = 10
                        logic_confidence += 22
                    elif order_rank == 2:
                        order_delta = 2
                        logic_confidence += 12
                    else:
                        order_delta = -10
                        logic_confidence -= 14
                elif order_rank == 1:
                    order_delta = 14
                    logic_confidence += 25
                elif order_rank == 2:
                    order_delta = 6
                    logic_confidence += 15
                elif order_rank == 3:
                    order_delta = -6
                    logic_confidence += 4
                elif order_rank <= 5:
                    order_delta = -16
                    logic_confidence -= 18
                else:
                    order_delta = -22
                    logic_confidence -= 26
                board_delta += order_delta
                logic_reasons.append(f"封板顺位第{order_rank}/{order_count or 0}")
                board_factors.append({
                    "name": "板块内封板顺位",
                    "score_delta": order_delta,
                    "message": f"{board.get('board_name') or '参考板块'}内第 {order_rank} 个触板/封板，共 {order_count or 0} 个",
                    "data": {
                        "rank": order_rank,
                        "count": order_count,
                        "main_board_rank": board.get("main_board_limit_order_rank"),
                        "main_board_count": board.get("main_board_limit_order_count"),
                        "growth_star_count": board.get("growth_star_limit_order_count"),
                        "first_limit_time": board.get("first_limit_time"),
                    },
                })
            elif members_summary.get("require_limit_order_score"):
                board_delta -= 6
                logic_confidence -= 8
                board_factors.append({"name": "板块内封板顺位", "score_delta": -6, "message": "缺少涨停池/炸板池顺位数据，先扣主逻辑分"})

            main_order_rank = board.get("main_board_limit_order_rank")
            main_order_count = board.get("main_board_limit_order_count")
            growth_star_order_count = int(board.get("growth_star_limit_order_count") or 0)
            if self._is_main_board_stock(current_code) and isinstance(main_order_rank, int):
                main_order_delta = 0
                if main_order_rank == 1:
                    main_order_delta = 8
                    logic_confidence += 10
                elif main_order_rank == 2:
                    main_order_delta = 3
                    logic_confidence += 5
                elif main_order_rank > 2:
                    main_order_delta = -6
                    logic_confidence -= 6
                if growth_star_order_count >= 2 and main_order_rank > 1:
                    main_order_delta -= 4
                    logic_confidence -= 4
                if main_order_delta:
                    board_delta += main_order_delta
                    logic_reasons.append(f"主板封板顺位第{main_order_rank}/{main_order_count or 0}")
                    board_factors.append({
                        "name": "主板封板顺位",
                        "score_delta": main_order_delta,
                        "message": f"全市场封板顺位第 {order_rank if isinstance(order_rank, int) else '-'}，主板内第 {main_order_rank}/{main_order_count or 0}，创业板/科创板触板 {growth_star_order_count} 只",
                        "data": {
                            "main_board_limit_order_rank": main_order_rank,
                            "main_board_limit_order_count": main_order_count,
                            "growth_star_limit_order_count": growth_star_order_count,
                        },
                    })

            board_change = self._float_or_none(board.get("board_change_pct"))
            if board_change is not None:
                if board_change >= 5:
                    change_delta = 5
                    logic_confidence += 10
                elif board_change >= 3:
                    change_delta = 3
                    logic_confidence += 6
                elif board_change >= 1.5:
                    change_delta = 1
                    logic_confidence += 3
                elif board_change <= 0:
                    change_delta = -5
                    logic_confidence -= 8
                else:
                    change_delta = 0
                    logic_confidence -= 3
                if change_delta:
                    board_delta += change_delta
                    board_factors.append({
                        "name": "板块涨幅强度",
                        "score_delta": change_delta,
                        "message": f"{board.get('board_name') or '参考板块'}涨幅 {board_change:.2f}%",
                        "data": {"board_change_pct": round(board_change, 3)},
                    })

            member_changes = [self._float_or_none(member.get("change_pct")) for member in members]
            member_changes = [value for value in member_changes if value is not None]
            avg_change = sum(member_changes) / len(member_changes) if member_changes else 0.0
            red_ratio = sum(1 for value in member_changes if value > 0) / len(member_changes) if member_changes else 0.0
            strong_count = sum(1 for value in member_changes if value >= 5.0)
            heat_delta = 0
            if avg_change >= 4:
                heat_delta += 5
                logic_confidence += 10
            elif avg_change >= 2.5:
                heat_delta += 3
                logic_confidence += 6
            elif avg_change >= 1:
                heat_delta += 1
                logic_confidence += 2
            if red_ratio >= 0.8:
                heat_delta += 3
                logic_confidence += 4
            elif red_ratio >= 0.65:
                heat_delta += 1
                logic_confidence += 2
            elif red_ratio < 0.5:
                heat_delta -= 6
                logic_confidence -= 8
            if strong_count >= 5:
                heat_delta += 3
                logic_confidence += 6
            elif strong_count >= 3:
                heat_delta += 1
                logic_confidence += 3
            heat_delta = max(-8, min(heat_delta, 9))
            if heat_delta:
                board_delta += heat_delta
                board_factors.append({
                    "name": "板块扩散质量",
                    "score_delta": heat_delta,
                    "message": f"{board.get('board_name') or '参考板块'}前20均涨 {avg_change:.2f}%，红盘率 {red_ratio:.0%}",
                    "data": {"avg_change_pct": round(avg_change, 3), "red_ratio": round(red_ratio, 3), "strong_count": strong_count},
                })

            limit_count = sum(
                1
                for member in members
                if (self._float_or_none(member.get("change_pct")) or 0) >= self._limit_like_threshold_pct(str(member.get("code") or ""))
            )
            main_limit_count = int(member_stats.get("main_board_limit_like_count") or 0)
            growth_star_limit_count = int(member_stats.get("growth_star_limit_like_count") or 0)
            best_rank = rank if isinstance(rank, int) else None
            if limit_count >= 6:
                width_delta = 4 if best_rank is not None and best_rank <= 2 else -12
                logic_confidence += 20 if best_rank is not None and best_rank <= 2 else -14
            elif limit_count >= 3:
                width_delta = 6 if best_rank is not None and best_rank <= 2 else (2 if best_rank == 3 else -8)
                logic_confidence += 12 if best_rank is not None and best_rank <= 2 else (5 if best_rank == 3 else -10)
            elif limit_count == 2:
                width_delta = 2 if best_rank is not None and best_rank <= 2 else -4
                logic_confidence += 4 if best_rank is not None and best_rank <= 2 else -5
            elif limit_count == 1:
                width_delta = -8
                logic_confidence -= 10
            else:
                width_delta = -6
                logic_confidence -= 12
            if self._is_main_board_stock(current_code):
                if growth_star_limit_count >= 2 and main_limit_count <= 1 and (best_rank is None or best_rank > 2):
                    width_delta -= 8
                    logic_confidence -= 8
                elif main_limit_count >= 2 and isinstance(main_board_rank, int) and main_board_rank <= 2:
                    width_delta += 4
                    logic_confidence += 5
            if width_delta:
                board_delta += width_delta
                board_factors.append({
                    "name": "板块涨停宽度",
                    "score_delta": width_delta,
                    "message": f"{board.get('board_name') or '参考板块'}前20内 {limit_count} 只接近涨停，其中主板 {main_limit_count} 只，创业/科创 {growth_star_limit_count} 只",
                    "data": {
                        "limit_count_top20": limit_count,
                        "main_board_limit_like_count": main_limit_count,
                        "growth_star_limit_like_count": growth_star_limit_count,
                        "best_rank": best_rank,
                        "current_main_board_rank": main_board_rank,
                    },
                })

            member_streaks: dict[str, int] = {}
            for member in members:
                member_code = str(member.get("code") or "")
                member_change = self._float_or_none(member.get("change_pct")) or 0.0
                if not member_code or member_change < self._limit_like_threshold_pct(member_code):
                    continue
                member_streaks[member_code] = self._limit_streak_cached(member_code, include_current_limit=True).get("streak", 0)
            chain_streaks = [streak for streak in member_streaks.values() if streak >= 2]
            other_chain_streaks = [streak for code, streak in member_streaks.items() if code != current_code and streak >= 2]
            max_chain = max(chain_streaks) if chain_streaks else 0
            other_max_chain = max(other_chain_streaks) if other_chain_streaks else 0
            follow_penalty = 0
            front_order = isinstance(order_rank, int) and order_rank <= 2
            current_chain = int(current_streak.get("streak") or 0)
            if other_max_chain >= 2:
                if current_chain >= 2:
                    if current_chain >= other_max_chain:
                        if not front_order:
                            follow_penalty -= 10
                            logic_confidence -= 10
                        elif order_rank == 2:
                            follow_penalty -= 3
                            logic_confidence -= 3
                    elif not front_order:
                        follow_penalty -= 18
                        logic_confidence -= 18
                    elif order_rank == 2:
                        follow_penalty -= 5
                        logic_confidence -= 5
                elif not front_order:
                    if other_max_chain >= 4:
                        follow_penalty -= 30
                        logic_confidence -= 30
                    elif other_max_chain >= 3:
                        follow_penalty -= 26
                        logic_confidence -= 26
                    else:
                        follow_penalty -= 20
                        logic_confidence -= 20
                elif order_rank == 2:
                    follow_penalty -= 6
                    logic_confidence -= 6
            elif max_chain >= 4 and (best_rank is None or best_rank > 2):
                follow_penalty -= 16
                logic_confidence -= 16
            elif max_chain >= 3 and (best_rank is None or best_rank > 2):
                follow_penalty -= 12
                logic_confidence -= 12
            elif max_chain >= 2 and (best_rank is None or best_rank > 2):
                follow_penalty -= 8
                logic_confidence -= 8
            if limit_count >= 5 and (best_rank is None or best_rank > 3):
                follow_penalty -= 12
            elif limit_count >= 3 and (best_rank is None or best_rank > 3):
                follow_penalty -= 8
            if current_streak.get("streak", 0) < max_chain and (best_rank is None or best_rank > 10):
                follow_penalty -= 8
            if self._should_refresh_board_members(current_code, current_change) and board_change is not None and board_change < 1.5:
                follow_penalty -= 6
                logic_confidence -= 6
            follow_penalty = max(-42, follow_penalty)
            if follow_penalty:
                board_delta += follow_penalty
                board_factors.append({
                    "name": "连板/后排跟风风险",
                    "score_delta": follow_penalty,
                    "message": (
                        f"{board.get('board_name') or '参考板块'}已有连板票，当前票自身也是连板，按分歧回封风险处理"
                        if other_max_chain >= 2 and current_chain >= 2
                        else f"{board.get('board_name') or '参考板块'}已有连板票，当前票封板顺位不是前二，按跟风加重扣分"
                        if other_max_chain >= 2 and not front_order
                        else f"{board.get('board_name') or '参考板块'}已有连板或多只涨停，当前票不是前排"
                    ),
                    "data": {
                        "best_rank": best_rank,
                        "limit_order_rank": order_rank if isinstance(order_rank, int) else None,
                        "current_streak": current_streak,
                        "current_chain_streak": current_chain,
                        "max_chain_streak": max_chain,
                        "other_max_chain_streak": other_max_chain,
                        "other_chain_count": len(other_chain_streaks),
                        "limit_count_top20": limit_count,
                    },
                })

            same_window_count = self._same_window_limit_count(board.get("limit_pool_events") or [], current_code, window_seconds=600)
            if same_window_count >= 3:
                logic_confidence += 10
                logic_reasons.append(f"10分钟内同板块{same_window_count}只触板")
            elif same_window_count == 2:
                logic_confidence += 5
                logic_reasons.append("10分钟内同板块2只触板")

            logic_confidence = max(0, min(100, int(round(logic_confidence))))
            logic_status = "locked" if logic_confidence >= 70 else "candidate" if logic_confidence >= 55 else "weak"
            if logic_confidence < 55:
                board_delta -= 6
                board_factors.append({
                    "name": "主逻辑偏弱",
                    "score_delta": -6,
                    "message": f"{board_name or '参考板块'}主逻辑偏弱，已并入情绪分扣分",
                    "data": {"logic_confidence": logic_confidence, "logic_status": logic_status},
                })
            board_scores.append({
                "board_name": board.get("board_name"),
                "board_code": board.get("board_code"),
                "board_kind": board_kind,
                "score_delta": board_delta,
                "factors": board_factors,
                "rank": best_rank,
                "limit_order_rank": order_rank if isinstance(order_rank, int) else None,
                "main_board_rank": main_board_rank if isinstance(main_board_rank, int) else None,
                "main_board_limit_order_rank": main_order_rank if isinstance(main_order_rank, int) else None,
                "limit_order_count": order_count if isinstance(order_count, int) else 0,
                "first_limit_time": board.get("first_limit_time"),
                "limit_count_top20": limit_count,
                "main_board_limit_like_count": main_limit_count,
                "growth_star_limit_like_count": growth_star_limit_count,
                "other_max_chain_streak": other_max_chain,
                "other_chain_count": len(other_chain_streaks),
                "current_chain_streak": current_chain,
                "logic_confidence": logic_confidence,
                "logic_status": logic_status,
                "logic_reasons": logic_reasons[:5],
                "board_change_pct": board_change,
                "avg_change_pct": avg_change,
                "red_ratio": red_ratio,
                "strong_count": strong_count,
                "same_window_count": same_window_count,
            })
        if board_scores:
            sentiment_score = self._sentiment_score(item, board_scores)
            best_board_score = max(
                board_scores,
                key=lambda value: (
                    int(value.get("sentiment_total") or -1),
                    int(value.get("score_delta") or 0),
                    int(value.get("logic_confidence") or 0),
                ),
            )
            score += int(best_board_score["score_delta"])
            factors.append({
                "name": "主逻辑板块",
                "score_delta": int(best_board_score["score_delta"]),
                "message": f"采用 {best_board_score.get('board_name') or '参考板块'}，主逻辑已并入情绪分",
                "data": {
                    "board_name": best_board_score.get("board_name"),
                    "board_code": best_board_score.get("board_code"),
                    "logic_status": best_board_score.get("logic_status"),
                    "logic_reasons": best_board_score.get("logic_reasons") or [],
                },
            })
            factors.extend(best_board_score["factors"])
            cap = 100
            cap_reasons: list[str] = []
            best_rank = best_board_score.get("rank")
            best_main_rank = best_board_score.get("main_board_rank")
            best_order_rank = best_board_score.get("limit_order_rank")
            best_main_order_rank = best_board_score.get("main_board_limit_order_rank")
            best_order_count = int(best_board_score.get("limit_order_count") or 0)
            best_limit_count = int(best_board_score.get("limit_count_top20") or 0)
            best_main_limit_count = int(best_board_score.get("main_board_limit_like_count") or 0)
            best_growth_star_limit_count = int(best_board_score.get("growth_star_limit_like_count") or 0)
            best_other_max_chain = int(best_board_score.get("other_max_chain_streak") or 0)
            best_current_chain = int(best_board_score.get("current_chain_streak") or 0)
            if not isinstance(best_rank, int) or best_rank > 10:
                cap = min(cap, 55)
                cap_reasons.append("当前票未进板块前10")
            elif best_rank > 3:
                if self._is_main_board_stock(str(item.get("code") or "")) and isinstance(best_main_rank, int) and best_main_rank <= 2:
                    cap = min(cap, 82)
                    cap_reasons.append("当前票不是全市场前三，但属于主板前二")
                else:
                    cap = min(cap, 70)
                    cap_reasons.append("当前票不是板块前三")
            if best_order_count <= 1 and best_limit_count <= 1:
                cap = min(cap, 76)
                cap_reasons.append("单票触板缺少板块扩散验证")
            if best_order_count >= 3 and isinstance(best_order_rank, int) and best_order_rank > 2:
                if self._is_main_board_stock(str(item.get("code") or "")) and isinstance(best_main_order_rank, int) and best_main_order_rank <= 2:
                    cap = min(cap, 82 if best_order_rank == 3 else 76)
                    cap_reasons.append("全市场封板顺位偏后，但主板封板顺位前二")
                else:
                    cap = min(cap, 75 if best_order_rank == 3 else 65)
                    cap_reasons.append("板块内封板顺位偏后")
            if best_growth_star_limit_count >= 2 and best_main_limit_count <= 1 and not (isinstance(best_main_rank, int) and best_main_rank <= 2):
                cap = min(cap, 68)
                cap_reasons.append("板块强度主要来自创业板/科创板，当前主板票不是主板前排")
            chain_risky_boards = [
                board
                for board in board_scores
                if int(board.get("other_max_chain_streak") or 0) >= 2
                and not (isinstance(board.get("limit_order_rank"), int) and int(board.get("limit_order_rank") or 0) <= 2)
            ]
            chain_front_boards = [
                board
                for board in board_scores
                if int(board.get("other_max_chain_streak") or 0) >= 2
                and isinstance(board.get("limit_order_rank"), int)
                and int(board.get("limit_order_rank") or 0) <= 2
            ]
            if best_current_chain >= 2 and best_other_max_chain >= 2 and not (isinstance(best_order_rank, int) and best_order_rank <= 2):
                cap = min(cap, 75 if best_current_chain >= best_other_max_chain else 68)
                cap_reasons.append("当前票自身连板但封板顺位偏后，按分歧回封风险限制")
            elif best_other_max_chain >= 2 and not (isinstance(best_order_rank, int) and best_order_rank <= 2):
                cap = min(cap, 60 if best_order_rank == 3 else 55)
                cap_reasons.append("所选板块已有连板票且当前票不是前二顺位")
            elif chain_risky_boards and not chain_front_boards:
                cap = min(cap, 62)
                cap_reasons.append("关联板块有连板票，但当前票没有任何前二顺位确认")
            if cap < 100 and score > cap:
                delta = cap - score
                score = cap
                factors.append({
                    "name": "情绪分上限",
                    "score_delta": delta,
                    "message": "；".join(cap_reasons),
                    "data": {
                        "cap": cap,
                        "rank": best_rank,
                        "main_board_rank": best_main_rank,
                        "limit_order_rank": best_order_rank,
                        "main_board_limit_order_rank": best_main_order_rank,
                        "limit_order_count": best_order_count,
                        "limit_count_top20": best_limit_count,
                        "main_board_limit_like_count": best_main_limit_count,
                        "growth_star_limit_like_count": best_growth_star_limit_count,
                        "other_max_chain_streak": best_other_max_chain,
                        "chain_risky_board_count": len(chain_risky_boards),
                        "chain_front_board_count": len(chain_front_boards),
                    },
                })
    elif self._should_refresh_board_members(str(item.get("code") or ""), item.get("change_pct")):
        factors.append({"name": "板块成分股", "score_delta": 0, "message": "等待成分股前20数据"})
    external = self._board_external_adjustments(item)
    if external["score_delta"]:
        score += int(external["score_delta"])
        factors.extend(external["factors"])
    ready_board_scores = locals().get("board_scores") if members_summary.get("status") == "ready" else []
    sentiment_score = locals().get("sentiment_score") if members_summary.get("status") == "ready" else None
    legacy_score = max(0, min(100, score))
    external_delta = int(external.get("score_delta") or 0)
    if isinstance(sentiment_score, dict) and sentiment_score.get("status") == "ready":
        raw_sentiment_total = int(sentiment_score.get("total") or 0)
        final_score = max(0, min(100, raw_sentiment_total + external_delta))
        final_floor = self._sentiment_final_floor(sentiment_score)
        if raw_sentiment_total > 0 and final_score < final_floor:
            final_score = final_floor
        sentiment_score = copy.deepcopy(sentiment_score)
        sentiment_score["raw_total"] = raw_sentiment_total
        sentiment_score["external_delta"] = external_delta
        sentiment_score["floor"] = final_floor
        sentiment_score["total"] = final_score
    else:
        final_score = legacy_score
    if isinstance(sentiment_score, dict) and sentiment_score.get("status") == "ready":
        factors.insert(0, {
            "name": "情绪分结构化",
            "score_delta": final_score - legacy_score,
            "message": (
                f"新情绪分 {final_score} = 地位 {sentiment_score.get('position')} + "
                f"强度 {sentiment_score.get('strength')} + 生态 {sentiment_score.get('limit_ecology')} + "
                f"逻辑 {sentiment_score.get('logic')} {sentiment_score.get('risk_penalty')}，外部修正 {external_delta}"
            ),
            "data": sentiment_score,
        })
    return {
        "status": "ready",
        "score": final_score,
        "legacy_score": legacy_score,
        "sentiment_score": sentiment_score,
        "component_scores": self._board_component_scores(final_score, ready_board_scores if isinstance(ready_board_scores, list) else [], external),
        "factors": factors,
        "board_count": len(boards),
        "member_status": members_summary.get("status") or "idle",
        "main_logic": self._main_logic_payload(ready_board_scores) if members_summary.get("status") == "ready" and isinstance(ready_board_scores, list) else None,
        "version": "sentiment_score_v1_structured",
    }
```

---

## 8. AlertEngine._sentiment_score and sub-scores

**source:** `astock_guard/alerts.py`
**class:** `AlertEngine`
**line range:** 4048–4310

### _sentiment_score (line 4048)

```python
def _sentiment_score(self, item: dict[str, Any], board_scores: list[dict[str, Any]]) -> dict[str, Any]:
    current_code = str(item.get("code") or "")
    candidates = [self._sentiment_board_score(item, board) for board in board_scores]
    for board, candidate in zip(board_scores, candidates):
        board["sentiment_total"] = candidate["total"]
        board["sentiment_components"] = candidate["components"]
        board["sentiment_level"] = candidate["level"]
    primary = max(
        candidates,
        key=lambda value: (
            int(value.get("total") or 0),
            int(((value.get("components") or {}).get("position")) or 0),
            int(value.get("confidence") or 0),
        ),
        default=None,
    )
    if primary is None:
        return {"status": "empty", "total": None, "candidates": []}
    total = int(primary["total"])
    return {
        "status": "ready",
        "total": total,
        "raw_total": primary.get("raw_total"),
        "floor": primary.get("floor"),
        "position": primary["components"]["position"],
        "strength": primary["components"]["strength"],
        "limit_ecology": primary["components"]["limit_ecology"],
        "logic": primary["components"]["logic"],
        "risk_penalty": primary["components"]["risk_penalty"],
        "level": self._sentiment_level(total),
        "main_logic": primary["board"],
        "confidence": primary["confidence"],
        "candidates": candidates[:5],
        "code": current_code,
    }
```

### _sentiment_board_score (line 4084)

```python
def _sentiment_board_score(self, item: dict[str, Any], board: dict[str, Any]) -> dict[str, Any]:
    position = self._sentiment_position_score(item, board)
    strength = self._sentiment_strength_score(board)
    ecology = self._sentiment_limit_ecology_score(board)
    logic = self._sentiment_logic_score(board)
    risk_penalty, risk_reasons = self._sentiment_risk_penalty(item, board)
    positive_total = position + strength + ecology + logic
    raw_total = position + strength + ecology + logic + risk_penalty
    total = max(0, min(100, raw_total))
    floor = self._sentiment_board_floor(position, strength, ecology, logic, board)
    if positive_total > 0 and total < floor:
        total = floor
    confidence = int(board.get("logic_confidence") or 0)
    return {
        "board": {
            "board_code": board.get("board_code"),
            "board_name": board.get("board_name"),
            "board_kind": board.get("board_kind"),
            "rank": board.get("rank"),
            "main_board_rank": board.get("main_board_rank"),
            "limit_order_rank": board.get("limit_order_rank"),
            "main_board_limit_order_rank": board.get("main_board_limit_order_rank"),
            "limit_order_count": board.get("limit_order_count"),
            "limit_count_top20": board.get("limit_count_top20"),
            "board_change_pct": board.get("board_change_pct"),
            "avg_change_pct": round(float(board.get("avg_change_pct") or 0), 3),
        },
        "total": int(total),
        "raw_total": int(max(0, min(100, raw_total))),
        "floor": floor,
        "confidence": confidence,
        "level": self._sentiment_level(total),
        "components": {
            "position": position,
            "strength": strength,
            "limit_ecology": ecology,
            "logic": logic,
            "risk_penalty": risk_penalty,
        },
        "risk_reasons": risk_reasons,
    }
```

### _sentiment_board_floor (line 4126)

```python
@staticmethod
def _sentiment_board_floor(
    position: int,
    strength: int,
    ecology: int,
    logic: int,
    board: dict[str, Any],
) -> int:
    positive_total = int(position or 0) + int(strength or 0) + int(ecology or 0) + int(logic or 0)
    if positive_total <= 0:
        return 0
    floor = 8
    if positive_total >= 35:
        floor = 18
    elif positive_total >= 25:
        floor = 14
    elif positive_total >= 15:
        floor = 10
    rank = board.get("rank")
    order_rank = board.get("limit_order_rank")
    main_rank = board.get("main_board_rank")
    main_order_rank = board.get("main_board_limit_order_rank")
    if isinstance(rank, int) and rank <= 3:
        floor = max(floor, 35)
    if isinstance(order_rank, int) and order_rank <= 2:
        floor = max(floor, 40)
    if isinstance(main_rank, int) and main_rank <= 2:
        floor = max(floor, 28)
    if isinstance(main_order_rank, int) and main_order_rank <= 2:
        floor = max(floor, 32)
    return min(50, floor)
```

### _sentiment_final_floor (line 4159)

```python
@staticmethod
def _sentiment_final_floor(sentiment_score: dict[str, Any]) -> int:
    floor = int(sentiment_score.get("floor") or 0)
    if floor <= 0:
        return 0
    return max(5, min(45, floor - 6))
```

### _sentiment_position_score (line 4166)

```python
def _sentiment_position_score(self, item: dict[str, Any], board: dict[str, Any]) -> int:
    rank = board.get("rank")
    if rank == 1:
        score = 40
    elif rank == 2:
        score = 34
    elif rank == 3:
        score = 24
    elif isinstance(rank, int) and rank <= 5:
        score = 12
    elif isinstance(rank, int) and rank <= 10:
        score = 4
    else:
        score = 0
    current_code = str(item.get("code") or "")
    if self._is_main_board_stock(current_code):
        main_rank = board.get("main_board_rank")
        if main_rank == 1:
            score += 6
        elif main_rank == 2:
            score += 4
        elif main_rank == 3:
            score += 2
        growth_star_ahead = max(0, int(board.get("rank") or 0) - int(main_rank or 0)) if isinstance(main_rank, int) and isinstance(rank, int) else 0
        if int(board.get("growth_star_limit_like_count") or 0) >= 2 and (not isinstance(main_rank, int) or main_rank > 2):
            score -= 8
        elif growth_star_ahead >= 2 and (not isinstance(main_rank, int) or main_rank > 2):
            score -= 8
    return max(0, min(40, int(score)))
```

### _sentiment_strength_score (line 4196)

```python
def _sentiment_strength_score(self, board: dict[str, Any]) -> int:
    score = 0
    board_change = self._float_or_none(board.get("board_change_pct"))
    if board_change is not None:
        if board_change >= 4:
            score += 8
        elif board_change >= 2:
            score += 6
        elif board_change >= 1:
            score += 3
        elif board_change >= 0:
            score += 1
    avg_change = self._float_or_none(board.get("avg_change_pct")) or 0.0
    if avg_change >= 3:
        score += 5
    elif avg_change >= 2:
        score += 3
    elif avg_change >= 1:
        score += 1
    red_ratio = self._float_or_none(board.get("red_ratio")) or 0.0
    if red_ratio >= 0.8:
        score += 4
    elif red_ratio >= 0.65:
        score += 2
    strong_count = int(board.get("strong_count") or 0)
    if strong_count >= 5:
        score += 3
    elif strong_count >= 3:
        score += 2
    elif strong_count >= 1:
        score += 1
    return max(0, min(20, int(score)))
```

### _sentiment_limit_ecology_score (line 4229)

```python
@staticmethod
def _sentiment_limit_ecology_score(board: dict[str, Any]) -> int:
    score = 0
    order_rank = board.get("limit_order_rank")
    if order_rank == 1:
        score += 12
    elif order_rank == 2:
        score += 9
    elif order_rank == 3:
        score += 4
    main_order_rank = board.get("main_board_limit_order_rank")
    if main_order_rank == 1:
        score += 5
    elif main_order_rank == 2:
        score += 3
    elif main_order_rank == 3:
        score += 1
    same_window = int(board.get("same_window_count") or 0)
    if same_window >= 3:
        score += 5
    elif same_window == 2:
        score += 3
    limit_count = int(board.get("limit_count_top20") or 0)
    if limit_count >= 3:
        score += 3
    elif limit_count == 2:
        score += 2
    return max(0, min(25, int(score)))
```

### _sentiment_logic_score (line 4258)

```python
def _sentiment_logic_score(self, board: dict[str, Any]) -> int:
    score = 0
    specificity = self._board_specificity_delta(str(board.get("board_name") or ""), str(board.get("board_kind") or ""))
    if specificity > 0:
        score += 5
    elif specificity == 0:
        score += 3
    elif specificity > -20:
        score += 1
    if board.get("rank") in {1, 2}:
        score += 5
    if int(board.get("limit_count_top20") or 0) >= 2:
        score += 3
    board_change = self._float_or_none(board.get("board_change_pct"))
    if board_change is not None and board_change >= 2:
        score += 2
    return max(0, min(15, int(score)))
```

### _sentiment_risk_penalty (line 4276)

```python
def _sentiment_risk_penalty(self, item: dict[str, Any], board: dict[str, Any]) -> tuple[int, list[str]]:
    penalty = 0
    reasons: list[str] = []
    order_rank = board.get("limit_order_rank")
    rank = board.get("rank")
    front_order = isinstance(order_rank, int) and order_rank <= 2
    other_chain = int(board.get("other_max_chain_streak") or 0)
    if other_chain >= 3 and not front_order:
        penalty += 28
        reasons.append("板块已有3板以上票且当前票不是前二触板")
    elif other_chain >= 2 and not front_order:
        penalty += 20
        reasons.append("板块已有连板票且当前票不是前二触板")
    if isinstance(order_rank, int) and order_rank >= 4:
        penalty += 15
        reasons.append("板块内封板顺位第4以后")
    if isinstance(rank, int) and rank > 5:
        penalty += 12
        reasons.append("板块涨幅排名5名以后")
    main_rank = board.get("main_board_rank")
    if self._is_main_board_stock(str(item.get("code") or "")):
        if int(board.get("growth_star_limit_like_count") or 0) >= 2 and (not isinstance(main_rank, int) or main_rank > 2):
            penalty += 10
            reasons.append("板块主要由创业板/科创板带动，当前主板票不是主板前二")
    if int(board.get("limit_count_top20") or 0) <= 1:
        penalty += 8
        reasons.append("单票独涨，缺少板块扩散")
    first_time = self._time_sort_key(board.get("first_limit_time"))
    if first_time >= 130000 and not (isinstance(order_rank, int) and order_rank <= 2):
        penalty += 8
        reasons.append("下午封板且不是板块前二")
    if int(board.get("logic_confidence") or 0) < 55:
        penalty += 10
        reasons.append("主逻辑偏弱")
    return -min(40, penalty), reasons
```

### _sentiment_level (line 4312)

```python
@staticmethod
def _sentiment_level(total: float | int) -> str:
    value = float(total)
    if value >= 85:
        return "strong"
    if value >= 70:
        return "pass"
    if value >= 55:
        return "watch"
    return "weak"
```

---

## 9. AlertEngine._board_external_adjustments

**source:** `astock_guard/alerts.py`
**class:** `AlertEngine`
**line range:** 4323–4449

```python
def _board_external_adjustments(self, item: dict[str, Any]) -> dict[str, Any]:
    factors: list[dict[str, Any]] = []
    score_delta = 0
    component = {"fund_flow": None, "seal_strength": None, "intraday": None, "kline_risk": None}

    fund_flow = item.get("fund_flow") or {}
    if isinstance(fund_flow, dict) and fund_flow.get("status") == "ready":
        summary = fund_flow.get("summary") or {}
        latest = fund_flow.get("latest") or {}
        latest_pct = self._float_or_none(latest.get("main_net_inflow_pct"))
        main_3d = self._float_or_none(summary.get("main_net_inflow_3d_yi"))
        positive_days = int(summary.get("positive_main_days_5d") or 0)
        fund_delta = 0
        if latest_pct is not None:
            if latest_pct >= 15:
                fund_delta += 6
            elif latest_pct >= 8:
                fund_delta += 4
            elif latest_pct <= -10:
                fund_delta -= 8
            elif latest_pct <= -5:
                fund_delta -= 4
        if main_3d is not None:
            if main_3d >= 1.0:
                fund_delta += 4
            elif main_3d > 0:
                fund_delta += 2
            elif main_3d <= -1.0:
                fund_delta -= 5
        if positive_days >= 4:
            fund_delta += 2
        elif positive_days <= 1 and latest_pct is not None and latest_pct < 0:
            fund_delta -= 3
        fund_delta = max(-10, min(10, fund_delta))
        component["fund_flow"] = fund_delta
        if fund_delta:
            score_delta += fund_delta
            factors.append({
                "name": "个股资金确认",
                "score_delta": fund_delta,
                "message": f"主力净占比 {latest_pct if latest_pct is not None else '-'}%，3日主力净流入 {main_3d if main_3d is not None else '-'} 亿，5日正流入 {positive_days} 天",
                "data": {"latest_main_net_inflow_pct": latest_pct, "main_net_inflow_3d_yi": main_3d, "positive_main_days_5d": positive_days},
            })
    elif self._should_refresh_board_members(str(item.get("code") or ""), item.get("change_pct")):
        factors.append({"name": "个股资金确认", "score_delta": 0, "message": "等待候选预热资金流缓存"})

    seal_delta = self._seal_strength_delta_from_state(item)
    seal_data = self._seal_strength_data_from_state(item)
    component["seal_strength"] = seal_delta
    component["entry_feasibility"] = seal_data.get("entry_feasibility")
    if seal_delta:
        score_delta += seal_delta
        factors.append({
            "name": "弱封风险",
            "score_delta": seal_delta,
            "message": "封单过弱才扣分；封单过强只标记买入难度，不再给情绪分加分",
            "data": seal_data,
        })
    elif seal_data.get("entry_feasibility") in {"hard_to_fill", "very_hard_to_fill"}:
        factors.append({
            "name": "买入难度",
            "score_delta": 0,
            "message": "封单偏强，说明可能买不进；不作为板块加分",
            "data": seal_data,
        })

    intraday = item.get("intraday_quality") or {}
    if isinstance(intraday, dict) and intraday.get("status") == "ready":
        open_count = int(intraday.get("open_board_minute_count") or 0)
        sealed_ratio = self._float_or_none(intraday.get("sealed_ratio_after_limit"))
        drop = self._float_or_none(intraday.get("open_drop_pct"))
        intraday_delta = 0
        if sealed_ratio is not None and sealed_ratio >= 0.95 and open_count == 0:
            intraday_delta += 4
        elif sealed_ratio is not None and sealed_ratio < 0.7:
            intraday_delta -= 6
        if open_count >= 3:
            intraday_delta -= 6
        elif open_count == 1:
            intraday_delta -= 2
        if drop is not None and drop <= -2.5:
            intraday_delta -= 4
        intraday_delta = max(-10, min(6, intraday_delta))
        component["intraday"] = intraday_delta
        if intraday_delta:
            score_delta += intraday_delta
            factors.append({
                "name": "分时封板质量",
                "score_delta": intraday_delta,
                "message": f"封板率 {sealed_ratio if sealed_ratio is not None else '-'}，开板分钟 {open_count}，开板低点 {drop if drop is not None else '-'}%",
                "data": {
                    "sealed_ratio_after_limit": sealed_ratio,
                    "open_board_minute_count": open_count,
                    "open_drop_pct": drop,
                },
            })

    open_board_count = int(item.get("open_board_count") or self.runtime.open_board_counts.get(str(item.get("code") or ""), 0) or 0)
    if open_board_count >= 3:
        score_delta -= 15
        factors.append({
            "name": "反复炸板",
            "score_delta": -15,
            "message": f"今日已炸板 {open_board_count} 次，按规则扣情绪分 15",
            "data": {"open_board_count": open_board_count},
        })

    strategy = item.get("strategy") or {}
    kline_score = self._kline_score_from_strategy(strategy)
    if kline_score is not None:
        kline_delta = 0
        if kline_score < 55:
            kline_delta = -12
        elif kline_score < 65:
            kline_delta = -6
        elif kline_score >= 90:
            kline_delta = 3
        component["kline_risk"] = kline_delta
        if kline_delta:
            score_delta += kline_delta
            factors.append({
                "name": "技术风险修正",
                "score_delta": kline_delta,
                "message": f"技术分 {kline_score:.0f}，用于限制情绪分对问题个股的高估",
                "data": {"kline_score": kline_score},
            })
    return {"score_delta": score_delta, "factors": factors, "component": component}
```

Also called by `_board_external_adjustments`:

### _seal_strength_delta_from_state (line 4451)

```python
def _seal_strength_delta_from_state(self, item: dict[str, Any]) -> int:
    data = self._seal_strength_data_from_state(item)
    pct = self._float_or_none(data.get("seal_amount_float_mv_pct"))
    at_limit = bool(item.get("at_limit"))
    if pct is None:
        return 0
    if pct >= 0.2:
        return 0
    if at_limit:
        return -8
    if (self._float_or_none(item.get("change_pct")) or 0) >= self._near_limit_refresh_threshold_pct(str(item.get("code") or "")):
        return -4
    return 0
```

### _seal_strength_data_from_state (line 4465)

```python
def _seal_strength_data_from_state(self, item: dict[str, Any]) -> dict[str, Any]:
    meta = item.get("stock_meta") if isinstance(item.get("stock_meta"), dict) else {}
    float_mv = self._float_or_none(meta.get("float_market_value"))
    limit_price = self._float_or_none(item.get("limit_up_price"))
    seal_volume = self._float_or_none(item.get("seal_volume"))
    seal_amount = None
    pct = None
    if limit_price and seal_volume:
        seal_amount = seal_volume * 100.0 * limit_price
        if float_mv:
            pct = seal_amount / float_mv * 100.0
    return {
        "seal_volume": seal_volume,
        "limit_price": limit_price,
        "seal_amount_yi": None if seal_amount is None else round(seal_amount / 100_000_000, 3),
        "float_market_value_yi": None if float_mv is None else round(float_mv / 100_000_000, 3),
        "seal_amount_float_mv_pct": None if pct is None else round(pct, 3),
        "entry_feasibility": self._entry_feasibility_from_seal_pct(pct),
    }
```

---

## 10. AlertEngine._record_score_snapshot

**source:** `astock_guard/alerts.py`
**class:** `AlertEngine`
**line range:** 2028–2081

```python
def _record_score_snapshot(
    self,
    item: dict[str, Any],
    stage: str,
    *,
    source_area: str,
    event_time: str | None = None,
    passed: bool | None = None,
    reject_reason: str = "",
    raw: dict[str, Any] | None = None,
    trade_date: str | None = None,
    once: bool = False,
    once_key: str | None = None,
) -> None:
    if not item:
        return
    code = str(item.get("code") or "").zfill(6)[-6:]
    date_key = self._normalize_trade_date(trade_date or self._today_key())
    memory_key = once_key or f"{date_key}:{source_area}:{stage}:{code}:{reject_reason}"
    if once and memory_key in self.runtime.score_snapshot_once_keys:
        return
    try:
        result = self.score_snapshots.record(
            item,
            stage,
            source_area=source_area,
            event_time=event_time,
            passed=passed,
            reject_reason=reject_reason,
            raw=raw,
            trade_date=date_key,
            once=once,
            idempotency_key=memory_key,
        )
        if once and result.get("ok"):
            self.runtime.score_snapshot_once_keys.add(memory_key)
        if not result.get("skipped") and not result.get("db_ok", True):
            self.health.record(
                "score_snapshots",
                False,
                None,
                category="score_snapshots",
                detail={"code": code, "stage": stage, "log_ok": result.get("log_ok")},
                error=str(result.get("db_error") or "score snapshot database write failed"),
            )
    except Exception as exc:  # noqa: BLE001
        self.health.record(
            "score_snapshots",
            False,
            None,
            category="score_snapshots",
            detail={"code": code, "stage": stage},
            error=f"{type(exc).__name__}: {exc}",
        )
```

---

## 11. Additional helpers called by _board_score

### _board_specificity_delta (line 4612)

```python
def _board_specificity_delta(self, board_name: str, board_kind: str) -> int:
    name = str(board_name or "")
    upper = name.upper()
    noise_keywords = (...)
    if any(keyword.upper() in upper for keyword in noise_keywords):
        return -30
    broad_keywords = (...)
    precise_keywords = (...)
    if any(keyword.upper() in upper for keyword in precise_keywords):
        return 12
    if board_kind == "tag":
        return -25
    if board_kind == "industry":
        return -10
    if len(name) <= 4 and not any(keyword.upper() in upper for keyword in precise_keywords):
        return -6
    if any(keyword.upper() in upper for keyword in broad_keywords):
        return -8
    return 4 if board_kind == "concept" else 0
```

### _board_member_market_stats (line 4523)

Full source included above (lines 4523–4562). Filters members by main board vs growth/star, computes rank and counts.

### _main_logic_payload (line 4564)

Full source included above (lines 4564–4610). Sorts board_scores, picks primary + support + rejected.

### _board_component_scores (line 4497)

```python
@staticmethod
def _board_component_scores(final_score: int, board_scores: list[dict[str, Any]], external: dict[str, Any]) -> dict[str, Any]:
    ...
```

### _board_score_stage_snapshot (line 3193)

```python
def _board_score_stage_snapshot(self, item: dict[str, Any], stage: str) -> dict[str, Any] | None:
    score = item.get("board_score")
    if not isinstance(score, dict) or score.get("score") is None:
        return None
    snapshot = copy.deepcopy(score)
    snapshot.update({
        "snapshot_stage": stage,
        "captured_at": time.time(),
        "code": item.get("code"),
        "name": item.get("name"),
        "state": item.get("state"),
        "price": item.get("price"),
        "change_pct": item.get("change_pct"),
        "board_summary_status": (item.get("board_summary") or {}).get("status"),
        "board_members_status": (item.get("board_members") or {}).get("status"),
    })
    return snapshot
```

---

## 12. ScoreSnapshotArchive (full file)

Full source in original file at `astock_guard/score_snapshot_archive.py` (1–479). Extracted into this md for reference.
