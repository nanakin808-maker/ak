# External Interface Inventory

Extracted from: `~/Documents/Codex/2026-04-26/a-k/`
Date: 2026-05-11
Scope: all providers, external SDK/HTTP dependencies, fallback patterns, write actions

---

## Source Summary

| # | Source Key | Category | Dependency | Read/Write | Fallback |
|---|-----------|----------|-----------|------------|----------|
| 1 | eastmoney_quote | quote | `requests` → push2.eastmoney.com | read | fallback member in CompositeProvider |
| 2 | sina_quote | quote | `requests` → hq.sinajs.cn | read | fallback member in CompositeProvider |
| 3 | tencent_quote | quote | `requests` → qt.gtimg.cn | read | fallback member in CompositeProvider |
| 4 | pytdx_quote | quote | `pytdx` SDK → TCP | read | PRIMARY in CompositeProvider |
| 5 | eastmoney_limit_pool | limit_pool | `requests` → push2ex.eastmoney.com | read | primary, paired with THS fallback |
| 6 | ths_limit_pool | limit_pool | `requests` → 同花顺 (cookie) | read | fallback for EastmoneyLimitPoolProvider |
| 7 | composite_limit_pool | limit_pool | delegates to 5+6 | read | composite wrapper |
| 8 | eastmoney_fund_flow | fund_flow | `requests` → push2.eastmoney.com | read | standalone |
| 9 | eastmoney_rank_speed | speed_rank | `requests` → push2.eastmoney.com | read | standalone |
| 10 | ths_speed_rank | speed_rank | `requests` → 同花顺 (cookie) | read | standalone |
| 11 | ths_board | board_mapping | `requests` + akshare 同花顺JS | read | primary |
| 12 | eastmoney_board_member | board_members | `requests` + `efinance` | read | standalone |
| 13 | stock_board_summary | board_mapping | `efinance` | read | standalone |
| 14 | daily_history_kline | daily_kline | `requests` (THS) + `efinance` + `akshare` + SQLite cache | read | THS→efinance→akshare 三级fallback |
| 15 | ths_kline | daily_kline | `requests` → 同花顺 HTTP | read | primary kline provider |
| 16 | eastmoney_intraday | intraday | `requests` → push2.eastmoney.com | read | primary intraday |
| 17 | pytdx_intraday | intraday | `pytdx` SDK | read | fallback for EastmoneyIntradayProvider |
| 18 | ths_intraday | intraday | `requests` → 同花顺 (cookie) | read | fallback for EastmoneyIntradayProvider |
| 19 | composite_intraday | intraday | delegates to 16→17→18 | read | composite wrapper |
| 20 | stock_meta | stock_basic | `akshare` + `requests` → Eastmoney | read | standalone |
| 21 | ths_self_stock_add | ths_self_stock | `requests` → 同花顺 (cookie) | write | standalone, adds to 同花顺 self-selected |
| 22 | ths_self_stock_list | ths_self_stock | `requests` → 同花顺 (cookie) | read | standalone |
| 23 | feishu_notify | feishu | `requests` POST → webhook | write | standalone |
| 24 | feishu_inbox | feishu | SQLite (stored from webhook) | read/write | standalone, receives from Feishu event |
| 25 | market_calendar | calendar | `requests` → tool.bitefu.net | read | standalone |
| 26 | eastmoney_shortline | shortline | `requests` → push2.eastmoney.com | read | standalone |
| 27 | seal_strength | intraday | computed from quote data, no external call | read | derived/cached |

---

## Detail per source

### 1. eastmoney_quote
- **Module:** `astock_guard/providers/eastmoney.py`
- **Class:** `EastmoneyProvider(QuoteProvider)`
- **Dependency:** `requests` → `https://push2.eastmoney.com/api/qt/stock/get`
- **Category:** quote (single-stock HTTP)
- **Input:** `codes: Iterable[str]`
- **Output fields:** price, pre_close, open, high, low, volume, amount, bid1-5, ask1-5, bid_vol1-5, ask_vol1-5, change_pct, turnover_rate
- **Callers:** `CompositeProvider.get_quotes`, `server.py` internal routes
- **Fallback:** CompositeProvider (pytdx→tencent→sina→eastmoney)
- **Notes:** Uses per-code HTTP call, proxy support via `ASTOCK_EASTMONEY_PROXY`

### 2. sina_quote
- **Module:** `astock_guard/providers/sina.py`
- **Class:** `SinaProvider(QuoteProvider)`
- **Dependency:** `requests` → `https://hq.sinajs.cn/list=`
- **Category:** quote (batch HTTP)
- **Output fields:** price, pre_close, open, high, low, volume, amount, bid1, ask1, change_pct
- **Callers:** `CompositeProvider`
- **Fallback:** member in CompositeProvider

### 3. tencent_quote
- **Module:** `astock_guard/providers/tencent.py`
- **Class:** `TencentProvider(QuoteProvider)`
- **Dependency:** `requests` → `https://qt.gtimg.cn/q=`
- **Category:** quote (batch HTTP)
- **Output fields:** price, pre_close, open, high, low, volume, amount, bid1-5, ask1-5, change_pct
- **Callers:** `CompositeProvider`
- **Fallback:** member in CompositeProvider

### 4. pytdx_quote
- **Module:** `astock_guard/providers/pytdx_provider.py`
- **Class:** `PytdxProvider(QuoteProvider)`
- **Dependency:** `pytdx` SDK (TCP connection to 通达信 data server)
- **Category:** quote (TCP)
- **Output fields:** price, pre_close, open, high, low, volume, amount, bid1-5, ask1-5, change_pct, turnover_rate
- **Callers:** `CompositeProvider` (FIRST in default order)
- **Fallback:** PRIMARY in CompositeProvider (default order: pytdx→tencent→sina→eastmoney)
- **Circuit breaker:** 2 failures → 180s cooldown per source

### 5. eastmoney_limit_pool
- **Module:** `astock_guard/providers/limit_pool.py`
- **Class:** `EastmoneyLimitPoolProvider`
- **Dependency:** `requests` → `push2ex.eastmoney.com/getTopicZTPool` / `getTopicZBPool`
- **Category:** limit_pool (涨停池 / 炸板池)
- **Input:** `date: str = YYYYMMDD`
- **Output fields:** code, name, pool(limit_up/open_board), price, change_pct, first_limit_time, last_limit_time, open_count, seal_amount, streak, industry, reason
- **Callers:** `CompositeLimitPoolProvider`, `server.py`, `alerts.py`
- **Fallback:** paired with ThsLimitPoolProvider

### 6. ths_limit_pool
- **Module:** `astock_guard/providers/limit_pool.py`
- **Class:** `ThsLimitPoolProvider`
- **Dependency:** `requests` → 同花顺 HTTP (requires cookie + hexin_v)
- **Category:** limit_pool
- **Callers:** `CompositeLimitPoolProvider`
- **Fallback:** for EastmoneyLimitPoolProvider

### 7. composite_limit_pool
- **Module:** `astock_guard/providers/limit_pool.py`
- **Class:** `CompositeLimitPoolProvider`
- **Category:** limit_pool composite
- **Internal delegates:** `EastmoneyLimitPoolProvider` (primary), `ThsLimitPoolProvider` (fallback)
- **Callers:** `server.py`, `alerts.py`

### 8. eastmoney_fund_flow
- **Module:** `astock_guard/providers/fund_flow.py`
- **Class:** `EastmoneyFundFlowProvider`
- **Dependency:** `requests` → `push2.eastmoney.com/api/qt/stock/.../kline` (资金流 API)
- **Category:** fund_flow
- **Input:** `code, limit=20, refresh=False`
- **Output fields:** main_net_inflow, main_net_inflow_pct, retail_net_inflow, total_net_inflow, 3d/5d summaries, latest
- **Callers:** `alerts.py:evaluate_stock_score`
- **Fallback:** standalone

### 9. eastmoney_rank_speed
- **Module:** `astock_guard/providers/eastmoney_rank.py`
- **Class:** `EastmoneyRankProvider`
- **Dependency:** `requests` → `push2.eastmoney.com/api/qt/clist/get` (涨速榜)
- **Category:** speed_rank
- **Input:** `limit=30`
- **Output fields:** code, name, price, change_pct, speed_pct, volume, amount
- **Callers:** `server.py`, external source adapter

### 10. ths_speed_rank
- **Module:** `astock_guard/providers/ths_speed_rank.py`
- **Class:** `ThsSpeedRankProvider`
- **Dependency:** `requests` → 同花顺 HTTP (cookie + hexin_v)
- **Category:** speed_rank
- **Callers:** `server.py`
- **Notes:** Uses 同花顺 竞价/涨速 API

### 11. ths_board
- **Module:** `astock_guard/providers/ths_board.py`
- **Class:** `ThsBoardProvider`
- **Dependency:** `requests` + `akshare` (同花顺 JS data)
- **Category:** board_mapping (板块映射/概念)
- **Output fields:** board_code, board_name, board_kind(concept/industry/tag)
- **Callers:** `StockBoardProvider`

### 12. eastmoney_board_member
- **Module:** `astock_guard/providers/em_board_members.py`
- **Class:** `EastmoneyBoardMemberProvider`
- **Dependency:** `requests` + `efinance`
- **Category:** board_members (板块成分股)
- **Input:** `board_code, limit=20, with_quote=True`
- **Output fields:** list of {code, name, price, change_pct, rank}
- **Callers:** `alerts.py:_get_board_top20_cached`

### 13. stock_board_summary
- **Module:** `astock_guard/providers/stock_boards.py`
- **Class:** `StockBoardProvider`
- **Dependency:** `efinance`
- **Category:** board_mapping (个股所属板块)
- **Input:** `code, name, refresh=False`
- **Output fields:** list of {board_code, board_name, board_kind, board_change_pct}
- **Callers:** `alerts.py:evaluate_stock_score`

### 14. daily_history_kline
- **Module:** `astock_guard/providers/history.py`
- **Class:** `DailyHistoryProvider`
- **Dependency:** `requests` (THS) + `efinance` + `akshare` + SQLite cache
- **Category:** daily_kline
- **Fallback chain:** THS kline → efinance → akshare, with SQLite cache (daily_bars table)
- **Input:** `code, start, end, current_price, cached_only`
- **Output fields:** kline DataFrame, LimitTouchEvent list, score, technical_score breakdown
- **Callers:** `alerts.py:evaluate_stock_score`, `strategy_engine`, `server.py`

### 15. ths_kline
- **Module:** `astock_guard/providers/ths_kline.py`
- **Class:** `ThsKlineProvider`
- **Dependency:** `requests` → 同花顺 HTTP
- **Category:** daily_kline
- **Callers:** `DailyHistoryProvider`
- **Notes:** Primary kline data source (THS), with 2 fallbacks

### 16. eastmoney_intraday
- **Module:** `astock_guard/providers/intraday.py`
- **Class:** `EastmoneyIntradayProvider`
- **Dependency:** `requests` → `push2.eastmoney.com/api/qt/stock/.../kline` (分钟线)
- **Category:** intraday
- **Input:** `code, limit=240`
- **Output fields:** list of IntradayMinuteBar {time, price, volume, amount, change_pct}
- **Callers:** `CompositeIntradayProvider`

### 17. pytdx_intraday
- **Module:** `astock_guard/providers/intraday.py`
- **Class:** `PytdxIntradayProvider(EastmoneyIntradayProvider)`
- **Dependency:** `pytdx` SDK
- **Category:** intraday (fallback)
- **Callers:** `CompositeIntradayProvider`

### 18. ths_intraday
- **Module:** `astock_guard/providers/intraday.py`
- **Class:** `ThsIntradayProvider(EastmoneyIntradayProvider)`
- **Dependency:** `requests` → 同花顺 (cookie)
- **Category:** intraday (fallback)

### 19. composite_intraday
- **Module:** `astock_guard/providers/intraday.py`
- **Class:** `CompositeIntradayProvider`
- **Category:** intraday composite
- **Internal delegates:** EastmoneyIntradayProvider → PytdxIntradayProvider → ThsIntradayProvider
- **Callers:** `server.py`, `alerts.py`

### 20. stock_meta
- **Module:** `astock_guard/providers/stock_meta.py`
- **Class:** `StockMetaProvider`
- **Dependency:** `akshare` + `requests` (Eastmoney)
- **Category:** stock_basic
- **Input:** `code, refresh=False`
- **Output fields:** float_share, float_market_value, total_share, industry, market, name
- **Callers:** `alerts.py`

### 21. ths_self_stock_add (WRITE)
- **Module:** `astock_guard/providers/ths_self_stock.py`
- **Class:** `ThsSelfStockProvider`
- **Dependency:** `requests` → 同花顺 (cookie-based)
- **Category:** ths_self_stock — WRITE (add stock)
- **Method:** `add(code)`, `ensure_added(code)`
- **Callers:** `server.py:add_ths_self_stock` (API endpoint)
- **Output:** `ThsSelfStockResult {ok, code, message}`

### 22. ths_self_stock_list (READ)
- **Module:** `astock_guard/providers/ths_self_stock.py`
- **Class:** `ThsSelfStockProvider`
- **Dependency:** `requests` → 同花顺
- **Category:** ths_self_stock — READ (list)
- **Method:** `list()`
- **Callers:** `server.py:get_ths_self_stock_list`

### 23. feishu_notify (WRITE)
- **Module:** `astock_guard/notifiers/feishu.py`
- **Class:** `FeishuNotifier`
- **Dependency:** `requests` POST → webhook URL (`ASTOCK_FEISHU_WEBHOOK`)
- **Category:** feishu — WRITE (send notification)
- **Methods:** `send_text(text)`, `send_interactive(card)`
- **Callers:** `alert_engine`, `server.py`
- **Notes:** Optional HMAC secret; configured via .env or API

### 24. feishu_inbox
- **Module:** `astock_guard/feishu_inbox.py`
- **Class:** `FeishuInbox`
- **Dependency:** SQLite (local store)
- **Category:** feishu — inbox (received from Feishu event webhook)
- **Methods:** `record(event)`, `list_recent(limit)`
- **Callers:** `server.py` (Feishu event endpoint)

### 25. market_calendar
- **Module:** `astock_guard/market_time.py`
- **Dependency:** `requests` → `http://tool.bitefu.net/jiari/`
- **Category:** calendar (交易日历)
- **Callers:** `alert_runtime.py`, `server.py`
- **Notes:** Tells if today is trading day, market session (morning/afternoon)

### 26. eastmoney_shortline
- **Module:** `astock_guard/providers/shortline.py`
- **Class:** `EastmoneyShortlineProvider`
- **Dependency:** `requests` → `push2.eastmoney.com/api/qt/slist/get` (短线精灵)
- **Category:** shortline (短线事件)
- **Input:** `page_size=50`
- **Output fields:** list of ShortlineEvent {code, name, price, change_pct, speed, event_type, time}
- **Callers:** `server.py`

### 27. seal_strength
- **Module:** `astock_guard/providers/seal_strength.py`
- **Class:** `SealStrengthAnalyzer`
- **Dependency:** computed from quote bid/ask volumes + stock_meta float_market_value
- **Category:** intraday (derived)
- **Callers:** `alerts.py`, `server.py`

---

## Composite/Fallback Summary

| Composite | Primary | Fallback(s) | Strategy |
|-----------|---------|-------------|----------|
| CompositeProvider (quote) | pytdx | tencent → sina → eastmoney | ordered chain, circuit breaker per source |
| CompositeLimitPoolProvider | eastmoney_limit_pool | ths_limit_pool | first success |
| CompositeIntradayProvider | eastmoney_intraday | pytdx_intraday → ths_intraday | ordered chain |
| DailyHistoryProvider (kline) | ths_kline | efinance → akshare | ordered chain with SQLite cache |
| ScoreSnapshotArchive | SQLite | JSONL log file | db write with log fallback |

---

## External Write Actions

1. **FeishuNotifier.send_text** — POST to webhook; sends alert notifications
2. **FeishuNotifier.send_interactive** — POST to webhook; sends card notifications
3. **ThsSelfStockProvider.add(code)** — HTTP POST to 同花顺; adds stock to 同花顺自选股
4. **ThsSelfStockProvider.ensure_added(code)** — idempotent add
5. **FeishuInbox.record** — local SQLite write (passive, stores incoming events)

## External Read-Only Sources

All other 22+ sources are read-only HTTP/SDK calls.

## Callers Mapping (score-relevant)

| Caller | Sources Used |
|--------|-------------|
| `AlertEngine.evaluate_stock_score` | quote, kline, volume(quote), board, fund_flow, intraday |
| `AlertEngine._board_score` | board_summary, board_members, fund_flow, intraday_quality |
| `AlertEngine._volume_momentum_score` | quote (real-time) |
| `AlertEngine._record_score_snapshot` | ScoreSnapshotArchive (SQLite) |
| `LimitPoolIngestionService` | limit_pool (EastmoneyLimitPoolProvider) |
| `StrategyEngine.evaluate_code` | DailyHistoryProvider.get_kline_score |

## Scoring Input Sources (for v2 migration)

| Scoring Component | Required External Sources |
|------------------|-------------------------|
| technical/kline | DailyHistoryProvider (THS → efinance → akshare + SQLite daily_bars) |
| volume (real-time) | CompositeProvider quotes (pytdx → tencent → sina → eastmoney) |
| board/sentiment | StockBoardProvider (efinance), BoardMemberProvider (efinance+requests) |
| fund_flow | EastmoneyFundFlowProvider (requests → push2.eastmoney.com) |
| intraday quality | CompositeIntradayProvider |
| seal_strength | Quote bid/ask volumes + stock_meta float_market_value |
| stock_meta | StockMetaProvider (akshare + requests) |
