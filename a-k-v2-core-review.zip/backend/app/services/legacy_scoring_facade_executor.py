"""
LegacyScoringFacadeExecutor: componentized legacy scoring bridge.

V1 scope: technical/kline only via subprocess call to legacy_kline_worker.py.
All other components (volume, sentiment, board, fund_flow) are reported as
partial_missing.  Never returns passed=True or status="ready" — v1 is always
partial or failed.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

from app.db.models import ScoreTaskCurrent
from app.services.score_worker_service import ScoreExecutionResult


class LegacyScoringFacadeExecutor:
    """ScoringExecutor that bridges old DailyHistoryProvider.get_kline_score
    via subprocess.  All non-technical components return partial in v1."""

    def __init__(
        self,
        old_project_root: str = "../a-k",
        old_python: str | None = None,
        old_db_path: str | None = None,
        kline_worker_path: str | None = None,
        timeout_seconds: float = 30.0,
    ) -> None:
        self.old_project_root = old_project_root
        self.old_python = old_python
        self.old_db_path = old_db_path
        self.kline_worker_path = kline_worker_path
        self.timeout_seconds = timeout_seconds

    def execute(self, task: ScoreTaskCurrent) -> ScoreExecutionResult:
        worker = self._resolve_worker()
        if worker is None:
            return self._partial_result(
                score=None, technical_score=None,
                reject_reason="legacy_kline_worker_not_found",
                score_json_extra={"error": "kline_worker_not_found"},
            )

        old_python = self._resolve_old_python()
        if old_python is None:
            return self._partial_result(
                score=None, technical_score=None,
                reject_reason="old_python_not_found",
                score_json_extra={"error": "old_python_not_found"},
            )

        old_db_path = self._resolve_old_db()
        input_refs = self._parse_input_refs(task)
        current_price = input_refs.get("price") or input_refs.get("current_price")

        cmd = [
            str(old_python), str(worker),
            "--old-project-root", str(self.old_project_root),
            "--old-db-path", str(old_db_path),
            "--code", task.code,
            "--name", task.name,
        ]
        if current_price:
            cmd.extend(["--current-price", str(current_price)])

        try:
            cp = subprocess.run(
                cmd, check=False, capture_output=True, text=True,
                timeout=self.timeout_seconds,
            )
        except subprocess.TimeoutExpired:
            return self._partial_result(
                score=None, technical_score=None,
                reject_reason=f"legacy_kline_timeout:{self.timeout_seconds}s",
                score_json_extra={"error": "timeout"},
            )

        if cp.returncode != 0:
            return self._partial_result(
                score=None, technical_score=None,
                reject_reason=cp.stderr.strip()[:500] or f"kline_exit:{cp.returncode}",
                score_json_extra={"stderr": cp.stderr.strip()[:500]},
            )

        try:
            payload = json.loads(cp.stdout)
        except json.JSONDecodeError as exc:
            return self._partial_result(
                score=None, technical_score=None,
                reject_reason=f"kline_invalid_json:{exc}",
                score_json_extra={"error": str(exc)},
            )

        if not payload.get("ok"):
            error = payload.get("error", "unknown_kline_error")
            return self._partial_result(
                score=None, technical_score=None,
                reject_reason=f"kline_failed:{error}",
                score_json_extra={"kline_error": error, "detail": payload.get("detail")},
            )

        technical_score_raw = payload.get("technical_score")
        technical_score = self._extract_score(technical_score_raw)
        score = self._to_float(payload.get("score")) or technical_score

        return self._partial_result(
            score=score,
            technical_score=technical_score,
            reject_reason="partial_components_missing:volume,board,sentiment,fund_flow",
            technical_detail=payload.get("detail"),
            score_json_extra={
                "raw_technical_score": technical_score_raw,
                "raw_kline": payload.get("raw"),
                "kline_detail": payload.get("detail"),
            },
        )

    # ── internal helpers ──────────────────────────────────────────

    def _resolve_worker(self) -> Path | None:
        if self.kline_worker_path:
            p = Path(self.kline_worker_path)
            if p.exists():
                return p
        p = Path(__file__).resolve().parents[3] / "scripts" / "legacy_kline_worker.py"
        return p if p.exists() else None

    def _resolve_old_python(self) -> Path | None:
        if self.old_python:
            p = Path(self.old_python)
            if p.exists():
                return p
        p = Path(self.old_project_root).resolve() / ".venv" / "bin" / "python3"
        return p if p.exists() else Path(self.old_project_root).resolve() / ".venv" / "bin" / "python"

    def _resolve_old_db(self) -> Path:
        if self.old_db_path:
            return Path(self.old_db_path)
        return Path(self.old_project_root).resolve() / "data" / "astock_guard.db"

    @staticmethod
    def _parse_input_refs(task: ScoreTaskCurrent) -> dict[str, Any]:
        raw = task.input_refs_json or "{}"
        try:
            return json.loads(raw) if isinstance(raw, str) else raw
        except (json.JSONDecodeError, TypeError):
            return {}

    def _partial_result(
        self,
        *,
        score: Any,
        technical_score: Any,
        reject_reason: str,
        technical_detail: dict[str, Any] | None = None,
        score_json_extra: dict[str, Any] | None = None,
    ) -> ScoreExecutionResult:
        technical_value: float | None = self._extract_score(technical_score)
        score_value: float | None = self._to_float(score)

        rejected = bool(reject_reason)

        components: dict[str, Any] = {
            "technical": {
                "status": "ready" if technical_value is not None else "failed",
                "score": technical_value,
            },
            "volume": {
                "status": "partial_missing_quote_window",
                "score": None,
                "note": "v1 partial — requires real-time quote window (VolumeScoringMixin runtime)",
            },
            "board": {
                "status": "partial_missing_board_inputs",
                "score": None,
                "note": "v1 partial — requires board_summary + board_members from stock_board_provider",
            },
            "sentiment": {
                "status": "partial_missing_board_inputs",
                "score": None,
                "note": "v1 partial — requires board_scores from _board_score pipeline",
            },
            "fund_flow": {
                "status": "partial_missing_fund_flow_inputs",
                "score": None,
                "note": "v1 partial — requires fund_flow_provider + runtime.open_board_counts",
            },
        }

        missing_components = [
            name for name, comp in components.items()
            if comp["status"].startswith("partial_") or comp["status"] == "failed"
        ]

        score_json: dict[str, Any] = {
            "scoring_mode": "legacy_component",
            "is_full_legacy_score": False,
            "components": components,
            "missing_components": missing_components,
        }
        if score_json_extra:
            score_json.update(score_json_extra)
        if technical_detail:
            score_json.setdefault("kline_detail", technical_detail)

        status = "partial" if technical_value is not None else "failed"

        return ScoreExecutionResult(
            score=score_value,
            technical_score=technical_value,
            sentiment_score=None,
            volume_score=None,
            passed=False,
            status=status,
            reject_reason=reject_reason,
            main_logic="legacy_component_facade",
            board_rank=None,
            score_json=json.dumps(score_json, ensure_ascii=False, default=str),
            input_refs_json=None,
        )

    @staticmethod
    def _extract_score(value: Any) -> float | None:
        """Extract a numeric score from a dict (e.g. {'total': 82}) or a raw float."""
        if isinstance(value, dict):
            for key in ("total", "score", "legacy_score"):
                candidate = value.get(key)
                if candidate is not None:
                    try:
                        return float(candidate)
                    except (TypeError, ValueError):
                        continue
            return None
        try:
            return None if value is None else float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _to_float(value: Any) -> float | None:
        try:
            return None if value is None else float(value)
        except (TypeError, ValueError):
            return None
