"""
Engine lifecycle: starts/stops a background scan loop.

The loop runs: speed_rank → PRE_CANDIDATE → CANDIDATE →
               orderbook seal check → CORE → scoring → repeat.

All external data comes from real HTTP sources (eastmoney, tencent).
"""

from __future__ import annotations

import asyncio
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any

from app.schemas.engine import EngineResponse, EngineState


# ── global engine state ──────────────────────────────

_state = EngineState(
    status="idle",
    running=False,
    message="引擎尚未启动",
)

_loop_task: asyncio.Task | None = None
_scan_summary: dict[str, Any] = {}
_scoring_queue: Any = None  # ScoringQueue instance


def now_text() -> str:
    return datetime.now().isoformat(timespec="seconds")


def engine_status() -> EngineResponse:
    return EngineResponse(state=_state, summary=_scan_summary if _scan_summary else None)


# ── start / stop / reset ─────────────────────────────

async def start_engine() -> EngineResponse:
    global _state, _loop_task, _scoring_queue

    if _state.running and _loop_task and not _loop_task.done():
        _state = _state.model_copy(update={"message": "引擎已经在运行"})
        return EngineResponse(state=_state)

    from app.services.scoring_queue import ScoringQueue
    db_path = str(Path(__file__).resolve().parents[3] / "data" / "astock_guard_v2_shadow.db")
    _scoring_queue = ScoringQueue(db_path)
    await _scoring_queue.start()

    _loop_task = asyncio.create_task(_scan_loop())
    _state = EngineState(
        status="running",
        running=True,
        startedAt=now_text(),
        message="引擎已启动 — 扫描循环运行中",
    )
    return EngineResponse(state=_state)


async def stop_engine() -> EngineResponse:
    global _state, _loop_task, _scoring_queue

    if not _state.running:
        _state = _state.model_copy(update={"message": "引擎当前未运行"})
        return EngineResponse(state=_state)

    if _loop_task:
        _loop_task.cancel()
        try:
            await _loop_task
        except asyncio.CancelledError:
            pass
        _loop_task = None

    if _scoring_queue:
        await _scoring_queue.stop()
        _scoring_queue = None

    _state = EngineState(
        status="stopped",
        running=False,
        stoppedAt=now_text(),
        message="引擎已停止",
    )
    return EngineResponse(state=_state)


async def reset_engine() -> EngineResponse:
    global _state

    if _state.running:
        await stop_engine()

    _state = EngineState(
        status="idle",
        running=False,
        resetAt=now_text(),
        message="引擎状态已重置",
    )
    return EngineResponse(state=_state)


def _publish_scan_delta(summary: dict[str, Any]) -> None:
    """Publish scan status + stock snapshots to event bus for WebSocket clients."""
    try:
        from app.realtime.event_bus import get_event_bus
        from app.realtime.delta_builder import build_scan_status, build_stock_state_upsert
        bus = get_event_bus()
        td = summary.get("trading_date", "")
        seq = summary.get("seq", 0)
        bus.publish(build_scan_status(td, summary))
        for snap in summary.get("_stock_snapshots", []):
            bus.publish(build_stock_state_upsert(td, seq, snap))
    except Exception:
        pass  # best-effort, never block scan loop


# ── the scan loop ────────────────────────────────────

async def _scan_loop():
    """Background loop: fetch events → lifecycle → scoring → repeat."""
    global _scan_summary

    db_path = str(Path(__file__).resolve().parents[3] / "data" / "astock_guard_v2_shadow.db")

    # Import heavy modules lazily so FastAPI startup is fast
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.db.init_db import init_db
    from app.runtime.realtime_dev_scan import RealtimeDevScanRunner

    db_path_obj = Path(db_path)
    db_path_obj.parent.mkdir(parents=True, exist_ok=True)
    engine = create_engine(f"sqlite:///{db_path_obj.resolve()}", future=True)
    init_db(engine)

    runner = RealtimeDevScanRunner(db_path=str(db_path_obj))

    scan_interval = 1.0

    while True:
        try:
            from app.domain.market_calendar import (
                MarketSession, is_nominal_trading_day, market_session,
                effective_trading_date_ymd,
            )
            session = market_session()
            is_nominal = is_nominal_trading_day()

            global _state
            _state = EngineState(
                status="running", running=True,
                startedAt=_state.startedAt,
                message=f"引擎运行中 — {session.value}",
            )

            # Non-trading: sleep longer, no scan
            if session in (MarketSession.WEEKEND, MarketSession.CLOSED_NO_DATA):
                await asyncio.sleep(60)
                continue
            if not is_nominal:
                await asyncio.sleep(30)
                continue

            # Before open: wait, no scan
            if session == MarketSession.BEFORE_OPEN:
                await asyncio.sleep(30)
                continue

            # Lunch break / Post-close: slow down but keep monitoring
            if session == MarketSession.LUNCH_BREAK:
                scan_interval = 3.0
            elif session == MarketSession.POST_CLOSE:
                scan_interval = 10.0
            else:
                scan_interval = 1.0

            runner.trading_date = effective_trading_date_ymd()

            summary = await asyncio.to_thread(runner.run_once)
            _scan_summary = {
                "last_scan_at": datetime.utcnow().isoformat(),
                "interval_seconds": scan_interval,
                "market_session": session.value,
                **summary,
            }
            _publish_scan_delta(summary)
            if _scoring_queue:
                _scoring_queue.notify()
        except asyncio.CancelledError:
            break
        except Exception:
            traceback.print_exc()

        await asyncio.sleep(scan_interval)
