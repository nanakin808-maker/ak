from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Protocol

from sqlalchemy.orm import Session

from app.db.models import ScoreTaskCurrent
from app.repositories import ScoreSnapshotRepository, ScoreTaskRepository


@dataclass(slots=True)
class ScoreExecutionResult:
    score: float | None
    technical_score: float | None
    sentiment_score: float | None
    volume_score: float | None
    passed: bool | None
    status: str
    reject_reason: str | None = None
    main_logic: str | None = None
    board_rank: int | None = None
    score_json: str = "{}"
    input_refs_json: str = "{}"
    input_context: str = "{}"


class ScoringExecutor(Protocol):
    def execute(self, task: ScoreTaskCurrent) -> ScoreExecutionResult:
        ...


class StaticScoringExecutor:
    """Deterministic test executor. Not real business scoring."""

    def execute(self, task: ScoreTaskCurrent) -> ScoreExecutionResult:
        return ScoreExecutionResult(
            score=88.0, technical_score=80.0, sentiment_score=90.0,
            volume_score=70.0, passed=True, status="ready",
            reject_reason=None, main_logic="mock_executor",
            board_rank=None,
            score_json='{"executor":"static_mock","total":88}',
            input_refs_json=task.input_refs_json,
            input_context='{"mock":true}',
        )


def _create_default_executor(*, production: bool = False) -> ScoringExecutor:
    from app.services.legacy_full_scoring_executor import LegacyFullScoringExecutor

    if production:
        return LegacyFullScoringExecutor()
    from pathlib import Path as P
    old_root = P(__file__).resolve().parents[3] / ".." / "a-k"
    if old_root.exists():
        return LegacyFullScoringExecutor()
    return StaticScoringExecutor()


@dataclass(slots=True)
class ScoreWorkerRunResult:
    processed: int
    ready: int
    failed: int


def _save_scoring_context(session: Session, task: ScoreTaskCurrent,
                          result: ScoreExecutionResult) -> None:
    """Save scoring input context to SQLite + JSONL."""
    try:
        # SQLite
        from sqlalchemy import text
        session.execute(text(
            """INSERT INTO scoring_contexts
               (trading_date, code, name, event_type, score_stage,
                snapshot_time, price, change_pct, scores_json, context_json, created_at)
               VALUES (:td, :code, :name, :et, :ss, :st, :p, :cp, :sj, :cj, :now)"""
        ), {
            "td": task.trading_date, "code": task.code, "name": task.name,
            "et": task.source_type, "ss": task.score_stage,
            "st": datetime.utcnow(), "p": None, "cp": None,
            "sj": result.score_json, "cj": result.input_context,
            "now": datetime.utcnow(),
        })

        # Cleanup: keep last 3 per (code, score_stage)
        session.execute(text(
            """DELETE FROM scoring_contexts WHERE id IN (
                 SELECT id FROM scoring_contexts
                 WHERE code = :code AND score_stage = :ss
                 ORDER BY created_at DESC
                 LIMIT -1 OFFSET 3
               )"""
        ), {"code": task.code, "ss": task.score_stage})
        session.flush()

        # JSONL
        logs_dir = Path(__file__).resolve().parents[3] / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        jsonl_path = logs_dir / f"scoring_contexts_{task.trading_date}.jsonl"
        line = json.dumps({
            "trading_date": task.trading_date, "code": task.code,
            "name": task.name, "event_type": task.source_type,
            "score_stage": task.score_stage,
            "snapshot_time": datetime.utcnow().isoformat(),
            "scores": json.loads(result.score_json),
            "context": json.loads(result.input_context),
        }, ensure_ascii=False, default=str)
        with open(jsonl_path, "a") as f:
            f.write(line + "\n")
    except Exception:
        pass  # context save is best-effort, don't fail scoring


class ScoreWorkerService:
    def __init__(self, session: Session, executor: ScoringExecutor | None = None,
                 *, production: bool = False) -> None:
        self.session = session
        self.tasks = ScoreTaskRepository(session)
        self.snapshots = ScoreSnapshotRepository(session)
        self.executor = executor or _create_default_executor(production=production)

    def process_pending(self, *, trading_date: str, limit: int = 100) -> ScoreWorkerRunResult:
        pending = self.tasks.list_pending(trading_date=trading_date, limit=limit)
        processed = ready = failed = 0

        for task in pending:
            processed += 1
            self.tasks.mark_running(task.id)
            self.session.flush()

            try:
                result = self.executor.execute(task)
                self.snapshots.add_snapshot(
                    trading_date=task.trading_date,
                    source_trading_date=task.source_trading_date,
                    code=task.code, name=task.name,
                    score_type=task.task_type,
                    score_stage=task.score_stage,
                    score=result.score, status=result.status,
                    passed=result.passed, reject_reason=result.reject_reason,
                    technical_score=result.technical_score,
                    sentiment_score=result.sentiment_score,
                    volume_score=result.volume_score,
                    main_logic=result.main_logic, board_rank=result.board_rank,
                    source_type=task.source_type,
                    source_event_id=task.source_event_id,
                    source_snapshot_id=task.source_snapshot_id,
                    source_row_id=task.source_row_id,
                    score_json=result.score_json,
                    input_refs_json=result.input_refs_json or task.input_refs_json,
                    config_version=task.config_version,
                    as_of=datetime.utcnow(), seq=task.seq,
                    freshness_status=task.freshness_status,
                )
                _save_scoring_context(self.session, task, result)
                self.tasks.mark_ready(task.id)
                ready += 1
            except Exception as exc:
                self.tasks.mark_failed(task.id, error=str(exc))
                failed += 1

            self.session.flush()

        return ScoreWorkerRunResult(processed=processed, ready=ready, failed=failed)
