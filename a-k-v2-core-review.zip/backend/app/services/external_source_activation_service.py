from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from typing import Any

from sqlalchemy.orm import Session

from app.repositories import ExternalSourceActivationRepository
from app.services.provider_bridge_service import ProviderCallResult


class SourceActivationState(str, Enum):
    PROBE_ONLY = "probe_only"; SHADOW = "shadow"
    CANDIDATE = "candidate"; ACTIVE = "active"
    DEGRADED = "degraded"; CIRCUIT_OPEN = "circuit_open"
    DISABLED = "disabled"


@dataclass(slots=True)
class SourceActivationPolicy:
    min_success_rate: float = 0.9
    max_p95_latency_ms: float = 3000.0
    max_consecutive_failures: int = 3
    circuit_open_seconds: int = 60
    require_freshness_for_business: bool = True
    require_non_empty_data: bool = True


@dataclass(slots=True)
class SourceBusinessDecision:
    allowed_to_call: bool
    allowed_for_business: bool
    state: str
    reason: str


class ExternalSourceActivationService:
    def __init__(self, session: Session, policy: SourceActivationPolicy | None = None) -> None:
        self.session = session
        self.repo = ExternalSourceActivationRepository(session)
        self.policy = policy or SourceActivationPolicy()

    def set_state(self, *, source_key: str, trading_date: str, state: SourceActivationState, reason: str = ""):
        return self.repo.update_state(
            source_key=source_key, trading_date=trading_date, state=state.value, reason=reason,
            business_enabled=state in {SourceActivationState.CANDIDATE, SourceActivationState.ACTIVE},
            shadow_only=state not in {SourceActivationState.CANDIDATE, SourceActivationState.ACTIVE},
        )

    def can_call(self, *, source_key: str, trading_date: str, now: datetime | None = None) -> SourceBusinessDecision:
        current = now or datetime.utcnow()
        row = self.repo.get_or_create(source_key=source_key, trading_date=trading_date)

        if row.state == SourceActivationState.DISABLED.value:
            return SourceBusinessDecision(False, False, row.state, "source_disabled")
        if row.state == SourceActivationState.PROBE_ONLY.value:
            return SourceBusinessDecision(False, False, row.state, "probe_only_no_real_call")
        if row.state == SourceActivationState.CIRCUIT_OPEN.value:
            if row.circuit_open_until is not None and row.circuit_open_until > current:
                return SourceBusinessDecision(False, False, row.state, "circuit_open")
            row.state = SourceActivationState.DEGRADED.value
            row.reason = "circuit_window_elapsed"
        return SourceBusinessDecision(True, False, row.state, "call_allowed")

    def can_use_for_business(self, *, source_key: str, trading_date: str, freshness_status: str, data: Any) -> SourceBusinessDecision:
        row = self.repo.get_or_create(source_key=source_key, trading_date=trading_date)
        if row.state not in {SourceActivationState.CANDIDATE.value, SourceActivationState.ACTIVE.value}:
            return SourceBusinessDecision(False, False, row.state, "source_not_business_active")
        if self.policy.require_freshness_for_business and freshness_status != "fresh":
            return SourceBusinessDecision(True, False, row.state, "freshness_not_fresh")
        if self.policy.require_non_empty_data and _is_empty_data(data):
            return SourceBusinessDecision(True, False, row.state, "empty_data")
        return SourceBusinessDecision(True, True, row.state, "business_allowed")

    def record_call_result(self, *, source_key: str, trading_date: str, result: ProviderCallResult, now: datetime | None = None):
        current = now or datetime.utcnow()
        row = self.repo.get_or_create(source_key=source_key, trading_date=trading_date)
        row.total_calls += 1
        row.last_latency_ms = result.latency_ms
        row.last_freshness_status = result.freshness_status
        row.last_detail_json = json.dumps(result.detail or {}, ensure_ascii=False, default=str)
        if result.ok:
            row.ok_calls += 1
            row.consecutive_failures = 0
            row.last_ok_at = current
            row.last_error = ""
        else:
            row.fail_calls += 1
            row.consecutive_failures += 1
            row.last_fail_at = current
            row.last_error = result.error
        if row.consecutive_failures >= self.policy.max_consecutive_failures:
            row.state = SourceActivationState.CIRCUIT_OPEN.value
            row.reason = "max_consecutive_failures"
            row.business_enabled = False
            row.shadow_only = True
            row.circuit_open_until = current + timedelta(seconds=self.policy.circuit_open_seconds)
        row.updated_at = current
        return row

    def evaluate_shadow_promotion(self, *, source_key: str, trading_date: str) -> SourceBusinessDecision:
        row = self.repo.get_or_create(source_key=source_key, trading_date=trading_date)
        if row.total_calls <= 0:
            return SourceBusinessDecision(True, False, row.state, "no_calls")
        rate = row.ok_calls / row.total_calls
        if rate < self.policy.min_success_rate:
            return SourceBusinessDecision(True, False, row.state, "success_rate_below_threshold")
        if row.last_freshness_status != "fresh":
            return SourceBusinessDecision(True, False, row.state, "last_freshness_not_fresh")
        return SourceBusinessDecision(True, row.state in {"candidate", "active"}, row.state, "shadow_stable")


def _is_empty_data(data: Any) -> bool:
    if data is None:
        return True
    if isinstance(data, list):
        return len(data) == 0
    if isinstance(data, dict):
        if "rows" in data and isinstance(data["rows"], list):
            return len(data["rows"]) == 0
        return len(data) == 0
    return False
