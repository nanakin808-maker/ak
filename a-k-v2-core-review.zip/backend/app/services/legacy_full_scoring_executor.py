"""
LegacyFullScoringExecutor: calls copied legacy scoring functions
with v2-native providers (daily_kline, stock_boards, board_members).

Phase 2: all subprocess bridges removed. Volume from quote_samples.

Each execute() returns input_context dict for replay/audit.
"""

from __future__ import annotations

import json
import time
from datetime import datetime
from typing import Any

from sqlalchemy.orm import Session

from app.db.models import ScoreTaskCurrent
from app.scoring.legacy_board import compute_board_score
from app.scoring.legacy_score_composer import compose_score
from app.scoring.legacy_sentiment import compute_sentiment_score
from app.scoring.legacy_technical import compute_technical_score
from app.services.score_worker_service import ScoreExecutionResult


class LegacyFullScoringExecutor:
    """ScoringExecutor using copied legacy functions and v2-native HTTP providers."""

    def __init__(self, db_session: Session | None = None) -> None:
        self.db_session = db_session

    def execute(self, task: ScoreTaskCurrent) -> ScoreExecutionResult:
        input_refs = self._parse_input_refs(task)
        current_price = input_refs.get("price") or input_refs.get("current_price")
        change_pct = input_refs.get("change_pct")
        components = self._parse_components(task)

        input_context: dict[str, Any] = {
            "scored_at": datetime.utcnow().isoformat(),
            "code": task.code, "name": task.name,
            "trading_date": task.trading_date,
            "components": list(components),
        }

        # ── technical ──
        technical_result: dict[str, Any] = {"status": "skipped", "score": None}
        if "technical" in components:
            technical_result = self._compute_technical(task, current_price, input_context)

        # ── board + sentiment ──
        # board is a prerequisite for sentiment — compute board whenever sentiment is needed
        board_result: dict[str, Any] = {"status": "skipped", "score": None}
        sentiment_result: dict[str, Any] = {"status": "skipped", "total": None}
        need_board = "board" in components or "sentiment" in components
        if need_board:
            scoring_inputs = self._fetch_scoring_inputs(task, input_context)
            board_result = compute_board_score(
                code=task.code, change_pct=float(change_pct) if change_pct else None,
                board_summary=scoring_inputs.get("board_summary"),
                board_members=scoring_inputs.get("board_members"),
                fund_flow=scoring_inputs.get("fund_flow"),
                intraday_quality=None, strategy=None,
                stock_meta=scoring_inputs.get("stock_meta"),
                open_board_count=0, limit_streak=None,
            )
            if "sentiment" in components and board_result.get("status") == "ready":
                board_scores = board_result.get("board_scores") or []
                sentiment_result = compute_sentiment_score(
                    code=task.code, change_pct=None, board_scores=board_scores,
                )

        # ── volume ──
        volume_result: dict[str, Any] = {"status": "skipped", "total": None}
        if "volume" in components:
            volume_result = self._compute_volume(task, input_context)

        # ── compose ──
        composed = compose_score(
            code=task.code, name=task.name, trading_date=task.trading_date,
            technical_result=technical_result, volume_result=volume_result,
            board_result=board_result, sentiment_result=sentiment_result,
        )

        return ScoreExecutionResult(
            score=composed.get("score"),
            technical_score=composed.get("technical_score"),
            sentiment_score=composed.get("sentiment_score"),
            volume_score=composed.get("volume_score"),
            passed=composed.get("passed", False),
            status=composed.get("status", "partial"),
            reject_reason=composed.get("reject_reason"),
            main_logic=composed.get("main_logic", "legacy_full_score"),
            score_json=composed.get("score_json", "{}"),
            input_refs_json=task.input_refs_json,
            input_context=json.dumps(input_context, ensure_ascii=False, default=str),
        )

    # ── technical via v2-native daily_kline ────────────────

    def _compute_technical(
        self, task: ScoreTaskCurrent, current_price: Any, ctx: dict
    ) -> dict[str, Any]:
        from app.sources.daily_kline import fetch_daily_kline

        bars = fetch_daily_kline(task.code, limit=250)
        ctx["technical"] = {
            "source": "tencent_daily_kline",
            "bars_count": len(bars),
            "current_price": current_price,
            "last_bar_date": bars[-1].date if bars else None,
        }
        if not bars or len(bars) < 20:
            return {"status": "partial_missing_daily_bars", "score": None,
                    "message": f"got {len(bars)} bars, need >= 20"}

        price = float(current_price) if current_price else None
        # Map to Chinese column names expected by legacy scoring functions
        bar_dicts = [{
            "日期": b.date, "开盘": b.open, "最高": b.high,
            "最低": b.low, "收盘": b.close, "成交量": b.volume,
            "成交额": 0,
        } for b in bars]

        result = compute_technical_score(
            code=task.code, current_price=price,
            daily_bars=bar_dicts, limit_events=None,
        )
        return {
            "status": result.get("status", "failed"),
            "score": result.get("score") or result.get("technical_score"),
            "technical_score": result.get("technical_score"),
            "detail": result.get("factors"),
            "raw": result,
        }

    # ── scoring inputs via v2-native providers ──────────────

    def _fetch_scoring_inputs(self, task: ScoreTaskCurrent, ctx: dict) -> dict[str, Any]:
        from app.sources.stock_boards import fetch_stock_boards
        from app.sources.board_members import fetch_board_members

        boards = fetch_stock_boards(task.code)
        ctx["boards"] = {
            "source": "tencent_board_index",
            "count": len(boards),
            "raw": [{"code": b.board_code, "name": b.board_name,
                     "change_pct": b.board_change_pct, "kind": b.board_kind}
                    for b in boards[:10]],
        }

        if not boards:
            return {"status": "partial_missing_board_summary"}

        board_summary = {
            "status": "ready",
            "boards": [{
                "board_code": b.board_code, "board_name": b.board_name,
                "board_change_pct": b.board_change_pct,
                "board_kind": b.board_kind,
            } for b in boards],
        }

        board_members: dict[str, Any] = {"status": "missing_board_members", "boards": []}
        ctx_members: list[dict] = []
        top_boards = boards[:3]
        for b in top_boards:
            members = fetch_board_members(b.board_code, limit=20)
            if members:
                member_dicts = [{
                    "code": m.code, "name": m.name,
                    "price": m.price, "change_pct": m.change_pct,
                    "volume": m.volume, "amount": m.amount,
                } for m in members]
                codes = [str(m.code).zfill(6)[-6:] for m in members]
                current_idx = next(
                    (i for i, c in enumerate(codes) if c == task.code.zfill(6)[-6:]), None
                )
                board_members["boards"].append({
                    "board_code": b.board_code, "board_name": b.board_name,
                    "board_kind": b.board_kind,
                    "board_change_pct": b.board_change_pct,
                    "rank": (current_idx + 1) if current_idx is not None else None,
                    "members": member_dicts,
                })
                ctx_members.append({
                    "board_code": b.board_code, "member_count": len(members),
                    "stock_rank": (current_idx + 1) if current_idx is not None else None,
                })
        if board_members["boards"]:
            board_members["status"] = "ready"
        ctx["board_members"] = {"source": "eastmoney_board", "boards": ctx_members}

        # Fund flow
        fund_flow: dict | None = None
        try:
            from app.sources.fund_flow import fetch_fund_flow
            fund_flow = fetch_fund_flow(task.code)
            ctx["fund_flow"] = {"status": fund_flow.get("status")}
        except Exception:
            pass

        # Stock meta
        stock_meta: dict | None = None
        try:
            from app.sources.stock_meta import fetch_stock_meta
            stock_meta = fetch_stock_meta(task.code)
            ctx["stock_meta"] = {"status": stock_meta.get("status", "ready")}
        except Exception:
            pass

        return {
            "board_summary": board_summary,
            "board_members": board_members,
            "fund_flow": fund_flow,
            "intraday_quality": None,
            "strategy": None,
            "stock_meta": stock_meta,
        }

    # ── volume from quote_samples table ────────────────────

    def _compute_volume(self, task: ScoreTaskCurrent, ctx: dict) -> dict[str, Any]:
        if self.db_session is None:
            ctx["volume"] = {"status": "no_db_session"}
            return {"status": "warming", "total": None,
                    "message": "需要 db_session", "code": task.code}

        from app.scoring.legacy_volume import compute_volume_score
        from sqlalchemy import text

        rows = self.db_session.execute(
            text(
                """SELECT timestamp, price, change_pct, amount, volume, bid_vol1, ask_vol1
                   FROM quote_samples
                   WHERE code = :code AND trading_date = :td
                   ORDER BY timestamp DESC LIMIT 120"""
            ),
            {"code": task.code, "td": task.trading_date},
        ).fetchall()

        ctx["volume"] = {"source": "quote_samples", "sample_count": len(rows)}
        if not rows or len(rows) < 2:
            return {"status": "warming", "total": None,
                    "message": "缺少至少2个报价样本", "code": task.code}

        samples = list(reversed(rows))
        quote_window = [{
            "timestamp": r.timestamp.timestamp() if hasattr(r.timestamp, 'timestamp')
                        else time.time(),
            "price": r.price, "change_pct": r.change_pct,
            "amount": r.amount, "volume": r.volume,
            "bid_vol1": r.bid_vol1, "ask_vol1": r.ask_vol1,
        } for r in samples]

        return compute_volume_score(
            code=task.code, quote_window=quote_window,
            latest_quote=quote_window[-1] if quote_window else None,
            stock_meta=None, technical_metrics=None,
        )

    # ── helpers ────────────────────────────────────────────

    @staticmethod
    def _parse_input_refs(task: ScoreTaskCurrent) -> dict[str, Any]:
        raw = task.input_refs_json or "{}"
        try:
            return json.loads(raw) if isinstance(raw, str) else raw
        except (json.JSONDecodeError, TypeError):
            return {}

    @staticmethod
    def _parse_components(task: ScoreTaskCurrent) -> set[str]:
        raw = task.components_json or '["technical","sentiment","volume"]'
        try:
            parsed = json.loads(raw) if isinstance(raw, str) else raw
            return set(parsed) if isinstance(parsed, list) else {"technical", "sentiment", "volume"}
        except (json.JSONDecodeError, TypeError):
            return {"technical", "sentiment", "volume"}
