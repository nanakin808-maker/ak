from __future__ import annotations

import os
from datetime import datetime

from app.adapters.legacy.http_client import LegacyHttpError, fetch_legacy_json
from app.adapters.legacy.speed_rank import normalize_speed_rank
from app.mocks.speed_rank import mock_speed_rank
from app.schemas.speed_rank import SpeedRankResponse


def now_text() -> str:
    return datetime.now().isoformat(timespec="seconds")


def legacy_speed_rank_url() -> str:
    return os.getenv("LEGACY_SPEED_RANK_URL", "").strip()


def fetch_legacy_payload() -> dict:
    url = legacy_speed_rank_url()

    if not url:
        raise RuntimeError("LEGACY_SPEED_RANK_URL 未配置")

    return fetch_legacy_json(url)

def get_speed_rank() -> SpeedRankResponse:
    try:
        payload = fetch_legacy_payload()
        rows = normalize_speed_rank(payload)

        if not rows:
            raise RuntimeError("旧涨速榜接口没有返回有效数据")

        return SpeedRankResponse(
            source="legacy",
            updatedAt=now_text(),
            rows=rows,
        )
    except (RuntimeError, LegacyHttpError) as exc:
        return SpeedRankResponse(
            source="mock",
            updatedAt=now_text(),
            rows=mock_speed_rank(),
            error=str(exc),
        )
