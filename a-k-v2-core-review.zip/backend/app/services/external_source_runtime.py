from __future__ import annotations

import importlib
import json
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from app.services.provider_bridge_service import ProviderFetchResult


class ExternalSourceExecutionMode(str, Enum):
    DISABLED = "disabled"; IN_PROCESS = "in_process"; SUBPROCESS = "subprocess"


@dataclass(slots=True)
class ExternalSourceRuntimeRequest:
    source_key: str; requested_trading_date: str; module_name: str; callable_name: str
    old_project_root: str | None = None
    execution_mode: ExternalSourceExecutionMode = ExternalSourceExecutionMode.SUBPROCESS
    timeout_seconds: float = 10.0; kwargs: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ExternalSourceRuntimeResult:
    source_key: str; ok: bool
    fetch_result: ProviderFetchResult | None = None
    execution_mode: ExternalSourceExecutionMode = ExternalSourceExecutionMode.SUBPROCESS
    error: str = ""; detail: dict[str, Any] = field(default_factory=dict)


class ExternalSourceRuntime:
    def call(self, request: ExternalSourceRuntimeRequest) -> ExternalSourceRuntimeResult:
        if request.execution_mode == ExternalSourceExecutionMode.DISABLED:
            return ExternalSourceRuntimeResult(source_key=request.source_key, ok=False, execution_mode=request.execution_mode, error="external_source_disabled")
        if request.execution_mode == ExternalSourceExecutionMode.IN_PROCESS:
            return self._call_in_process(request)
        if request.execution_mode == ExternalSourceExecutionMode.SUBPROCESS:
            return self._call_subprocess(request)
        return ExternalSourceRuntimeResult(source_key=request.source_key, ok=False, execution_mode=request.execution_mode, error=f"unsupported_mode:{request.execution_mode}")

    def _call_in_process(self, request: ExternalSourceRuntimeRequest) -> ExternalSourceRuntimeResult:
        original_path = list(sys.path)
        try:
            if request.old_project_root:
                sys.path.insert(0, str(Path(request.old_project_root).resolve()))
            module = importlib.import_module(request.module_name)
            fn = getattr(module, request.callable_name)
            payload = fn(requested_trading_date=request.requested_trading_date, **request.kwargs)
            return ExternalSourceRuntimeResult(
                source_key=request.source_key, ok=True,
                fetch_result=_normalize_provider_fetch_result(payload, requested_trading_date=request.requested_trading_date),
                execution_mode=request.execution_mode, detail={"module": request.module_name, "callable": request.callable_name},
            )
        except Exception as exc:
            return ExternalSourceRuntimeResult(
                source_key=request.source_key, ok=False, execution_mode=request.execution_mode,
                error=str(exc), detail={"module": request.module_name, "callable": request.callable_name, "exception_type": exc.__class__.__name__},
            )
        finally:
            sys.path[:] = original_path

    def _call_subprocess(self, request: ExternalSourceRuntimeRequest) -> ExternalSourceRuntimeResult:
        worker = Path(__file__).resolve().parents[3] / "scripts" / "external_source_worker.py"
        if not worker.exists():
            return ExternalSourceRuntimeResult(
                source_key=request.source_key, ok=False, execution_mode=request.execution_mode,
                error=f"worker_not_found:{worker}",
            )
        cmd = [sys.executable, str(worker), "--source-key", request.source_key,
               "--requested-trading-date", request.requested_trading_date,
               "--module", request.module_name, "--callable", request.callable_name,
               "--kwargs-json", json.dumps(request.kwargs, ensure_ascii=False, default=str)]
        if request.old_project_root:
            cmd.extend(["--old-project-root", request.old_project_root])
        try:
            completed = subprocess.run(cmd, check=False, capture_output=True, text=True, timeout=request.timeout_seconds)
        except subprocess.TimeoutExpired:
            return ExternalSourceRuntimeResult(source_key=request.source_key, ok=False, execution_mode=request.execution_mode, error="subprocess_timeout", detail={"timeout": request.timeout_seconds})

        if completed.returncode != 0:
            return ExternalSourceRuntimeResult(
                source_key=request.source_key, ok=False, execution_mode=request.execution_mode,
                error=completed.stderr.strip() or f"exit_{completed.returncode}",
                detail={"stdout": completed.stdout[-500:], "stderr": completed.stderr[-500:]},
            )
        try:
            payload = json.loads(completed.stdout)
        except json.JSONDecodeError as exc:
            return ExternalSourceRuntimeResult(
                source_key=request.source_key, ok=False, execution_mode=request.execution_mode,
                error=f"invalid_json:{exc}", detail={"stdout": completed.stdout[-500:]},
            )
        if not payload.get("ok"):
            return ExternalSourceRuntimeResult(
                source_key=request.source_key, ok=False, execution_mode=request.execution_mode,
                error=str(payload.get("error", "")), detail=payload.get("detail") or {},
            )
        fetch_payload = payload.get("fetch_result") or {}
        return ExternalSourceRuntimeResult(
            source_key=request.source_key, ok=True, execution_mode=request.execution_mode,
            fetch_result=_provider_fetch_result_from_json(fetch_payload), detail=payload.get("detail") or {},
        )


class ExternalSourceRuntimeFetcher:
    def __init__(self, runtime: ExternalSourceRuntime, request: ExternalSourceRuntimeRequest) -> None:
        self.runtime = runtime; self.request = request

    def fetch(self, *, requested_trading_date: str) -> ProviderFetchResult:
        req = ExternalSourceRuntimeRequest(
            source_key=self.request.source_key, requested_trading_date=requested_trading_date,
            module_name=self.request.module_name, callable_name=self.request.callable_name,
            old_project_root=self.request.old_project_root, execution_mode=self.request.execution_mode,
            timeout_seconds=self.request.timeout_seconds, kwargs=self.request.kwargs,
        )
        result = self.runtime.call(req)
        if not result.ok or result.fetch_result is None:
            raise RuntimeError(result.error or "runtime_failed")
        return result.fetch_result


def _normalize_provider_fetch_result(payload: Any, *, requested_trading_date: str) -> ProviderFetchResult:
    if isinstance(payload, ProviderFetchResult):
        return payload
    if isinstance(payload, dict) and "data" in payload:
        updated = payload.get("source_updated_at")
        return ProviderFetchResult(
            data=payload["data"], source_trading_date=payload.get("source_trading_date") or requested_trading_date,
            source_updated_at=_parse_datetime(updated), detail=payload.get("detail") if isinstance(payload.get("detail"), dict) else {},
        )
    return ProviderFetchResult(data=payload, source_trading_date=requested_trading_date, detail={"normalized": True})


def _provider_fetch_result_from_json(payload: dict[str, Any]) -> ProviderFetchResult:
    return ProviderFetchResult(
        data=payload.get("data"), source_trading_date=payload.get("source_trading_date"),
        source_updated_at=_parse_datetime(payload.get("source_updated_at")),
        detail=payload.get("detail") if isinstance(payload.get("detail"), dict) else {},
    )


def _parse_datetime(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str) and value:
        try:
            return datetime.fromisoformat(value)
        except ValueError:
            return None
    return None
