from __future__ import annotations

import sys
from dataclasses import dataclass, field
from enum import Enum
from typing import Protocol

from app.services.provider_bridge_service import ProviderFetchResult


class ExternalSourceKind(str, Enum):
    STOCK_BASIC = "stock_basic"; QUOTE_BATCH = "quote_batch"; SPEED_RANK = "speed_rank"
    SHORTLINE_EVENT = "shortline_event"; LIMIT_POOL = "limit_pool"; DAILY_KLINE = "daily_kline"
    INTRADAY = "intraday"; BOARD_MAPPING = "board_mapping"; BOARD_MEMBERS = "board_members"
    FUND_FLOW = "fund_flow"; FEISHU = "feishu"; TONGHUASHUN_SELF_STOCK = "tonghuashun_self_stock"


class SourceRequirement(str, Enum):
    REQUIRED = "required"; ENHANCEMENT = "enhancement"; FALLBACK = "fallback"
    EXTERNAL_ACTION = "external_action"; DISABLED = "disabled"


class SourceChain(str, Enum):
    LIFECYCLE = "lifecycle"; LIMIT_POOL_SOURCE = "limit_pool_source"
    SCORING = "scoring"; NOTIFICATION = "notification"; SELF_STOCK = "self_stock"


class BlockingMode(str, Enum):
    BLOCKING_ALLOWED = "blocking_allowed"; ASYNC_REQUIRED = "async_required"
    NEVER_BLOCK_LIFECYCLE = "never_block_lifecycle"


class AdapterKind(str, Enum):
    SDK = "sdk"; HTTP = "http"; PYTHON_LIBRARY = "python_library"
    LEGACY_PROVIDER = "legacy_provider"; UNKNOWN = "unknown"


class FailurePolicy(str, Enum):
    FAIL_CLOSED = "fail_closed"; PARTIAL_SCORE = "partial_score"
    FALLBACK_ALLOWED = "fallback_allowed"; SUPPRESS_ACTION = "suppress_action"
    RECORD_ONLY = "record_only"


class ExternalSourceAdapter(Protocol):
    def fetch(self, *, requested_trading_date: str) -> ProviderFetchResult: ...


@dataclass(slots=True)
class ExternalSourceRegistration:
    key: str; kind: ExternalSourceKind; chain: SourceChain; requirement: SourceRequirement
    blocking_mode: BlockingMode; adapter_kind: AdapterKind; failure_policy: FailurePolicy
    v2_target: str; cache_ttl_seconds: int = 0; freshness_required: bool = True
    primary: bool = True; fallback_for: str | None = None
    old_modules: list[str] = field(default_factory=list)
    old_callables: list[str] = field(default_factory=list); notes: str = ""


@dataclass(slots=True)
class ExternalSourceProbeResult:
    key: str; found_module: str | None; found_callable: str | None
    import_ok: bool; callable_found: bool; error: str = ""
    adapter_kind: AdapterKind = AdapterKind.UNKNOWN


R = SourceRequirement; C = SourceChain; B = BlockingMode; F = FailurePolicy; A = AdapterKind; K = ExternalSourceKind


def _reg(key, kind, chain, requirement, blocking, failure, target, ttl=0, modules=None, callables=None, notes=""):
    return ExternalSourceRegistration(
        key=key, kind=kind, chain=chain, requirement=requirement, blocking_mode=blocking,
        adapter_kind=A.UNKNOWN, failure_policy=failure, v2_target=target, cache_ttl_seconds=ttl,
        old_modules=modules or [], old_callables=callables or [], notes=notes,
    )


def default_external_source_registrations() -> list[ExternalSourceRegistration]:
    return [
        _reg("stock_basic_st", K.STOCK_BASIC, C.LIFECYCLE, R.REQUIRED, B.BLOCKING_ALLOWED, F.FAIL_CLOSED,
             "CandidateLifecycleService ST filter", 86400,
             ["astock_guard.providers.stock_basic", "astock_guard.providers.stock_meta"],
             ["fetch_stock_basic", "get_stock_meta", "load_stock_meta"],
             "ST 过滤固定不可关闭；失败不能默认非 ST。"),
        _reg("quote_batch", K.QUOTE_BATCH, C.LIFECYCLE, R.REQUIRED, B.NEVER_BLOCK_LIFECYCLE, F.RECORD_ONLY,
             "MarketSourceAdapterService.ingest_quote_batch", 1,
             ["astock_guard.providers.quotes", "astock_guard.providers.realtime", "astock_guard.alerts"],
             ["fetch_quotes", "get_realtime_quotes", "quote_batch"],
             "驱动 CANDIDATE/CORE/open/reseal；mismatch 不得触发生命周期。"),
        _reg("speed_rank", K.SPEED_RANK, C.LIFECYCLE, R.REQUIRED, B.NEVER_BLOCK_LIFECYCLE, F.RECORD_ONLY,
             "MarketSourceAdapterService.ingest_event_source", 3,
             ["astock_guard.providers.speed_rank", "astock_guard.providers.eastmoney_changes"],
             ["fetch_speed_rank", "fetch_changes", "get_speed_rank"],
             "至少 speed_rank/shortline 需要一个主事件源触发 PRE_CANDIDATE。"),
        _reg("shortline_event", K.SHORTLINE_EVENT, C.LIFECYCLE, R.REQUIRED, B.NEVER_BLOCK_LIFECYCLE, F.RECORD_ONLY,
             "MarketSourceAdapterService.ingest_event_source", 3,
             ["astock_guard.providers.shortline", "astock_guard.shortline"],
             ["fetch_shortline_events", "get_shortline_events"],
             "短线事件源；与 speed_rank 需要去重，不能重复进入 active 状态。"),
        _reg("limit_pool", K.LIMIT_POOL, C.LIMIT_POOL_SOURCE, R.REQUIRED, B.NEVER_BLOCK_LIFECYCLE, F.RECORD_ONLY,
             "LimitPoolProviderIngestionService -> limit_pool_snapshots/rows", 5,
             ["astock_guard.providers.limit_pool", "astock_guard.limit_pool"],
             ["fetch_limit_pool", "get_limit_pool", "fetch_limit_pool_snapshot"],
             "只写源输入；不得直接触发生命周期；不得把评分结果写回 limit_pool_rows。"),
        _reg("daily_kline", K.DAILY_KLINE, C.SCORING, R.REQUIRED, B.ASYNC_REQUIRED, F.PARTIAL_SCORE,
             "ScoreWorker / LegacyScoringExecutor", 86400,
             ["astock_guard.providers.history", "astock_guard.providers.ths_kline"],
             ["get_kline_score", "get_daily_history", "_technical_score_v1"],
             "技术分依赖；not_real_time；可一次拉取全量。"),
        _reg("intraday", K.INTRADAY, C.SCORING, R.REQUIRED, B.ASYNC_REQUIRED, F.PARTIAL_SCORE,
             "ScoreWorker / LegacyScoringExecutor -> seal_quality / open_board_detect", 2,
             ["astock_guard.providers.intraday"],
             ["get_minute_bars", "seal_quality", "limit_phase"],
             "分时封板质量检测；情绪分外部修正。"),
        _reg("board_mapping", K.BOARD_MAPPING, C.SCORING, R.REQUIRED, B.ASYNC_REQUIRED, F.PARTIAL_SCORE,
             "ScoreWorker / LegacyScoringExecutor -> stock_boards / board_score", 300,
             ["astock_guard.providers.stock_boards"],
             ["summary", "get_boards", "cached_summary"],
             "股票所属板块；情绪分基础输入。"),
        _reg("board_members", K.BOARD_MEMBERS, C.SCORING, R.REQUIRED, B.ASYNC_REQUIRED, F.PARTIAL_SCORE,
             "ScoreWorker / LegacyScoringExecutor -> board_members / rank / order", 10,
             ["astock_guard.providers.em_board_members"],
             ["get_members", "get_board_top20"],
             "板块内排名和封板顺位。"),
        _reg("fund_flow", K.FUND_FLOW, C.SCORING, R.REQUIRED, B.ASYNC_REQUIRED, F.PARTIAL_SCORE,
             "ScoreWorker / LegacyScoringExecutor -> board_external_adjustments / fund_delta", 30,
             ["astock_guard.providers.fund_flow"],
             ["get_flow", "get_fund_flow"],
             "旧系统慢点，但属于情绪/资金确认输入，不能删除；失败必须显式 partial/failed，不能默认达标。"),
        _reg("feishu", K.FEISHU, C.NOTIFICATION, R.EXTERNAL_ACTION, B.NEVER_BLOCK_LIFECYCLE, F.SUPPRESS_ACTION,
             "NotificationGate -> FeishuBot", 0,
             ["astock_guard.notifiers.feishu", "astock_guard.feishu"],
             ["send_feishu", "feishu_notify", "send_message"],
             "通知不改变生命周期。失败需要记录但不得阻塞引擎。"),
        _reg("tonghuashun_self_stock", K.TONGHUASHUN_SELF_STOCK, C.SELF_STOCK, R.EXTERNAL_ACTION, B.NEVER_BLOCK_LIFECYCLE, F.SUPPRESS_ACTION,
             "SelfStockAction -> ThsSelfStockService", 0,
             ["astock_guard.self_stock", "astock_guard.providers.ths_self_stock"],
             ["add_self_stock", "self_stock_add", "add_stock"],
             "自选不改变生命周期。封板后仍需情绪分达标才 BUYABLE，否则 WARNING。"),
    ]


class ExternalSourceRegistry:
    def __init__(self, registrations: list[ExternalSourceRegistration] | None = None) -> None:
        self._items: dict[str, ExternalSourceRegistration] = {}
        for item in registrations or default_external_source_registrations():
            self.register(item)

    def register(self, item: ExternalSourceRegistration) -> None:
        self._items[item.key] = item

    def get(self, key: str) -> ExternalSourceRegistration | None:
        return self._items.get(key)

    def all(self) -> list[ExternalSourceRegistration]:
        return list(self._items.values())

    def by_chain(self, chain: SourceChain) -> list[ExternalSourceRegistration]:
        return [item for item in self._items.values() if item.chain == chain]

    def required(self) -> list[ExternalSourceRegistration]:
        return [item for item in self._items.values() if item.requirement == SourceRequirement.REQUIRED]

    def required_for_initial_backend(self) -> list[ExternalSourceRegistration]:
        keys = {"stock_basic_st", "quote_batch", "speed_rank", "shortline_event", "limit_pool",
                "daily_kline", "intraday", "board_mapping", "board_members", "fund_flow"}
        return [item for item in self._items.values() if item.key in keys]


def probe_legacy_sources(*, old_project_root: str, registry: ExternalSourceRegistry | None = None) -> list[ExternalSourceProbeResult]:
    reg = registry or ExternalSourceRegistry()
    original_path = list(sys.path)
    sys.path.insert(0, old_project_root)
    results: list[ExternalSourceProbeResult] = []
    try:
        for item in reg.all():
            found_module = None; found_callable = None; import_ok = False; callable_found = False; error = ""
            for mod_name in item.old_modules:
                try:
                    mod = __import__(mod_name, fromlist=item.old_callables)
                    import_ok = True; found_module = mod_name
                    for fn in item.old_callables:
                        if getattr(mod, fn, None) is not None and callable(getattr(mod, fn)):
                            found_callable = fn; callable_found = True; break
                    if import_ok:
                        break
                except (ImportError, ModuleNotFoundError, Exception) as exc:
                    error = f"{type(exc).__name__}: {exc}"
            results.append(ExternalSourceProbeResult(key=item.key, found_module=found_module, found_callable=found_callable, import_ok=import_ok, callable_found=callable_found, error=error))
    finally:
        sys.path = original_path
    return results
