from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime

from sqlalchemy.orm import Session

from app.db.models import LimitPoolRow
from app.repositories import ScoreTaskRepository


def _json_value(val):
    if val is None:
        return "null"
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, (int, float)):
        return val
    return f'"{val}"'


@dataclass(slots=True)
class ScoreTaskScheduleResult:
    task_id: int
    action: str
    status: str
    code: str
    source_type: str
    source_row_id: int | None = None


class ScoreTaskService:
    def __init__(self, session: Session) -> None:
        self.session = session
        self.tasks = ScoreTaskRepository(session)

    def schedule_for_limit_pool_row(
        self, row: LimitPoolRow, *, score_stage: str = "limit_pool_first_score",
        task_type: str = "limit_pool_score", priority: int = 100,
        config_version: str = "default",
    ) -> ScoreTaskScheduleResult:
        return self.schedule_scoring(
            trading_date=row.trading_date,
            source_trading_date=row.source_trading_date,
            code=row.code, name=row.name,
            score_stage=score_stage, task_type=task_type,
            components_json='["technical","sentiment","volume"]',
            source_type="limit_pool_row",
            source_snapshot_id=row.snapshot_id,
            source_row_id=row.id,
            input_refs_json=json.dumps({
                "limit_pool_snapshot_id": row.snapshot_id,
                "limit_pool_row_id": row.id,
                "price": row.price, "change_pct": row.change_pct,
            }, ensure_ascii=False, default=str),
            priority=priority,
            as_of=row.as_of, seq=row.seq,
            freshness_status=row.freshness_status,
            config_version=config_version,
        )

    def schedule_scoring(
        self, *, trading_date: str, source_trading_date: str | None,
        code: str, name: str = "", score_stage: str = "",
        task_type: str = "", components_json: str = '["technical","sentiment","volume"]',
        source_type: str = "", source_event_id: int | None = None,
        source_snapshot_id: int | None = None, source_row_id: int | None = None,
        input_refs_json: str = "{}", priority: int = 100,
        config_version: str = "default",
        as_of: datetime | None = None, seq: int = 0,
        freshness_status: str = "fresh",
    ) -> ScoreTaskScheduleResult:
        task = self.tasks.upsert_task(
            trading_date=trading_date,
            source_trading_date=source_trading_date,
            code=code, name=name,
            task_type=task_type, score_stage=score_stage,
            source_type=source_type,
            source_snapshot_id=source_snapshot_id,
            source_row_id=source_row_id,
            source_event_id=source_event_id,
            components_json=components_json,
            priority=priority,
            input_refs_json=input_refs_json,
            as_of=as_of or datetime.utcnow(),
            seq=seq, freshness_status=freshness_status,
            config_version=config_version,
        )
        self.session.flush()
        return ScoreTaskScheduleResult(
            task_id=task.id, action="scheduled", status=task.status,
            code=task.code, source_type=task.source_type,
            source_row_id=task.source_row_id,
        )
