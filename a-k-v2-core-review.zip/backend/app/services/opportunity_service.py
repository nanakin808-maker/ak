from __future__ import annotations

import json
import os
from datetime import datetime

from app.adapters.legacy.http_client import LegacyHttpError, fetch_legacy_json
from app.schemas.event import EventsResponse
from app.schemas.opportunity import OpportunitiesResponse
from app.adapters.legacy.alerts_state import normalize_events, normalize_opportunities
from app.mocks.events import mock_events
from app.mocks.opportunities import mock_candidates
from app.services.opportunity_helpers import (
    _extract_boards, _extract_score_details, _resolve_sentiment_score,
)

def now_text() -> str:
    return datetime.now().isoformat(timespec="seconds")

def legacy_url() -> str:
    return os.getenv("LEGACY_ALERTS_STATE_URL", "").strip()

def legacy_configured() -> bool:
    return bool(legacy_url())

def fetch_legacy_payload() -> dict:
    url = legacy_url()
    if not url:
        raise RuntimeError("LEGACY_ALERTS_STATE_URL 未配置")
    return fetch_legacy_json(url, timeout=5)

def _read_v2_db_stocks() -> list[dict]:
    """Read monitoring stock states from v2 shadow DB."""
    import sqlite3
    from pathlib import Path

    db_path = Path(__file__).resolve().parents[3] / "data" / "astock_guard_v2_shadow.db"
    if not db_path.exists():
        return []

    conn = sqlite3.connect(f"file:{db_path.resolve()}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute("""
            SELECT s.code, s.name, s.stage, s.price, s.change_pct, s.is_sealed,
                   s.at_limit, s.open_count, s.active_monitoring, s.inactive_reason,
                   s.freshness_status, s.as_of, s.created_at,
                   ss.technical_score, ss.sentiment_score, ss.volume_score,
                   ss.score_stage, ss.status as score_status, ss.score_json,
                   sc.context_json,
                   (SELECT lpr.industry FROM limit_pool_rows lpr
                    WHERE lpr.code = s.code AND lpr.trading_date = s.trading_date
                    AND lpr.industry != ''
                    ORDER BY lpr.id DESC LIMIT 1) as industry
            FROM monitoring_stock_states s
            LEFT JOIN (
                SELECT code, trading_date, technical_score, sentiment_score,
                       volume_score, score_stage, status, score_json,
                       ROW_NUMBER() OVER (PARTITION BY code, trading_date ORDER BY as_of DESC) as rn
                FROM score_snapshots
                WHERE technical_score IS NOT NULL OR sentiment_score IS NOT NULL
            ) ss ON s.code = ss.code AND s.trading_date = ss.trading_date AND ss.rn = 1
            LEFT JOIN (
                SELECT code, trading_date, context_json,
                       ROW_NUMBER() OVER (PARTITION BY code, trading_date ORDER BY created_at DESC) as rn
                FROM scoring_contexts
                WHERE score_stage = 'core_seal'
            ) sc ON s.code = sc.code AND s.trading_date = sc.trading_date AND sc.rn = 1
            WHERE s.active_monitoring = 1
            ORDER BY
              CASE s.stage
                WHEN 'CORE' THEN 0
                WHEN 'CANDIDATE' THEN 1
                WHEN 'PRE_CANDIDATE' THEN 2
                ELSE 3
              END,
              s.code
        """).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def _read_v2_db_events(limit: int = 50) -> list[dict]:
    """Read monitoring events from v2 shadow DB."""
    import sqlite3
    from pathlib import Path

    db_path = Path(__file__).resolve().parents[3] / "data" / "astock_guard_v2_shadow.db"
    if not db_path.exists():
        return []

    conn = sqlite3.connect(f"file:{db_path.resolve()}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute("""
            SELECT e.id, e.code, e.name, e.event_type, e.event_source, e.event_time,
                   e.price, e.change_pct, e.is_sealed, e.is_first_seal,
                   e.as_of, e.freshness_status, e.trading_date
            FROM monitoring_events e
            ORDER BY e.as_of DESC
            LIMIT ?
        """, (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def _stage_to_decision_stage(stage: str) -> str:
    """Map v2 lifecycle stage to frontend decisionStage."""
    mapping = {
        "PRE_CANDIDATE": "watch",
        "CANDIDATE": "candidate",
        "CORE": "core",
        "REJECTED_TODAY": "rejected",
    }
    return mapping.get(stage, "watch")

def _v2_stocks_to_opportunity_rows(stocks: list[dict]) -> list[dict]:
    """Convert v2 stock states to frontend CandidateSummary format."""
    rows = []
    for s in stocks:
        stage = s.get("stage", "") or ""
        context_json = s.get("context_json") or "{}"
        industry = s.get("industry") or ""
        if industry:
            board_name, board_change = industry, None
        else:
            board_name, board_change, _ = _extract_boards(context_json)
        score_json_str = s.get("score_json") or "{}"
        sentiment = _resolve_sentiment_score(score_json_str, s.get("sentiment_score"), s)
        score_details = _extract_score_details(score_json_str)

        row = {
            "code": s["code"], "name": s.get("name", ""),
            "price": s.get("price") or 0,
            "changePct": s.get("change_pct") or 0,
            "technicalScore": s.get("technical_score") or 0,
            "sentimentScore": sentiment or 0,
            "firstSealSentimentScore": sentiment,
            "volumeScore": s.get("volume_score"),
            "volumeStatus": "monitoring" if s.get("volume_score") else "pending",
            "board": board_name,
            "boardChangePct": board_change,
            "decisionStage": _stage_to_decision_stage(stage),
            "scoreDetails": score_details,
            "stage": stage,
            "isSealed": bool(s.get("is_sealed")),
            "atLimit": bool(s.get("at_limit")),
            "openCount": s.get("open_count"),
            "activeMonitoring": bool(s.get("active_monitoring")),
            "inactiveReason": s.get("inactive_reason"),
            "freshnessStatus": s.get("freshness_status"),
            "asOf": s.get("as_of"),
        }
        rows.append(row)
    return rows

def _v2_events_to_monitor_events(events: list[dict]) -> list[dict]:
    """Convert v2 events to frontend MonitorEvent format."""
    return [
        {
            "id": str(e.get("id", "")),
            "time": str(e.get("event_time") or e.get("as_of", "")),
            "code": e.get("code", ""),
            "name": e.get("name", ""),
            "event": e.get("event_type", ""),
            "detail": "",
            "tone": "red" if e.get("is_sealed") else "blue",
            "eventType": e.get("event_type", ""),
            "eventSource": e.get("event_source", ""),
            "eventTime": e.get("event_time", ""),
            "price": e.get("price"),
            "changePct": e.get("change_pct"),
            "isSealed": bool(e.get("is_sealed")),
            "isFirstSeal": bool(e.get("is_first_seal")),
            "tradingDate": e.get("trading_date", ""),
        }
        for e in events
    ]

def _market_meta() -> dict:
    try:
        from app.domain.market_calendar import (
            effective_trading_date, is_live_trading, market_session,
        )
        return {
            "marketSession": market_session().value,
            "effectiveTradingDate": effective_trading_date(),
            "isLiveTrading": is_live_trading(),
        }
    except Exception:
        return {}


def get_opportunities() -> OpportunitiesResponse:
    meta = _market_meta()
    # 1. Try legacy (old system bridge)
    if legacy_configured():
        try:
            payload = fetch_legacy_payload()
            rows = normalize_opportunities(payload)
            if rows:
                return OpportunitiesResponse(
                    source="legacy", updatedAt=now_text(), rows=rows, **meta,
                )
        except (RuntimeError, LegacyHttpError):
            pass

    # 2. Try v2 shadow DB
    v2_stocks = _read_v2_db_stocks()
    if v2_stocks:
        rows = _v2_stocks_to_opportunity_rows(v2_stocks)
        return OpportunitiesResponse(
            source="v2_shadow", updatedAt=now_text(), rows=rows, **meta,
        )

    # 3. Fallback to mock
    return OpportunitiesResponse(
        source="mock", updatedAt=now_text(),
        rows=mock_candidates(),
        error="no_legacy_or_v2_data",
        **meta,
    )

def get_events() -> EventsResponse:
    # 1. Try legacy
    if legacy_configured():
        try:
            payload = fetch_legacy_payload()
            events = normalize_events(payload)
            if events:
                return EventsResponse(
                    source="legacy", updatedAt=now_text(), events=events,
                )
        except (RuntimeError, LegacyHttpError):
            pass

    # 2. Try v2 shadow DB
    v2_events = _read_v2_db_events(limit=50)
    if v2_events:
        events = _v2_events_to_monitor_events(v2_events)
        return EventsResponse(
            source="v2_shadow", updatedAt=now_text(), events=events,
        )

    # 3. Fallback to mock
    return EventsResponse(
        source="mock", updatedAt=now_text(),
        events=mock_events(),
        error="no_legacy_or_v2_data",
    )
