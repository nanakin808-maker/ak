from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from app.db.models import ScoreTaskCurrent
from app.services.score_worker_service import ScoreExecutionResult


class LegacyScoringExecutor:
    def __init__(
        self,
        old_project_root: str = "../a-k",
        old_python: str | None = None,
        module_name: str | None = None,
        callable_name: str | None = None,
        timeout_seconds: float = 30.0,
        fallback_to_failed: bool = True,
    ) -> None:
        self.old_project_root = old_project_root
        self.old_python = old_python
        self.module_name = module_name
        self.callable_name = callable_name
        self.timeout_seconds = timeout_seconds
        self.fallback_to_failed = fallback_to_failed

    def execute(self, task: ScoreTaskCurrent) -> ScoreExecutionResult:
        worker = Path(__file__).resolve().parents[3] / "scripts" / "legacy_scoring_worker.py"
        if not worker.exists():
            return ScoreExecutionResult(
                score=None, technical_score=None, sentiment_score=None,
                volume_score=None, passed=False, status="failed",
                score_json="{}", reject_reason=f"legacy_scoring_worker_not_found:{worker}",
            )

        old_python = self.old_python or str(
            Path(self.old_project_root).resolve() / ".venv" / "bin" / "python3"
        )

        cmd = [
            old_python, str(worker),
            "--code", task.code,
            "--name", task.name,
            "--trading-date", task.trading_date,
            "--source-type", task.source_type,
            f"--source-row-id={task.source_row_id}" if task.source_row_id is not None else "",
            "--score-stage", task.score_stage,
            "--input-refs-json", task.input_refs_json or "{}",
        ]
        if self.module_name:
            cmd.extend(["--module", self.module_name])
        if self.callable_name:
            cmd.extend(["--callable", self.callable_name])
        if self.old_project_root:
            cmd.extend(["--old-project-root", self.old_project_root])
        cmd = [c for c in cmd if c]

        try:
            cp = subprocess.run(cmd, check=False, capture_output=True, text=True, timeout=self.timeout_seconds)
        except subprocess.TimeoutExpired:
            return ScoreExecutionResult(
                score=None, technical_score=None, sentiment_score=None,
                volume_score=None, passed=False, status="failed",
                score_json="{}", reject_reason=f"legacy_scoring_timeout:{self.timeout_seconds}s",
            )

        if cp.returncode != 0:
            return ScoreExecutionResult(
                score=None, technical_score=None, sentiment_score=None,
                volume_score=None, passed=False, status="failed",
                score_json="{}", reject_reason=cp.stderr.strip()[:500] or f"exit:{cp.returncode}",
            )

        try:
            payload = json.loads(cp.stdout)
        except json.JSONDecodeError as exc:
            return ScoreExecutionResult(
                score=None, technical_score=None, sentiment_score=None,
                volume_score=None, passed=False, status="failed",
                score_json="{}", reject_reason=f"invalid_json:{exc}",
            )

        if not payload.get("ok"):
            raise RuntimeError(payload.get("error", "unknown_legacy_error"))

        return ScoreExecutionResult(
            score=payload.get("score"),
            technical_score=payload.get("technical_score"),
            sentiment_score=payload.get("sentiment_score"),
            volume_score=payload.get("volume_score"),
            passed=payload.get("passed", False),
            status=payload.get("status", "ready"),
            reject_reason=payload.get("reject_reason"),
            main_logic=payload.get("main_logic", "legacy_scoring"),
            score_json=json.dumps(payload.get("score_json", {}), ensure_ascii=False, default=str),
            input_refs_json=json.dumps(payload.get("input_refs_json", {}), ensure_ascii=False, default=str) if not isinstance(payload.get("input_refs_json"), str) else payload.get("input_refs_json", "{}"),
        )
