"""Score detail and board extraction helpers for opportunity_service."""

import json

_NOISE_KEYWORDS = [
    "融资融券", "深股通", "沪股通", "创业板综", "上证", "深证", "沪深", "HS300",
    "MSCI", "富时罗素", "标准普尔", "证金持股", "机构重仓", "QFII", "百元股",
    "昨日", "最近多板", "历史新高", "百日新高", "转债标的", "东方财富热股",
    "长江三角", "京津冀", "粤港澳", "成渝", "东北振兴", "西部大开发", "参股",
    "破发股", "年报", "预增", "小盘股", "低价股", "国企改革", "央企",
    "基金重仓", "同花顺漂亮", "标普", "中盘", "大盘",
]

def _is_noise(board_name: str) -> bool:
    for kw in _NOISE_KEYWORDS:
        if kw in board_name:
            return True
    return len(board_name) <= 4 and board_name.endswith("板块")

def _extract_boards(context_json: str) -> tuple[str, float | None, list[dict]]:
    try:
        ctx = json.loads(context_json) if isinstance(context_json, str) else (context_json or {})
    except (json.JSONDecodeError, TypeError):
        return "", None, []
    raw = ctx.get("boards", {}).get("raw", [])
    if not raw or not isinstance(raw, list):
        return "", None, []
    useful = [b for b in raw if not _is_noise(b.get("name", ""))]
    if not useful:
        useful = raw
    useful.sort(key=lambda b: b.get("change_pct") or -999, reverse=True)
    primary = useful[0]
    return primary.get("name", ""), primary.get("change_pct"), useful

def _extract_score_details(score_json_str: str) -> dict | None:
    try:
        sj = json.loads(score_json_str) if isinstance(score_json_str, str) else (score_json_str or {})
    except (json.JSONDecodeError, TypeError):
        return None
    components = sj.get("components", {})
    detail: dict[str, list] = {}
    tech = components.get("technical", {})
    tech_detail = tech.get("detail", {})
    tech_comps = tech_detail.get("components", {})
    tech_rules = []
    for name, score in tech_comps.get("flat", {}).items():
        tech_rules.append({"label": f"平铺-{name}", "delta": int(score or 0)})
    for name, score in tech_comps.get("trend", {}).items():
        tech_rules.append({"label": f"趋势-{name}", "delta": int(score or 0)})
    if tech_rules:
        detail["technical"] = tech_rules
    board = components.get("board", {})
    bd = sj.get("board_detail", {}) or board.get("detail", {})
    factors = bd.get("factors", []) or board.get("factors", [])
    sent_rules = [{"label": f.get("name", ""), "delta": int(f.get("score_delta", 0))}
                  for f in factors if f.get("score_delta")]
    if sent_rules:
        detail["realtimeSentiment"] = sent_rules
        detail["sealSentiment"] = sent_rules
    vol = components.get("volume", {})
    vd = sj.get("volume_detail", {}) or vol
    vol_rules = []
    for key, label in [("short_window", "短窗口量能"), ("amount_confirm", "成交额确认"),
                       ("turnover_fit", "换手适配"), ("history_compare", "历史对比")]:
        s = vd.get(key, {})
        if s.get("score"):
            vol_rules.append({"label": label, "delta": int(s.get("score", 0))})
    risk = vd.get("risk_penalty", {})
    if risk.get("penalty"):
        vol_rules.append({"label": "风险扣分", "delta": -int(risk.get("penalty", 0))})
    if vol_rules:
        detail["volume"] = vol_rules
    return detail if detail else None

def _resolve_sentiment_score(score_json_str: str, sentiment_score: float | None,
                             s: dict) -> float | None:
    if sentiment_score:
        return sentiment_score
    try:
        sj = json.loads(score_json_str) if isinstance(score_json_str, str) else (score_json_str or {})
    except (json.JSONDecodeError, TypeError):
        return None
    bd = sj.get("board_detail", {})
    bs = bd.get("score")
    return float(bs) if bs is not None else None
