from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Callable

from sqlalchemy.orm import Session

from app.domain.time_scope import MarketSession
from app.runtime.candidate_base import CandidateEntryInput, CandidateQuoteInput
from app.runtime.state import RuntimeState
from app.services.limit_pool_provider_service import (
    LimitPoolFetcher,
    LimitPoolProviderIngestionService,
    LimitPoolProviderRunResult,
)
from app.services.provider_bridge_service import ProviderBridgeService, ProviderFetchResult


@dataclass(slots=True)
class SourceAdapterRunResult:
    source_type: str
    provider_ok: bool
    processed: int
    actions: list[str]
    freshness_status: str
    error: str = ""


class MarketSourceAdapterService:
    def __init__(self, session: Session, runtime: RuntimeState, engine: object | None = None) -> None:
        self.session = session
        self.runtime = runtime
        if engine is not None:
            self.engine = engine
        else:
            from app.runtime.monitoring_engine import MonitoringEngine as ME  # noqa: E402
            self.engine = ME(session, runtime)
        self.bridge = ProviderBridgeService(session)

    def ingest_limit_pool(
        self,
        *,
        requested_trading_date: str,
        as_of: datetime,
        seq: int,
        fetcher: LimitPoolFetcher,
        market_session: MarketSession = MarketSession.UNKNOWN,
        cache_key: str | None = None,
        ttl_seconds: float = 0,
        timeout_ms: float | None = None,
        provider_name: str = "limit_pool_provider",
        primary_source: str = "unknown",
    ) -> LimitPoolProviderRunResult:
        service = LimitPoolProviderIngestionService(self.session, fetcher)
        return service.fetch_and_ingest(
            requested_trading_date=requested_trading_date,
            as_of=as_of,
            seq=seq,
            market_session=market_session,
            cache_key=cache_key,
            ttl_seconds=ttl_seconds,
            timeout_ms=timeout_ms,
            provider_name=provider_name,
            provider_category="limit_pool",
            primary_source=primary_source,
        )

    def ingest_event_source(
        self,
        *,
        source_type: str,
        provider_name: str,
        requested_trading_date: str,
        fetcher: Callable[[], ProviderFetchResult],
        as_of: datetime,
        seq_start: int,
        market_session: MarketSession = MarketSession.UNKNOWN,
        cache_key: str | None = None,
        ttl_seconds: float = 0,
        timeout_ms: float | None = None,
    ) -> SourceAdapterRunResult:
        call = self.bridge.call(
            name=provider_name,
            category=source_type,
            requested_trading_date=requested_trading_date,
            fetcher=fetcher,
            cache_key=cache_key,
            ttl_seconds=ttl_seconds,
            timeout_ms=timeout_ms,
            market_session=market_session,
        )

        if not call.ok:
            return SourceAdapterRunResult(
                source_type=source_type, provider_ok=False, processed=0,
                actions=[], freshness_status=call.freshness_status, error=call.error,
            )

        rows = self._rows_from_data(call.data)
        actions: list[str] = []
        for idx, row in enumerate(rows):
            entry = self._to_entry_input(
                row, source_type=source_type,
                trading_date=requested_trading_date,
                source_trading_date=call.source_trading_date,
                freshness_status=call.freshness_status,
                as_of=as_of, seq=seq_start + idx,
            )
            result = self.engine.handle_source_event(entry)
            actions.append(result.action)

        return SourceAdapterRunResult(
            source_type=source_type, provider_ok=True, processed=len(rows),
            actions=actions, freshness_status=call.freshness_status, error="",
        )

    def ingest_quote_batch(
        self,
        *,
        provider_name: str,
        requested_trading_date: str,
        fetcher: Callable[[], ProviderFetchResult],
        as_of: datetime,
        seq_start: int,
        market_session: MarketSession = MarketSession.UNKNOWN,
        cache_key: str | None = None,
        ttl_seconds: float = 0,
        timeout_ms: float | None = None,
    ) -> SourceAdapterRunResult:
        call = self.bridge.call(
            name=provider_name, category="quote_batch",
            requested_trading_date=requested_trading_date,
            fetcher=fetcher, cache_key=cache_key,
            ttl_seconds=ttl_seconds, timeout_ms=timeout_ms,
            market_session=market_session,
        )

        if not call.ok:
            return SourceAdapterRunResult(
                source_type="quote_batch", provider_ok=False, processed=0,
                actions=[], freshness_status=call.freshness_status, error=call.error,
            )

        rows = self._rows_from_data(call.data)
        actions: list[str] = []
        for idx, row in enumerate(rows):
            quote = self._to_quote_input(
                row, trading_date=requested_trading_date,
                source_trading_date=call.source_trading_date,
                freshness_status=call.freshness_status,
                as_of=as_of, seq=seq_start + idx,
            )
            result = self.engine.process_quote(quote)
            actions.append(result.action)

        return SourceAdapterRunResult(
            source_type="quote_batch", provider_ok=True, processed=len(rows),
            actions=actions, freshness_status=call.freshness_status, error="",
        )

    def ingest_seal_check_for_candidates(
        self,
        *,
        trading_date: str,
        as_of: datetime,
        seq_start: int,
        market_session: MarketSession = MarketSession.UNKNOWN,
    ) -> SourceAdapterRunResult:
        """For each CANDIDATE stock, fetch real orderbook and check seal state.
        Promotes to CORE if sealed."""
        from app.runtime.candidate_base import CandidateQuoteInput
        from app.sources.composite_orderbook import fetch_one_orderbook

        states = self.engine.monitoring.list_stock_states(trading_date, freshness_status="fresh")
        candidates = [s for s in states if s.stage == "CANDIDATE" and s.active_monitoring]
        if not candidates:
            return SourceAdapterRunResult(
                source_type="seal_check", provider_ok=True, processed=0,
                actions=["no_candidates"], freshness_status="fresh", error="",
            )

        actions: list[str] = []
        for idx, state in enumerate(candidates):
            snap = fetch_one_orderbook(state.code, timeout=3.0)
            if snap is None:
                actions.append(f"seal_check_failed:{state.code}")
                continue

            quote = CandidateQuoteInput(
                trading_date=state.trading_date or trading_date,
                source_trading_date=state.source_trading_date,
                code=state.code, name=state.name,
                as_of=as_of, seq=seq_start + idx,
                freshness_status=state.freshness_status or "fresh",
                price=snap.price, change_pct=snap.change_pct or 0,
                bid1=snap.bid1, bid_vol1=snap.bid_vol1,
                ask1=snap.ask1, ask_vol1=snap.ask_vol1,
                is_sealed=snap.is_sealed,
                at_limit=(snap.limit_up is not None and snap.price is not None
                          and abs(snap.price - snap.limit_up) < 0.01),
                seal_confidence=snap.seal_confidence,
                seal_source=f"orderbook_{snap.source}",
                event_source=f"orderbook_{snap.source}",
            )
            result = self.engine.process_quote(quote)
            actions.append(result.action)

        return SourceAdapterRunResult(
            source_type="seal_check", provider_ok=True, processed=len(candidates),
            actions=actions, freshness_status="fresh", error="",
        )

    @staticmethod
    def _rows_from_data(data: Any) -> list[dict[str, Any]]:
        if isinstance(data, dict):
            rows = data.get("rows", [])
        elif isinstance(data, list):
            rows = data
        else:
            rows = []
        return [row for row in rows if isinstance(row, dict)]

    @staticmethod
    def _to_entry_input(
        row: dict[str, Any], *, source_type: str,
        trading_date: str, source_trading_date: str | None,
        freshness_status: str, as_of: datetime, seq: int,
    ) -> CandidateEntryInput:
        return CandidateEntryInput(
            trading_date=trading_date, source_trading_date=source_trading_date,
            code=str(row.get("code") or row.get("symbol") or ""),
            name=str(row.get("name") or ""),
            event_type=str(row.get("event_type") or source_type.upper()),
            event_source=str(row.get("event_source") or source_type),
            event_title=str(row.get("event_title") or row.get("title") or source_type),
            event_time=row.get("event_time"),
            as_of=as_of, seq=seq,
            freshness_status=freshness_status,
            price=row.get("price"), change_pct=row.get("change_pct"),
            raw_json=json.dumps(row, ensure_ascii=False, default=str),
        )

    @staticmethod
    def _to_quote_input(
        row: dict[str, Any], *, trading_date: str,
        source_trading_date: str | None,
        freshness_status: str, as_of: datetime, seq: int,
    ) -> CandidateQuoteInput:
        return CandidateQuoteInput(
            trading_date=trading_date, source_trading_date=source_trading_date,
            code=str(row.get("code") or row.get("symbol") or ""),
            name=str(row.get("name") or ""),
            as_of=as_of, seq=seq,
            freshness_status=freshness_status,
            price=row.get("price"),
            change_pct=row.get("change_pct") or 0.0,
            event_source=str(row.get("source") or "quote_batch"),
            is_sealed=bool(row.get("is_sealed", False)),
            at_limit=bool(row.get("at_limit", False)),
            open_count=row.get("open_count"),
            raw_json=json.dumps(row, ensure_ascii=False, default=str),
        )
