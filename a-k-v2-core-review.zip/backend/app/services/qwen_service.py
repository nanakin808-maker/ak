"""Qwen AI service."""


class QwenService:
    def __init__(self) -> None:
        self.available = False

    def status(self) -> dict:
        return {"available": self.available, "model": ""}


qwen_service = QwenService()
