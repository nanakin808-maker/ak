"""Alert engine service — orchestrates monitoring lifecycle."""


class AlertService:
    def __init__(self) -> None:
        self.running = False

    def start(self, notify_enabled: bool = False, interval_seconds: float = 3.0) -> None:
        self.running = True

    def stop(self) -> None:
        self.running = False

    def reset(self) -> None:
        self.running = False


alert_service = AlertService()
