from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Callable

from sqlalchemy.orm import Session

from app.domain.time_scope import MarketSession, evaluate_freshness
from app.repositories import InterfaceHealthRepository


@dataclass(slots=True)
class ProviderFetchResult:
    data: Any
    source_trading_date: str | None = None
    source_updated_at: datetime | None = None
    detail: dict[str, Any] | None = None


@dataclass(slots=True)
class ProviderCallResult:
    name: str
    category: str
    ok: bool
    data: Any | None
    requested_trading_date: str
    source_trading_date: str | None
    freshness_status: str
    as_of: datetime
    source_updated_at: datetime | None = None
    latency_ms: float | None = None
    from_cache: bool = False
    error: str = ""
    detail: dict[str, Any] | None = None


@dataclass(slots=True)
class _CacheEntry:
    expires_at: datetime
    result: ProviderCallResult


class ProviderBridgeService:
    def __init__(self, session: Session) -> None:
        self.session = session
        self.health = InterfaceHealthRepository(session)
        self._cache: dict[str, _CacheEntry] = {}

    def call(
        self,
        *,
        name: str,
        category: str,
        requested_trading_date: str,
        fetcher: Callable[[], ProviderFetchResult],
        cache_key: str | None = None,
        ttl_seconds: float = 0,
        timeout_ms: float | None = None,
        market_session: MarketSession = MarketSession.UNKNOWN,
    ) -> ProviderCallResult:
        now = datetime.utcnow()

        if cache_key:
            cached = self._cache.get(cache_key)
            if cached is not None and cached.expires_at > now:
                cached_result = cached.result
                return ProviderCallResult(
                    name=cached_result.name,
                    category=cached_result.category,
                    ok=cached_result.ok,
                    data=cached_result.data,
                    requested_trading_date=cached_result.requested_trading_date,
                    source_trading_date=cached_result.source_trading_date,
                    freshness_status=cached_result.freshness_status,
                    as_of=datetime.utcnow(),
                    source_updated_at=cached_result.source_updated_at,
                    latency_ms=0.0,
                    from_cache=True,
                    error=cached_result.error,
                    detail={**(cached_result.detail or {}), "cache_hit": True},
                )

        started = time.perf_counter()
        as_of = datetime.utcnow()

        try:
            fetched = fetcher()
            latency_ms = (time.perf_counter() - started) * 1000.0
            slow = bool(timeout_ms is not None and latency_ms > timeout_ms)

            freshness = evaluate_freshness(
                trading_date=requested_trading_date,
                source_trading_date=fetched.source_trading_date,
                market_session=market_session,
            )

            detail: dict[str, Any] = {
                "requested_trading_date": requested_trading_date,
                "source_trading_date": fetched.source_trading_date,
                "source_updated_at": fetched.source_updated_at.isoformat() if fetched.source_updated_at else None,
                "timeout_ms": timeout_ms,
                "slow": slow,
            }
            if fetched.detail:
                detail.update(fetched.detail)

            result = ProviderCallResult(
                name=name,
                category=category,
                ok=True,
                data=fetched.data,
                requested_trading_date=requested_trading_date,
                source_trading_date=fetched.source_trading_date,
                freshness_status=freshness if isinstance(freshness, str) else freshness.value,
                as_of=as_of,
                source_updated_at=fetched.source_updated_at,
                latency_ms=latency_ms,
                from_cache=False,
                error="",
                detail=detail,
            )

            self.health.record(
                name=name,
                category=category,
                ok=True,
                latency_ms=latency_ms,
                error="",
                detail_json=json.dumps(detail, ensure_ascii=False, default=str),
                timestamp=as_of,
            )

            if cache_key and ttl_seconds > 0:
                self._cache[cache_key] = _CacheEntry(
                    expires_at=datetime.utcnow() + timedelta(seconds=ttl_seconds),
                    result=result,
                )

            return result

        except Exception as exc:
            latency_ms = (time.perf_counter() - started) * 1000.0
            error = str(exc)
            detail: dict[str, Any] = {  # type: ignore[no-redef]
                "requested_trading_date": requested_trading_date,
                "timeout_ms": timeout_ms,
                "exception_type": exc.__class__.__name__,
            }

            self.health.record(
                name=name,
                category=category,
                ok=False,
                latency_ms=latency_ms,
                error=error,
                detail_json=json.dumps(detail, ensure_ascii=False, default=str),
                timestamp=as_of,
            )

            return ProviderCallResult(
                name=name,
                category=category,
                ok=False,
                data=None,
                requested_trading_date=requested_trading_date,
                source_trading_date=None,
                freshness_status="unknown",
                as_of=as_of,
                latency_ms=latency_ms,
                from_cache=False,
                error=error,
                detail=detail,
            )
