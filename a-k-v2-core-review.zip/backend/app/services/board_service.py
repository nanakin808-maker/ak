from __future__ import annotations

import os
from datetime import datetime

from app.adapters.legacy.boards import normalize_boards
from app.adapters.legacy.http_client import LegacyHttpError, fetch_legacy_json
from app.mocks.boards import mock_boards
from app.schemas.board import BoardsResponse


def now_text() -> str:
    return datetime.now().isoformat(timespec="seconds")


def legacy_boards_url() -> str:
    return os.getenv("LEGACY_BOARDS_URL", "").strip()


def fetch_legacy_payload() -> dict:
    url = legacy_boards_url()

    if not url:
        raise RuntimeError("LEGACY_BOARDS_URL 未配置")

    return fetch_legacy_json(url)


def get_boards() -> BoardsResponse:
    try:
        payload = fetch_legacy_payload()
        rows = normalize_boards(payload)

        if not rows:
            raise RuntimeError("旧板块动向接口没有返回有效数据")

        return BoardsResponse(
            source="legacy",
            updatedAt=now_text(),
            rows=rows,
        )
    except (RuntimeError, LegacyHttpError) as exc:
        return BoardsResponse(
            source="mock",
            updatedAt=now_text(),
            rows=mock_boards(),
            error=str(exc),
        )
