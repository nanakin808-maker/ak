from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Protocol

from sqlalchemy.orm import Session

from app.domain.time_scope import MarketSession
from app.services.limit_pool_ingestion_service import (
    LimitPoolIngestionResult,
    LimitPoolIngestionService,
    LimitPoolInputRow,
    LimitPoolInputSnapshot,
)
from app.services.provider_bridge_service import ProviderBridgeService, ProviderCallResult, ProviderFetchResult


class LimitPoolFetcher(Protocol):
    def fetch(self, *, requested_trading_date: str) -> ProviderFetchResult:
        ...


@dataclass(slots=True)
class LimitPoolProviderRunResult:
    provider_ok: bool
    ingested: bool
    freshness_status: str
    snapshot_id: int | None
    row_count: int
    error: str = ""


class LimitPoolProviderIngestionService:
    def __init__(self, session: Session, fetcher: LimitPoolFetcher) -> None:
        self.session = session
        self.fetcher = fetcher
        self.bridge = ProviderBridgeService(session)
        self.ingestion = LimitPoolIngestionService(session)

    def fetch_and_ingest(
        self,
        *,
        requested_trading_date: str,
        as_of: datetime,
        seq: int,
        market_session: MarketSession = MarketSession.UNKNOWN,
        cache_key: str | None = None,
        ttl_seconds: float = 0,
        timeout_ms: float | None = None,
        provider_name: str = "limit_pool_provider",
        provider_category: str = "limit_pool",
        primary_source: str = "unknown",
    ) -> LimitPoolProviderRunResult:
        call = self.bridge.call(
            name=provider_name,
            category=provider_category,
            requested_trading_date=requested_trading_date,
            fetcher=lambda: self.fetcher.fetch(requested_trading_date=requested_trading_date),
            cache_key=cache_key,
            ttl_seconds=ttl_seconds,
            timeout_ms=timeout_ms,
            market_session=market_session,
        )

        if not call.ok:
            return LimitPoolProviderRunResult(
                provider_ok=False,
                ingested=False,
                freshness_status=call.freshness_status,
                snapshot_id=None,
                row_count=0,
                error=call.error,
            )

        snapshot = self._to_input_snapshot(
            requested_trading_date=requested_trading_date,
            as_of=as_of,
            seq=seq,
            call=call,
            primary_source=primary_source,
            market_session=market_session,
        )
        result = self.ingestion.ingest_snapshot(snapshot)
        return LimitPoolProviderRunResult(
            provider_ok=True,
            ingested=True,
            freshness_status=result.freshness_status,
            snapshot_id=result.snapshot_id,
            row_count=result.row_count,
            error="",
        )

    def _to_input_snapshot(
        self,
        *,
        requested_trading_date: str,
        as_of: datetime,
        seq: int,
        call: ProviderCallResult,
        primary_source: str,
        market_session: MarketSession,
    ) -> LimitPoolInputSnapshot:
        data = call.data
        if isinstance(data, dict):
            rows_data = data.get("rows", [])
            source_counts = data.get("source_counts", {})
            raw = data.get("raw", data)
        else:
            rows_data = data if isinstance(data, list) else []
            source_counts = {}
            raw = data

        rows = [self._to_input_row(row, default_source=primary_source) for row in rows_data]

        return LimitPoolInputSnapshot(
            trading_date=requested_trading_date,
            source_trading_date=call.source_trading_date,
            source=call.name,
            primary_source=primary_source,
            as_of=as_of,
            seq=seq,
            freshness_status=call.freshness_status,
            rows=rows,
            source_counts_json=json.dumps(source_counts, ensure_ascii=False, default=str),
            fallback_errors_json="[]",
            market_session=market_session.value if hasattr(market_session, "value") else str(market_session),
            raw_json=json.dumps(raw, ensure_ascii=False, default=str),
        )

    def _to_input_row(self, row: Any, *, default_source: str) -> LimitPoolInputRow:
        if isinstance(row, LimitPoolInputRow):
            return row
        d: dict = row if isinstance(row, dict) else {}
        return LimitPoolInputRow(
            pool=str(d.get("pool") or d.get("type") or ""),
            code=str(d.get("code") or d.get("symbol") or ""),
            name=str(d.get("name") or ""),
            source=str(d.get("source") or default_source),
            price=d.get("price"),
            change_pct=d.get("change_pct"),
            first_limit_time=d.get("first_limit_time"),
            last_limit_time=d.get("last_limit_time"),
            open_count=d.get("open_count"),
            seal_amount=d.get("seal_amount"),
            streak=d.get("streak"),
            industry=d.get("industry"),
            reason=d.get("reason"),
            raw_json=json.dumps(d, ensure_ascii=False, default=str),
        )
