"""Settings service."""


class SettingsService:
    def get_all(self) -> dict:
        return {
            "ths_ok": False,
            "feishu_ok": False,
            "notification_kline_min_score": 50.0,
            "notification_seal_board_min_score": 50.0,
            "speed_rank_available": False,
        }


settings_service = SettingsService()
