from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from app.db.models import LimitPoolRow
from app.domain.seal_state import evaluate_seal_state_from_quote
from app.runtime.candidate_base import CandidateQuoteInput


@dataclass(slots=True)
class SealSourceFact:
    trading_date: str
    source_trading_date: str | None
    code: str
    name: str
    source_type: str
    source_id: int | None
    at_limit: bool
    is_sealed: bool
    opened: bool
    open_count: int | None
    limit_price: float | None
    seal_volume: float | None
    confidence: str
    reason: str
    as_of: datetime
    seq: int
    freshness_status: str


class SealSourceAdapterService:
    @staticmethod
    def from_orderbook(code: str, name: str, trading_date: str, source_trading_date: str,
                       as_of: datetime, seq: int, freshness_status: str,
                       timeout: float = 3.0) -> SealSourceFact:
        """Fetch real-time orderbook from Tencent/Sina and evaluate seal state."""
        from app.sources.composite_orderbook import fetch_one_orderbook

        snap = fetch_one_orderbook(code, timeout=timeout)
        if snap is None:
            return SealSourceFact(
                trading_date=trading_date, source_trading_date=source_trading_date,
                code=code, name=name, source_type="orderbook", source_id=None,
                at_limit=False, is_sealed=False, opened=False, open_count=None,
                limit_price=None, seal_volume=None,
                confidence="insufficient", reason="orderbook_unavailable",
                as_of=as_of, seq=seq, freshness_status=freshness_status,
            )

        return SealSourceFact(
            trading_date=trading_date, source_trading_date=source_trading_date,
            code=code, name=name, source_type=f"orderbook_{snap.source}", source_id=None,
            at_limit=snap.limit_up is not None and snap.price is not None and abs(snap.price - snap.limit_up) < 0.01,
            is_sealed=snap.is_sealed,
            opened=False,
            open_count=None,
            limit_price=snap.limit_up,
            seal_volume=float(snap.bid_vol1) if snap.bid_vol1 > 0 else None,
            confidence=snap.seal_confidence,
            reason=snap.seal_reason,
            as_of=as_of, seq=seq, freshness_status=freshness_status,
        )

    @staticmethod
    def from_quote_input(quote: CandidateQuoteInput) -> SealSourceFact:
        seal = evaluate_seal_state_from_quote(
            code=quote.code, name=quote.name,
            price=quote.price, pre_close=quote.pre_close,
            bid1=quote.bid1, bid_vol1=quote.bid_vol1,
            ask1=quote.ask1, ask_vol1=quote.ask_vol1,
            explicit_is_sealed=quote.is_sealed if quote.seal_confidence == "explicit" else None,
            explicit_at_limit=quote.at_limit if quote.seal_confidence == "explicit" else None,
            source=quote.seal_source or "quote",
        )
        return SealSourceFact(
            trading_date=quote.trading_date,
            source_trading_date=quote.source_trading_date,
            code=quote.code,
            name=quote.name,
            source_type="quote_input",
            source_id=None,
            at_limit=seal.at_limit,
            is_sealed=seal.is_sealed,
            opened=seal.opened,
            open_count=quote.open_count,
            limit_price=seal.limit_price,
            seal_volume=seal.seal_volume,
            confidence=seal.confidence,
            reason=seal.reason,
            as_of=quote.as_of,
            seq=quote.seq,
            freshness_status=quote.freshness_status if isinstance(quote.freshness_status, str) else quote.freshness_status.value,
        )

    @staticmethod
    def from_limit_pool_row(row: LimitPoolRow) -> SealSourceFact:
        pool = str(row.pool or "")
        open_count = row.open_count

        if pool == "limit_up":
            return SealSourceFact(
                trading_date=row.trading_date, source_trading_date=row.source_trading_date,
                code=row.code, name=row.name,
                source_type="limit_pool_row", source_id=row.id,
                at_limit=True, is_sealed=True, opened=False,
                open_count=open_count,
                limit_price=None, seal_volume=row.seal_amount,
                confidence="source_fact", reason="limit_pool_limit_up",
                as_of=row.as_of, seq=row.seq,
                freshness_status=row.freshness_status,
            )

        if pool == "open_board":
            return SealSourceFact(
                trading_date=row.trading_date, source_trading_date=row.source_trading_date,
                code=row.code, name=row.name,
                source_type="limit_pool_row", source_id=row.id,
                at_limit=False, is_sealed=False, opened=True,
                open_count=open_count,
                limit_price=None, seal_volume=None,
                confidence="source_fact", reason="limit_pool_open_board",
                as_of=row.as_of, seq=row.seq,
                freshness_status=row.freshness_status,
            )

        return SealSourceFact(
            trading_date=row.trading_date, source_trading_date=row.source_trading_date,
            code=row.code, name=row.name,
            source_type="limit_pool_row", source_id=row.id,
            at_limit=False, is_sealed=False, opened=False,
            open_count=open_count,
            limit_price=None, seal_volume=None,
            confidence="unknown", reason=f"unexpected_pool:{pool}",
            as_of=row.as_of, seq=row.seq,
            freshness_status=row.freshness_status,
        )
