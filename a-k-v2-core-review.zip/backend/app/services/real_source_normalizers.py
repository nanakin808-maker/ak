from __future__ import annotations

from typing import Any


def _pick(d: dict[str, Any], *keys: str) -> Any:
    for k in keys:
        v = d.get(k)
        if v is not None:
            return v
    return None


def _float(v: Any) -> float | None:
    if v is None or v == "-":
        return None
    try:
        return float(v)
    except (ValueError, TypeError):
        return None


def _int(v: Any) -> int | None:
    if v is None or v == "-":
        return None
    try:
        return int(v)
    except (ValueError, TypeError):
        return None


def _str(v: Any) -> str:
    if v is None:
        return ""
    return str(v).strip()


def normalize_limit_pool_rows(raw_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for r in raw_rows:
        if not isinstance(r, dict):
            continue
        code = _str(_pick(r, "code", "f12", "symbol"))
        name = _str(_pick(r, "name", "f14"))
        if not code or not name:
            continue
        pool = _str(_pick(r, "pool", "type"))
        if pool not in ("limit_up", "open_board"):
            pool = "limit_up"
        result.append({
            "pool": pool,
            "code": code,
            "name": name,
            "source": _str(r.get("source")),
            "price": _float(_pick(r, "price", "f2")),
            "change_pct": _float(_pick(r, "change_pct", "f3")),
            "first_limit_time": _str(_pick(r, "first_limit_time", "ftime", "first_time")),
            "last_limit_time": _str(_pick(r, "last_limit_time", "ltime", "last_time")),
            "open_count": _int(_pick(r, "open_count", "openCnt", "jkCnt")),
            "seal_amount": _float(_pick(r, "seal_amount", "sealAmt")),
            "streak": _int(_pick(r, "streak")),
            "industry": _str(_pick(r, "industry")),
            "reason": _str(_pick(r, "reason")),
        })
    return result


def normalize_speed_rank_rows(raw_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for r in raw_rows:
        if not isinstance(r, dict):
            continue
        code = _str(_pick(r, "code", "f12", "symbol"))
        name = _str(_pick(r, "name", "f14"))
        if not code or not name:
            continue
        change_pct = _float(_pick(r, "change_pct", "f3", "zdpct"))
        price = _float(_pick(r, "price", "f2"))
        result.append({
            "code": code,
            "name": name,
            "price": price,
            "change_pct": change_pct,
            "event_type": "SPEED_RANK",
            "event_source": "eastmoney_rank",
            "event_title": name,
            "event_time": _str(_pick(r, "time", "last_limit_time")),
        })
    return result


def normalize_quote_rows(raw_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for r in raw_rows:
        if not isinstance(r, dict):
            continue
        code = _str(_pick(r, "code", "f12", "symbol"))
        name = _str(_pick(r, "name", "f14"))
        if not code or not name:
            continue
        change_pct = _float(_pick(r, "change_pct", "f3"))
        price = _float(_pick(r, "price", "f2"))
        amount = _float(_pick(r, "amount", "f4", "turnover"))
        volume = _float(_pick(r, "volume", "f5", "vol"))
        bid_vol1 = _float(_pick(r, "bid_vol1", "f10", "bidv"))
        ask_vol1 = _float(_pick(r, "ask_vol1", "f20", "askv"))
        bid1 = _float(_pick(r, "bid1", "f19"))
        has_bid_data = bid1 is not None and bid_vol1 is not None and bid_vol1 > 0
        result.append({
            "code": code,
            "name": name,
            "price": price,
            "change_pct": change_pct,
            "is_sealed": False,
            "at_limit": False,
            "open_count": 0,
            "bid_vol1": bid_vol1,
            "ask_vol1": ask_vol1,
            "bid1": bid1,
            "amount": amount,
            "volume": volume,
            "seal_confidence": "explicit" if has_bid_data else "insufficient",
            "seal_reason": None if has_bid_data else "missing_bid1_or_bid_vol1",
        })
    return result
