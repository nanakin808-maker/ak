from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from sqlalchemy.orm import Session

from app.repositories import LimitPoolRepository


@dataclass(slots=True)
class LimitPoolInputRow:
    pool: str
    code: str
    name: str
    source: str
    price: float | None = None
    change_pct: float | None = None
    first_limit_time: str | None = None
    last_limit_time: str | None = None
    open_count: int | None = None
    seal_amount: float | None = None
    streak: int | None = None
    industry: str | None = None
    reason: str | None = None
    raw_json: str = "{}"


@dataclass(slots=True)
class LimitPoolInputSnapshot:
    trading_date: str
    source_trading_date: str | None
    source: str
    primary_source: str
    as_of: datetime
    seq: int
    freshness_status: str
    rows: list[LimitPoolInputRow] = field(default_factory=list)
    source_counts_json: str = "{}"
    fallback_errors_json: str = "[]"
    market_session: str | None = None
    raw_json: str = "{}"


@dataclass(slots=True)
class LimitPoolIngestionResult:
    snapshot_id: int
    row_count: int
    trading_date: str
    source_trading_date: str | None
    freshness_status: str


class LimitPoolIngestionService:
    def __init__(self, session: Session) -> None:
        self.session = session
        self.limit_pool = LimitPoolRepository(session)

    def ingest_snapshot(self, snapshot: LimitPoolInputSnapshot) -> LimitPoolIngestionResult:
        db_snapshot = self.limit_pool.add_snapshot(
            trading_date=snapshot.trading_date,
            source_trading_date=snapshot.source_trading_date,
            source=snapshot.source,
            primary_source=snapshot.primary_source,
            source_counts_json=snapshot.source_counts_json,
            fallback_errors_json=snapshot.fallback_errors_json,
            market_session=snapshot.market_session,
            raw_json=snapshot.raw_json,
            as_of=snapshot.as_of,
            seq=snapshot.seq,
            freshness_status=snapshot.freshness_status,
        )
        self.session.flush()

        for row in snapshot.rows:
            self.limit_pool.add_row(
                snapshot_id=db_snapshot.id,
                trading_date=snapshot.trading_date,
                source_trading_date=snapshot.source_trading_date,
                pool=row.pool,
                code=row.code,
                name=row.name,
                source=row.source,
                price=row.price,
                change_pct=row.change_pct,
                first_limit_time=row.first_limit_time,
                last_limit_time=row.last_limit_time,
                open_count=row.open_count,
                seal_amount=row.seal_amount,
                streak=row.streak,
                industry=row.industry,
                reason=row.reason,
                raw_json=row.raw_json,
                as_of=snapshot.as_of,
                seq=snapshot.seq,
                freshness_status=snapshot.freshness_status,
            )

        self.session.flush()
        return LimitPoolIngestionResult(
            snapshot_id=db_snapshot.id,
            row_count=len(snapshot.rows),
            trading_date=snapshot.trading_date,
            source_trading_date=snapshot.source_trading_date,
            freshness_status=snapshot.freshness_status,
        )
