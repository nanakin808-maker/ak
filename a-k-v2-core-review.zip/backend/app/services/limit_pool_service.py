from __future__ import annotations

import os
from datetime import datetime

from app.adapters.legacy.http_client import LegacyHttpError, fetch_legacy_json
from app.adapters.legacy.limit_pool import normalize_limit_pool
from app.mocks.limit_pool import mock_limit_pool
from app.schemas.limit_pool import LimitPoolItem, LimitPoolResponse


def now_text() -> str:
    return datetime.now().isoformat(timespec="seconds")


def legacy_limit_pool_url() -> str:
    return os.getenv("LEGACY_LIMIT_POOL_URL", "").strip()


def fetch_legacy_payload() -> dict:
    url = legacy_limit_pool_url()

    if not url:
        raise RuntimeError("LEGACY_LIMIT_POOL_URL 未配置")

    return fetch_legacy_json(url)


def get_limit_pool() -> LimitPoolResponse:
    try:
        payload = fetch_legacy_payload()
        rows = normalize_limit_pool(payload)

        if not rows:
            raise RuntimeError("旧涨停炸板池接口没有返回有效数据")

        return LimitPoolResponse(
            source="legacy",
            updatedAt=now_text(),
            rows=rows,
        )
    except (RuntimeError, LegacyHttpError) as exc:
        return LimitPoolResponse(
            source="mock",
            updatedAt=now_text(),
            rows=mock_limit_pool(),
            error=str(exc),
        )
