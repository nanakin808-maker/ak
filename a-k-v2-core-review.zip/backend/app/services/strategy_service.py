"""Strategy service."""


class StrategyService:
    def list_definitions(self) -> list:
        return []

    def list_saved(self, enabled_only: bool = False) -> list:
        return []


strategy_service = StrategyService()
