"""Async scoring queue — prevents scan loop from blocking on slow scoring.
Pattern: v1 LimitPoolScoringQueue — separate async worker processes tasks from DB."""

from __future__ import annotations

import asyncio
import traceback
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db.models import ScoreTaskCurrent
from app.repositories import ScoreSnapshotRepository
from app.services.legacy_full_scoring_executor import LegacyFullScoringExecutor
from app.services.score_worker_service import ScoreExecutionResult


class ScoringQueue:
    """Background scoring worker. Scan pushes trigger; worker processes DB tasks."""

    def __init__(self, db_path: str, max_workers: int = 2) -> None:
        self._db_path = db_path
        self._max_workers = max_workers
        self._trigger = asyncio.Event()
        self._workers: list[asyncio.Task] = []
        self._running = False

    async def start(self) -> None:
        if self._running:
            return
        self._running = True
        db_path_obj = Path(self._db_path)
        db_path_obj.parent.mkdir(parents=True, exist_ok=True)
        eng = create_engine(f"sqlite:///{db_path_obj.resolve()}", future=True)
        self._engine = eng
        self._Session = sessionmaker(bind=eng, autoflush=False, autocommit=False, future=True)
        for _ in range(self._max_workers):
            self._workers.append(asyncio.create_task(self._worker()))

    async def stop(self) -> None:
        self._running = False
        self._trigger.set()  # wake workers to exit
        for w in self._workers:
            w.cancel()
        await asyncio.gather(*self._workers, return_exceptions=True)
        self._workers.clear()

    def notify(self) -> None:
        """Non-blocking trigger: scan calls this after pushing score tasks to DB."""
        self._trigger.set()

    async def _worker(self) -> None:
        """Process pending score tasks from DB in a loop."""
        executor = LegacyFullScoringExecutor()
        while self._running:
            try:
                with self._Session() as session:
                    tasks = list(session.execute(
                        __import__('sqlalchemy').select(ScoreTaskCurrent)
                        .where(ScoreTaskCurrent.status == "pending")
                        .order_by(ScoreTaskCurrent.priority.desc(), ScoreTaskCurrent.id.asc())
                        .limit(20)
                    ).scalars())
                    if not tasks:
                        self._trigger.clear()
                        try:
                            await asyncio.wait_for(self._trigger.wait(), timeout=5.0)
                        except asyncio.TimeoutError:
                            pass
                        continue

                    snapshots = ScoreSnapshotRepository(session)
                    for task in tasks:
                        try:
                            task.status = "running"
                            session.flush()
                            result: ScoreExecutionResult = executor.execute(task)
                            snapshots.add_snapshot(
                                trading_date=task.trading_date,
                                source_trading_date=task.trading_date,
                                code=task.code, name=task.name,
                                score_type="COMPOSITE", score_stage=task.score_stage,
                                status=result.status, passed=result.passed,
                                reject_reason=result.reject_reason,
                                technical_score=result.technical_score,
                                sentiment_score=result.sentiment_score,
                                volume_score=result.volume_score,
                                score=result.score, main_logic=result.main_logic,
                                board_rank=result.board_rank,
                                score_json=result.score_json or "{}",
                                input_refs_json=result.input_refs_json,
                                source_type=task.source_type or "scoring_queue",
                                source_event_id=task.source_event_id,
                                source_snapshot_id=task.source_snapshot_id,
                                source_row_id=task.source_row_id,
                                as_of=task.as_of, seq=task.seq,
                                freshness_status=task.freshness_status or "fresh",
                            )
                            task.status = "ready"
                            session.flush()
                        except Exception:
                            traceback.print_exc()
                            task.status = "failed"
                            session.flush()
                    session.commit()
            except asyncio.CancelledError:
                break
            except Exception:
                traceback.print_exc()
                await asyncio.sleep(1)

        self._engine.dispose()
