"""Minimal copy of old DailyHistoryProvider technical scoring. No provider code."""

from datetime import timedelta
from typing import Any

import pandas as pd

from app.scoring.legacy_technical_funcs import (
    _bars_to_dataframe, _events_to_limit_touches, _finite_float,
    _flat_breakout_score, _flat_structure_score, _latest_comparable_limit,
    _next_day_premium, _pressure_score, _technical_common_risk,
    _technical_level, _technical_memory_score, _technical_volume_confirm_score,
    _trend_breakout_score, _trend_position_score, _trend_risk_control_score,
    _trend_strength_score,
)

def compute_technical_score(
    *, code: str, current_price: float | None,
    daily_bars: list[dict[str, Any]] | None,
    limit_events: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    if not daily_bars or len(daily_bars) < 20:
        return {
            "status": "partial_missing_daily_bars",
            "score": None,
            "technical_score": None,
            "message": f"daily_bars insufficient: got {len(daily_bars or [])}, need >= 20",
            "code": code,
        }

    frame = _bars_to_dataframe(daily_bars)
    price = current_price if current_price and current_price > 0 else float(frame.iloc[-1]["收盘"])

    events = _events_to_limit_touches(limit_events or [])

    try:
        result = _kline_score(frame, events, price)
        return result
    except Exception as exc:
        return {
            "status": "failed",
            "score": None,
            "technical_score": None,
            "message": f"technical scoring error: {exc}",
            "code": code,
        }

def _kline_score(frame: pd.DataFrame, events: list, current_price: float) -> dict[str, Any]:
    factors: list[dict[str, Any]] = []
    if frame.empty or current_price <= 0:
        return {"status": "unknown", "score": None, "score_delta": 0, "message": "no data", "factors": factors}

    recent = frame.copy()
    end_date = recent["日期"].max()
    start_date = end_date - pd.Timedelta(days=365)
    recent = recent[recent["日期"] >= start_date].copy()
    if recent.empty:
        return {"status": "unknown", "score": None, "score_delta": 0, "message": "近一年K线为空", "factors": factors}

    max_row = recent.loc[recent["最高"].idxmax()]
    max_high = float(max_row["最高"])
    peak_ratio = max_high / current_price
    drawdown_pct = (current_price / max_high - 1.0) * 100.0 if max_high > 0 else 0.0
    peak_penalty = 0
    if peak_ratio >= 2.5:
        peak_penalty = -35
    elif peak_ratio >= 2.0:
        peak_penalty = -26
    elif peak_ratio >= 1.6:
        peak_penalty = -18
    elif peak_ratio >= 1.3:
        peak_penalty = -10
    elif peak_ratio >= 1.15:
        peak_penalty = -4
    if peak_penalty:
        factors.append({"name": "历史高点压力", "score_delta": peak_penalty, "message": f"近一年最高价 {max_high:.2f} 是当前价 {current_price:.2f} 的 {peak_ratio:.2f} 倍", "data": {"max_high": round(max_high, 3), "max_high_date": str(max_row["日期"].date()), "current_price": round(current_price, 3), "ratio": round(peak_ratio, 3)}})
    drawdown_penalty = 0
    if drawdown_pct <= -50: drawdown_penalty = -25
    elif drawdown_pct <= -35: drawdown_penalty = -18
    elif drawdown_pct <= -25: drawdown_penalty = -12
    elif drawdown_pct <= -15: drawdown_penalty = -6
    if drawdown_penalty:
        factors.append({"name": "高点后回撤", "score_delta": drawdown_penalty, "message": f"当前价较近一年高点回撤 {abs(drawdown_pct):.1f}%", "data": {"drawdown_pct": round(drawdown_pct, 3)}})

    close = recent["收盘"].astype(float)
    if len(recent) >= 40:
        peak_pos = int(recent["最高"].astype(float).to_numpy().argmax())
        days_since_peak = len(recent) - peak_pos - 1
        if days_since_peak >= 20:
            sd = drawdown_pct
            if sd <= -20:
                factors.append({"name": "阶段高点后走弱", "score_delta": -12, "message": f"近一年高点后已经 {days_since_peak} 个交易日，当前回落 {abs(sd):.1f}%", "data": {"days_since_peak": days_since_peak, "drawdown_pct": round(sd, 3)}})
            elif sd <= -12:
                factors.append({"name": "阶段高点后走弱", "score_delta": -6, "message": f"近一年高点后已经 {days_since_peak} 个交易日，当前回落 {abs(sd):.1f}%", "data": {"days_since_peak": days_since_peak, "drawdown_pct": round(sd, 3)}})
    ma20 = close.rolling(20).mean()
    ma60 = close.rolling(60).mean()
    last_close = float(close.iloc[-1])
    below20 = len(ma20.dropna()) > 0 and last_close < float(ma20.iloc[-1])
    below60 = len(ma60.dropna()) > 0 and last_close < float(ma60.iloc[-1])
    if below20 and below60:
        factors.append({
            "name": "均线弱势", "score_delta": -10,
            "message": "最近收盘价同时低于20日和60日均线",
            "data": {"close": round(last_close, 3), "ma20": round(float(ma20.iloc[-1]), 3), "ma60": round(float(ma60.iloc[-1]), 3)},
        })
    elif below20:
        factors.append({
            "name": "短线转弱", "score_delta": -4,
            "message": "最近收盘价低于20日均线",
            "data": {"close": round(last_close, 3), "ma20": round(float(ma20.iloc[-1]), 3)},
        })
    if len(ma20.dropna()) >= 6:
        ma20_now = float(ma20.iloc[-1])
        ma20_prev = float(ma20.iloc[-6])
        ma20_slope_pct = (ma20_now / ma20_prev - 1.0) * 100.0 if ma20_prev > 0 else 0.0
        if ma20_slope_pct <= -3.0:
            factors.append({
                "name": "20日趋势下行", "score_delta": -5,
                "message": f"20日均线近5个交易日下行 {abs(ma20_slope_pct):.1f}%",
                "data": {"ma20_slope_pct": round(ma20_slope_pct, 3)},
            })

    recent_events = [e for e in events if hasattr(e, "date") and pd.to_datetime(e.date) >= end_date - pd.Timedelta(days=60)]
    failed_touches = [e for e in recent_events if e.touched_limit and not e.closed_limit]
    if failed_touches:
        penalty = -min(15, len(failed_touches) * 5)
        factors.append({
            "name": "近期触板未封", "score_delta": penalty,
            "message": f"近60日有 {len(failed_touches)} 次触及涨停但未收涨停",
            "data": {"failed_touch_count": len(failed_touches), "dates": [e.date for e in failed_touches[-5:]]},
        })

    comparable = _latest_comparable_limit(frame, [e for e in events if hasattr(e, "closed_limit") and e.closed_limit])
    premium = _next_day_premium(frame, comparable) if comparable else None
    if premium is not None:
        premium_pct = float(premium["premium_pct"])
        if premium_pct >= 1.0:
            delta = 8
        elif premium_pct >= 0.1:
            delta = 4
        elif premium_pct < 0:
            delta = -8
        else:
            delta = 0
        if delta:
            factors.append({
                "name": "涨停次日承接", "score_delta": delta,
                "message": f"{premium['limit_event_date']} 涨停后次日收盘溢价 {premium_pct:.2f}%",
                "data": premium,
            })

    score_delta = sum(int(item["score_delta"]) for item in factors)
    base_score = 90
    legacy_score = max(0, min(100, base_score + score_delta))
    technical_score = _technical_score_v1(recent, frame, events, current_price, premium)
    score = technical_score["total"]
    return {
        "status": "ready",
        "score": score,
        "legacy_score": legacy_score,
        "technical_score": technical_score,
        "score_delta": score_delta,
        "base_score": base_score,
        "current_price": round(current_price, 3),
        "last_trade_date": str(end_date.date()),
        "message": f"技术评分 {score} 分，{technical_score['style_label']}，旧技术分 {legacy_score}",
        "factors": factors,
    }

def _technical_score_v1(
    recent: pd.DataFrame,
    frame: pd.DataFrame,
    events: list,
    current_price: float,
    premium: dict | None,
) -> dict[str, Any]:
    end_date = recent["日期"].max()
    recent_for_shape = recent
    close_all = recent["收盘"].astype(float)
    last_close = float(close_all.iloc[-1])
    previous_close = float(close_all.iloc[-2]) if len(close_all) >= 2 else last_close
    latest_bar_change_pct = (last_close / previous_close - 1.0) * 100.0 if previous_close > 0 else 0.0
    if len(recent) >= 61 and abs(last_close / current_price - 1.0) <= 0.003 and latest_bar_change_pct >= 5.0:
        recent_for_shape = recent.iloc[:-1].copy()
    close = recent_for_shape["收盘"].astype(float)
    current_change_pct = (current_price / float(close.iloc[-1]) - 1.0) * 100.0 if len(close) and float(close.iloc[-1]) > 0 else 0.0

    def tail(days: int) -> pd.DataFrame:
        return recent_for_shape.tail(min(days, len(recent_for_shape))).copy()

    def amplitude(window: pd.DataFrame) -> float:
        if window.empty:
            return 999.0
        lo = float(window["最低"].astype(float).min())
        hi = float(window["最高"].astype(float).max())
        return (hi / lo - 1.0) * 100.0 if lo > 0 else 999.0

    def pct_return(window: pd.DataFrame) -> float:
        if len(window) < 2:
            return 0.0
        first = float(window.iloc[0]["收盘"])
        last = float(window.iloc[-1]["收盘"])
        return (last / first - 1.0) * 100.0 if first > 0 else 0.0

    w20 = tail(20)
    w40 = tail(40)
    w60 = tail(60)
    amp20 = amplitude(w20)
    amp40 = amplitude(w40)
    amp60 = amplitude(w60)
    ret20 = pct_return(w20)
    ret60 = pct_return(w60)
    high20 = float(w20["最高"].astype(float).max()) if not w20.empty else current_price
    high60 = float(w60["最高"].astype(float).max()) if not w60.empty else current_price
    close20 = w20["收盘"].astype(float)
    close_std20 = float(close20.std() / close20.mean() * 100.0) if len(close20) > 1 and close20.mean() > 0 else 999.0
    amount20 = pd.to_numeric(w20["成交额"], errors="coerce").dropna() if "成交额" in w20.columns else pd.Series(dtype=float)
    amount_mean20 = float(amount20.mean()) if len(amount20) else 0.0
    amount_std20 = float(amount20.std() / amount_mean20 * 100.0) if len(amount20) > 1 and amount_mean20 > 0 else 999.0
    today_amount = _finite_float(recent.iloc[-1].get("成交额"), 0.0)
    amount_ratio20 = today_amount / amount_mean20 if amount_mean20 > 0 else None

    max_row = recent_for_shape.loc[recent_for_shape["最高"].idxmax()]
    max_high = float(max_row["最高"])
    peak_ratio = max_high / current_price if current_price > 0 else 999.0
    ma20 = close.rolling(20).mean()
    ma60 = close.rolling(60).mean()
    ma20_now = float(ma20.iloc[-1]) if len(ma20.dropna()) else None
    ma60_now = float(ma60.iloc[-1]) if len(ma60.dropna()) else None
    ma20_prev = float(ma20.iloc[-6]) if len(ma20.dropna()) >= 6 else None
    ma20_slope_pct = (ma20_now / ma20_prev - 1.0) * 100.0 if ma20_now and ma20_prev and ma20_prev > 0 else None

    recent_ev = [e for e in events if hasattr(e, "date") and pd.to_datetime(e.date) >= end_date - pd.Timedelta(days=60)]
    failed_touch_60 = len([e for e in recent_ev if e.touched_limit and not e.closed_limit])
    premium_pct = None if premium is None else float(premium.get("premium_pct", 0))

    flat_components = {
        "structure": _flat_structure_score(amp60, amp40, amp20, close_std20, amount_std20),
        "pressure": _pressure_score(peak_ratio),
        "breakout": _flat_breakout_score(current_price, current_change_pct, high20, high60, ma60_now),
        "volume_confirm": _technical_volume_confirm_score(amount_ratio20, today_amount),
        "memory": _technical_memory_score(failed_touch_60, premium_pct, strict_failed_zero=True),
    }
    trend_components = {
        "trend_strength": _trend_strength_score(ma20_now, ma60_now, ma20_slope_pct, ret60, ret20),
        "position": _trend_position_score(current_price, high60, ma20_now, peak_ratio),
        "breakout": _trend_breakout_score(current_price, current_change_pct, high20, high60),
        "memory": _technical_memory_score(failed_touch_60, premium_pct, strict_failed_zero=False),
        "risk_control": _trend_risk_control_score(peak_ratio, ret60, amount_ratio20),
    }
    flat_score = sum(flat_components.values())
    trend_score = sum(trend_components.values())
    risk_penalty, risk_flags, veto = _technical_common_risk(
        peak_ratio=peak_ratio, failed_touch_60=failed_touch_60, current_price=current_price,
        ma20=ma20_now, ma60=ma60_now, ret60=ret60, today_amount=today_amount,
    )
    raw_score = max(flat_score, trend_score)
    total = 0 if veto else max(0, min(100, raw_score + risk_penalty))
    if flat_score >= 70 and trend_score >= 70:
        style = "mixed"
    elif raw_score < 55:
        style = "weak"
    elif flat_score >= trend_score:
        style = "flat_breakout"
    else:
        style = "trend_acceleration"
    label_map = {"flat_breakout": "平铺爆发", "trend_acceleration": "趋势加速", "mixed": "平铺+趋势", "weak": "技术弱"}
    return {
        "status": "ready",
        "total": int(total),
        "style": style,
        "style_label": label_map[style],
        "level": _technical_level(total),
        "flat_breakout": int(flat_score),
        "trend_acceleration": int(trend_score),
        "risk_penalty": int(risk_penalty),
        "veto": bool(veto),
        "components": {"flat": flat_components, "trend": trend_components},
        "risk_flags": risk_flags,
        "metrics": {
            "amp20": round(amp20, 3), "amp40": round(amp40, 3), "amp60": round(amp60, 3),
            "ret20": round(ret20, 3), "ret60": round(ret60, 3),
            "close_std20": round(close_std20, 3), "amount_std20": round(amount_std20, 3),
            "amount_ratio20": None if amount_ratio20 is None else round(amount_ratio20, 3),
            "today_amount_yi": round(today_amount / 100_000_000, 3),
            "peak_ratio": round(peak_ratio, 3),
            "ma20_slope_pct": None if ma20_slope_pct is None else round(ma20_slope_pct, 3),
            "failed_touch_60": failed_touch_60, "premium_pct": None if premium_pct is None else round(premium_pct, 3),
        },
    }

