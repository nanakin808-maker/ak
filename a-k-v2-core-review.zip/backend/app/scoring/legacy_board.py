"""Minimal copy of old _board_score / _board_external_adjustments. Pure functions."""

from typing import Any

def compute_board_score(
    *,
    code: str,
    change_pct: float | None,
    board_summary: dict[str, Any] | None,
    board_members: dict[str, Any] | None,
    fund_flow: dict[str, Any] | None,
    intraday_quality: dict[str, Any] | None,
    strategy: dict[str, Any] | None,
    stock_meta: dict[str, Any] | None,
    open_board_count: int = 0,
    limit_streak: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Entry point for board/sentiment scoring.
    All inputs are explicit; partial inputs produce partial output.
    """
    if not board_summary or board_summary.get("status") != "ready":
        return {"status": "partial_missing_board_summary", "score": None}

    factors: list[dict[str, Any]] = []
    score = 40
    factors.append({"name": "板块基础分", "score_delta": 40, "message": "基础分 40"})
    boards = _board_member_targets(board_summary)
    changes = [_float_or_none(b.get("board_change_pct")) for b in boards]
    changes = [v for v in changes if v is not None]

    if boards:
        breadth_delta = 2 if len(boards) >= 3 else 0
        score += breadth_delta
        if breadth_delta:
            factors.append({"name": "关联板块数量", "score_delta": breadth_delta, "message": f"有效参考板块 {len(boards)} 个"})

    members_summary = board_members or {}
    board_scores: list = []
    if members_summary.get("status") == "ready":
        # fallback: use board_summary boards directly (same data, different format)
        current_code = str(code or "")
        current_change = _float_or_none(change_pct) or 0.0
        current_streak_data = limit_streak or {}

        for board in members_summary.get("boards") or []:
            board_delta = 0
            board_factors: list = []
            logic_confidence = 0
            logic_reasons: list = []
            board_name = str(board.get("board_name") or "")
            board_kind = str(board.get("board_kind") or "")
            specificity_delta = _board_specificity_delta(board_name, board_kind)
            logic_confidence += specificity_delta
            if specificity_delta:
                board_delta += int(round(specificity_delta * 0.35))
                board_factors.append({"name": "板块精准度", "score_delta": int(round(specificity_delta * 0.35)), "message": _board_specificity_message(board_name, board_kind, specificity_delta), "data": {"board_name": board_name, "board_kind": board_kind, "logic_delta": specificity_delta}})
                logic_reasons.append(_board_specificity_message(board_name, board_kind, specificity_delta))

            rank = board.get("rank")
            if isinstance(rank, int):
                if rank == 1: rank_delta, logic_confidence_delta = 28, 25
                elif rank == 2: rank_delta, logic_confidence_delta = 18, 18
                elif rank == 3: rank_delta, logic_confidence_delta = 8, 10
                elif rank <= 5: rank_delta, logic_confidence_delta = -4, -8
                elif rank <= 10: rank_delta, logic_confidence_delta = -14, -16
                elif rank <= 20: rank_delta, logic_confidence_delta = -24, -24
                else: rank_delta, logic_confidence_delta = -28, -28
            else:
                rank_delta, logic_confidence_delta = -28, -28
            logic_confidence += logic_confidence_delta
            board_delta += rank_delta
            if isinstance(rank, int):
                logic_reasons.append(f"涨幅排名第{rank}")
            board_factors.append({"name": "当前票板块地位", "score_delta": rank_delta, "message": f"{board.get('board_name') or '参考板块'}内涨幅排名第 {rank}" if isinstance(rank, int) else "未进前20", "data": {"rank": rank}})

            members = board.get("members") or []
            member_stats = _board_member_market_stats(members, current_code)
            main_board_rank = member_stats.get("current_main_board_rank")
            growth_star_ahead = int(member_stats.get("growth_star_ahead_count") or 0)
            if _is_main_board_stock(current_code):
                main_rank_delta = 0
                if isinstance(main_board_rank, int):
                    if main_board_rank == 1: main_rank_delta, lc_d = 10, 12
                    elif main_board_rank == 2: main_rank_delta, lc_d = 6, 8
                    elif main_board_rank == 3: main_rank_delta, lc_d = 2, 3
                    elif main_board_rank > 5: main_rank_delta, lc_d = -8, -8
                    else: main_rank_delta, lc_d = 0, 0
                else:
                    main_rank_delta, lc_d = -6, -6
                logic_confidence += lc_d
                if isinstance(rank, int) and rank > 3 and isinstance(main_board_rank, int) and main_board_rank <= 2:
                    main_rank_delta += 4; logic_confidence += 5; logic_reasons.append(f"全市场第{rank}但主板第{main_board_rank}")
                if growth_star_ahead >= 2 and (not isinstance(main_board_rank, int) or main_board_rank > 2):
                    main_rank_delta -= 6; logic_confidence -= 6
                if main_rank_delta:
                    board_delta += main_rank_delta
                    board_factors.append({"name": "主板可交易地位", "score_delta": main_rank_delta, "message": f"主板内第 {main_board_rank}" if isinstance(main_board_rank, int) else "-", "data": member_stats})

            order_rank = board.get("limit_order_rank")
            order_count = board.get("limit_order_count")
            if isinstance(order_rank, int):
                order_total = order_count if isinstance(order_count, int) else 0
                if order_total <= 1: order_delta, lc_d = -4, -8
                elif order_total == 2: order_delta, lc_d = (8, 18) if order_rank == 1 else (-4, -6)
                elif order_total == 3:
                    if order_rank == 1: order_delta, lc_d = 10, 22
                    elif order_rank == 2: order_delta, lc_d = 2, 12
                    else: order_delta, lc_d = -10, -14
                elif order_rank == 1: order_delta, lc_d = 14, 25
                elif order_rank == 2: order_delta, lc_d = 6, 15
                elif order_rank == 3: order_delta, lc_d = -6, 4
                elif order_rank <= 5: order_delta, lc_d = -16, -18
                else: order_delta, lc_d = -22, -26
                board_delta += order_delta; logic_confidence += lc_d
                logic_reasons.append(f"封板顺位第{order_rank}/{order_count or 0}")
                board_factors.append({"name": "板块内封板顺位", "score_delta": order_delta, "message": f"第 {order_rank} 个触板/封板，共 {order_count or 0} 个", "data": {"rank": order_rank, "count": order_count}})

            board_change = _float_or_none(board.get("board_change_pct"))
            if board_change is not None:
                if board_change >= 5: change_delta, lc_d = 5, 10
                elif board_change >= 3: change_delta, lc_d = 3, 6
                elif board_change >= 1.5: change_delta, lc_d = 1, 3
                elif board_change <= 0: change_delta, lc_d = -5, -8
                else: change_delta, lc_d = 0, -3
                if change_delta: board_delta += change_delta; logic_confidence += lc_d; board_factors.append({"name": "板块涨幅强度", "score_delta": change_delta, "message": f"{board_name}涨幅 {board_change:.2f}%", "data": {"board_change_pct": round(board_change, 3)}})

            member_changes = [_float_or_none(m.get("change_pct")) for m in members]
            member_changes = [v for v in member_changes if v is not None]
            avg_change = sum(member_changes) / len(member_changes) if member_changes else 0.0
            red_ratio = sum(1 for v in member_changes if v > 0) / len(member_changes) if member_changes else 0.0
            strong_count = sum(1 for v in member_changes if v >= 5.0)

            limit_count = sum(1 for m in members if (_float_or_none(m.get("change_pct")) or 0) >= (_limit_like_threshold_for_code(str(m.get("code", "")))))

            best_rank = rank if isinstance(rank, int) else None
            width_delta = 0
            if limit_count >= 6: width_delta = 4 if best_rank is not None and best_rank <= 2 else -12; lc_d = 20 if best_rank is not None and best_rank <= 2 else -14
            elif limit_count >= 3: width_delta = 6 if best_rank is not None and best_rank <= 2 else (2 if best_rank == 3 else -8); lc_d = 12 if best_rank is not None and best_rank <= 2 else (5 if best_rank == 3 else -10)
            elif limit_count == 2: width_delta = 2 if best_rank is not None and best_rank <= 2 else -4; lc_d = 4 if best_rank is not None and best_rank <= 2 else -5
            elif limit_count == 1: width_delta = -8; lc_d = -10
            else: width_delta = -6; lc_d = -12
            if width_delta: board_delta += width_delta; logic_confidence += lc_d; board_factors.append({"name": "板块涨停宽度", "score_delta": width_delta, "message": f"前20内 {limit_count} 只接近涨停", "data": {"limit_count_top20": limit_count}})

            logic_confidence = max(0, min(100, int(round(logic_confidence))))
            board_scores.append({
                "board_name": board.get("board_name"), "board_code": board.get("board_code"), "board_kind": board_kind,
                "score_delta": board_delta, "factors": board_factors, "rank": best_rank,
                "limit_order_rank": order_rank if isinstance(order_rank, int) else None,
                "board_change_pct": board_change,
                "logic_confidence": logic_confidence, "logic_reasons": logic_reasons[:5],
            })

    if not board_scores and boards:
        # Fallback: use board_summary when members data is unavailable
        for b in boards[:3]:
            board_scores.append({
                "board_name": b.get("board_name"), "board_code": b.get("board_code"),
                "board_kind": b.get("board_kind"), "score_delta": 10,
                "board_change_pct": _float_or_none(b.get("board_change_pct")), "logic_confidence": 10,
                "factors": [{"name": "板块联动(降级)", "score_delta": 10, "message": "板块" + str(b.get("board_name", "")) + "联动"}],
            })

    if board_scores:
        board_scores.sort(key=lambda x: x.get("score_delta", 0), reverse=True)
        best = board_scores[0]
        score += int(best["score_delta"])
        factors.extend(best.get("factors", []))

    external = _board_external_adjustments(stock_meta, fund_flow, intraday_quality, strategy, open_board_count)
    if external["score_delta"]:
        score += int(external["score_delta"])
        factors.extend(external["factors"])

    score = max(0, min(100, score))
    return {
        "status": "ready",
        "score": score,
        "factors": factors,
        "board_count": len(boards),
        "member_status": members_summary.get("status") or "idle",
        "external": external,
        "board_scores": board_scores[:3],
    }

# ── external adjustments ────────────────────────────────────

def _board_external_adjustments(stock_meta, fund_flow, intraday_quality, strategy, open_board_count: int) -> dict[str, Any]:
    factors: list = []
    score_delta = 0
    component = {"fund_flow": None, "seal_strength": None, "intraday": None, "kline_risk": None}

    if isinstance(fund_flow, dict) and fund_flow.get("status") == "ready":
        summary = fund_flow.get("summary") or {}
        latest = fund_flow.get("latest") or {}
        latest_pct = _float_or_none(latest.get("main_net_inflow_pct"))
        main_3d = _float_or_none(summary.get("main_net_inflow_3d_yi"))
        positive_days = int(summary.get("positive_main_days_5d") or 0)
        fund_delta = 0
        if latest_pct is not None:
            if latest_pct >= 15: fund_delta += 6
            elif latest_pct >= 8: fund_delta += 4
            elif latest_pct <= -10: fund_delta -= 8
            elif latest_pct <= -5: fund_delta -= 4
        if main_3d is not None:
            if main_3d >= 1.0: fund_delta += 4
            elif main_3d > 0: fund_delta += 2
            elif main_3d <= -1.0: fund_delta -= 5
        if positive_days >= 4: fund_delta += 2
        elif positive_days <= 1 and latest_pct is not None and latest_pct < 0: fund_delta -= 3
        fund_delta = max(-10, min(10, fund_delta))
        component["fund_flow"] = fund_delta
        if fund_delta:
            score_delta += fund_delta
            factors.append({"name": "个股资金确认", "score_delta": fund_delta, "message": f"主力净占比 {latest_pct}% 3日 {main_3d}亿", "data": {"latest_main_net_inflow_pct": latest_pct, "main_net_inflow_3d_yi": main_3d, "positive_main_days_5d": positive_days}})

    if open_board_count >= 3:
        score_delta -= 15
        factors.append({"name": "反复炸板", "score_delta": -15, "message": f"今日已炸板 {open_board_count} 次", "data": {"open_board_count": open_board_count}})

    kline_score_val = _kline_score_from_strategy(strategy)
    if kline_score_val is not None:
        kline_delta = 0
        if kline_score_val < 55: kline_delta = -12
        elif kline_score_val < 65: kline_delta = -6
        elif kline_score_val >= 90: kline_delta = 3
        component["kline_risk"] = kline_delta
        if kline_delta:
            score_delta += kline_delta
            factors.append({"name": "技术风险修正", "score_delta": kline_delta, "message": f"技术分 {kline_score_val:.0f}"})

    return {"score_delta": score_delta, "factors": factors, "component": component}

# ── small helpers ──────────────────────────────────────────

def _board_member_targets(summary: dict[str, Any]) -> list[dict[str, Any]]:
    """Extract board list from summary."""
    mapping = summary.get("board_mappings") or summary.get("boards") or summary.get("results") or []
    return list(mapping) if isinstance(mapping, list) else []

def _board_specificity_delta(board_name: str, board_kind: str) -> int:
    name = board_name.upper()
    noise = ("融资融券", "基金重仓", "机构重仓", "沪股通", "深股通", "国企改革", "央企", "MSCI", "富时罗素", "证金持股", "昨日", "近期", "百日新高", "同花顺漂亮", "标普")
    precise = ("锂", "钠", "钨", "稀土", "TOPCON", "TOPCon", "光刻", "先进封装", "商业航天", "机器人", "卫星", "存储", "芯片", "玻纤", "预制菜", "调味", "彩票", "小金属", "低空", "固态电池")
    broad = ("概念", "板块", "电子", "化工", "机械", "设备", "汽车", "有色金属", "房地产", "计算机", "食品饮料", "电池技术", "新能源车", "互联网金融")
    if any(k.upper() in name for k in noise): return -30
    if any(k.upper() in name for k in precise): return 12
    if board_kind == "tag": return -25
    if board_kind == "industry": return -10
    if len(board_name) <= 4 and not any(k.upper() in name for k in precise): return -6
    if any(k.upper() in name for k in broad): return -8
    return 4 if board_kind == "concept" else 0

def _board_specificity_message(board_name: str, board_kind: str, delta: int) -> str:
    if delta >= 10: return f"{board_name}偏细分题材"
    if delta <= -20: return f"{board_name}偏标签/宽泛"
    if delta < 0: return f"{board_name}偏宽泛"
    return f"{board_name}具备一定题材指向"

def _board_member_market_stats(members: list[dict], current_code: str) -> dict[str, Any]:
    nc = current_code.strip().zfill(6)[-6:]
    main_rank = None; main_seen = 0; growth_star_ahead = 0; current_seen = False
    main_limit_like = 0; growth_star_limit_like = 0
    for m in members:
        c = str(m.get("code", "")).strip().zfill(6)[-6:]
        chg = _float_or_none(m.get("change_pct")) or 0.0
        is_main = _is_main_board_stock(c)
        is_gs = _is_growth_or_star_stock(c)
        if is_main:
            main_seen += 1
            if chg >= _limit_like_threshold_for_code(c): main_limit_like += 1
            if c == nc: main_rank = main_seen; current_seen = True
        elif is_gs:
            if not current_seen: growth_star_ahead += 1
            if chg >= _limit_like_threshold_for_code(c): growth_star_limit_like += 1
    return {"current_main_board_rank": main_rank, "growth_star_ahead_count": growth_star_ahead, "main_board_limit_like_count": main_limit_like, "growth_star_limit_like_count": growth_star_limit_like}

def _is_main_board_stock(code: str) -> bool:
    c = code.strip().zfill(6)[-6:]
    return c.startswith("0") or c.startswith("6") or c.startswith("8")

def _is_growth_or_star_stock(code: str) -> bool:
    c = code.strip().zfill(6)[-6:]
    return c.startswith("3") or c.startswith("4")

def _limit_like_threshold_for_code(code: str) -> float:
    c = code.strip().zfill(6)[-6:]
    if c.startswith("3") or c.startswith("4") or c.startswith("8"):
        return 19.0  # 科创板/创业板 20% threshold
    if c.startswith("0") or c.startswith("6"):
        return 9.5  # 主板 threshold
    return 9.5

def _float_or_none(value) -> float | None:
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None

def _kline_score_from_strategy(strategy: dict | None) -> float | None:
    if not strategy:
        return None
    for result in strategy.get("results") or []:
        if result.get("strategy_id") != "kline_structure_score":
            continue
        data = result.get("data") or {}
        value = data.get("score")
        try:
            return None if value is None else float(value)
        except (TypeError, ValueError):
            return None
    return None
