"""
Legacy technical scoring helper functions.
Split from legacy_technical.py to stay within 300-line limit.
All @staticmethod in old code — pure functions.
"""

from __future__ import annotations

import math
from typing import Any

import pandas as pd


def _bars_to_dataframe(bars: list[dict[str, Any]]) -> pd.DataFrame:
    df = pd.DataFrame(bars)
    if "日期" in df.columns:
        df["日期"] = pd.to_datetime(df["日期"])
    for col in ["收盘", "最高", "最低", "成交额", "涨跌幅", "开盘", "成交量", "换手率"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df.sort_values("日期").reset_index(drop=True)


def _events_to_limit_touches(events: list[dict[str, Any]]) -> list[Any]:
    class _Touch:
        __slots__ = ("date", "touched_limit", "closed_limit", "pre_close", "close", "change_pct")
        def __init__(self, d: dict[str, Any]) -> None:
            self.date = str(d.get("date", ""))
            self.touched_limit = bool(d.get("touched_limit", False))
            self.closed_limit = bool(d.get("closed_limit", False))
            self.pre_close = float(d.get("pre_close", 0))
            self.close = float(d.get("close", 0))
            self.change_pct = float(d.get("change_pct", 0))
    return [_Touch(e) for e in events if e.get("date")]


def _latest_comparable_limit(frame: pd.DataFrame, events: list) -> dict | None:
    if not events:
        return events[-1] if events else None
    for event in reversed(events):
        premium = _next_day_premium(frame, event)
        if premium is not None:
            return event
    return events[-1] if events else None


def _next_day_premium(frame: pd.DataFrame, event) -> dict | None:
    if event is None or frame.empty:
        return None
    event_date = pd.to_datetime(event.date)
    next_rows = frame[frame["日期"] > event_date]
    if next_rows.empty:
        return None
    next_row = next_rows.iloc[0]
    premium_pct = round((float(next_row["收盘"]) / event.close - 1.0) * 100.0, 3)
    return {
        "event_id": event.date,
        "limit_event_date": event.date,
        "next_date": str(next_row["日期"].date()),
        "next_close": float(next_row["收盘"]),
        "premium_pct": premium_pct,
        "has_premium": premium_pct > 0,
    }


def _flat_structure_score(amp60: float, amp40: float, amp20: float, close_std20: float, amount_std20: float) -> int:
    score = 0
    if amp60 <= 35: score += 10
    if amp40 <= 28: score += 8
    if amp20 <= 18: score += 7
    if close_std20 <= 6: score += 5
    if amount_std20 <= 60: score += 5
    return min(35, score)

def _pressure_score(peak_ratio: float) -> int:
    if peak_ratio < 1.2: return 25
    if peak_ratio < 1.5: return 18
    if peak_ratio < 2.0: return 10
    if peak_ratio < 2.5: return 4
    return 0

def _flat_breakout_score(current_price: float, current_change_pct: float, high20: float, high60: float, ma60: float | None) -> int:
    score = 0
    if high60 > 0 and current_price >= high60 * 1.005: score += 8
    if high20 > 0 and current_price >= high20 * 1.005: score += 5
    if current_change_pct >= 7: score += 4
    if ma60 and current_price >= ma60: score += 3
    return min(20, score)

def _technical_volume_confirm_score(amount_ratio20: float | None, today_amount: float) -> int:
    score = 0
    if amount_ratio20 is not None and amount_ratio20 >= 1.2: score += 5
    if amount_ratio20 is not None and amount_ratio20 <= 4.0: score += 3
    if today_amount >= 50_000_000: score += 2
    return min(10, score)

def _technical_memory_score(failed_touch_60: int, premium_pct: float | None, strict_failed_zero: bool) -> int:
    score = 0
    if (failed_touch_60 == 0 if strict_failed_zero else failed_touch_60 <= 1): score += 5
    if premium_pct is not None and premium_pct >= 0.1: score += 5
    return min(10, score)

def _trend_strength_score(ma20: float | None, ma60: float | None, ma20_slope_pct: float | None, ret60: float, ret20: float) -> int:
    score = 0
    if ma20 and ma60 and ma20 > ma60: score += 10
    if ma20_slope_pct is not None and ma20_slope_pct > 0: score += 8
    if 15 <= ret60 <= 60: score += 10
    if 5 <= ret20 <= 25: score += 7
    return min(35, score)

def _trend_position_score(current_price: float, high60: float, ma20: float | None, peak_ratio: float) -> int:
    score = 0
    if high60 > 0 and current_price >= high60 * 0.95: score += 8
    if ma20 and current_price <= ma20 * 1.25: score += 6
    if peak_ratio < 1.8: score += 6
    return min(20, score)

def _trend_breakout_score(current_price: float, current_change_pct: float, high20: float, high60: float) -> int:
    score = 0
    if high20 > 0 and current_price >= high20 * 1.005: score += 8
    if high60 > 0 and current_price >= high60 * 1.005: score += 8
    if current_change_pct >= 7: score += 4
    return min(20, score)

def _trend_risk_control_score(peak_ratio: float, ret60: float, amount_ratio20: float | None) -> int:
    score = 0
    if peak_ratio < 2.0: score += 8
    if ret60 < 100 and (amount_ratio20 is None or amount_ratio20 <= 4.0): score += 7
    return min(15, score)

def _technical_common_risk(*, peak_ratio: float, failed_touch_60: int, current_price: float, ma20: float | None, ma60: float | None, ret60: float, today_amount: float) -> tuple[int, list[dict[str, Any]], bool]:
    penalty = 0
    flags: list[dict[str, Any]] = []
    veto = peak_ratio >= 3.0
    if veto:
        flags.append({"name": "三倍周期风险", "message": f"近一年高点/当前价 {peak_ratio:.2f}，触发一票否决"})
    if peak_ratio >= 2.5:
        penalty -= 20; flags.append({"name": "高点压力过重", "score_delta": -20})
    elif peak_ratio >= 2.0:
        penalty -= 12; flags.append({"name": "高点压力偏重", "score_delta": -12})
    if failed_touch_60 >= 2:
        penalty -= 10; flags.append({"name": "近期多次触板失败", "score_delta": -10, "count": failed_touch_60})
    if ma20 and ma60 and current_price < ma20 and current_price < ma60:
        penalty -= 10; flags.append({"name": "均线下方弱势", "score_delta": -10})
    if ret60 >= 100:
        penalty -= 15; flags.append({"name": "前期已翻倍", "score_delta": -15, "ret60": round(ret60, 3)})
    if today_amount and today_amount < 20_000_000:
        penalty -= 10; flags.append({"name": "成交额过低", "score_delta": -10})
    return max(-40, penalty), flags, veto

def _technical_level(total: float | int) -> str:
    value = float(total)
    if value >= 85: return "strong"
    if value >= 70: return "pass"
    if value >= 55: return "watch"
    return "weak"

def _finite_float(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if math.isfinite(result) else default
