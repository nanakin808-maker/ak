"""
Minimal copy of old VolumeScoringMixin volume momentum scoring.
No AlertRuntime. No quote_window deque management.
Input: explicit sample list + stock_meta + technical_metrics.
"""

from __future__ import annotations

import math
import time
from typing import Any


def compute_volume_score(
    *,
    code: str,
    quote_window: list[dict[str, Any]] | None,
    latest_quote: dict[str, Any] | None,
    stock_meta: dict[str, Any] | None,
    technical_metrics: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Entry point for volume scoring.
    quote_window: ordered list of {timestamp, price, change_pct, amount, volume, bid_vol1, ask_vol1}
    latest_quote: latest real-time quote with {code, price, change_pct, amount, volume, bid_vol1, ask_vol1}
    stock_meta: {float_share, float_market_value}
    technical_metrics: from compute_technical_score output metrics dict
    """
    if not quote_window or len(quote_window) < 2:
        return {
            "status": "warming",
            "total": None,
            "message": "缺少至少2个报价样本",
            "code": code,
        }

    if latest_quote is None and quote_window:
        latest_quote = quote_window[-1]
    if latest_quote is None:
        return {"status": "warming", "total": None, "message": "缺少最新报价", "code": code}

    samples = list(quote_window)
    metrics = technical_metrics or {}
    meta = stock_meta or {}

    if latest_quote.get("amount") is None and latest_quote.get("volume") is None:
        return {"status": "missing_quote_volume", "total": None, "message": "缺少实时成交量和成交额", "code": code}

    short_window = _volume_short_window_score(samples, latest_quote)
    amount_confirm = _volume_amount_confirm_score(latest_quote, metrics)
    turnover_fit = _volume_turnover_fit_score(latest_quote, meta)
    history_compare = _volume_history_compare_score(metrics)
    risk = _volume_momentum_risk_penalty(samples, latest_quote, metrics, meta)

    component_values = [
        short_window.get("score"),
        amount_confirm.get("score"),
        turnover_fit.get("score"),
        history_compare.get("score"),
    ]
    ready_components = [v for v in component_values if v is not None]
    status = "ready" if len(samples) >= 2 and ready_components else "warming"
    total = sum(int(v or 0) for v in component_values) - int(risk.get("penalty") or 0)
    total = max(0, min(100, total))

    if status != "ready":
        level = "warming"
        label = "等待短窗口"
    elif total >= 85:
        level, label = "strong", "放量上推"
    elif total >= 70:
        level, label = "pass", "量能合格"
    elif total >= 55:
        level, label = "watch", "量能观察"
    else:
        level, label = "weak", "量能不足"

    return {
        "version": "volume_momentum_score_v1",
        "status": status,
        "total": total,
        "level": level,
        "label": label,
        "short_window": short_window,
        "amount_confirm": amount_confirm,
        "turnover_fit": turnover_fit,
        "history_compare": history_compare,
        "risk_penalty": risk,
        "metrics": {
            "sample_count": len(samples),
            "price": _round_or_none(latest_quote.get("price"), 3),
            "change_pct": _round_or_none(latest_quote.get("change_pct"), 3),
            "amount_yi": _round_or_none(None if latest_quote.get("amount") is None else latest_quote["amount"] / 100_000_000, 3),
        },
        "updated_at": time.time(),
    }


# ── sub-score functions (adapted from VolumeScoringMixin) ────

def _volume_short_window_score(samples: list[dict[str, Any]], quote: dict[str, Any]) -> dict[str, Any]:
    if len(samples) < 2:
        return {"status": "warming", "score": 0, "message": "等待至少2个报价样本"}
    first = samples[0]
    last = samples[-1]
    seconds = max(0.001, float(last.get("timestamp") or 0) - float(first.get("timestamp") or 0))
    pct_delta = (_finite_or_none(last.get("change_pct")) or 0) - (_finite_or_none(first.get("change_pct")) or 0)
    amount_delta = _positive_delta(first.get("amount"), last.get("amount"))
    volume_delta = _positive_delta(first.get("volume"), last.get("volume"))
    changes = [_finite_or_none(item.get("change_pct")) for item in samples]
    checked = [v for v in changes if v is not None]
    monotonic_hits = sum(1 for prev, cur in zip(checked, checked[1:]) if cur >= prev)
    monotonic_ratio = monotonic_hits / max(1, len(checked) - 1)
    max_change = max(checked) if checked else None
    drawdown = 0.0 if max_change is None else max(0.0, max_change - (_finite_or_none(last.get("change_pct")) or 0))

    score = 0
    reasons: list[str] = []
    if seconds >= 3:
        if pct_delta >= 0.8:
            score += 12; reasons.append("短窗口涨幅推进强")
        elif pct_delta >= 0.4:
            score += 8; reasons.append("短窗口涨幅推进")
        elif pct_delta >= 0.15:
            score += 4; reasons.append("短窗口小幅推进")
    if monotonic_ratio >= 0.8:
        score += 8; reasons.append("报价连续上推")
    elif monotonic_ratio >= 0.6:
        score += 5; reasons.append("报价偏上行")
    if drawdown <= 0.15:
        score += 5; reasons.append("短窗口回撤小")
    elif drawdown >= 0.5:
        reasons.append("短窗口有回落")
    change_pct = _finite_or_none(quote.get("change_pct")) or 0.0
    if change_pct >= 9.5:
        score += 5; reasons.append("接近涨停区")
    if amount_delta is not None and amount_delta >= 10_000_000:
        score += 5; reasons.append("短窗口成交额增加")
    elif volume_delta is not None and volume_delta >= 10_000:
        score += 3; reasons.append("短窗口成交量增加")
    score = max(0, min(35, score))
    return {
        "status": "ready", "score": score, "window_seconds": round(seconds, 3),
        "change_pct_delta": round(pct_delta, 3), "monotonic_ratio": round(monotonic_ratio, 3),
        "drawdown_pct": round(drawdown, 3), "reasons": reasons,
    }


def _volume_amount_confirm_score(quote: dict[str, Any], metrics: dict[str, Any]) -> dict[str, Any]:
    amount = _finite_or_none(quote.get("amount"))
    amount_ratio20 = _finite_or_none(metrics.get("amount_ratio20"))
    if amount is not None and amount_ratio20 is not None:
        today_amount = _finite_or_none(metrics.get("today_amount_yi"))
        if today_amount and today_amount > 0:
            amount_ratio20 = amount / (today_amount * 100_000_000) * amount_ratio20
    score = 0
    reasons: list[str] = []
    if amount_ratio20 is not None:
        if 1.2 <= amount_ratio20 <= 3.5:
            score += 14; reasons.append("日内成交额相对20日均量健康放大")
        elif 0.8 <= amount_ratio20 < 1.2:
            score += 8; reasons.append("日内成交额相对20日均量持平")
        elif 3.5 < amount_ratio20 <= 6.0:
            score += 8; reasons.append("日内成交额相对20日均量显著放大")
        else:
            score += 3; reasons.append("日内成交额相对20日均量异常放大")
    return {"status": "ready" if amount is not None else "missing", "score": score, "amount_ratio20": round(amount_ratio20, 3) if amount_ratio20 is not None else None, "reasons": reasons}


def _volume_turnover_fit_score(quote: dict[str, Any], meta: dict[str, Any]) -> dict[str, Any]:
    volume = _finite_or_none(quote.get("volume"))
    float_share = _finite_or_none(meta.get("float_share"))
    float_mv = _finite_or_none(meta.get("float_market_value"))
    if volume is None or not float_share:
        return {"status": "missing", "score": 0, "turnover_pct": None, "message": "缺少实时成交量或流通股本"}
    traded_shares = _quote_volume_shares(quote)
    if traded_shares is None:
        return {"status": "missing", "score": 0, "turnover_pct": None, "message": "无法判断实时成交量单位"}
    turnover = traded_shares / float_share * 100.0
    low, high = 2.0, 12.0
    if float_mv is not None:
        if float_mv < 5_000_000_000:
            low, high = 5.0, 18.0
        elif float_mv < 15_000_000_000:
            low, high = 3.0, 12.0
        else:
            low, high = 1.5, 8.0
    if low <= turnover <= high:
        score = 20; message = "换手与流通市值匹配"
    elif turnover < low:
        score = 8 if turnover >= low * 0.6 else 3; message = "换手偏低，承接确认不足"
    else:
        score = 10 if turnover <= high * 1.4 else 4; message = "换手偏高，分歧消耗偏大"
    return {"status": "ready", "score": score, "turnover_pct": round(turnover, 3), "fit_range_pct": [low, high], "message": message}


def _volume_history_compare_score(metrics: dict[str, Any]) -> dict[str, Any]:
    amount_ratio20 = _finite_or_none(metrics.get("amount_ratio20"))
    amount_std20 = _finite_or_none(metrics.get("amount_std20"))
    if amount_ratio20 is None and amount_std20 is None:
        return {"status": "missing", "score": 0, "message": "缺少历史成交额对比"}
    score = 0
    reasons: list[str] = []
    if amount_ratio20 is not None:
        if 1.2 <= amount_ratio20 <= 2.8:
            score += 12; reasons.append("相对20日成交额温和放量")
        elif 2.8 < amount_ratio20 <= 4.5:
            score += 8; reasons.append("相对20日成交额明显放量")
        elif 0.8 <= amount_ratio20 < 1.2:
            score += 6; reasons.append("相对20日成交额略放大")
        elif amount_ratio20 > 4.5:
            score += 3; reasons.append("相对20日成交额过大")
    if amount_std20 is not None:
        if amount_std20 <= 80:
            score += 8; reasons.append("前期量能波动可控")
        elif amount_std20 <= 140:
            score += 5; reasons.append("前期量能波动一般")
        else:
            reasons.append("前期量能波动偏大")
    return {"status": "ready", "score": max(0, min(20, score)), "amount_ratio20": _round_or_none(amount_ratio20, 3), "amount_std20": _round_or_none(amount_std20, 3), "reasons": reasons}


def _volume_momentum_risk_penalty(samples: list[dict[str, Any]], quote: dict[str, Any], metrics: dict[str, Any], meta: dict[str, Any]) -> dict[str, Any]:
    penalty = 0
    flags: list[str] = []
    if len(samples) >= 2:
        first = samples[0]; last = samples[-1]
        pct_delta = (_finite_or_none(last.get("change_pct")) or 0) - (_finite_or_none(first.get("change_pct")) or 0)
        amount_delta = _positive_delta(first.get("amount"), last.get("amount"))
        changes = [_finite_or_none(item.get("change_pct")) for item in samples]
        checked = [v for v in changes if v is not None]
        if pct_delta >= 0.3 and (amount_delta is None or amount_delta < 2_000_000):
            penalty += 10; flags.append("价格上推但短窗口成交额确认弱")
        if checked:
            drawdown = max(checked) - checked[-1]
            if drawdown >= 0.6:
                penalty += 8; flags.append("短窗口冲高回落")
    amount = _finite_or_none(quote.get("amount"))
    amount_ratio20 = _finite_or_none(metrics.get("amount_ratio20"))
    if amount_ratio20 is not None and amount_ratio20 > 6.0:
        penalty += 12; flags.append("历史对比爆量过高")
    if amount is not None and (_finite_or_none(quote.get("change_pct")) or 0) >= 7 and amount < 20_000_000:
        penalty += 8; flags.append("高涨幅但成交额偏低")
    volume = _finite_or_none(quote.get("volume"))
    float_share = _finite_or_none(meta.get("float_share"))
    if volume is not None and float_share:
        traded_shares = _quote_volume_shares(quote)
        turnover = None if traded_shares is None else traded_shares / float_share * 100.0
        if turnover is not None and turnover >= 25:
            penalty += 10; flags.append("换手过高")
    return {"penalty": max(0, min(35, penalty)), "flags": flags}


def _quote_volume_shares(quote: dict[str, Any]) -> float | None:
    volume = _finite_or_none(quote.get("volume"))
    if volume is None:
        return None
    amount = _finite_or_none(quote.get("amount"))
    price = _finite_or_none(quote.get("price"))
    if amount and price and price > 0:
        implied_shares = amount / price
        direct_error = abs(volume - implied_shares)
        hand_error = abs(volume * 100.0 - implied_shares)
        return volume if direct_error <= hand_error else volume * 100.0
    source = str(quote.get("source") or "").lower()
    if source == "sina":
        return volume
    return volume * 100.0


# ── small helpers ────────────────────────────────────────────

def _finite_or_none(value: Any) -> float | None:
    try:
        v = float(value)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None

def _round_or_none(value: Any, decimals: int = 3) -> float | None:
    v = _finite_or_none(value)
    return round(v, decimals) if v is not None else None

def _positive_delta(first: Any, last: Any) -> float | None:
    f = _finite_or_none(first)
    lv = _finite_or_none(last)
    if f is not None and lv is not None and lv > f:
        return lv - f
    return None
