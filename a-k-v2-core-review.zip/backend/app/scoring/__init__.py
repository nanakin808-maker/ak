"""
Scoring module: minimal copies of legacy scoring pure functions.
No AlertEngine. No provider code. No test interfaces.
"""
