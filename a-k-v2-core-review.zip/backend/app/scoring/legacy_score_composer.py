"""
AStockLegacyScoreComposer: combines component scores into final ScoreExecutionResult.
No AlertRuntime dependency. All inputs are explicit.
"""

from __future__ import annotations

import json
from typing import Any


def compose_score(
    *,
    code: str,
    name: str = "",
    trading_date: str = "",
    technical_result: dict[str, Any] | None = None,
    volume_result: dict[str, Any] | None = None,
    board_result: dict[str, Any] | None = None,
    sentiment_result: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Compose scoring components into a unified result dict.
    Returns dict matching ScoreExecutionResult field layout.
    """
    components: dict[str, dict] = {}
    missing: list[str] = []

    # ── technical ──
    technical_score: float | None = None
    if technical_result and technical_result.get("status") == "ready":
        technical_score = _to_float(technical_result.get("score"))
        components["technical"] = {
            "status": "ready",
            "score": technical_score,
            "detail": technical_result.get("technical_score"),
        }
    elif technical_result:
        components["technical"] = {"status": technical_result.get("status", "failed"), "score": None}
        missing.append("technical")
    else:
        components["technical"] = {"status": "missing_input", "score": None}
        missing.append("technical")

    # ── volume ──
    volume_score: float | None = None
    if volume_result and volume_result.get("status") in ("ready", "warming"):
        volume_score = _to_float(volume_result.get("total"))
        components["volume"] = {"status": volume_result.get("status"), "score": volume_score}
        if volume_result.get("status") != "ready":
            missing.append("volume")
    else:
        components["volume"] = {"status": volume_result.get("status", "missing_input") if volume_result else "missing_input", "score": None}
        missing.append("volume")

    # ── board ──
    board_score: float | None = None
    if board_result and board_result.get("status") == "ready":
        board_score = _to_float(board_result.get("score"))
        components["board"] = {"status": "ready", "score": board_score}
    else:
        status = board_result.get("status", "missing_input") if board_result else "missing_input"
        components["board"] = {"status": status, "score": None}
        missing.append("board")

    # ── sentiment ──
    sentiment_score: float | None = None
    if sentiment_result and sentiment_result.get("status") == "ready":
        sentiment_score = _to_float(sentiment_result.get("total"))
        components["sentiment"] = {"status": "ready", "score": sentiment_score}
    else:
        status = sentiment_result.get("status", "missing_input") if sentiment_result else "missing_input"
        components["sentiment"] = {"status": status, "score": None}
        missing.append("sentiment")

    # ── final logic ──
    all_ready = all(
        comp.get("status") == "ready"
        for key, comp in components.items()
    )

    if all_ready:
        is_full = True
        status = "ready"
        passed = True
        reject_reason = ""
        main_logic = "legacy_full_score"
        # Final score: use board/sentiment if available, else technical
        final_score = sentiment_score or board_score or technical_score
    else:
        is_full = False
        status = "partial"
        passed = False
        reject_reason = "partial_components_missing:" + ",".join(sorted(missing))
        main_logic = "legacy_component_facade"
        # Use technical score if available
        final_score = technical_score

    score_json: dict[str, Any] = {
        "scoring_mode": "legacy_full",
        "is_full_legacy_score": is_full,
        "components": components,
        "missing_components": missing,
        "technical_detail": technical_result.get("technical_score") if technical_result else None,
        "volume_detail": volume_result,
        "board_detail": board_result,
        "sentiment_detail": sentiment_result,
    }

    return {
        "score": final_score,
        "technical_score": technical_score,
        "sentiment_score": sentiment_score,
        "volume_score": volume_score,
        "board_score": board_score,
        "passed": passed,
        "status": status,
        "reject_reason": reject_reason,
        "main_logic": main_logic,
        "score_json": json.dumps(score_json, ensure_ascii=False, default=str),
    }


def _to_float(value) -> float | None:
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None
