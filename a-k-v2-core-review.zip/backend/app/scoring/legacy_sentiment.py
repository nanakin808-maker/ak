"""
Minimal copy of old _sentiment_score and sub-scores.
Pure functions: board_scores + item are explicit inputs.
"""

from __future__ import annotations

from typing import Any


def compute_sentiment_score(
    *,
    code: str,
    change_pct: float | None = None,
    board_scores: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Entry point for sentiment scoring.
    board_scores: list of board evaluation dicts from compute_board_score.
    """
    if not board_scores:
        return {"status": "partial_missing_board_scores", "total": None}

    candidates = [_sentiment_board_score(code, bs) for bs in board_scores]
    for bs, cand in zip(board_scores, candidates):
        bs["sentiment_total"] = cand["total"]
        bs["sentiment_components"] = cand["components"]
        bs["sentiment_level"] = cand["level"]

    primary = max(
        candidates,
        key=lambda v: (int(v.get("total") or 0), int(((v.get("components") or {}).get("position")) or 0), int(v.get("confidence") or 0)),
        default=None,
    )
    if primary is None:
        return {"status": "empty", "total": None, "candidates": []}

    total = int(primary["total"])
    return {
        "status": "ready",
        "total": total,
        "raw_total": primary.get("raw_total"),
        "floor": primary.get("floor"),
        "position": primary["components"]["position"],
        "strength": primary["components"]["strength"],
        "limit_ecology": primary["components"]["limit_ecology"],
        "logic": primary["components"]["logic"],
        "risk_penalty": primary["components"]["risk_penalty"],
        "level": _sentiment_level(total),
        "main_logic": primary["board"],
        "confidence": primary["confidence"],
        "candidates": candidates[:5],
        "code": code,
    }


def _sentiment_board_score(code: str, board: dict[str, Any]) -> dict[str, Any]:
    position = _sentiment_position_score(code, board)
    strength = _sentiment_strength_score(board)
    ecology = _sentiment_limit_ecology_score(board)
    logic = _sentiment_logic_score(board)
    risk_penalty = _sentiment_risk_penalty(code, board)
    positive_total = position + strength + ecology + logic
    raw_total = position + strength + ecology + logic + risk_penalty
    total = max(0, min(100, raw_total))
    floor = _sentiment_board_floor(position, strength, ecology, logic, board)
    if positive_total > 0 and total < floor:
        total = floor
    confidence = int(board.get("logic_confidence") or 0)
    return {
        "board": {
            "board_code": board.get("board_code"), "board_name": board.get("board_name"),
            "board_kind": board.get("board_kind"), "rank": board.get("rank"),
            "limit_order_rank": board.get("limit_order_rank"),
            "board_change_pct": board.get("board_change_pct"),
        },
        "total": int(total), "raw_total": int(max(0, min(100, raw_total))),
        "floor": floor, "confidence": confidence,
        "level": _sentiment_level(total),
        "components": {"position": position, "strength": strength, "limit_ecology": ecology, "logic": logic, "risk_penalty": risk_penalty},
    }


def _sentiment_position_score(code: str, board: dict[str, Any]) -> int:
    rank = board.get("rank")
    if rank == 1: score = 40
    elif rank == 2: score = 34
    elif rank == 3: score = 24
    elif isinstance(rank, int) and rank <= 5: score = 12
    elif isinstance(rank, int) and rank <= 10: score = 4
    else: score = 0
    if _is_main_board_stock(code):
        main_rank = board.get("main_board_rank")
        if main_rank == 1: score += 6
        elif main_rank == 2: score += 4
        elif main_rank == 3: score += 2
    return max(0, min(40, int(score)))

def _sentiment_strength_score(board: dict[str, Any]) -> int:
    score = 0
    bc = _float_or_none(board.get("board_change_pct"))
    if bc is not None:
        if bc >= 4: score += 8
        elif bc >= 2: score += 6
        elif bc >= 1: score += 3
        elif bc >= 0: score += 1
    avg = _float_or_none(board.get("avg_change_pct")) or 0.0
    if avg >= 3: score += 5
    elif avg >= 2: score += 3
    elif avg >= 1: score += 1
    rr = _float_or_none(board.get("red_ratio")) or 0.0
    if rr >= 0.8: score += 4
    elif rr >= 0.65: score += 2
    sc = int(board.get("strong_count") or 0)
    if sc >= 5: score += 3
    elif sc >= 3: score += 2
    elif sc >= 1: score += 1
    return max(0, min(20, int(score)))

def _sentiment_limit_ecology_score(board: dict[str, Any]) -> int:
    score = 0
    order_rank = board.get("limit_order_rank")
    if order_rank == 1: score += 12
    elif order_rank == 2: score += 9
    elif order_rank == 3: score += 4
    limit_count = int(board.get("limit_count_top20") or 0)
    if limit_count >= 3: score += 3
    elif limit_count == 2: score += 2
    return max(0, min(25, int(score)))

def _sentiment_logic_score(board: dict[str, Any]) -> int:
    score = 0
    if board.get("rank") in {1, 2}: score += 5
    if int(board.get("limit_count_top20") or 0) >= 2: score += 3
    bc = _float_or_none(board.get("board_change_pct"))
    if bc is not None and bc >= 2: score += 2
    return max(0, min(15, int(score)))

def _sentiment_risk_penalty(code: str, board: dict[str, Any]) -> int:
    penalty = 0
    order_rank = board.get("limit_order_rank")
    rank = board.get("rank")
    front_order = isinstance(order_rank, int) and order_rank <= 2
    other_chain = int(board.get("other_max_chain_streak") or 0)
    if other_chain >= 3 and not front_order: penalty += 28
    elif other_chain >= 2 and not front_order: penalty += 20
    if isinstance(order_rank, int) and order_rank >= 4: penalty += 15
    if isinstance(rank, int) and rank > 5: penalty += 12
    if int(board.get("limit_count_top20") or 0) <= 1: penalty += 8
    if int(board.get("logic_confidence") or 0) < 55: penalty += 10
    return -min(40, penalty)

def _sentiment_board_floor(position: int, strength: int, ecology: int, logic: int, board: dict[str, Any]) -> int:
    positive = int(position or 0) + int(strength or 0) + int(ecology or 0) + int(logic or 0)
    if positive <= 0: return 0
    floor = 8
    if positive >= 35: floor = 18
    elif positive >= 25: floor = 14
    elif positive >= 15: floor = 10
    if isinstance(board.get("rank"), int) and board["rank"] <= 3: floor = max(floor, 35)
    if isinstance(board.get("limit_order_rank"), int) and board["limit_order_rank"] <= 2: floor = max(floor, 40)
    return min(50, floor)

def _sentiment_level(total: float | int) -> str:
    v = float(total)
    if v >= 85: return "strong"
    if v >= 70: return "pass"
    if v >= 55: return "watch"
    return "weak"


# ── helpers ────────────────────────────────────────────────────

def _is_main_board_stock(code: str) -> bool:
    c = code.strip().zfill(6)[-6:]
    return c.startswith("0") or c.startswith("6") or c.startswith("8")

def _float_or_none(value) -> float | None:
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None
