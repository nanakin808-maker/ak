"""
Stock → boards (板块归属) — Tencent primary.

Tencent: web.ifzq.gtimg.cn/appstock/app/board/index?code=sh600519
  Returns board list with name, code, change%, leading stock.
"""

from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass, field

UA = "Mozilla/5.0"


@dataclass(slots=True)
class StockBoard:
    board_code: str       # e.g. "pt01801081"
    board_name: str       # e.g. "半导体"
    board_change_pct: float | None
    board_kind: str       # "plate", "concept", "area", etc.
    source: str = "tencent"


def _prefix(code: str) -> str:
    c = code.strip().zfill(6)[-6:]
    return f"sh{c}" if c.startswith("6") else f"sz{c}"


def fetch_stock_boards(code: str, timeout: float = 5.0) -> list[StockBoard]:
    """Fetch boards a stock belongs to."""
    prefix = _prefix(code)
    url = f"https://web.ifzq.gtimg.cn/appstock/app/board/index?code={prefix}"
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        data = json.loads(resp.read().decode())
    except Exception:
        return []

    rank = data.get("data", {}).get("rank", {})
    if not isinstance(rank, dict):
        return []

    results: list[StockBoard] = []
    for kind in ["plate", "plate_zs", "plate_lb", "plate_hsl", "plate_zdf5"]:
        items = rank.get(kind)
        if not isinstance(items, list):
            continue
        for item in items:
            code_bd = str(item.get("bd_code", ""))
            name_bd = str(item.get("bd_name", ""))
            if not code_bd or not name_bd:
                continue
            zdf = _f(item.get("bd_zdf"))
            results.append(StockBoard(
                board_code=code_bd,
                board_name=name_bd,
                board_change_pct=zdf,
                board_kind=kind,
                source="tencent",
            ))
    return results


def _f(v) -> float | None:
    try:
        return None if v is None else float(v)
    except (TypeError, ValueError):
        return None
