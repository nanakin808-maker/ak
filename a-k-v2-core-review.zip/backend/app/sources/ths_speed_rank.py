"""
THS (同花顺) speed rank — backup source, requires cookie from old .env.

URL: https://q.10jqka.com.cn/index/index/board/all/field/zs/order/desc/page/1/ajax/1/
Cookie read from old project .env ASTOCK_THS_COOKIE.
"""

from __future__ import annotations

import os
import re
import urllib.request
from pathlib import Path
from typing import Any

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"
RANK_URL = "https://q.10jqka.com.cn/index/index/board/all/field/zs/order/desc/page/1/ajax/1/"

# Cache cookie to avoid repeated file reads
_COOKIE: str | None = None


def _get_ths_cookie() -> str:
    global _COOKIE
    if _COOKIE is not None:
        return _COOKIE
    # Read from old project .env
    old_env = Path(__file__).resolve().parents[3] / ".." / "a-k" / ".env"
    try:
        if old_env.exists():
            for line in old_env.read_text().splitlines():
                line = line.strip()
                if line.startswith("ASTOCK_THS_COOKIE="):
                    _COOKIE = line.split("=", 1)[1].strip().strip('"').strip("'")
                    break
    except Exception:
        pass
    if not _COOKIE:
        _COOKIE = ""
    return _COOKIE


def fetch_ths_speed_rank(limit: int = 30, timeout: float = 5.0) -> list[dict[str, Any]]:
    """Fetch THS speed rank. Returns empty list if cookie not configured."""
    cookie = _get_ths_cookie()
    if not cookie:
        return []

    # Compute hexin-v from cookie
    hexin_v = "".join(re.findall(r"userid=(\d+)", cookie)) or ""

    req = urllib.request.Request(RANK_URL, headers={
        "User-Agent": UA, "Cookie": cookie, "hexin-v": hexin_v,
    })
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        html = resp.read().decode("utf-8", errors="replace")
    except Exception:
        return []

    # Parse HTML table rows: <tr> <td>rank</td> <td><a>code</a></td> <td><a>name</a></td> ...
    results: list[dict] = []
    rows = re.findall(r"<tr[^>]*>(.*?)</tr>", html, re.DOTALL)
    for row in rows:
        tds = re.findall(r"<td[^>]*>(.*?)</td>", row, re.DOTALL)
        if len(tds) < 5:
            continue
        try:
            rank = int(re.sub(r"<[^>]+>", "", tds[0]).strip())
            code_match = re.search(r">(\d{6})<", tds[1])
            name_match = re.search(r">([^<]+)<", tds[2])
            if not code_match:
                continue
            code = code_match.group(1)
            name = name_match.group(1) if name_match else ""
            # Extract price/change_pct/speed from remaining tds
            price = _f(re.sub(r"<[^>]+>", "", tds[3]))
            change_pct = _f(re.sub(r"<[^>]+>", "", tds[4]))
            speed_pct = _f(re.sub(r"<[^>]+>", "", tds[5])) if len(tds) > 5 else None
            results.append({
                "code": code, "name": name, "price": price,
                "change_pct": change_pct, "speed_pct": speed_pct,
                "rank": rank, "source": "ths_speed_rank",
            })
        except (ValueError, IndexError):
            continue

    return results[:limit]


def _f(v: str) -> float | None:
    v = v.replace("%", "").replace(",", "").strip()
    try:
        return float(v)
    except (TypeError, ValueError):
        return None
