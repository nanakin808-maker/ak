"""
HTTP fetchers for RealtimeDevScanRunner. Extracted to keep scan file under 300 lines.
"""

from __future__ import annotations

import json
import urllib.request
from datetime import datetime

UA = "Mozilla/5.0"


def _get_json(url: str, timeout: float = 3.0) -> dict:
    req = urllib.request.Request(url, headers={
        "User-Agent": UA, "Referer": "https://quote.eastmoney.com/",
    })
    resp = urllib.request.urlopen(req, timeout=timeout)
    return json.loads(resp.read().decode())


def _f(v) -> float | None:
    try:
        return None if v is None else float(v)
    except (TypeError, ValueError):
        return None


def _fetch_speed_rank() -> list[dict]:
    url = (
        "https://push2.eastmoney.com/api/qt/clist/get?"
        "ut=fa5fd1943c7b386f172d6893dbfb2dc6"
        "&pn=1&pz=30&po=1&np=1&fltt=2&invt=2&fid=f3"
        "&fs=m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23"
        "&fields=f12,f14,f2,f3,f4,f5,f6,f7,f15,f16,f17,f18"
    )
    data = _get_json(url)
    items = ((data.get("data") or {}).get("diff") or [])
    return [
        {
            "code": str(item.get("f12", "")).zfill(6)[-6:],
            "name": str(item.get("f14", "")),
            "price": _f(item.get("f2")),
            "change_pct": _f(item.get("f3")),
            "speed_pct": _f(item.get("f7")),
            "source": "eastmoney_speed_rank",
        }
        for item in items if item.get("f12")
    ]


def _fetch_limit_pool(trading_date: str | None = None) -> list[dict]:
    rows = []
    if trading_date is None:
        from app.domain.market_calendar import effective_trading_date_ymd
        trading_date = effective_trading_date_ymd()
    for pool, url in [
        ("limit_up", "https://push2ex.eastmoney.com/getTopicZTPool"),
        ("open_board", "https://push2ex.eastmoney.com/getTopicZBPool"),
    ]:
        full_url = (
            f"{url}?ut=7eea3edcaed734bea9cbfc24409ed989"
            f"&dpt=wz.ztzt&Pageindex=0&pagesize=5000&sort=fbt:asc&date={trading_date}"
        )
        data = _get_json(full_url)
        for row in ((data.get("data") or {}).get("pool") or []):
            rows.append({
                "pool": pool,
                "code": str(row.get("c", "")).zfill(6)[-6:],
                "name": str(row.get("n", "")),
                "price": _f(row.get("p")),
                "change_pct": _f(row.get("zdp")),
                "first_limit_time": str(row.get("fbt", "") or ""),
                "open_count": int(row.get("oc", 0) or 0),
                "seal_amount": _f(row.get("ma")) or _f(row.get("se")),
                "industry": str(row.get("hybk", "") or ""),
                "source": "eastmoney_limit_pool",
            })
    return rows


def _fetch_quote_via_tencent(codes: list[str]) -> list[dict]:
    if not codes:
        return []
    prefixes = []
    for c in codes:
        cc = c.strip().zfill(6)[-6:]
        prefixes.append(f"sh{cc}" if cc.startswith("6") else f"sz{cc}")
    url = f"https://qt.gtimg.cn/q={','.join(prefixes)}"
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    resp = urllib.request.urlopen(req, timeout=3)
    body = resp.read().decode("gbk", errors="replace")
    results = []
    for line in body.strip().split(";"):
        if '="' not in line:
            continue
        raw = line.split('="', 1)[1].rstrip('"')
        parts = raw.split("~")
        if len(parts) < 50:
            continue
        results.append({
            "code": parts[2], "name": parts[1],
            "price": _f(parts[3]), "pre_close": _f(parts[4]),
            "change_pct": _f(parts[32]) if len(parts) > 32 else None,
            "limit_up": _f(parts[47]) if len(parts) > 47 else None,
            "bid1": _f(parts[9]),
            "bid_vol1": int(_f(parts[10]) or 0),
            "ask1": _f(parts[19]),
            "ask_vol1": int(_f(parts[20]) or 0),
            "source": "tencent_quote",
        })
    return results
