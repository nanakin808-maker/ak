"""
Sina real-time orderbook provider (hq.sinajs.cn).

Backup source. Provides 5-level orderbook with bid/ask volumes.
Tencent is primary; Sina is fallback.

Source: https://hq.sinajs.cn/list={prefix}{code}
Fields: 0 name, 1 open, 2 pre_close, 3 price, 4 high, 5 low,
        6 bid1, 7 ask1, 8 volume, 9 amount,
        10-14 bid_vol1-5 (//100), 20-24 ask_vol1-5 (//100)
"""

from __future__ import annotations

import time
import urllib.request
from dataclasses import dataclass


@dataclass(slots=True)
class SinaQuote:
    code: str
    name: str
    price: float | None
    pre_close: float | None
    open: float | None
    high: float | None
    low: float | None
    change_pct: float | None
    volume: int = 0
    amount: float | None = None
    bid1: float | None = None
    bid_vol1: int = 0
    bid2: float | None = None
    bid_vol2: int = 0
    bid3: float | None = None
    bid_vol3: int = 0
    bid4: float | None = None
    bid_vol4: int = 0
    bid5: float | None = None
    bid_vol5: int = 0
    ask1: float | None = None
    ask_vol1: int = 0
    ask2: float | None = None
    ask_vol2: int = 0
    ask3: float | None = None
    ask_vol3: int = 0
    ask4: float | None = None
    ask_vol4: int = 0
    ask5: float | None = None
    ask_vol5: int = 0
    source: str = "sina"
    timestamp: float = 0.0


UA = "Mozilla/5.0"
REFERER = "https://finance.sina.com.cn/"
QUOTE_URL = "https://hq.sinajs.cn/list="


def _prefix(code: str) -> str:
    c = code.strip().zfill(6)[-6:]
    if c.startswith("6"):
        return f"sh{c}"
    if c.startswith("8") or c.startswith("4"):
        return f"bj{c}"
    return f"sz{c}"


def fetch_sina_quotes(codes: list[str], timeout: float = 3.0) -> list[SinaQuote]:
    if not codes:
        return []
    symbols = [_prefix(c) for c in codes]
    url = QUOTE_URL + ",".join(symbols)
    req = urllib.request.Request(url, headers={
        "User-Agent": UA, "Referer": REFERER,
    })
    resp = urllib.request.urlopen(req, timeout=timeout)
    body = resp.read().decode("gbk", errors="replace")
    return [_parse(line, codes) for line in body.strip().split(";") if (q := _parse(line, codes)) and q.code in set(codes)]


def fetch_one_sina(code: str, timeout: float = 3.0) -> SinaQuote | None:
    results = fetch_sina_quotes([code], timeout=timeout)
    return results[0] if results else None


def _parse(line: str, expected_codes: list[str]) -> SinaQuote | None:
    if '="' not in line:
        return None
    prefix = "hq_str_"
    if prefix not in line:
        return None
    symbol = line.split(prefix, 1)[1].split("=", 1)[0]
    raw = line.split('="', 1)[1].rstrip('"')
    parts = raw.split(",")
    if len(parts) < 32 or not parts[0]:
        return None

    # normalize code: remove sh/sz/bj prefix
    code = symbol[2:] if len(symbol) > 2 else symbol

    price = _f(parts[3])
    pre_close = _f(parts[2])
    change_pct = round((price - pre_close) / pre_close * 100, 2) if price and pre_close and pre_close > 0 else None

    return SinaQuote(
        code=code,
        name=parts[0],
        price=price,
        pre_close=pre_close,
        open=_f(parts[1]),
        high=_f(parts[4]),
        low=_f(parts[5]),
        change_pct=change_pct,
        volume=_i(parts[8]),
        amount=_f(parts[9]),
        bid1=_f(parts[6]),
        bid_vol1=_i(parts[10]) // 100 if len(parts) > 10 else 0,
        ask1=_f(parts[7]),
        ask_vol1=_i(parts[20]) // 100 if len(parts) > 20 else 0,
        timestamp=time.time(),
    )


def _f(value: str | None) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _i(value: str | None) -> int:
    if value is None or value == "":
        return 0
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0
