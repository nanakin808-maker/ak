"""
Direct eastmoney HTTP adapters for v2 realtime scan.
No old-system subprocess. No akshare. No pytdx. No requests.
Fields confirmed by scripts/validate_external_sources.py.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from datetime import datetime
from typing import Any

from app.services.provider_bridge_service import ProviderFetchResult

EASTMONEY_PROXY_ENV = "ASTOCK_EASTMONEY_PROXY"

_LIMIT_POOL_URL = "https://push2ex.eastmoney.com/getTopicZTPool"
_OPEN_BOARD_URL = "https://push2ex.eastmoney.com/getTopicZBPool"
_SPEED_RANK_URL = "https://push2.eastmoney.com/api/qt/clist/get"
_QUOTE_URL = "https://push2.eastmoney.com/api/qt/stock/get"

_HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Referer": "https://quote.eastmoney.com/",
}


def _fetch_json(url: str, params: dict[str, str] | None = None) -> dict[str, Any]:
    """HTTP GET via urllib, return parsed JSON."""
    if params:
        qs = "&".join(f"{k}={urllib.request.quote(str(v))}" for k, v in params.items())
        full_url = f"{url}?{qs}"
    else:
        full_url = url
    req = urllib.request.Request(full_url, headers=_HEADERS)
    proxy = os.environ.get(EASTMONEY_PROXY_ENV, "")
    if proxy:
        handler = urllib.request.ProxyHandler({"http": proxy, "https": proxy})
        opener = urllib.request.build_opener(handler)
        resp = opener.open(req, timeout=10)
    else:
        resp = urllib.request.urlopen(req, timeout=10)
    return json.loads(resp.read().decode())


def fetch_eastmoney_limit_pool(trading_date: str) -> ProviderFetchResult:
    """Fetch 涨停池 + 炸板池. Returns normalized rows."""
    all_rows: list[dict[str, Any]] = []

    for pool, url, params in [
        ("limit_up", _LIMIT_POOL_URL, {"ut": "7eea3edcaed734bea9cbfc24409ed989", "dpt": "wz.ztzt", "Pageindex": "0", "pagesize": "10000", "sort": "fbt:asc", "date": trading_date}),
        ("open_board", _OPEN_BOARD_URL, {"ut": "7eea3edcaed734bea9cbfc24409ed989", "dpt": "wz.ztzt", "Pageindex": "0", "pagesize": "5000", "sort": "fbt:asc", "date": trading_date}),
    ]:
        data = _fetch_json(url, params)
        pool_data = ((data.get("data") or {}).get("pool") or [])
        for row in pool_data:
            stats = row.get("zttj") if isinstance(row.get("zttj"), dict) else {}
            all_rows.append({
                "code": str(row.get("c", "")).zfill(6)[-6:],
                "name": str(row.get("n", "")),
                "pool": pool,
                "price": _float_or_none(row.get("p")),
                "change_pct": _float_or_none(row.get("zdp")),
                "first_limit_time": str(row.get("fbt", "") or ""),
                "last_limit_time": str(row.get("lbt", "") or ""),
                "open_count": _int_or_none(row.get("oc")) or 0,
                "seal_amount": _float_or_none(row.get("ma")) if row.get("ma") else (_float_or_none(row.get("se")) if row.get("se") else None),
                "streak": int(stats.get("zs", 0)) if stats else None,
                "industry": str(row.get("hybk", "") or ""),
                "reason": str(row.get("zdzy", "") or row.get("zy", "") or ""),
                "source": "eastmoney_limit_pool",
                "raw_json": json.dumps(row, ensure_ascii=False),
            })

    return ProviderFetchResult(
        data={"rows": all_rows},
        source_trading_date=trading_date,
        source_updated_at=datetime.utcnow(),
    )


def fetch_eastmoney_speed_rank(trading_date: str) -> ProviderFetchResult:
    """Fetch 涨速榜. Returns normalized rows."""
    params = {
        "f12": "1", "f13": "1", "f14": "3",
        "fields": "f12,f14,f3,f2,f4,f5,f6,f7,f15,f16,f17,f18",
        "po": "1", "pz": "30", "pn": "1", "np": "1", "fltt": "2",
        "invt": "2", "fs": "m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23,m:0+t:81+s:2048",
        "stat": "1",
    }
    data = _fetch_json(_SPEED_RANK_URL, params)
    items = ((data.get("data") or {}).get("diff") or [])
    rows: list[dict[str, Any]] = []
    for item in items:
        rows.append({
            "code": str(item.get("f12", "")).zfill(6)[-6:],
            "name": str(item.get("f14", "")),
            "price": _float_or_none(item.get("f2")),
            "change_pct": _float_or_none(item.get("f3")),
            "speed_pct": _float_or_none(item.get("f7")),
            "volume": _float_or_none(item.get("f17")),
            "amount": _float_or_none(item.get("f6")),
            "source": "eastmoney_speed_rank",
            "raw_json": json.dumps(item, ensure_ascii=False),
        })
    return ProviderFetchResult(
        data={"rows": rows},
        source_trading_date=trading_date,
        source_updated_at=datetime.utcnow(),
    )


def fetch_eastmoney_quote_batch(codes: list[str], trading_date: str) -> ProviderFetchResult:
    """Fetch price/change_pct only. seal_confidence=insufficient always."""
    rows: list[dict[str, Any]] = []
    for code in codes:
        try:
            clean = code.strip().zfill(6)[-6:]
            secid = f"1.{clean}" if clean.startswith("6") else f"0.{clean}"
            fields = "f43,f44,f45,f46,f47,f48,f57,f58,f60,f168,f169,f170,f171,f116,f117"
            data = _fetch_json(f"{_QUOTE_URL}?secid={secid}&fields={fields}")
            data = data.get("data") or {}
            if not data:
                continue
            rows.append({
                "code": clean,
                "price": _float_or_none(data.get("f43")),
                "pre_close": _float_or_none(data.get("f60")),
                "open": _float_or_none(data.get("f44")),
                "high": _float_or_none(data.get("f45")),
                "low": _float_or_none(data.get("f46")),
                "volume": _float_or_none(data.get("f47")),
                "amount": _float_or_none(data.get("f48")),
                "change_pct": _float_or_none(data.get("f170")) if data.get("f170") is not None else _float_or_none(data.get("f169")),
                "bid_vol1": None,
                "ask_vol1": None,
                "seal_confidence": "insufficient",
                "source": "eastmoney_quote",
                "raw_json": json.dumps(data, ensure_ascii=False),
            })
        except Exception:
            pass
    return ProviderFetchResult(
        data={"rows": rows},
        source_trading_date=trading_date,
        source_updated_at=datetime.utcnow(),
    )


def _float_or_none(value) -> float | None:
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None


def _int_or_none(value) -> int | None:
    try:
        return None if value is None else int(float(value))
    except (TypeError, ValueError):
        return None
