"""
Eastmoney stock metadata (股票元数据) — v2 native HTTP provider.

URL: push2.eastmoney.com/api/qt/stock/get
Returns float_share, float_market_value, total_share, industry, listing_date.
"""

from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass
from typing import Any

UA = "Mozilla/5.0"
META_URL = "https://push2.eastmoney.com/api/qt/stock/get"


@dataclass(slots=True)
class StockMeta:
    code: str
    name: str = ""
    latest_price: float | None = None
    total_share: float | None = None
    float_share: float | None = None
    total_market_value: float | None = None
    float_market_value: float | None = None
    industry: str = ""


def fetch_stock_meta(code: str, timeout: float = 5.0) -> dict[str, Any]:
    """Returns v1-compatible stock_meta dict."""
    cc = code.strip().zfill(6)[-6:]
    secid = f"1.{cc}" if cc.startswith("6") else f"0.{cc}"

    url = (
        f"{META_URL}?secid={secid}"
        f"&fields=f57,f58,f43,f84,f85,f116,f117,f127"
        f"&ut=fa5fd1943c7b386f172d6893dbfb2dc6"
    )
    req = urllib.request.Request(url, headers={
        "User-Agent": UA, "Referer": "https://quote.eastmoney.com/",
    })
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        data = json.loads(resp.read().decode()).get("data") or {}
    except Exception:
        return {"code": cc, "status": "error", "source": "eastmoney_stock_meta"}

    if not data:
        return {"code": cc, "status": "empty", "source": "eastmoney_stock_meta"}

    total_share = _f(data.get("f84"))
    float_share = _f(data.get("f85"))
    price = _f(data.get("f43"))
    total_mv = round(total_share * price, 2) if total_share and price else None
    float_mv = round(float_share * price, 2) if float_share and price else None

    return {
        "code": cc,
        "name": str(data.get("f58", "")),
        "latest_price": price,
        "total_share": total_share,
        "float_share": float_share,
        "total_market_value": total_mv,
        "float_market_value": float_mv,
        "total_market_value_yi": round(total_mv / 1e8, 2) if total_mv else None,
        "float_market_value_yi": round(float_mv / 1e8, 2) if float_mv else None,
        "industry": str(data.get("f127", "") or data.get("f116", "") or ""),
        "listing_date": str(data.get("f117", "") or ""),
        "source": "eastmoney_stock_meta",
        "status": "ready",
    }


def _f(v) -> float | None:
    try:
        return None if v is None else float(v)
    except (TypeError, ValueError):
        return None
