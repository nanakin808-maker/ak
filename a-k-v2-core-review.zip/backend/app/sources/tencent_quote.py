"""
Tencent real-time quote provider (qt.gtimg.cn).

Provides full 5-level orderbook (bid1-5, ask1-5 with volumes).
Verified: bid_vol1 present even during CLOSED session.
Seal detection: when bid1 == limit_up_price and bid_vol1 > 0, stock is sealed.

Source: https://qt.gtimg.cn/q={prefix}{code}
Fields: ~0 name, ~1 code, ~3 price, ~4 pre_close, ~9 bid1, ~10 bid_vol1,
        ~19 ask1, ~20 ask_vol1, ~32 change_pct, ~33 high, ~34 low,
        ~37 amount(万), ~47 limit_up_price, ~48 limit_down_price
"""

from __future__ import annotations

import json
import time
import urllib.request
from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class TencentQuote:
    code: str
    name: str
    price: float | None
    pre_close: float | None
    open: float | None
    high: float | None
    low: float | None
    change_pct: float | None
    volume: int = 0
    amount: float | None = None
    limit_up: float | None = None
    limit_down: float | None = None
    bid1: float | None = None
    bid_vol1: int = 0
    bid2: float | None = None
    bid_vol2: int = 0
    bid3: float | None = None
    bid_vol3: int = 0
    bid4: float | None = None
    bid_vol4: int = 0
    bid5: float | None = None
    bid_vol5: int = 0
    ask1: float | None = None
    ask_vol1: int = 0
    ask2: float | None = None
    ask_vol2: int = 0
    ask3: float | None = None
    ask_vol3: int = 0
    ask4: float | None = None
    ask_vol4: int = 0
    ask5: float | None = None
    ask_vol5: int = 0
    source: str = "tencent"
    timestamp: float = 0.0


UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"
QUOTE_URL = "https://qt.gtimg.cn/q="


def _prefix(code: str) -> str:
    c = code.strip().zfill(6)[-6:]
    if c.startswith("6"):
        return f"sh{c}"
    if c.startswith("8") or c.startswith("4"):
        return f"bj{c}"
    return f"sz{c}"


def fetch_tencent_quotes(codes: list[str], timeout: float = 3.0) -> list[TencentQuote]:
    if not codes:
        return []
    symbols = [_prefix(c) for c in codes]
    url = QUOTE_URL + ",".join(symbols)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    resp = urllib.request.urlopen(req, timeout=timeout)
    body = resp.read().decode("gbk", errors="replace")
    return [_parse(line) for line in body.strip().split(";") if (q := _parse(line)) and q.code in set(codes)]


def fetch_one_tencent(code: str, timeout: float = 3.0) -> TencentQuote | None:
    results = fetch_tencent_quotes([code], timeout=timeout)
    return results[0] if results else None


def _parse(line: str) -> TencentQuote | None:
    if '="' not in line:
        return None
    raw = line.split('="', 1)[1].rstrip('"')
    parts = raw.split("~")
    if len(parts) < 50:
        return None
    return TencentQuote(
        code=parts[2],
        name=parts[1],
        price=_f(parts[3]),
        pre_close=_f(parts[4]),
        open=_f(parts[5]),
        high=_f(parts[33]) if len(parts) > 33 else None,
        low=_f(parts[34]) if len(parts) > 34 else None,
        change_pct=_f(parts[32]) if len(parts) > 32 else None,
        volume=_i(parts[6]),
        amount=_f(parts[37]) * 10000 if len(parts) > 37 and _f(parts[37]) else None,
        limit_up=_f(parts[47]) if len(parts) > 47 else None,
        limit_down=_f(parts[48]) if len(parts) > 48 else None,
        bid1=_f(parts[9]),
        bid_vol1=_i(parts[10]),
        bid2=_f(parts[11]),
        bid_vol2=_i(parts[12]),
        bid3=_f(parts[13]),
        bid_vol3=_i(parts[14]),
        bid4=_f(parts[15]),
        bid_vol4=_i(parts[16]),
        bid5=_f(parts[17]),
        bid_vol5=_i(parts[18]),
        ask1=_f(parts[19]),
        ask_vol1=_i(parts[20]),
        ask2=_f(parts[21]),
        ask_vol2=_i(parts[22]),
        ask3=_f(parts[23]),
        ask_vol3=_i(parts[24]),
        ask4=_f(parts[25]),
        ask_vol4=_i(parts[26]),
        ask5=_f(parts[27]),
        ask_vol5=_i(parts[28]),
        timestamp=time.time(),
    )


def _f(value: str | None) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _i(value: str | None) -> int:
    if value is None or value == "":
        return 0
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0
