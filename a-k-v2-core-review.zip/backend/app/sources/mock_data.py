"""
Mock data generators — produce realistic fake data matching real API formats.
Used by pytest tests to simulate full scan pipeline without external APIs.
"""

from __future__ import annotations

import random
from typing import Any


def mock_speed_rank() -> list[dict[str, Any]]:
    """Simulate eastmoney speed_rank API response."""
    return [
        {"code": "002108", "name": "沧州明珠", "price": 6.44, "change_pct": 10.09,
         "speed_pct": 2.1, "source": "mock_sr"},
        {"code": "600360", "name": "*ST华微", "price": 3.21, "change_pct": 3.2,
         "speed_pct": 0.8, "source": "mock_sr"},
        {"code": "000001", "name": "平安银行", "price": 11.28, "change_pct": 4.5,
         "speed_pct": 0.5, "source": "mock_sr"},
        {"code": "300750", "name": "宁德时代", "price": 446.6, "change_pct": 8.2,
         "speed_pct": 1.5, "source": "mock_sr"},
        {"code": "600519", "name": "贵州茅台", "price": 1363.0, "change_pct": 1.2,
         "speed_pct": 0.3, "source": "mock_sr"},
    ]


def mock_shortline() -> list[dict[str, Any]]:
    """Simulate eastmoney shortline API. Uses DECIMAL format (0.1009 = 10.09%)."""
    return [
        {"c": "002108", "n": "沧州明珠", "t": 8201, "tm": "093015",
         "i": "0.1009,6.44"},
        {"c": "002108", "n": "沧州明珠", "t": 4, "tm": "093201",
         "i": "6.44,265000,0.1009"},
        {"c": "300604", "n": "长川科技", "t": 8201, "tm": "093500",
         "i": "0.085,210.0"},
        {"c": "300604", "n": "长川科技", "t": 8201, "tm": "093500",
         "i": "0.085,210.0"},  # duplicate event_key
        {"c": "600869", "n": "远东股份", "t": 16, "tm": "094500",
         "i": "20.82,0.0998"},
        {"c": "603063", "n": "禾望电气", "t": 4, "tm": "100000",
         "i": "56.65,15000,0.10"},
        {"c": "605369", "n": "拱东医疗", "t": 8201, "tm": "101500",
         "i": "0.075,22.5"},
        {"c": "688146", "n": "中船特气", "t": 16, "tm": "102000",
         "i": "45.0,0.055"},
    ]


def mock_limit_pool() -> list[dict[str, Any]]:
    """Simulate limit_pool API: 5 limit_up + 2 open_board."""
    return [
        {"pool": "limit_up", "code": "002108", "name": "沧州明珠",
         "price": 6.44, "change_pct": 10.09, "first_limit_time": "09:35:00",
         "last_limit_time": "09:35:00", "open_count": 0, "seal_amount": 265000,
         "streak": 1, "industry": "塑料", "reason": "化工板块大涨",
         "source": "mock_lp"},
        {"pool": "limit_up", "code": "300604", "name": "长川科技",
         "price": 218.41, "change_pct": 20.0, "first_limit_time": "09:40:00",
         "last_limit_time": "10:30:00", "open_count": 2, "seal_amount": 8000,
         "streak": 3, "industry": "半导体", "reason": "半导体概念",
         "source": "mock_lp"},
        {"pool": "limit_up", "code": "603063", "name": "禾望电气",
         "price": 56.65, "change_pct": 10.0, "first_limit_time": "10:00:00",
         "last_limit_time": "10:00:00", "open_count": 0, "seal_amount": 15000,
         "streak": 1, "industry": "风电设备", "reason": "风电政策利好",
         "source": "mock_lp"},
        {"pool": "limit_up", "code": "605369", "name": "拱东医疗",
         "price": 22.5, "change_pct": 5.49, "first_limit_time": "10:15:00",
         "last_limit_time": "10:15:00", "open_count": 0, "seal_amount": 5000,
         "streak": 1, "industry": "医疗器械", "reason": "",
         "source": "mock_lp"},
        {"pool": "limit_up", "code": "688146", "name": "中船特气",
         "price": 45.0, "change_pct": 5.5, "first_limit_time": "10:20:00",
         "last_limit_time": "10:20:00", "open_count": 0, "seal_amount": 3000,
         "streak": 1, "industry": "船舶制造", "reason": "",
         "source": "mock_lp"},
        {"pool": "open_board", "code": "600869", "name": "远东股份",
         "price": 20.82, "change_pct": 9.98, "first_limit_time": "09:45:00",
         "last_limit_time": "09:50:00", "open_count": 1, "seal_amount": 0,
         "streak": 0, "industry": "电网设备", "reason": "",
         "source": "mock_lp"},
        {"pool": "open_board", "code": "688146", "name": "中船特气",
         "price": 43.5, "change_pct": 3.2, "first_limit_time": "",
         "last_limit_time": "", "open_count": 1, "seal_amount": 0,
         "streak": 0, "industry": "船舶制造", "reason": "",
         "source": "mock_lp"},
    ]


def mock_tencent_quotes(codes: list[str]) -> list[dict[str, Any]]:
    """Simulate Tencent quote API. Matches format: {code, name, price, bid1, bid_vol1, ask1, ask_vol1, limit_up, change_pct, source}."""
    quotes = []
    for c in codes:
        c = str(c).strip().zfill(6)[-6:]
        if c == "002108":
            quotes.append({"code": c, "name": "沧州明珠", "price": 6.44,
                "change_pct": 10.09, "limit_up": 6.44,
                "bid1": 6.44, "bid_vol1": 265000, "ask1": 0.0, "ask_vol1": 0,
                "source": "mock"})
        elif c == "300604":
            quotes.append({"code": c, "name": "长川科技", "price": 218.41,
                "change_pct": 20.0, "limit_up": 218.41,
                "bid1": 218.41, "bid_vol1": 8000, "ask1": 0.0, "ask_vol1": 0,
                "source": "mock"})
        elif c == "600869":
            quotes.append({"code": c, "name": "远东股份", "price": 20.5,
                "change_pct": 8.5, "limit_up": 20.82,
                "bid1": 20.50, "bid_vol1": 500, "ask1": 20.51, "ask_vol1": 2000,
                "source": "mock"})
        elif c == "603063":
            quotes.append({"code": c, "name": "禾望电气", "price": 56.65,
                "change_pct": 10.0, "limit_up": 56.65,
                "bid1": 56.65, "bid_vol1": 15000, "ask1": 0.0, "ask_vol1": 0,
                "source": "mock"})
        else:
            quotes.append({"code": c, "name": f"股票{c}", "price": 10.0,
                "change_pct": 2.0, "limit_up": 11.0,
                "bid1": 10.0, "bid_vol1": 100, "ask1": 10.01, "ask_vol1": 200,
                "source": "mock"})
    return quotes


def mock_stock_boards(code: str) -> list[Any]:
    """Return mock StockBoard list matching v2 format."""
    from app.sources.stock_boards import StockBoard
    boards = [
        StockBoard("pt0001", "半导体", 6.08, "plate", "mock"),
        StockBoard("pt0002", "融资融券", 1.5, "plate", "mock"),
        StockBoard("pt0003", "电子化学品", 5.27, "plate", "mock"),
        StockBoard("pt0004", "深股通", 0.5, "plate", "mock"),
    ]
    return boards[:random.randint(3, 4)]


def mock_board_members(board_code: str, limit: int = 20) -> list[Any]:
    """Return mock BoardMember list."""
    from app.sources.board_members import BoardMember
    members = []
    for i in range(min(limit, 5)):
        members.append(BoardMember(
            code=f"60{i:04d}", name=f"成分股{i}",
            price=10.0 + i, change_pct=5.0 - i, volume=10000 * (i + 1),
        ))
    return members


def mock_daily_kline(code: str, limit: int = 250) -> list[Any]:
    """Return mock DailyBar list with enough data for technical scoring."""
    from app.sources.daily_kline import DailyBar
    bars = []
    base = 10.0
    for i in range(limit):
        y = 2025 + i // 250
        m = (i % 250) // 21 + 1
        d = (i % 250) % 21 + 1
        date_str = f"{y:04d}-{m:02d}-{d:02d}"
        o = base + i * 0.02
        bars.append(DailyBar(
            date=date_str, open=o, high=o * 1.02, low=o * 0.98,
            close=o * 1.01, volume=50000 + i * 100, source="mock",
        ))
    return bars


def mock_fund_flow(code: str) -> dict[str, Any]:
    """Return v1-compatible fund_flow dict."""
    return {
        "status": "ready", "source": "mock_fund_flow",
        "code": code, "count": 20,
        "latest": {"main_net_inflow": 5000000, "main_net_inflow_pct": 8.5},
        "summary": {"main_net_inflow_3d_yi": 0.15, "positive_main_days_5d": 3},
        "rows": [{"date": f"202605{i:02d}", "main_net_inflow": 5000000 + i * 100000,
                   "main_net_inflow_pct": 5.0 + i * 0.5} for i in range(1, 21)],
    }


def mock_stock_meta(code: str) -> dict[str, Any]:
    """Return v1-compatible stock_meta dict."""
    return {
        "code": code, "name": f"股票{code}", "status": "ready",
        "float_share": 1_000_000_000, "float_market_value": 10_000_000_000,
        "float_market_value_yi": 10.0, "total_share": 2_000_000_000,
        "total_market_value": 20_000_000_000, "source": "mock_meta",
    }
