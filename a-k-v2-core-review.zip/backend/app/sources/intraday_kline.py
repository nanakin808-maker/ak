"""
Intraday minute K-line — Tencent primary, Sina fallback.

Tencent: ifzq.gtimg.cn/appstock/app/kline/mkline?param=sh600519,m5,,240
  Returns 5-min bars for current trading day.
Sina: same endpoint as daily, scale=5 (5-min bars).
"""

from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass

UA = "Mozilla/5.0"


@dataclass(slots=True)
class MinuteBar:
    time: str       # "HH:MM" or "YYYYMMDDHHMM"
    open: float
    high: float
    low: float
    close: float
    volume: int
    source: str = ""


def _prefix(code: str) -> str:
    c = code.strip().zfill(6)[-6:]
    return f"sh{c}" if c.startswith("6") else f"sz{c}"


def fetch_intraday_kline(code: str, limit: int = 240, timeout: float = 5.0) -> list[MinuteBar]:
    """Fetch 5-min intraday bars. Tencent first, Sina fallback."""
    bars = _fetch_tencent_minute(code, limit, timeout)
    if bars:
        return bars
    return _fetch_sina_minute(code, limit, timeout)


def _fetch_tencent_minute(code: str, limit: int, timeout: float) -> list[MinuteBar]:
    prefix = _prefix(code)
    url = (
        f"https://ifzq.gtimg.cn/appstock/app/kline/mkline?"
        f"param={prefix},m5,,{limit}"
    )
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        data = json.loads(resp.read().decode())
    except Exception:
        return []

    days = data.get("data", {}).get(prefix, {})
    bars = days.get("m5") or []
    if not bars:
        return []

    results = []
    for row in bars:
        if len(row) < 6:
            continue
        # Format: [YYYYMMDDHHMM, open, close, high, low, volume, ...]
        t = str(row[0])
        if len(t) >= 12:
            t = f"{t[8:10]}:{t[10:12]}"
        results.append(MinuteBar(
            time=t, open=float(row[1]), close=float(row[2]),
            high=float(row[3]), low=float(row[4]),
            volume=int(float(row[5])), source="tencent",
        ))
    return results


def _fetch_sina_minute(code: str, limit: int, timeout: float) -> list[MinuteBar]:
    prefix = _prefix(code)
    url = (
        f"https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/"
        f"CN_MarketData.getKLineData?symbol={prefix}&scale=5&ma=no&datalen={limit}"
    )
    req = urllib.request.Request(url, headers={
        "User-Agent": UA, "Referer": "https://finance.sina.com.cn/",
    })
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        data = json.loads(resp.read().decode())
    except Exception:
        return []

    if not isinstance(data, list):
        return []
    results = []
    for row in data:
        t = str(row.get("day", ""))
        if " " in t:
            t = t.split(" ")[1][:5]
        results.append(MinuteBar(
            time=t, open=float(row.get("open", 0)),
            high=float(row.get("high", 0)), low=float(row.get("low", 0)),
            close=float(row.get("close", 0)),
            volume=int(float(row.get("volume", 0))), source="sina",
        ))
    return results
