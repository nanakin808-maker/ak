"""
Eastmoney fund flow (资金流向) — v2 native HTTP provider.

URL: push2his.eastmoney.com/api/qt/stock/fflow/daykline/get
Returns daily main_net_inflow, super_large/large/medium/small breakdowns.
"""

from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass
from typing import Any

UA = "Mozilla/5.0"
FUND_FLOW_URL = "https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get"


@dataclass(slots=True)
class FundFlowDay:
    date: str
    main_net_inflow: float | None       # 主力净流入(元)
    main_net_inflow_pct: float | None   # 主力净流入占比(%)
    super_large_net_inflow: float | None
    super_large_net_inflow_pct: float | None
    large_net_inflow: float | None
    large_net_inflow_pct: float | None
    medium_net_inflow: float | None
    medium_net_inflow_pct: float | None
    small_net_inflow: float | None
    small_net_inflow_pct: float | None


def fetch_fund_flow(code: str, limit: int = 20, timeout: float = 5.0) -> dict[str, Any]:
    """Returns v1-compatible fund_flow dict with latest, summary, rows."""
    cc = code.strip().zfill(6)[-6:]
    secid = f"1.{cc}" if cc.startswith("6") else f"0.{cc}"

    url = (
        f"{FUND_FLOW_URL}?lmt=0&klt=101&secid={secid}"
        f"&fields1=f1,f2,f3,f7"
        f"&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64,f65"
        f"&ut=b2884a393a59ad64002292a3e90d46a5"
    )
    req = urllib.request.Request(url, headers={
        "User-Agent": UA, "Referer": "https://quote.eastmoney.com/",
    })
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        data = json.loads(resp.read().decode())
    except Exception:
        return {"status": "error", "code": cc, "source": "eastmoney_fund_flow"}

    klines = (data.get("data") or {}).get("klines") or []
    rows: list[FundFlowDay] = []
    for line in klines[-limit:]:
        p = line.split(",")
        if len(p) < 11:
            continue
        rows.append(FundFlowDay(
            date=p[0],
            main_net_inflow=_f(p[1]),
            main_net_inflow_pct=_f(p[2]),
            super_large_net_inflow=_f(p[3]),
            super_large_net_inflow_pct=_f(p[4]),
            large_net_inflow=_f(p[5]),
            large_net_inflow_pct=_f(p[6]),
            medium_net_inflow=_f(p[7]),
            medium_net_inflow_pct=_f(p[8]),
            small_net_inflow=_f(p[9]),
            small_net_inflow_pct=_f(p[10]),
        ))
    if not rows:
        return {"status": "empty", "code": cc, "source": "eastmoney_fund_flow"}

    latest = rows[-1]
    main_3d = sum((r.main_net_inflow or 0) / 1e8 for r in rows[-3:])
    positive_days = sum(1 for r in rows[-5:] if (r.main_net_inflow or 0) > 0)

    return {
        "status": "ready", "source": "eastmoney_fund_flow",
        "code": cc, "count": len(rows),
        "latest": {
            "main_net_inflow": latest.main_net_inflow,
            "main_net_inflow_pct": latest.main_net_inflow_pct,
            "super_large_net_inflow": latest.super_large_net_inflow,
            "large_net_inflow": latest.large_net_inflow,
            "medium_net_inflow": latest.medium_net_inflow,
            "small_net_inflow": latest.small_net_inflow,
        },
        "summary": {
            "main_net_inflow_3d_yi": round(main_3d, 3),
            "positive_main_days_5d": positive_days,
        },
        "rows": [{
            "date": r.date, "main_net_inflow": r.main_net_inflow,
            "main_net_inflow_pct": r.main_net_inflow_pct,
        } for r in rows],
    }


def _f(v) -> float | None:
    try:
        return None if v is None or v == "-" else float(v)
    except (TypeError, ValueError):
        return None
