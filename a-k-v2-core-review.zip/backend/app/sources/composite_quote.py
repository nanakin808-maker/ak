"""
Composite quote provider: pytdx → tencent → sina → eastmoney.
Matches v1 CompositeProvider fallback chain. Each source fails independently.
"""

from __future__ import annotations

import json
import urllib.request
from typing import Any

UA = "Mozilla/5.0"
API_TIMEOUT = 3.0  # per-source timeout


def _f(v) -> float | None:
    try:
        return None if v is None else float(v)
    except (TypeError, ValueError):
        return None


# ── tencent ────────────────────────────────────────────

def _fetch_tencent(codes: list[str]) -> list[dict]:
    prefixes = []
    for c in codes:
        cc = c.strip().zfill(6)[-6:]
        prefixes.append(f"sh{cc}" if cc.startswith("6") else f"sz{cc}")
    url = f"https://qt.gtimg.cn/q={','.join(prefixes)}"
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    resp = urllib.request.urlopen(req, timeout=API_TIMEOUT)
    body = resp.read().decode("gbk", errors="replace")
    results = []
    for line in body.strip().split(";"):
        if '="' not in line:
            continue
        raw = line.split('="', 1)[1].rstrip('"')
        parts = raw.split("~")
        if len(parts) < 50:
            continue
        results.append({
            "code": parts[2], "name": parts[1],
            "price": _f(parts[3]), "pre_close": _f(parts[4]),
            "change_pct": _f(parts[32]) if len(parts) > 32 else None,
            "limit_up": _f(parts[47]) if len(parts) > 47 else None,
            "bid1": _f(parts[9]),
            "bid_vol1": int(_f(parts[10]) or 0),
            "ask1": _f(parts[19]),
            "ask_vol1": int(_f(parts[20]) or 0),
            "source": "tencent",
        })
    return results


# ── sina ───────────────────────────────────────────────

def _fetch_sina(codes: list[str]) -> list[dict]:
    symbols = []
    for c in codes:
        cc = c.strip().zfill(6)[-6:]
        symbols.append(f"sh{cc}" if cc.startswith("6") else f"sz{cc}")
    url = f"https://hq.sinajs.cn/list={','.join(symbols)}"
    req = urllib.request.Request(url, headers={
        "User-Agent": UA, "Referer": "https://finance.sina.com.cn/",
    })
    resp = urllib.request.urlopen(req, timeout=API_TIMEOUT)
    body = resp.read().decode("gbk", errors="replace")
    results = []
    for line in body.strip().split(";"):
        if '="' not in line:
            continue
        raw = line.split('="', 1)[1].rstrip('"')
        parts = raw.split(",")
        if len(parts) < 32 or not parts[0]:
            continue
        pre_close = _f(parts[2])
        price = _f(parts[3])
        chg = round((price - pre_close) / pre_close * 100, 2) if price and pre_close and pre_close > 0 else None
        results.append({
            "code": c.strip().zfill(6)[-6:], "name": parts[0],
            "price": price, "pre_close": pre_close,
            "change_pct": chg,
            "bid1": _f(parts[6]),
            "bid_vol1": int(_f(parts[10]) or 0) // 100,
            "ask1": _f(parts[7]),
            "ask_vol1": int(_f(parts[20]) or 0) // 100,
            "source": "sina",
        })
    return results


# ── eastmoney ──────────────────────────────────────────

def _fetch_eastmoney(codes: list[str]) -> list[dict]:
    results = []
    for code in codes:
        cc = code.strip().zfill(6)[-6:]
        secid = f"1.{cc}" if cc.startswith("6") else f"0.{cc}"
        url = (
            f"https://push2.eastmoney.com/api/qt/stock/get?"
            f"ut=fa5fd1943c7b386f172d6893dbfb2dc6&invt=2&fltt=2"
            f"&fields=f43,f57,f58,f60,f169,f170&secid={secid}"
        )
        req = urllib.request.Request(url, headers={
            "User-Agent": UA, "Referer": "https://quote.eastmoney.com/",
        })
        try:
            resp = urllib.request.urlopen(req, timeout=API_TIMEOUT)
            data = json.loads(resp.read().decode()).get("data") or {}
            price = _f(data.get("f43"))
            if not price:
                continue
            pre_close = _f(data.get("f60"))
            results.append({
                "code": cc, "name": str(data.get("f58", "")),
                "price": price, "pre_close": pre_close,
                "change_pct": _f(data.get("f170")) or _f(data.get("f169")),
                "source": "eastmoney",
            })
        except Exception:
            continue
    return results


# ── composite ──────────────────────────────────────────

def fetch_composite_quotes(codes: list[str]) -> list[dict[str, Any]]:
    """Fallback chain: pytdx → tencent → sina → eastmoney."""
    if not codes:
        return []

    remaining = {c.strip().zfill(6)[-6:] for c in codes}
    collected: dict[str, dict] = {}

    # 1. pytdx (skip if pre_close missing — need next source for limit calc)
    try:
        from app.sources.pytdx_worker import fetch_pytdx_quotes
        for q in fetch_pytdx_quotes(list(remaining)):
            if q.get("pre_close") and q["pre_close"] > 0:
                collected[q["code"]] = q
                remaining.discard(q["code"])
    except Exception:
        pass
    if not remaining:
        return [collected[c.strip().zfill(6)[-6:]] for c in codes if c.strip().zfill(6)[-6:] in collected]

    # 2. tencent
    try:
        for q in _fetch_tencent(list(remaining)):
            if q["code"] in remaining:
                collected[q["code"]] = q
                remaining.discard(q["code"])
    except Exception:
        pass
    if not remaining:
        return [collected[c.strip().zfill(6)[-6:]] for c in codes if c.strip().zfill(6)[-6:] in collected]

    # 3. sina
    try:
        for q in _fetch_sina(list(remaining)):
            c = q["code"]
            if c in remaining:
                collected[c] = q
                remaining.discard(c)
    except Exception:
        pass
    if not remaining:
        return [collected[c.strip().zfill(6)[-6:]] for c in codes if c.strip().zfill(6)[-6:] in collected]

    # 4. eastmoney (price/change_pct only, no orderbook)
    try:
        for q in _fetch_eastmoney(list(remaining)):
            c = q["code"]
            if c in remaining:
                collected[c] = q
                remaining.discard(c)
    except Exception:
        pass

    return [collected[c.strip().zfill(6)[-6:]] for c in codes if c.strip().zfill(6)[-6:] in collected]
