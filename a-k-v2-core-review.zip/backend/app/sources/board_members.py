"""
Board members (成分股) — Eastmoney API.

Eastmoney: push2.eastmoney.com/api/qt/clist/get?fs=b:{board_code}
  Returns top stocks in a board with price, change%, volume.
  Works during trading hours. Returns empty in CLOSED session.
"""

from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass

UA = "Mozilla/5.0"


@dataclass(slots=True)
class BoardMember:
    code: str
    name: str
    price: float | None
    change_pct: float | None
    volume: int = 0
    amount: float | None = None


def fetch_board_members(
    board_code: str, limit: int = 20, timeout: float = 5.0
) -> list[BoardMember]:
    """Fetch top stocks in a board, sorted by change% desc."""
    url = (
        f"https://push2.eastmoney.com/api/qt/clist/get?"
        f"pn=1&pz={limit}&po=1&np=1&fltt=2&invt=2&fid=f3"
        f"&fs=b:{board_code}"
        f"&fields=f12,f14,f2,f3,f5,f6,f15,f16,f17"
    )
    req = urllib.request.Request(url, headers={
        "User-Agent": UA, "Referer": "https://quote.eastmoney.com/",
    })
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        data = json.loads(resp.read().decode())
    except Exception:
        return []

    items = (data.get("data") or {}).get("diff") or []
    results: list[BoardMember] = []
    for item in items:
        code = str(item.get("f12", "")).zfill(6)[-6:]
        if not code:
            continue
        results.append(BoardMember(
            code=code,
            name=str(item.get("f14", "")),
            price=_f(item.get("f2")),
            change_pct=_f(item.get("f3")),
            volume=int(_f(item.get("f5") or 0)),
            amount=_f(item.get("f6")),
        ))
    return results


def fetch_members_for_stock(
    code: str, board_codes: list[str], limit: int = 20, timeout: float = 5.0
) -> dict[str, list[BoardMember]]:
    """Fetch members for multiple boards a stock belongs to."""
    result: dict[str, list[BoardMember]] = {}
    for bc in board_codes:
        members = fetch_board_members(bc, limit=limit, timeout=timeout)
        if members:
            result[bc] = members
    return result


def _f(v) -> float | None:
    try:
        return None if v is None else float(v)
    except (TypeError, ValueError):
        return None
