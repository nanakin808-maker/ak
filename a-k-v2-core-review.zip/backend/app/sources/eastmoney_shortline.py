"""
Eastmoney shortline (短线异动) real-time push API.

Event types:
  8201 - rapid_rise      快速拉升 → PRE_CANDIDATE
  4    - limit_up_sealed 封涨停板 → promote to CORE (seal confirmed)
  16   - limit_up_opened 打开涨停板 → demote to CANDIDATE

Dedup key: {event_time}:{code}:{raw_type}:{raw_i}
Per-stock dedup: a stock can only be in one lifecycle stage at a time.
"""

from __future__ import annotations

import json
import time
import urllib.request
from dataclasses import dataclass, field
from typing import Any

UA = "Mozilla/5.0"
SHORTLINE_URL = "http://push2ex.eastmoney.com/getAllStockChanges"
SHORTLINE_UT = "7eea3edcaed734bea9cbfc24409ed989"

EVENT_TYPES: dict[int, tuple[str, str]] = {
    8201: ("rapid_rise", "快速拉升"),
    4: ("limit_up_sealed", "封涨停板"),
    16: ("limit_up_opened", "打开涨停板"),
}


@dataclass(slots=True)
class ShortlineEvent:
    event_time: str          # "HH:MM:SS"
    code: str
    name: str
    kind: str                # "rapid_rise" | "limit_up_sealed" | "limit_up_opened"
    title: str               # Chinese description
    raw_type: int            # 8201, 4, 16
    price: float | None
    change_pct: float | None
    seal_volume: int | None  # type=4 only
    source: str = "eastmoney_changes"
    raw: dict | None = None
    received_at: float = 0.0

    @property
    def dedup_key(self) -> str:
        """Composite key: event_time:code:raw_type:raw_i"""
        raw_i = str(self.raw.get("i", "")) if self.raw else ""
        return f"{self.event_time}:{self.code}:{self.raw_type}:{raw_i}"


def fetch_shortline_events(page_size: int = 50, timeout: float = 3.0) -> list[ShortlineEvent]:
    """Fetch all shortline events (8201+4+16). Returns deduplicated list."""
    url = (
        f"{SHORTLINE_URL}?type=8201,4,16"
        f"&pageindex=0&pagesize={page_size}"
        f"&ut={SHORTLINE_UT}&dpt=wzchanges"
        f"&_={int(time.time() * 1000)}"
    )
    req = urllib.request.Request(url, headers={
        "User-Agent": UA,
        "Referer": "https://quote.eastmoney.com/",
    })
    resp = urllib.request.urlopen(req, timeout=timeout)
    data = json.loads(resp.read().decode())
    items = (data.get("data") or {}).get("allstock") or []
    return [evt for item in items if (evt := _parse(item))]


def _parse(row: dict) -> ShortlineEvent | None:
    try:
        raw_type = int(row.get("t", 0))
    except (TypeError, ValueError):
        return None

    kind_title = EVENT_TYPES.get(raw_type)
    if kind_title is None:
        return None
    kind, title = kind_title

    code = str(row.get("c", "")).strip().zfill(6)[-6:]
    name = str(row.get("n", ""))
    tm = str(row.get("tm", "")).strip().zfill(6)
    event_time = f"{tm[:2]}:{tm[2:4]}:{tm[4:6]}" if len(tm) >= 6 else tm

    raw_i = str(row.get("i", ""))
    values = raw_i.split(",") if raw_i else []

    price: float | None = None
    change_pct: float | None = None
    seal_volume: int | None = None

    if raw_type == 8201:
        # i = "change_pct,price"
        if len(values) >= 2:
            change_pct = _pct(values[0])
            price = _f(values[1])
    elif raw_type == 4:
        # i = "price,seal_volume,...,change_pct"
        if len(values) >= 2:
            price = _f(values[0])
            seal_volume = _i(values[1])
            if len(values) >= 3:
                change_pct = _pct(values[-1])
    elif raw_type == 16:
        # i = "price,...,change_pct"
        if len(values) >= 1:
            price = _f(values[0])
            if len(values) >= 2:
                change_pct = _pct(values[-1])

    return ShortlineEvent(
        event_time=event_time,
        code=code,
        name=name,
        kind=kind,
        title=title,
        raw_type=raw_type,
        price=price,
        change_pct=change_pct,
        seal_volume=seal_volume,
        raw=row,
        received_at=time.time(),
    )


def _f(value: str) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _i(value: str) -> int | None:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def _pct(value: str) -> float | None:
    """API returns decimal (e.g. 0.035 = 3.5%). Convert to percentage."""
    v = _f(value)
    return round(v * 100.0, 3) if v is not None else None
