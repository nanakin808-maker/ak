"""
PyTDX quote via subprocess to old venv (only place pytdx is installed).

Returns JSON: {"ok": true, "quotes": [{code, name, price, bid1, bid_vol1, ...}]}
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

OLD_ROOT = Path(__file__).resolve().parents[3] / ".." / "a-k"
OLD_PYTHON = OLD_ROOT / ".venv" / "bin" / "python"

TDX_SCRIPT = """
import sys, json
from pytdx.hq import TdxHq_API

codes = json.loads(sys.argv[1])
servers = [
    ('180.153.18.170', 7709), ('115.238.90.165', 7709),
    ('218.75.126.9', 7709), ('60.191.117.167', 7709),
]
results = []
for host, port in servers:
    api = TdxHq_API(heartbeat=True, auto_retry=False, raise_exception=False)
    try:
        if not api.connect(host, port, time_out=3.0):
            continue
        for code in codes:
            c = code.strip().zfill(6)[-6:]
            market = 1 if c.startswith('6') else 0
            quotes = api.get_security_quotes([(market, c)])
            if quotes:
                q = quotes[0]
                results.append({
                    'code': c,
                    'name': str(q.get('name', '')),
                    'price': float(q.get('price', 0) or 0),
                    'pre_close': float(q.get('pre_close', 0) or 0),
                    'bid1': float(q.get('bid1', 0) or 0),
                    'bid_vol1': int(float(q.get('bid_vol1', 0) or 0)),
                    'ask1': float(q.get('ask1', 0) or 0),
                    'ask_vol1': int(float(q.get('ask_vol1', 0) or 0)),
                    'source': 'pytdx',
                })
        break
    except Exception:
        continue
    finally:
        try: api.disconnect()
        except: pass
print(json.dumps({'ok': True, 'quotes': results}, ensure_ascii=False))
"""


def fetch_pytdx_quotes(codes: list[str], timeout: float = 5.0) -> list[dict[str, Any]]:
    if not codes or not OLD_PYTHON.exists():
        return []
    try:
        cp = subprocess.run(
            [str(OLD_PYTHON), "-c", TDX_SCRIPT, json.dumps(codes)],
            capture_output=True, text=True, timeout=timeout,
        )
        if cp.returncode != 0:
            return []
        data = json.loads(cp.stdout)
        return data.get("quotes", []) if data.get("ok") else []
    except Exception:
        return []
