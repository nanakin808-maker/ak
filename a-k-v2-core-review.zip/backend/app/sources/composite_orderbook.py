"""
Composite orderbook provider: Tencent primary, Sina fallback.

Provides SealSourceFact for seal/open detection:
  is_sealed = (bid1 == limit_up_price AND bid_vol1 > 0)
  is_open_board = (was sealed AND now bid1 < limit_up_price)

Verified 2026-05-11 CLOSED session:
  - Tencent: bid_vol1=265,634 (封单量), ask1=0 (卖盘清空) for limit-up stocks
  - Sina: matches Tencent within 0.1%
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from app.sources.tencent_quote import TencentQuote, fetch_tencent_quotes
from app.sources.sina_orderbook import SinaQuote, fetch_sina_quotes


@dataclass(slots=True)
class OrderbookSnapshot:
    code: str
    name: str
    price: float | None
    change_pct: float | None
    pre_close: float | None
    limit_up: float | None
    limit_down: float | None
    bid1: float | None
    bid_vol1: int
    ask1: float | None
    ask_vol1: int
    bid_depth: list[dict[str, Any]] = field(default_factory=list)
    ask_depth: list[dict[str, Any]] = field(default_factory=list)
    source: str = ""
    is_sealed: bool = False
    seal_confidence: str = "insufficient"
    seal_reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code, "name": self.name,
            "price": self.price, "change_pct": self.change_pct,
            "limit_up": self.limit_up, "limit_down": self.limit_down,
            "bid1": self.bid1, "bid_vol1": self.bid_vol1,
            "ask1": self.ask1, "ask_vol1": self.ask_vol1,
            "is_sealed": self.is_sealed,
            "seal_confidence": self.seal_confidence,
            "seal_reason": self.seal_reason,
            "source": self.source,
        }


def fetch_orderbooks(codes: list[str], timeout: float = 3.0) -> list[OrderbookSnapshot]:
    """Fetch orderbook snapshots, Tencent first then Sina fallback."""
    if not codes:
        return []

    code_set = set(codes)
    results: dict[str, OrderbookSnapshot] = {}
    remaining = set(codes)

    # Try Tencent (primary)
    try:
        quotes = fetch_tencent_quotes(list(remaining), timeout=timeout)
        for q in quotes:
            snap = _from_tencent(q)
            results[q.code] = snap
            remaining.discard(q.code)
    except Exception:
        pass

    # Fallback: Sina for missing
    if remaining:
        try:
            quotes = fetch_sina_quotes(list(remaining), timeout=timeout)
            for q in quotes:
                snap = _from_sina(q)
                results[q.code] = snap
                remaining.discard(q.code)
        except Exception:
            pass

    return [results[c] for c in codes if c in results]


def fetch_one_orderbook(code: str, timeout: float = 3.0) -> OrderbookSnapshot | None:
    results = fetch_orderbooks([code], timeout=timeout)
    return results[0] if results else None


def _from_tencent(q: TencentQuote) -> OrderbookSnapshot:
    limit_up = q.limit_up
    bid1 = q.bid1
    bid_vol1 = q.bid_vol1
    ask1 = q.ask1

    is_sealed, confidence, reason = _evaluate_seal(
        price=q.price, bid1=bid1, bid_vol1=bid_vol1,
        ask1=ask1, ask_vol1=q.ask_vol1, limit_up=limit_up,
    )

    return OrderbookSnapshot(
        code=q.code, name=q.name,
        price=q.price, change_pct=q.change_pct,
        pre_close=q.pre_close, limit_up=limit_up, limit_down=q.limit_down,
        bid1=bid1, bid_vol1=bid_vol1,
        ask1=ask1, ask_vol1=q.ask_vol1,
        bid_depth=[{"price": q.bid1, "volume": q.bid_vol1},
                   {"price": q.bid2, "volume": q.bid_vol2},
                   {"price": q.bid3, "volume": q.bid_vol3}],
        ask_depth=[{"price": q.ask1, "volume": q.ask_vol1},
                   {"price": q.ask2, "volume": q.ask_vol2},
                   {"price": q.ask3, "volume": q.ask_vol3}],
        source="tencent", is_sealed=is_sealed,
        seal_confidence=confidence, seal_reason=reason,
    )


def _from_sina(q: SinaQuote) -> OrderbookSnapshot:
    is_sealed, confidence, reason = _evaluate_seal(
        price=q.price, bid1=q.bid1, bid_vol1=q.bid_vol1,
        ask1=q.ask1, ask_vol1=q.ask_vol1, limit_up=None,
    )

    return OrderbookSnapshot(
        code=q.code, name=q.name,
        price=q.price, change_pct=q.change_pct,
        pre_close=q.pre_close, limit_up=None, limit_down=None,
        bid1=q.bid1, bid_vol1=q.bid_vol1,
        ask1=q.ask1, ask_vol1=q.ask_vol1,
        source="sina", is_sealed=is_sealed,
        seal_confidence=confidence, seal_reason=reason,
    )


def _evaluate_seal(
    *,
    price: float | None,
    bid1: float | None,
    bid_vol1: int,
    ask1: float | None,
    ask_vol1: int,
    limit_up: float | None,
) -> tuple[bool, str, str]:
    if price is None or bid1 is None:
        return False, "insufficient", "no_orderbook_data"

    # Case 1: bid1 is at limit-up price with volume → sealed
    if limit_up is not None and abs(bid1 - limit_up) < 0.01 and bid_vol1 > 0:
        if ask1 is not None and ask1 > 0:
            return True, "explicit", "sealed_at_limit_with_asks"
        return True, "explicit", "sealed_at_limit_no_asks"

    # Case 2: price is at limit-up, bid1 is at limit-up with volume
    if limit_up is not None and abs(price - limit_up) < 0.01 and bid_vol1 > 0:
        if abs(bid1 - limit_up) < 0.01:
            return True, "explicit", "sealed_at_limit"
        # Bid not at limit — may be slipping
        return True, "reliable", "price_at_limit_bid_slipping"

    # Case 3: bid_vol1 > 0 but not at limit — normal trading
    if limit_up is not None and bid1 < limit_up - 0.01:
        return False, "insufficient", "not_at_limit"

    # Case 4: no limit_up from source — use heuristic
    if limit_up is None:
        if bid_vol1 > 100 and ask_vol1 == 0:
            return True, "reliable", "heuristic_zero_asks"
        if bid_vol1 > 0 and ask_vol1 > 0:
            return False, "insufficient", "normal_trading_no_limit_ref"

    return False, "insufficient", "unknown"
