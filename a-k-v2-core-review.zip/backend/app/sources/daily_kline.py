"""
Daily K-line — Tencent primary, Sina fallback.

Tencent: web.ifzq.gtimg.cn/appstock/app/fqkline/get
  Returns OHLCV + volume. Always available.
Sina: money.finance.sina.com.cn/quotes_service/api/json_v2.php
  CN_MarketData.getKLineData?scale=240
"""

from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass

UA = "Mozilla/5.0"


@dataclass(slots=True)
class DailyBar:
    date: str
    open: float
    high: float
    low: float
    close: float
    volume: int
    source: str = ""


def _prefix(code: str) -> str:
    c = code.strip().zfill(6)[-6:]
    return f"sh{c}" if c.startswith("6") else f"sz{c}"


def fetch_daily_kline(code: str, limit: int = 250, timeout: float = 5.0) -> list[DailyBar]:
    """Fetch daily K-line bars. Tencent first, Sina fallback."""
    bars = _fetch_tencent(code, limit, timeout)
    if bars:
        return bars
    return _fetch_sina(code, limit, timeout)


def _fetch_tencent(code: str, limit: int, timeout: float) -> list[DailyBar]:
    prefix = _prefix(code)
    url = (
        f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?"
        f"param={prefix},day,,,{limit},qfq"
    )
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        data = json.loads(resp.read().decode())
    except Exception:
        return []

    days = data.get("data", {}).get(prefix, {}).get("day") or \
           data.get("data", {}).get(prefix, {}).get("qfqday") or []
    if not days:
        return []

    results = []
    for row in days:
        if len(row) < 6:
            continue
        results.append(DailyBar(
            date=str(row[0]),
            open=float(row[1]), high=float(row[3]),
            low=float(row[4]), close=float(row[2]),
            volume=int(float(row[5])), source="tencent",
        ))
    return results


def _fetch_sina(code: str, limit: int, timeout: float) -> list[DailyBar]:
    prefix = _prefix(code)
    url = (
        f"https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/"
        f"CN_MarketData.getKLineData?symbol={prefix}&scale=240&ma=no&datalen={limit}"
    )
    req = urllib.request.Request(url, headers={
        "User-Agent": UA, "Referer": "https://finance.sina.com.cn/",
    })
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        data = json.loads(resp.read().decode())
    except Exception:
        return []

    if not isinstance(data, list):
        return []
    results = []
    for row in data:
        results.append(DailyBar(
            date=str(row.get("day", "")),
            open=float(row.get("open", 0)), high=float(row.get("high", 0)),
            low=float(row.get("low", 0)), close=float(row.get("close", 0)),
            volume=int(float(row.get("volume", 0))), source="sina",
        ))
    return results
