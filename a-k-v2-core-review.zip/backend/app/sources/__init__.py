"""Direct v2 external source adapters. No old-system subprocess."""
