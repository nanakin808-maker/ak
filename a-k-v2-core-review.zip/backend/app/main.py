from __future__ import annotations

import asyncio

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.router import api_router
from app.api.routes.ws_monitoring import router as ws_monitoring_router


app = FastAPI(title="A Stock Guard v2")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173", "http://127.0.0.1:5173",
        "http://localhost:5174", "http://127.0.0.1:5174",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router)
app.include_router(ws_monitoring_router)


@app.on_event("startup")
async def startup_event_bus() -> None:
    from app.realtime.event_bus import get_event_bus
    bus = get_event_bus()
    asyncio.create_task(bus._broadcast_loop())


@app.on_event("shutdown")
async def shutdown_event_bus() -> None:
    from app.realtime.event_bus import get_event_bus
    get_event_bus().publish(None)  # type: ignore[arg-type]
