"""Alert and monitoring schemas."""

from __future__ import annotations

from pydantic import BaseModel, Field


class AlertStartPayload(BaseModel):
    notify_enabled: bool = False
    interval_seconds: float | None = Field(None, ge=1.0, le=60.0)


class AlertControlResponse(BaseModel):
    ok: bool = True
    action: str
    payload: AlertStartPayload | None = None
    scanned: int | None = None


class AlertStateResponse(BaseModel):
    ok: bool = True
    running: bool
    monitor_events: int
    candidates: int
    core: int
    pre_candidates: int
