from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

from app.schemas.score import CandidateScoreDetails


VolumeStatus = Literal["pending", "monitoring", "confirmed", "failed"]
DecisionStage = Literal["watch", "candidate", "core", "rejected"]


class CandidateSummary(BaseModel):
    code: str
    name: str = ""
    price: float | None = None
    changePct: float | None = None
    technicalScore: float | None = None
    sentimentScore: float | None = None
    firstSealSentimentScore: float | None = None
    volumeScore: float | None = None
    volumeStatus: VolumeStatus = "pending"
    board: str = ""
    boardChangePct: float | None = None
    decisionStage: DecisionStage | None = None
    scoreDetails: CandidateScoreDetails | None = None
    # v2 extended fields
    stage: str | None = None
    isSealed: bool | None = None
    atLimit: bool | None = None
    openCount: int | None = None
    activeMonitoring: bool | None = None
    inactiveReason: str | None = None
    freshnessStatus: str | None = None
    asOf: str | None = None


class OpportunitiesResponse(BaseModel):
    ok: bool = True
    source: Literal["legacy", "mock", "v2_shadow"] = "mock"
    updatedAt: str
    rows: list[CandidateSummary] = Field(default_factory=list)
    error: str | None = None
    marketSession: str | None = None
    effectiveTradingDate: str | None = None
    isLiveTrading: bool = False
    dataFreshness: str | None = None


class HealthResponse(BaseModel):
    ok: bool = True
    service: str = "astock-guard-v2"
    status: Literal["ok", "degraded"] = "ok"
    updatedAt: str
    legacyConfigured: bool = False
