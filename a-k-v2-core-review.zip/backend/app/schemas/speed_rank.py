from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

from app.schemas.opportunity import VolumeStatus


class SpeedRankItem(BaseModel):
    rank: int
    code: str
    name: str
    price: float | None = None
    changePct: float | None = None
    speedPct: float | None = None
    technicalScore: float | None = None
    sentimentScore: float | None = None
    volumeScore: float | None = None
    volumeStatus: VolumeStatus = "pending"
    board: str = "--"
    boardChangePct: float | None = None
    signal: str = ""
    eventTime: str | None = None
    source: str = ""


class SpeedRankResponse(BaseModel):
    ok: bool = True
    source: Literal["legacy", "mock"] = "mock"
    updatedAt: str
    rows: list[SpeedRankItem] = Field(default_factory=list)
    error: str | None = None
