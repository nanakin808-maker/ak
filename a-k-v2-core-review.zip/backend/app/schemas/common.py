"""Shared Pydantic models."""

from __future__ import annotations

from pydantic import BaseModel, Field


class PaginationParams(BaseModel):
    limit: int = Field(200, le=500)
    offset: int = Field(0, ge=0)


class PaginatedResponse(BaseModel):
    total: int
    limit: int
    offset: int
    rows: list
