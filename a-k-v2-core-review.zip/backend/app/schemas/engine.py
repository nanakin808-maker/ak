from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


EngineStatus = Literal["idle", "running", "stopped", "error"]


class EngineState(BaseModel):
    status: EngineStatus
    running: bool
    startedAt: str | None = None
    stoppedAt: str | None = None
    resetAt: str | None = None
    message: str = ""


class EngineResponse(BaseModel):
    ok: bool = True
    state: EngineState
    summary: dict | None = None
