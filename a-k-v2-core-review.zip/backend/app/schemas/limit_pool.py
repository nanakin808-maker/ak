from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


LimitPoolStatus = Literal[
    "sealed",
    "opened",
    "resealed",
    "near_limit",
    "broken",
    "unknown",
]


class LimitPoolItem(BaseModel):
    code: str
    name: str
    price: float | None = None
    changePct: float | None = None
    status: LimitPoolStatus = "unknown"
    board: str = "--"
    boardChangePct: float | None = None
    firstSealTime: str | None = None
    lastEventTime: str | None = None
    openCount: int | None = None
    sealAmount: float | None = None
    sentimentScore: float | None = None
    firstSealSentimentScore: float | None = None
    source: str = ""


class LimitPoolResponse(BaseModel):
    ok: bool = True
    source: Literal["legacy", "mock"] = "mock"
    updatedAt: str
    rows: list[LimitPoolItem] = Field(default_factory=list)
    error: str | None = None
