from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


BoardType = Literal["concept", "industry", "region", "unknown"]


class BoardItem(BaseModel):
    rank: int
    boardCode: str = ""
    boardName: str
    boardType: BoardType = "unknown"
    changePct: float | None = None
    hotScore: float | None = None
    sentimentScore: float | None = None
    limitUpCount: int | None = None
    openedCount: int | None = None
    stockCount: int | None = None
    leaderCode: str = ""
    leaderName: str = ""
    leaderChangePct: float | None = None
    mainLogic: str = ""
    eventTime: str | None = None
    source: str = ""


class BoardsResponse(BaseModel):
    ok: bool = True
    source: Literal["legacy", "mock"] = "mock"
    updatedAt: str
    rows: list[BoardItem] = Field(default_factory=list)
    error: str | None = None
