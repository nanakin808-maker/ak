"""Strategy schemas."""

from __future__ import annotations

from pydantic import BaseModel


class StrategyDefinition(BaseModel):
    strategy_id: str
    name: str
    category: str = ""
    enabled: bool = True
    veto: bool = False


class SavedStrategy(BaseModel):
    id: str
    strategy_id: str
    config: dict = {}
    enabled: bool = True
