from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


EventTone = Literal["red", "orange", "green", "blue", "purple"]


class MonitorEvent(BaseModel):
    id: str = ""
    time: str = ""
    code: str = ""
    name: str = ""
    event: str = ""
    eventType: str | None = None
    eventSource: str | None = None
    eventTime: str | None = None
    price: float | None = None
    changePct: float | None = None
    isSealed: bool | None = None
    isFirstSeal: bool | None = None
    tradingDate: str | None = None
    detail: str = ""
    tone: EventTone = "blue"


class EventsResponse(BaseModel):
    ok: bool = True
    source: Literal["legacy", "mock", "v2_shadow"] = "mock"
    updatedAt: str
    events: list[MonitorEvent] = Field(default_factory=list)
    error: str | None = None
