from __future__ import annotations

from pydantic import BaseModel


class ScoreRule(BaseModel):
    label: str
    delta: float


class CandidateScoreDetails(BaseModel):
    technical: list[ScoreRule] | None = None
    realtimeSentiment: list[ScoreRule] | None = None
    sealSentiment: list[ScoreRule] | None = None
    volume: list[ScoreRule] | None = None
