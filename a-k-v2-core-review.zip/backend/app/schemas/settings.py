"""Settings schemas."""

from __future__ import annotations

from pydantic import BaseModel


class SettingsResponse(BaseModel):
    ok: bool = True
    ths_ok: bool
    feishu_ok: bool
    notification: "SettingsResponse.NotificationSettings"
    speed_rank: "SettingsResponse.SpeedRankHealth"

    class NotificationSettings(BaseModel):
        kline_min_score: float = 50.0
        seal_board_min_score: float = 50.0

    class SpeedRankHealth(BaseModel):
        available: bool = False
