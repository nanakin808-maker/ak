from __future__ import annotations

from typing import Literal


VolumeStatus = Literal["pending", "monitoring", "confirmed", "failed"]
DecisionStage = Literal["watch", "candidate", "core", "rejected"]
EventTone = Literal["red", "orange", "green", "blue", "purple"]


def infer_volume_status(explicit: str, score: float | None) -> VolumeStatus:
    if explicit in {"pending", "monitoring", "confirmed", "failed"}:
        return explicit  # type: ignore[return-value]

    if score is None:
        return "pending"

    if score >= 85:
        return "confirmed"

    if score >= 55:
        return "monitoring"

    return "failed"


def infer_decision_stage(
    *,
    in_core: bool,
    sealed: bool,
    in_candidate: bool,
    rejected_today: bool,
    candidate_removed: bool,
    fallback: str,
) -> DecisionStage:
    if in_core or sealed:
        return "core"

    if in_candidate:
        return "candidate"

    if rejected_today or candidate_removed:
        return "rejected"

    if fallback in {"watch", "candidate", "core", "rejected"}:
        return fallback  # type: ignore[return-value]

    return "watch"


def infer_event_tone(event: str) -> EventTone:
    if "炸板" in event or "开板" in event:
        return "green"

    if "量能" in event or "放量" in event:
        return "purple"

    if "涨停" in event or "封板" in event:
        return "red"

    if "拉升" in event or "涨速" in event:
        return "blue"

    return "orange"
