from __future__ import annotations

from datetime import datetime
from enum import Enum


class FreshnessStatus(str, Enum):
    FRESH = "fresh"
    STALE = "stale"
    MISMATCH = "mismatch"
    UNKNOWN = "unknown"


class MarketSession(str, Enum):
    TRADING = "trading"
    PRE_MARKET = "pre_market"
    MIDDAY_BREAK = "midday_break"
    POST_CLOSE = "post_close"
    CLOSED = "closed"
    UNKNOWN = "unknown"


class TimeScope:
    def __init__(
        self,
        *,
        trading_date: str,
        source_trading_date: str | None,
        as_of: datetime,
        source_updated_at: datetime | None = None,
        freshness_status: str = "unknown",
        seq: int = 0,
        market_session: str = "unknown",
    ) -> None:
        self.trading_date = trading_date
        self.source_trading_date = source_trading_date
        self.as_of = as_of
        self.source_updated_at = source_updated_at
        self.freshness_status = freshness_status
        self.seq = seq
        self.market_session = market_session


def evaluate_freshness(
    trading_date: str,
    source_trading_date: str | None,
    market_session: str | None = None,
) -> str:
    if not source_trading_date:
        return FreshnessStatus.UNKNOWN.value
    if source_trading_date == trading_date:
        return FreshnessStatus.FRESH.value
    return FreshnessStatus.MISMATCH.value


def can_trigger_core(scope: TimeScope) -> bool:
    return scope.freshness_status == FreshnessStatus.FRESH.value


def can_trigger_notification(scope: TimeScope) -> bool:
    return scope.freshness_status == FreshnessStatus.FRESH.value


def can_trigger_self_stock(scope: TimeScope) -> bool:
    return scope.freshness_status == FreshnessStatus.FRESH.value


def assert_action_allowed(scope: TimeScope) -> bool:
    return scope.freshness_status == FreshnessStatus.FRESH.value
