from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class SealConfidence(str, Enum):
    RELIABLE = "reliable"
    EXPLICIT = "explicit"
    INSUFFICIENT = "insufficient"
    UNKNOWN = "unknown"


@dataclass(slots=True)
class SealState:
    at_limit: bool
    is_sealed: bool
    opened: bool
    limit_price: float | None
    seal_volume: float | None
    confidence: str
    source: str
    reason: str


def _limit_up_price(code: str, pre_close: float | None, name: str | None = None) -> float | None:
    if pre_close is None or pre_close <= 0:
        return None
    name_str = (name or "").upper().replace("＊", "*").strip()
    is_st = name_str.startswith("*ST") or name_str.lstrip("*").strip().startswith("ST")
    if is_st:
        return round(pre_close * 1.05, 2)
    normalized = str(code).strip()
    if normalized.startswith(("300", "301", "688", "689")):
        return round(pre_close * 1.20, 2)
    if normalized.startswith(("8", "4", "9")):
        return round(pre_close * 1.30, 2)
    return round(pre_close * 1.10, 2)


def evaluate_seal_state_from_quote(
    code: str,
    name: str | None = None,
    price: float | None = None,
    pre_close: float | None = None,
    bid1: float | None = None,
    bid_vol1: float | None = None,
    ask1: float | None = None,
    ask_vol1: float | None = None,
    explicit_is_sealed: bool | None = None,
    explicit_at_limit: bool | None = None,
    source: str = "quote",
) -> SealState:
    if explicit_is_sealed is not None:
        return SealState(
            at_limit=explicit_at_limit if explicit_at_limit is not None else explicit_is_sealed,
            is_sealed=explicit_is_sealed,
            opened=(explicit_at_limit is not None and explicit_at_limit and not explicit_is_sealed),
            limit_price=None,
            seal_volume=None,
            confidence=SealConfidence.EXPLICIT.value,
            source=source,
            reason="explicit_fields",
        )

    if price is None or pre_close is None or bid1 is None or bid_vol1 is None:
        return SealState(
            at_limit=False,
            is_sealed=False,
            opened=False,
            limit_price=None,
            seal_volume=None,
            confidence=SealConfidence.INSUFFICIENT.value,
            source=source,
            reason="missing_price_or_bid_fields",
        )

    limit_price = _limit_up_price(code, pre_close, name)
    if limit_price is None:
        return SealState(
            at_limit=False, is_sealed=False, opened=False,
            limit_price=None, seal_volume=None,
            confidence=SealConfidence.INSUFFICIENT.value,
            source=source, reason="cannot_calculate_limit_price",
        )

    at_limit = price >= limit_price - 0.005 if limit_price > 0 else False
    seal_volume = max(0, int(bid_vol1 or 0))
    sealed = bool(at_limit and seal_volume > 0 and bid1 is not None and abs(bid1 - limit_price) <= 0.01)

    if not bid_vol1 or bid_vol1 <= 0:
        return SealState(
            at_limit=at_limit, is_sealed=False, opened=False,
            limit_price=limit_price, seal_volume=seal_volume,
            confidence=SealConfidence.INSUFFICIENT.value,
            source=source, reason="no_bid_volume",
        )

    return SealState(
        at_limit=at_limit,
        is_sealed=sealed,
        opened=(at_limit and not sealed),
        limit_price=limit_price,
        seal_volume=seal_volume,
        confidence=SealConfidence.RELIABLE.value,
        source=source,
        reason="seal_state_from_bid",
    )
