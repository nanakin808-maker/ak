from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from app.domain.events import StockEvent
from app.domain.external_actions import SelfStockState
from app.domain.scores import StockScoreBundle
from app.domain.snapshots import BoardScoreSnapshotBundle
from app.domain.stocks import StockSnapshot


class CandidateStage(str, Enum):
    PRE_CANDIDATE = "pre_candidate"
    CANDIDATE = "candidate"
    CORE = "core"
    REJECTED_TODAY = "rejected_today"


class DecisionAction(str, Enum):
    IGNORE = "ignore"
    KEEP_CURRENT = "keep_current"
    ENTER_PRE_CANDIDATE = "enter_pre_candidate"
    ENTER_CANDIDATE = "enter_candidate"
    PROMOTE_TO_CORE = "promote_to_core"
    DEMOTE_TO_CANDIDATE = "demote_to_candidate"
    REJECT_TODAY = "reject_today"


@dataclass(frozen=True)
class CandidateState:
    stock: StockSnapshot
    stage: CandidateStage
    scores: StockScoreBundle
    snapshots: BoardScoreSnapshotBundle | None = None
    self_stock_state: SelfStockState | None = None
    last_event: StockEvent | None = None
    first_seen_at: str | None = None
    candidate_at: str | None = None
    core_at: str | None = None
    updated_at: str | None = None
    score_stage: str = ""
    limit_phase: str = ""
    state_version: int = 1
    tags: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class OpportunityDecision:
    action: DecisionAction
    target_stage: CandidateStage | None = None
    reason: str = ""
    should_notify: bool = False
    tags: list[str] = field(default_factory=list)
