from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class StockSnapshot:
    code: str
    name: str
    price: float | None = None
    change_pct: float | None = None
    board: str = "--"
    board_change_pct: float | None = None
    event_time: str | None = None


@dataclass(frozen=True)
class BoardSnapshot:
    board_name: str
    board_code: str = ""
    change_pct: float | None = None
    hot_score: float | None = None
    sentiment_score: float | None = None
    limit_up_count: int | None = None
    opened_count: int | None = None
    leader_code: str = ""
    leader_name: str = ""
    leader_change_pct: float | None = None
