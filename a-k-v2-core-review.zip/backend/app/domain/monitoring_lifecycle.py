from __future__ import annotations

from dataclasses import dataclass

from app.domain.decisions import (
    CandidateStage,
    CandidateState,
    DecisionAction,
    OpportunityDecision,
)
from app.domain.events import EventSource, EventType, StockEvent
from app.domain.gates import GateCheckResult, GateDecision, GateType, MonitoringGateConfig
from app.domain.scores import ScoreResult, StockScoreBundle
from app.domain.stocks import StockSnapshot


CORE_SEALED_EVENTS = {
    EventType.LIMIT_UP,
    EventType.LIMIT_UP_SEALED,
    EventType.RESEAL,
}

OPEN_EVENTS = {
    EventType.OPEN_BOARD,
    EventType.LIMIT_UP_OPENED,
}


@dataclass(frozen=True)
class MonitoringLifecycleInput:
    stock: StockSnapshot
    event: StockEvent
    scores: StockScoreBundle
    current_state: CandidateState | None = None
    config: MonitoringGateConfig = MonitoringGateConfig()
    is_st: bool = False
    has_valid_quote: bool = False
    history_ready: bool = False


def _score(value: ScoreResult | None) -> float | None:
    return value.score if value else None


def _above(value: float | None, threshold: float | None) -> bool:
    return threshold is None or (value is not None and value >= threshold)


def _is_sealed(event: StockEvent) -> bool:
    return event.is_sealed or event.event_type in CORE_SEALED_EVENTS


def _is_opened(event: StockEvent) -> bool:
    return event.event_type in OPEN_EVENTS


def _is_near_limit(event: StockEvent, threshold: float) -> bool:
    if event.event_type is EventType.NEAR_LIMIT or event.at_limit:
        return True

    return event.change_pct is not None and event.change_pct >= threshold


def _best_board_sentiment(scores: StockScoreBundle) -> float | None:
    values = [
        _score(scores.realtime_sentiment),
        _score(scores.entry_sentiment),
        _score(scores.seal_sentiment),
        _score(scores.open_board_sentiment),
        _score(scores.reseal_sentiment),
    ]
    known = [value for value in values if value is not None]
    return max(known) if known else None


def check_base_filter(data: MonitoringLifecycleInput) -> GateCheckResult:
    config = data.config.base_filter

    if config.st_filter_required and data.is_st:
        return GateCheckResult(
            gate_type=GateType.ENTRY,
            decision=GateDecision.BLOCK,
            reason="ST 股票固定过滤，进入当日剔除。",
            tags=["st_filter"],
        )

    if config.min_change_pct is not None:
        change_pct = data.event.change_pct if data.event.change_pct is not None else data.stock.change_pct
        if change_pct is None or change_pct < config.min_change_pct:
            return GateCheckResult(
                gate_type=GateType.ENTRY,
                decision=GateDecision.BLOCK,
                reason="涨幅未达到基础进入门槛。",
                tags=["change_pct_below_entry"],
            )

    return GateCheckResult(
        gate_type=GateType.ENTRY,
        decision=GateDecision.PASS,
        reason="基础过滤通过。",
    )


def check_candidate_entry(data: MonitoringLifecycleInput) -> GateCheckResult:
    config = data.config.candidate_entry

    if data.event.source not in config.allowed_sources:
        return GateCheckResult(
            gate_type=GateType.ENTRY,
            decision=GateDecision.BLOCK,
            reason="事件来源不在候选入口允许列表。",
            tags=["source_blocked"],
        )

    if data.event.event_type not in config.allowed_event_types:
        return GateCheckResult(
            gate_type=GateType.ENTRY,
            decision=GateDecision.BLOCK,
            reason="事件类型不在候选入口允许列表。",
            tags=["event_type_blocked"],
        )

    return GateCheckResult(
        gate_type=GateType.ENTRY,
        decision=GateDecision.PASS,
        reason="候选入口门禁通过。",
    )


def check_core_gate(data: MonitoringLifecycleInput) -> GateCheckResult:
    config = data.config.core_gate
    scores = data.scores
    sealed = _is_sealed(data.event)
    near_limit = _is_near_limit(data.event, config.near_limit_min_pct)

    if config.require_sealed and not sealed:
        return GateCheckResult(
            gate_type=GateType.CORE,
            decision=GateDecision.BLOCK,
            reason="核心监控股（CORE）默认要求封板，当前未封板。",
            tags=["wait_seal"],
        )

    if not config.require_sealed and config.allow_near_limit and not (sealed or near_limit):
        return GateCheckResult(
            gate_type=GateType.CORE,
            decision=GateDecision.BLOCK,
            reason="未封板且未达到接近封板条件。",
            tags=["wait_near_limit"],
        )

    if not _above(_score(scores.technical), config.min_technical_score):
        return GateCheckResult(
            gate_type=GateType.CORE,
            decision=GateDecision.BLOCK,
            reason="技术分未达到核心监控股（CORE）门槛。",
            tags=["technical_below_core"],
        )

    if not _above(_score(scores.realtime_sentiment), config.min_realtime_sentiment_score):
        return GateCheckResult(
            gate_type=GateType.CORE,
            decision=GateDecision.BLOCK,
            reason="实时情绪分未达到核心监控股（CORE）门槛。",
            tags=["realtime_sentiment_below_core"],
        )

    if not _above(_best_board_sentiment(scores), config.min_board_sentiment_score):
        return GateCheckResult(
            gate_type=GateType.CORE,
            decision=GateDecision.BLOCK,
            reason="板块情绪分未达到核心监控股（CORE）门槛。",
            tags=["board_sentiment_below_core"],
        )

    if config.require_volume_confirm and not _above(_score(scores.volume), config.min_volume_score):
        return GateCheckResult(
            gate_type=GateType.CORE,
            decision=GateDecision.BLOCK,
            reason="配置要求量能确认，但量能分未达标。",
            tags=["volume_below_core"],
        )

    if config.require_board_strength:
        board_change_pct = data.event.board_change_pct
        if board_change_pct is None:
            board_change_pct = data.stock.board_change_pct

        if not _above(board_change_pct, config.min_board_change_pct):
            return GateCheckResult(
                gate_type=GateType.CORE,
                decision=GateDecision.BLOCK,
                reason="主板块强度未达到核心监控股（CORE）门槛。",
                tags=["board_strength_below_core"],
            )

    return GateCheckResult(
        gate_type=GateType.CORE,
        decision=GateDecision.PASS,
        reason="核心监控股（CORE）门禁通过。",
    )


def decide_monitoring_lifecycle(data: MonitoringLifecycleInput) -> OpportunityDecision:
    base = check_base_filter(data)

    if base.decision is GateDecision.BLOCK:
        return OpportunityDecision(
            action=DecisionAction.REJECT_TODAY,
            target_stage=CandidateStage.REJECTED_TODAY,
            reason=base.reason,
            tags=base.tags,
        )

    current_stage = data.current_state.stage if data.current_state else None

    if current_stage is CandidateStage.REJECTED_TODAY:
        return OpportunityDecision(
            action=DecisionAction.KEEP_CURRENT,
            target_stage=CandidateStage.REJECTED_TODAY,
            reason="股票已在当日剔除中，保持状态。",
            tags=["rejected_today"],
        )

    if current_stage is CandidateStage.CORE and _is_opened(data.event):
        return OpportunityDecision(
            action=DecisionAction.DEMOTE_TO_CANDIDATE,
            target_stage=CandidateStage.CANDIDATE,
            reason="核心监控股（CORE）出现开板事件，降回候选监控股（CANDIDATE）。",
            tags=["open_board", "demote_to_candidate"],
        )

    if current_stage is None:
        entry = check_candidate_entry(data)
        if entry.decision is GateDecision.PASS:
            return OpportunityDecision(
                action=DecisionAction.ENTER_PRE_CANDIDATE,
                target_stage=CandidateStage.PRE_CANDIDATE,
                reason="事件通过入口门禁，进入初筛观察股（PRE_CANDIDATE）。",
                tags=["enter_pre_candidate"],
            )

        return OpportunityDecision(
            action=DecisionAction.IGNORE,
            reason=entry.reason,
            tags=entry.tags,
        )

    if current_stage is CandidateStage.PRE_CANDIDATE:
        if data.history_ready or data.has_valid_quote or data.event.source is EventSource.QUOTE:
            return OpportunityDecision(
                action=DecisionAction.ENTER_CANDIDATE,
                target_stage=CandidateStage.CANDIDATE,
                reason="初筛观察股已具备有效报价或历史回填，进入候选监控股（CANDIDATE）。",
                tags=["enter_candidate"],
            )

        return OpportunityDecision(
            action=DecisionAction.KEEP_CURRENT,
            target_stage=CandidateStage.PRE_CANDIDATE,
            reason="仍处于初筛观察股（PRE_CANDIDATE），等待报价或历史回填。",
            tags=["wait_quote_or_history"],
        )

    if current_stage is CandidateStage.CANDIDATE:
        core = check_core_gate(data)
        if core.decision is GateDecision.PASS:
            return OpportunityDecision(
                action=DecisionAction.PROMOTE_TO_CORE,
                target_stage=CandidateStage.CORE,
                reason=core.reason,
                tags=["promote_to_core", *core.tags],
            )

        return OpportunityDecision(
            action=DecisionAction.KEEP_CURRENT,
            target_stage=CandidateStage.CANDIDATE,
            reason=core.reason,
            tags=core.tags,
        )

    if current_stage is CandidateStage.CORE:
        return OpportunityDecision(
            action=DecisionAction.KEEP_CURRENT,
            target_stage=CandidateStage.CORE,
            reason="保持核心监控股（CORE）状态。",
            tags=["keep_core"],
        )

    return OpportunityDecision(
        action=DecisionAction.IGNORE,
        reason="未匹配任何监控状态迁移规则。",
        tags=["no_lifecycle_rule"],
    )
