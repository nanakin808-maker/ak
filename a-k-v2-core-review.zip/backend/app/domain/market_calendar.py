"""
Trading calendar and market session detection.

Uses Sina index quote (sh000001) to probe actual trading day.
60s cache. Weekday check for nominal trading day.
"""

from __future__ import annotations

import time
import urllib.request
from datetime import datetime, timezone
from enum import Enum

UA = "Mozilla/5.0"
SINA_INDEX_URL = "https://hq.sinajs.cn/list=sh000001"
PROBE_TTL = 60.0  # cache seconds
CST = timezone(__import__("datetime").timedelta(hours=8))


class MarketSession(str, Enum):
    WEEKEND = "weekend"
    BEFORE_OPEN = "before_open"
    CALL_AUCTION = "call_auction"
    MORNING = "morning"
    LUNCH_BREAK = "lunch_break"
    AFTERNOON = "afternoon"
    POST_CLOSE = "post_close"
    CLOSED_NO_DATA = "closed_no_trade_data"


def _now_cst() -> datetime:
    return datetime.now(CST)


def is_nominal_trading_day() -> bool:
    return _now_cst().weekday() < 5


def market_session() -> MarketSession:
    """Return current market session based on CST time."""
    now = _now_cst()
    if now.weekday() >= 5:
        return MarketSession.WEEKEND
    t = now.hour * 60 + now.minute
    if t < 9 * 60 + 15:
        return MarketSession.BEFORE_OPEN
    if t < 9 * 60 + 30:
        return MarketSession.CALL_AUCTION
    if t < 11 * 60 + 30:
        return MarketSession.MORNING
    if t < 13 * 60:
        return MarketSession.LUNCH_BREAK
    if t < 15 * 60:
        return MarketSession.AFTERNOON
    return MarketSession.POST_CLOSE


def is_live_trading() -> bool:
    return market_session() in (
        MarketSession.CALL_AUCTION, MarketSession.MORNING, MarketSession.AFTERNOON,
    )


# ── index probe ────────────────────────────────────────

_probe_cache: tuple[float, str | None] = (0, None)


def probe_trading_date() -> str | None:
    """Probe actual trading date from Sina index quote. Returns YYYY-MM-DD or None."""
    global _probe_cache
    now = time.time()
    if now - _probe_cache[0] < PROBE_TTL:
        return _probe_cache[1]

    try:
        req = urllib.request.Request(SINA_INDEX_URL, headers={
            "User-Agent": UA, "Referer": "https://finance.sina.com.cn/",
        })
        resp = urllib.request.urlopen(req, timeout=3)
        body = resp.read().decode("gbk", errors="replace")
        if '="' not in body:
            _probe_cache = (now, None)
            return None
        raw = body.split('="', 1)[1].rstrip('"')
        parts = raw.split(",")
        if len(parts) < 31:
            _probe_cache = (now, None)
            return None
        trade_date = parts[30].strip()
        if len(trade_date) == 8:
            trade_date = f"{trade_date[:4]}-{trade_date[4:6]}-{trade_date[6:8]}"
        _probe_cache = (now, trade_date if trade_date else None)
        return _probe_cache[1]
    except Exception:
        _probe_cache = (now, None)
        return None


def effective_trading_date() -> str:
    """Return effective trading date (YYYY-MM-DD).

    - Live trading: today
    - Post-close: today
    - Non-trading: probed date or today as fallback
    """
    today = _now_cst().strftime("%Y-%m-%d")
    session = market_session()
    if session in (MarketSession.WEEKEND,):
        probed = probe_trading_date()
        return probed or today
    if not is_nominal_trading_day():
        probed = probe_trading_date()
        return probed or today
    return today


def effective_trading_date_ymd() -> str:
    """Return effective trading date as YYYYMMDD."""
    return effective_trading_date().replace("-", "")


def annotate_data_date(data_date: str | None) -> str:
    """Annotate whether data_date matches today. Returns 'today' or 'stale_YYYYMMDD'."""
    if not data_date:
        return "unknown_date"
    today = effective_trading_date()
    if data_date == today or data_date == today.replace("-", ""):
        return "today"
    return f"stale_{data_date}"
