from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from app.domain.decisions import CandidateState
from app.domain.external_actions import SelfStockStatus
from app.domain.gates import NotificationAction, NotificationGateConfig
from app.domain.scores import ScoreResult, StockScoreBundle
from app.domain.stocks import StockSnapshot


class NotificationGateStatus(str, Enum):
    PASS = "pass"
    BLOCK = "block"
    SKIP = "skip"


class NotificationLevel(str, Enum):
    BUYABLE = "buyable"
    WARNING = "warning"
    INFO = "info"
    SUPPRESSED = "suppressed"


class NotificationBypassReason(str, Enum):
    SELF_STOCK_LIMIT_UP = "self_stock_limit_up"
    CORE_OPEN_BOARD = "core_open_board"


@dataclass(frozen=True)
class NotificationGateInput:
    stock: StockSnapshot
    action: NotificationAction
    scores: StockScoreBundle
    config: NotificationGateConfig = NotificationGateConfig()
    current_state: CandidateState | None = None
    is_reseal: bool = False
    limit_up_notice_sent: bool = False


@dataclass(frozen=True)
class NotificationGateResult:
    status: NotificationGateStatus
    should_notify: bool
    level: NotificationLevel
    reason: str = ""
    action: NotificationAction | None = None
    technical_score: float | None = None
    sentiment_score: float | None = None
    sentiment_source: str = ""
    realtime_sentiment_score: float | None = None
    volume_score: float | None = None
    bypass_reason: NotificationBypassReason | None = None
    tags: list[str] = field(default_factory=list)


def _score(value: ScoreResult | None) -> float | None:
    return value.score if value else None


def _passes(value: float | None, threshold: float | None) -> bool:
    return threshold is None or (value is not None and value >= threshold)


def _self_stock_added(state: CandidateState | None) -> bool:
    return (
        state is not None
        and state.self_stock_state is not None
        and state.self_stock_state.status is SelfStockStatus.ADDED
    )


def _candidate(source: str, value: float | None) -> tuple[str, float | None]:
    return source, value


def select_notification_sentiment(
    action: NotificationAction,
    scores: StockScoreBundle,
    *,
    is_reseal: bool = False,
) -> tuple[str, float | None]:
    realtime = _candidate("realtime", _score(scores.realtime_sentiment))
    entry = _candidate("entry", _score(scores.entry_sentiment))
    seal = _candidate("seal", _score(scores.seal_sentiment))
    open_board = _candidate("open_board", _score(scores.open_board_sentiment))
    reseal = _candidate("reseal", _score(scores.reseal_sentiment))

    if action is NotificationAction.OPEN_BOARD:
        candidates = [realtime, open_board, seal]
    elif action is NotificationAction.RESEAL or is_reseal:
        candidates = [realtime, reseal, seal]
    elif action is NotificationAction.LIMIT_UP:
        candidates = [seal, entry, realtime]
    elif action is NotificationAction.SELF_STOCK:
        candidates = [realtime, entry, seal]
    else:
        candidates = [realtime, seal, entry]

    for source, value in candidates:
        if value is not None:
            return source, value

    return "", None


def _score_passes(data: NotificationGateInput) -> tuple[bool, str, float | None, float | None, float | None]:
    technical = _score(data.scores.technical)
    sentiment_source, sentiment = select_notification_sentiment(
        data.action,
        data.scores,
        is_reseal=data.is_reseal,
    )
    volume = _score(data.scores.volume)

    technical_ok = _passes(technical, data.config.min_technical_score)
    sentiment_ok = _passes(sentiment, data.config.min_sentiment_score)
    volume_ok = (not data.config.require_volume_score) or _passes(volume, data.config.min_volume_score)

    return technical_ok and sentiment_ok and volume_ok, sentiment_source, technical, sentiment, volume


def _realtime_sentiment_passes(data: NotificationGateInput) -> bool:
    realtime = _score(data.scores.realtime_sentiment)

    if realtime is None:
        return False

    return _passes(realtime, data.config.min_sentiment_score)


def _base_result(
    data: NotificationGateInput,
    *,
    status: NotificationGateStatus,
    should_notify: bool,
    level: NotificationLevel,
    reason: str,
    bypass_reason: NotificationBypassReason | None = None,
    tags: list[str] | None = None,
) -> NotificationGateResult:
    _scores_passed, sentiment_source, technical, sentiment, volume = _score_passes(data)

    return NotificationGateResult(
        status=status,
        should_notify=should_notify,
        level=level,
        reason=reason,
        action=data.action,
        technical_score=technical,
        sentiment_score=sentiment,
        sentiment_source=sentiment_source,
        realtime_sentiment_score=_score(data.scores.realtime_sentiment),
        volume_score=volume,
        bypass_reason=bypass_reason,
        tags=tags or [],
    )


def check_notification_gate(data: NotificationGateInput) -> NotificationGateResult:
    if not data.config.enabled:
        return _base_result(
            data,
            status=NotificationGateStatus.SKIP,
            should_notify=False,
            level=NotificationLevel.SUPPRESSED,
            reason="飞书通知门禁已关闭。",
            tags=["notification_disabled"],
        )

    scores_passed, _sentiment_source, _technical, _sentiment, _volume = _score_passes(data)
    self_stock_added = _self_stock_added(data.current_state)

    if data.action in {NotificationAction.LIMIT_UP, NotificationAction.RESEAL}:
        if scores_passed:
            return _base_result(
                data,
                status=NotificationGateStatus.PASS,
                should_notify=True,
                level=NotificationLevel.BUYABLE,
                reason="封板/回封通知分数门禁通过，发送可购买通知。",
                tags=["buyable", "score_pass"],
            )

        if data.config.allow_self_stock_limit_up_bypass and self_stock_added:
            level = NotificationLevel.BUYABLE if _realtime_sentiment_passes(data) else NotificationLevel.WARNING
            reason = (
                "已加入同花顺自选，且实时情绪分达标，发送可购买通知。"
                if level is NotificationLevel.BUYABLE
                else "已加入同花顺自选，但实时情绪分未达标，发送警告通知。"
            )
            return _base_result(
                data,
                status=NotificationGateStatus.PASS,
                should_notify=True,
                level=level,
                reason=reason,
                bypass_reason=NotificationBypassReason.SELF_STOCK_LIMIT_UP,
                tags=["self_stock_bypass", level.value],
            )

        return _base_result(
            data,
            status=NotificationGateStatus.BLOCK,
            should_notify=False,
            level=NotificationLevel.SUPPRESSED,
            reason="封板/回封通知分数门禁未通过，且无同花顺自选豁免，抑制通知。",
            tags=["suppressed", "score_block"],
        )

    if data.action is NotificationAction.OPEN_BOARD:
        if scores_passed:
            return _base_result(
                data,
                status=NotificationGateStatus.PASS,
                should_notify=True,
                level=NotificationLevel.WARNING,
                reason="开板通知分数门禁通过，发送警告通知。",
                tags=["open_board", "warning"],
            )

        if data.config.allow_core_open_board_bypass and (self_stock_added or data.limit_up_notice_sent):
            return _base_result(
                data,
                status=NotificationGateStatus.PASS,
                should_notify=True,
                level=NotificationLevel.WARNING,
                reason="开板通知满足豁免条件，发送警告通知。",
                bypass_reason=NotificationBypassReason.CORE_OPEN_BOARD,
                tags=["open_board_bypass", "warning"],
            )

        return _base_result(
            data,
            status=NotificationGateStatus.BLOCK,
            should_notify=False,
            level=NotificationLevel.SUPPRESSED,
            reason="开板通知分数门禁未通过，且无豁免条件，抑制通知。",
            tags=["open_board_suppressed"],
        )

    if data.action is NotificationAction.SELF_STOCK:
        if scores_passed:
            return _base_result(
                data,
                status=NotificationGateStatus.PASS,
                should_notify=True,
                level=NotificationLevel.INFO,
                reason="同花顺自选通知门禁通过，发送信息通知。",
                tags=["self_stock_notice"],
            )

        return _base_result(
            data,
            status=NotificationGateStatus.BLOCK,
            should_notify=False,
            level=NotificationLevel.SUPPRESSED,
            reason="同花顺自选通知分数门禁未通过，抑制通知。",
            tags=["self_stock_suppressed"],
        )

    return _base_result(
        data,
        status=NotificationGateStatus.BLOCK,
        should_notify=False,
        level=NotificationLevel.SUPPRESSED,
        reason="未知通知动作，抑制通知。",
        tags=["unknown_action"],
    )
