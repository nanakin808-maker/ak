from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class EventType(str, Enum):
    SHORTLINE = "shortline"
    SPEED_RANK = "speed_rank"
    LIMIT_UP = "limit_up"
    LIMIT_UP_SEALED = "limit_up_sealed"
    LIMIT_UP_OPENED = "limit_up_opened"
    OPEN_BOARD = "open_board"
    RESEAL = "reseal"
    FAST_RISE = "fast_rise"
    VOLUME_EXPAND = "volume_expand"
    VOLUME_SPIKE = "volume_spike"
    NEAR_LIMIT = "near_limit"
    BOARD_MOVE = "board_move"
    CANDIDATE_PROMOTE = "candidate_promote"
    NOTIFY = "notify"
    UNKNOWN = "unknown"


class EventSource(str, Enum):
    SHORTLINE = "shortline"
    SPEED_RANK = "speed_rank"
    LIMIT_POOL = "limit_pool"
    QUOTE = "quote"
    BOARD = "board"
    GAIN_RANK = "gain_rank"
    ENGINE = "engine"
    LEGACY = "legacy"
    MOCK = "mock"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class StockEvent:
    code: str
    name: str
    event_type: EventType
    event_time: str
    source: EventSource = EventSource.UNKNOWN
    title: str = ""
    detail: str = ""
    price: float | None = None
    change_pct: float | None = None
    board: str = ""
    board_change_pct: float | None = None
    is_sealed: bool = False
    is_first_seal: bool = False
    at_limit: bool = False
    seal_volume: float | None = None
    open_count: int | None = None
    raw: dict[str, Any] = field(default_factory=dict)
