from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from app.domain.events import EventSource, EventType


class GateType(str, Enum):
    ENTRY = "entry"
    CORE = "core"
    NOTIFICATION = "notification"
    SELF_STOCK = "self_stock"


class GateDecision(str, Enum):
    PASS = "pass"
    BLOCK = "block"
    SKIP = "skip"


class NotificationAction(str, Enum):
    LIMIT_UP = "notify_limit_up"
    OPEN_BOARD = "notify_open_board"
    SELF_STOCK = "notify_self_stock"
    RESEAL = "notify_reseal"


@dataclass(frozen=True)
class GateCheckResult:
    gate_type: GateType
    decision: GateDecision
    reason: str = ""
    tags: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class BaseFilterConfig:
    """
    基础过滤配置。

    ST 过滤是固定规则，不允许配置关闭。
    其他黑名单、涨幅门槛等可后续扩展。
    """

    st_filter_required: bool = True
    allow_st_disable: bool = False
    reject_st_today: bool = True
    min_change_pct: float | None = None


@dataclass(frozen=True)
class CandidateEntryConfig:
    """
    初筛观察股（PRE_CANDIDATE）进入配置。

    事件来源包括短线事件、涨速榜、涨停炸板池、报价触发；
    后续可扩展涨幅榜封板或接近封板。
    """

    allowed_sources: set[EventSource] = field(
        default_factory=lambda: {
            EventSource.SHORTLINE,
            EventSource.SPEED_RANK,
            EventSource.LIMIT_POOL,
            EventSource.QUOTE,
            EventSource.GAIN_RANK,
        },
    )
    allowed_event_types: set[EventType] = field(
        default_factory=lambda: {
            EventType.SHORTLINE,
            EventType.SPEED_RANK,
            EventType.LIMIT_UP,
            EventType.LIMIT_UP_SEALED,
            EventType.LIMIT_UP_OPENED,
            EventType.OPEN_BOARD,
            EventType.RESEAL,
            EventType.FAST_RISE,
            EventType.VOLUME_SPIKE,
            EventType.VOLUME_EXPAND,
            EventType.NEAR_LIMIT,
        },
    )
    require_valid_quote_for_candidate: bool = True


@dataclass(frozen=True)
class CoreGateConfig:
    """
    核心监控股（CORE）门禁配置。

    旧系统事实：candidate -> core 主要由 sealed=True 触发。
    v2 目标：除 ST 固定过滤外，核心门槛允许配置。
    """

    require_sealed: bool = True
    allow_near_limit: bool = False
    near_limit_min_pct: float = 9.0

    min_technical_score: float | None = None
    min_realtime_sentiment_score: float | None = None
    min_board_sentiment_score: float | None = None

    require_volume_confirm: bool = False
    min_volume_score: float | None = None

    require_board_strength: bool = False
    min_board_change_pct: float | None = None


@dataclass(frozen=True)
class NotificationGateConfig:
    """
    飞书通知门禁配置。

    通知门禁不改变生命周期阶段。
    核心监控股（CORE）和飞书通知必须分离。
    """

    enabled: bool = True
    min_technical_score: float | None = 70.0
    min_sentiment_score: float | None = 70.0
    require_volume_score: bool = False
    min_volume_score: float | None = None

    allow_self_stock_limit_up_bypass: bool = True
    allow_core_open_board_bypass: bool = True

    per_stock_notice_window_seconds: int | None = None
    per_stock_notice_limit: int | None = None


@dataclass(frozen=True)
class SelfStockGateConfig:
    """
    同花顺加自选门禁配置。

    该门禁是独立外部动作链路：
    - 不改变监控生命周期阶段
    - 不等于核心监控股（CORE）
    - 可影响飞书通知豁免
    """

    enabled: bool = True
    require_main_board: bool = True
    not_first_board_filter: bool = True
    near_limit_pct: float = 9.0
    max_open_change_pct: float = 3.0
    min_board_sentiment_score: float | None = 70.0
    min_technical_score: float | None = 70.0


@dataclass(frozen=True)
class MonitoringGateConfig:
    """
    v2 监控门禁总配置。

    分层：
    - base_filter：固定基础过滤，ST 必须过滤
    - candidate_entry：初筛观察股进入条件
    - core_gate：核心监控股（CORE）进入条件
    - notification_gate：飞书通知条件
    - self_stock_gate：自选股条件
    """

    base_filter: BaseFilterConfig = field(default_factory=BaseFilterConfig)
    candidate_entry: CandidateEntryConfig = field(default_factory=CandidateEntryConfig)
    core_gate: CoreGateConfig = field(default_factory=CoreGateConfig)
    notification_gate: NotificationGateConfig = field(default_factory=NotificationGateConfig)
    self_stock_gate: SelfStockGateConfig = field(default_factory=SelfStockGateConfig)
