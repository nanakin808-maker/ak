from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ExternalActionType(str, Enum):
    SELF_STOCK = "self_stock"
    FEISHU_NOTIFICATION = "feishu_notification"


class SelfStockAction(str, Enum):
    ADD = "add"
    SKIP = "skip"


class SelfStockStatus(str, Enum):
    ADDED = "added"
    FILTERED = "filtered"
    WAITING = "waiting"
    ERROR = "error"


class SelfStockFilterReason(str, Enum):
    NOT_MAIN_BOARD = "not_main_board"
    ALREADY_ADDED = "already_added"
    INFLIGHT = "inflight"
    CHANGE_PCT_BELOW_THRESHOLD = "change_pct_below_threshold"
    NOT_FIRST_BOARD = "not_first_board"
    OPEN_CHANGE_PCT_NOT_READY = "open_change_pct_not_ready"
    OPEN_CHANGE_PCT_TOO_HIGH = "open_change_pct_too_high"
    BOARD_SCORE_NOT_READY = "board_score_not_ready"
    BOARD_SCORE_BELOW_THRESHOLD = "board_score_below_threshold"
    KLINE_SCORE_NOT_READY = "kline_score_not_ready"
    KLINE_SCORE_BELOW_THRESHOLD = "kline_score_below_threshold"
    PROVIDER_ERROR = "provider_error"


@dataclass(frozen=True)
class SelfStockDecision:
    action: SelfStockAction
    status: SelfStockStatus
    reason: SelfStockFilterReason | None = None
    message: str = ""
    tags: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class SelfStockProviderResult:
    ok: bool
    message: str = ""
    already_exists: bool = False
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SelfStockState:
    status: SelfStockStatus
    reason: SelfStockFilterReason | None = None
    trigger: str = ""
    board_score: float | None = None
    kline_score: float | None = None
    change_pct: float | None = None
    open_change_pct: float | None = None
    main_logic: str = ""
    message: str = ""
    already_exists: bool = False
    updated_at: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)
