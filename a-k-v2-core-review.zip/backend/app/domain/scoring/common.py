from __future__ import annotations

from app.domain.scores import ScoreResult, ScoreRuleResult, ScoreType


def clamp_score(value: float) -> float:
    return max(0.0, min(100.0, round(value, 2)))


def total_rules(rules: list[ScoreRuleResult]) -> float:
    return clamp_score(sum(rule.delta for rule in rules))


def result(
    score_type: ScoreType,
    rules: list[ScoreRuleResult],
    *,
    reason: str,
    snapshot_time: str | None = None,
    is_snapshot: bool = False,
    empty_score: float | None = 0.0,
) -> ScoreResult:
    score = total_rules(rules) if rules else empty_score

    return ScoreResult(
        score_type=score_type,
        score=score,
        rules=rules,
        reason=reason,
        snapshot_time=snapshot_time,
        is_snapshot=is_snapshot,
    )


def rule(label: str, delta: float, reason: str = "") -> ScoreRuleResult:
    return ScoreRuleResult(label=label, delta=delta, reason=reason)
