from __future__ import annotations

from dataclasses import dataclass

from app.domain.events import EventType


@dataclass(frozen=True)
class TechnicalSignal:
    ma_aligned_up: bool = False
    price_above_ma5: bool = False
    price_above_ma20: bool = False
    breakout_recent_high: bool = False
    intraday_strength_pct: float | None = None
    overextended_risk: bool = False


@dataclass(frozen=True)
class SentimentSignal:
    event_type: EventType = EventType.UNKNOWN
    board_rank: int | None = None
    board_change_pct: float | None = None
    is_board_leader: bool = False
    limit_up_count: int | None = None
    opened_count: int | None = None


@dataclass(frozen=True)
class VolumeSignal:
    volume_ratio: float | None = None
    amount_rank_pct: float | None = None
    net_inflow_positive: bool | None = None
    turnover_fit: bool = False
    abnormal_spike_risk: bool = False


@dataclass(frozen=True)
class SealSnapshotSignal:
    is_first_seal: bool = False
    seal_time: str | None = None
    seal_amount: float | None = None
    open_count: int | None = None
    board_sentiment_score: float | None = None
