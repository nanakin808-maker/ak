from __future__ import annotations

from app.domain.scores import ScoreResult, ScoreType
from app.domain.scoring.common import result, rule
from app.domain.scoring.signals import TechnicalSignal
from app.domain.stocks import StockSnapshot


def score_technical(stock: StockSnapshot, signal: TechnicalSignal) -> ScoreResult:
    rules = []

    if signal.ma_aligned_up:
        rules.append(rule("均线多头向上", 10, "短中期均线方向一致向上"))

    if signal.price_above_ma5:
        rules.append(rule("站上 5 日线", 8, "短线价格保持在 5 日线上方"))

    if signal.price_above_ma20:
        rules.append(rule("站上 20 日线", 10, "价格位于中期趋势线上方"))

    if signal.breakout_recent_high:
        rules.append(rule("突破近期高点", 15, "价格突破近期压力位"))

    if signal.intraday_strength_pct is not None:
        if signal.intraday_strength_pct >= 3:
            rules.append(rule("日内强势", 12, "日内涨幅达到强势阈值"))
        elif signal.intraday_strength_pct >= 1.5:
            rules.append(rule("日内转强", 6, "日内涨幅进入观察区间"))

    if signal.overextended_risk:
        rules.append(rule("短线过热风险", -10, "短线拉升过快，追高风险上升"))

    reason = f"{stock.code} 技术结构评分"
    return result(ScoreType.TECHNICAL, rules, reason=reason)
