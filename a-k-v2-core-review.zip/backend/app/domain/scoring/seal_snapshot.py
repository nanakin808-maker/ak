from __future__ import annotations

from app.domain.scores import ScoreResult, ScoreType
from app.domain.scoring.common import result, rule
from app.domain.scoring.signals import SealSnapshotSignal


def score_seal_snapshot(signal: SealSnapshotSignal) -> ScoreResult:
    if not signal.is_first_seal:
        return result(
            ScoreType.SEAL_SENTIMENT,
            [],
            reason="尚未触发首次封板",
            snapshot_time=signal.seal_time,
            is_snapshot=True,
            empty_score=None,
        )

    rules = [rule("首次封板", 20, "封板瞬间形成情绪快照")]

    if signal.board_sentiment_score is not None:
        if signal.board_sentiment_score >= 85:
            rules.append(rule("封板时板块情绪强", 25, "封板瞬间板块情绪处于强势区"))
        elif signal.board_sentiment_score >= 70:
            rules.append(rule("封板时板块情绪良好", 15, "封板瞬间板块情绪可支撑观察"))

    if signal.seal_amount is not None:
        if signal.seal_amount >= 2:
            rules.append(rule("封单强", 20, "封单金额达到强确认区间"))
        elif signal.seal_amount >= 1:
            rules.append(rule("封单一般", 10, "封单金额达到基础确认区间"))

    if signal.open_count is not None and signal.open_count > 0:
        rules.append(rule("封后开板惩罚", -10 * signal.open_count, "封板后开板次数削弱确定性"))

    return result(
        ScoreType.SEAL_SENTIMENT,
        rules,
        reason="封板瞬间情绪快照",
        snapshot_time=signal.seal_time,
        is_snapshot=True,
    )
