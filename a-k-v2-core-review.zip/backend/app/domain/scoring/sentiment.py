from __future__ import annotations

from app.domain.events import EventType
from app.domain.scores import ScoreResult, ScoreType
from app.domain.scoring.common import result, rule
from app.domain.scoring.signals import SentimentSignal


def score_sentiment(signal: SentimentSignal) -> ScoreResult:
    rules = []

    if signal.board_rank == 1:
        rules.append(rule("主板块排名第 1", 25, "当前股票所属主板块情绪地位最高"))
    elif signal.board_rank is not None and signal.board_rank <= 3:
        rules.append(rule("主板块排名前 3", 15, "所属主板块处于市场前排"))
    elif signal.board_rank is not None and signal.board_rank <= 5:
        rules.append(rule("主板块排名前 5", 8, "所属主板块具备一定热度"))

    if signal.board_change_pct is not None:
        if signal.board_change_pct >= 3:
            rules.append(rule("主板块涨幅强", 15, "主板块涨幅达到强势阈值"))
        elif signal.board_change_pct >= 1.5:
            rules.append(rule("主板块涨幅温和", 8, "主板块涨幅进入观察区间"))

    if signal.is_board_leader:
        rules.append(rule("板块领涨股", 20, "个股在主板块中具备领涨地位"))

    if signal.limit_up_count is not None and signal.limit_up_count >= 5:
        rules.append(rule("板块涨停家数多", 15, "板块涨停家数体现情绪扩散"))

    if signal.opened_count is not None and signal.opened_count >= 3:
        rules.append(rule("炸板风险升高", -10, "板块炸板数量偏多"))

    if signal.event_type is EventType.LIMIT_UP:
        rules.append(rule("涨停事件", 15, "涨停事件强化短线情绪"))
    elif signal.event_type is EventType.RESEAL:
        rules.append(rule("回封事件", 10, "回封说明承接仍在"))
    elif signal.event_type is EventType.OPEN_BOARD:
        rules.append(rule("炸板事件", -15, "炸板削弱买入确定性"))
    elif signal.event_type is EventType.FAST_RISE:
        rules.append(rule("快速拉升", 8, "快速拉升进入机会观察"))

    return result(ScoreType.REALTIME_SENTIMENT, rules, reason="实时情绪评分")
