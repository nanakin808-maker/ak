"""
PLACEHOLDER ONLY.

当前量能评分只是 v2 早期骨架，不能作为最终算法使用。

旧系统量能分来自 VolumeScoringMixin 的 5 个分量：
- short_window
- amount_confirm
- turnover_fit
- history_compare
- risk_penalty

最终实现必须基于连续报价样本、成交额变化、换手匹配、历史对比和风险惩罚。
"""

from __future__ import annotations

from app.domain.scores import ScoreResult, ScoreType
from app.domain.scoring.common import result, rule
from app.domain.scoring.signals import VolumeSignal


def score_volume(signal: VolumeSignal) -> ScoreResult:
    rules = []

    if signal.volume_ratio is not None:
        if signal.volume_ratio >= 2:
            rules.append(rule("量能明显放大", 20, "当前量比达到强确认区间"))
        elif signal.volume_ratio >= 1.5:
            rules.append(rule("量能温和放大", 12, "当前量比进入观察确认区间"))

    if signal.amount_rank_pct is not None:
        if signal.amount_rank_pct <= 10:
            rules.append(rule("成交额排名前 10%", 15, "成交额处于市场前排"))
        elif signal.amount_rank_pct <= 25:
            rules.append(rule("成交额排名前 25%", 8, "成交额具备一定活跃度"))

    if signal.net_inflow_positive is True:
        rules.append(rule("净流入为正", 10, "资金流向支持机会确认"))
    elif signal.net_inflow_positive is False:
        rules.append(rule("净流入为负", -10, "资金流向不支持追踪"))

    if signal.turnover_fit:
        rules.append(rule("换手匹配", 10, "换手率与当前阶段匹配"))

    if signal.abnormal_spike_risk:
        rules.append(rule("异常放量风险", -12, "放量过急，需警惕诱多或分歧"))

    return result(ScoreType.VOLUME, rules, reason="量能确认评分")
