from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class BoardScoreSnapshotType(str, Enum):
    TRIGGER = "trigger"
    SEAL = "seal"
    OPEN = "open"
    RESEAL = "reseal"


@dataclass(frozen=True)
class BoardScoreSnapshot:
    snapshot_type: BoardScoreSnapshotType
    score: float | None
    stage: str
    captured_at: str | None = None
    board_name: str = ""
    board_code: str = ""
    board_change_pct: float | None = None
    main_logic: str = ""
    factors: list[dict[str, Any]] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class BoardScoreSnapshotBundle:
    trigger: BoardScoreSnapshot | None = None
    seal: BoardScoreSnapshot | None = None
    open_board: BoardScoreSnapshot | None = None
    reseal: BoardScoreSnapshot | None = None
