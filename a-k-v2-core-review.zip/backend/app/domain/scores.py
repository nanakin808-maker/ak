from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class ScoreType(str, Enum):
    TECHNICAL = "technical"
    REALTIME_SENTIMENT = "realtime_sentiment"
    ENTRY_SENTIMENT = "entry_sentiment"
    SEAL_SENTIMENT = "seal_sentiment"
    OPEN_BOARD_SENTIMENT = "open_board_sentiment"
    RESEAL_SENTIMENT = "reseal_sentiment"
    VOLUME = "volume"


@dataclass(frozen=True)
class ScoreRuleResult:
    label: str
    delta: float
    reason: str = ""


@dataclass(frozen=True)
class ScoreResult:
    score_type: ScoreType
    score: float | None
    rules: list[ScoreRuleResult] = field(default_factory=list)
    reason: str = ""
    snapshot_time: str | None = None
    is_snapshot: bool = False


@dataclass(frozen=True)
class StockScoreBundle:
    technical: ScoreResult | None = None
    realtime_sentiment: ScoreResult | None = None
    entry_sentiment: ScoreResult | None = None
    seal_sentiment: ScoreResult | None = None
    open_board_sentiment: ScoreResult | None = None
    reseal_sentiment: ScoreResult | None = None
    volume: ScoreResult | None = None
