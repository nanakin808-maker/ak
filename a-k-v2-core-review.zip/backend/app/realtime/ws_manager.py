"""
WebSocket connection manager: subscribe per trading_date, broadcast, heartbeat.
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any

from fastapi import WebSocket


class ConnectionState:
    def __init__(self, ws: WebSocket, trading_date: str) -> None:
        self.ws = ws
        self.trading_date = trading_date
        self.connected_at = time.time()
        self.last_msg_at = time.time()
        self.last_seq = 0
        self._alive = True

    @property
    def alive(self) -> bool:
        return self._alive

    def mark_dead(self) -> None:
        self._alive = False


class WebSocketManager:
    def __init__(self) -> None:
        self._connections: dict[str, list[ConnectionState]] = {}
        self._heartbeat_interval = 15.0
        self._heartbeat_task: asyncio.Task | None = None

    async def connect(self, ws: WebSocket, trading_date: str) -> ConnectionState:
        await ws.accept()
        conn = ConnectionState(ws, trading_date)
        self._connections.setdefault(trading_date, []).append(conn)
        self._start_heartbeat()
        return conn

    def disconnect(self, conn: ConnectionState) -> None:
        conn.mark_dead()
        td = conn.trading_date
        lst = self._connections.get(td, [])
        try:
            lst.remove(conn)
        except ValueError:
            pass
        if not lst:
            self._connections.pop(td, None)

    async def broadcast(self, trading_date: str, message: dict[str, Any]) -> None:
        conns = self._connections.get(trading_date, [])
        dead: list[ConnectionState] = []
        raw = json.dumps(message, ensure_ascii=False, default=str)
        for c in conns:
            if not c.alive:
                dead.append(c)
                continue
            try:
                await c.ws.send_text(raw)
                c.last_msg_at = time.time()
                c.last_seq = max(c.last_seq, message.get("seq", 0))
            except Exception:
                dead.append(c)
        for c in dead:
            self.disconnect(c)

    def _start_heartbeat(self) -> None:
        if self._heartbeat_task and not self._heartbeat_task.done():
            return
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    async def _heartbeat_loop(self) -> None:
        while True:
            await asyncio.sleep(self._heartbeat_interval)
            now = time.time()
            for td, conns in list(self._connections.items()):
                dead: list[ConnectionState] = []
                for c in conns:
                    if not c.alive:
                        dead.append(c)
                        continue
                    try:
                        await c.ws.send_json({
                            "type": "heartbeat",
                            "trading_date": td,
                            "seq": c.last_seq,
                            "as_of": None,
                            "data": {"server_time": now},
                        })
                    except Exception:
                        dead.append(c)
                for c in dead:
                    self.disconnect(c)

    @property
    def connection_count(self) -> int:
        return sum(len(v) for v in self._connections.values())

    @property
    def active_trading_dates(self) -> list[str]:
        return list(self._connections.keys())


_manager: WebSocketManager | None = None


def get_ws_manager() -> WebSocketManager:
    global _manager
    if _manager is None:
        _manager = WebSocketManager()
    return _manager
