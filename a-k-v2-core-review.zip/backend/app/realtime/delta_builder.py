"""
Build WS delta messages from scan results. No business logic.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any


def build_scan_status(trading_date: str, summary: dict[str, Any]) -> dict[str, Any]:
    return {
        "type": "scan_status",
        "trading_date": trading_date,
        "seq": summary.get("seq", 0),
        "as_of": datetime.utcnow().isoformat(),
        "data": {
            "scan_at": summary.get("scan_at"),
            "pre_candidate": summary.get("pre_candidate", 0),
            "candidates": summary.get("candidates", 0),
            "core_states": summary.get("core_states", 0),
            "core_transitions": summary.get("core_transitions", 0),
            "notifiable": summary.get("notifiable", 0),
            "errors": summary.get("errors", [])[-3:],
        },
    }


def build_stock_state_upsert(
    trading_date: str, seq: int, state: Any,
) -> dict[str, Any]:
    """Build upsert from MonitoringStockState row or dict."""
    if hasattr(state, "_mapping"):
        d = dict(state._mapping)
    elif isinstance(state, dict):
        d = state
    else:
        return _empty_msg("stock_state_upsert", trading_date, seq)
    return {
        "type": "stock_state_upsert",
        "trading_date": trading_date,
        "seq": seq,
        "as_of": str(d.get("as_of") or datetime.utcnow().isoformat()),
        "data": {
            "code": d.get("code", ""),
            "name": d.get("name", ""),
            "stage": d.get("stage", ""),
            "price": d.get("price"),
            "change_pct": d.get("change_pct"),
            "is_sealed": bool(d.get("is_sealed")),
            "at_limit": bool(d.get("at_limit")),
            "active_monitoring": bool(d.get("active_monitoring")),
            "freshness_status": d.get("freshness_status", ""),
            "source_trading_date": d.get("source_trading_date"),
        },
    }


def build_monitoring_event(
    trading_date: str, seq: int, event: Any,
) -> dict[str, Any]:
    if hasattr(event, "_mapping"):
        d = dict(event._mapping)
    elif isinstance(event, dict):
        d = event
    else:
        return _empty_msg("monitoring_event", trading_date, seq)
    return {
        "type": "monitoring_event",
        "trading_date": trading_date,
        "seq": seq,
        "as_of": str(d.get("as_of") or datetime.utcnow().isoformat()),
        "data": {
            "code": d.get("code", ""),
            "name": d.get("name", ""),
            "event_type": d.get("event_type", ""),
            "event_source": d.get("event_source", ""),
            "event_time": d.get("event_time", ""),
            "price": d.get("price"),
            "change_pct": d.get("change_pct"),
            "is_sealed": bool(d.get("is_sealed")),
        },
    }


def build_score_snapshot(
    trading_date: str, seq: int, snap: Any,
) -> dict[str, Any]:
    if hasattr(snap, "_mapping"):
        d = dict(snap._mapping)
    elif isinstance(snap, dict):
        d = snap
    else:
        return _empty_msg("score_snapshot", trading_date, seq)
    return {
        "type": "score_snapshot",
        "trading_date": trading_date,
        "seq": seq,
        "as_of": str(d.get("as_of") or datetime.utcnow().isoformat()),
        "data": {
            "code": d.get("code", ""),
            "score_stage": d.get("score_stage", ""),
            "technical_score": d.get("technical_score"),
            "sentiment_score": d.get("sentiment_score"),
            "volume_score": d.get("volume_score"),
            "score": d.get("score"),
            "status": d.get("status", ""),
        },
    }


def _empty_msg(typ: str, td: str, seq: int) -> dict[str, Any]:
    return {
        "type": typ, "trading_date": td, "seq": seq,
        "as_of": datetime.utcnow().isoformat(), "data": {},
    }
