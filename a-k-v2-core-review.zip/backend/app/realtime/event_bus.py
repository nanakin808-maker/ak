"""
In-memory pub/sub for scan-to-WebSocket events.
Non-blocking: queue full → drop oldest heartbeat, keep state updates.
"""

from __future__ import annotations

import asyncio
from typing import Any


class EventBus:
    def __init__(self, maxsize: int = 256) -> None:
        self._queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue(maxsize=maxsize)
        self._subscribers: list[asyncio.Queue[dict[str, Any]]] = []
        self._msg_count = 0

    def publish(self, message: dict[str, Any]) -> None:
        """Non-blocking publish. Drops oldest heartbeat/scan_status if full."""
        try:
            self._queue.put_nowait(message)
        except asyncio.QueueFull:
            # Drop oldest non-critical message to make room
            dropped = False
            while True:
                try:
                    old = self._queue.get_nowait()
                    if old.get("type") in ("heartbeat", "scan_status"):
                        dropped = True
                        continue
                    self._queue.put_nowait(old)
                    break
                except asyncio.QueueFull:
                    continue
                except asyncio.QueueEmpty:
                    break
            try:
                self._queue.put_nowait(message)
            except asyncio.QueueFull:
                pass  # truly full, drop this message

    async def subscribe(self) -> asyncio.Queue[dict[str, Any]]:
        """Returns a queue that receives future messages."""
        q: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=128)
        self._subscribers.append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue[dict[str, Any]]) -> None:
        try:
            self._subscribers.remove(q)
        except ValueError:
            pass

    async def _broadcast_loop(self) -> None:
        """Run as background task. Reads from main queue, fans out to subscribers."""
        while True:
            msg = await self._queue.get()
            if msg is None:
                break
            self._msg_count += 1
            dead: list[asyncio.Queue] = []
            for q in self._subscribers:
                try:
                    q.put_nowait(msg)
                except asyncio.QueueFull:
                    dead.append(q)
            for q in dead:
                self.unsubscribe(q)


# Singleton
_bus: EventBus | None = None


def get_event_bus() -> EventBus:
    global _bus
    if _bus is None:
        _bus = EventBus()
    return _bus
