from __future__ import annotations

from typing import Any


def ok(data: Any = None, **extra: Any) -> dict[str, Any]:
    result: dict[str, Any] = {"ok": True}
    if data is not None:
        result["data"] = data
    result.update(extra)
    return result


def error(message: str, code: str = "error", **extra: Any) -> dict[str, Any]:
    return {"ok": False, "error": message, "code": code, **extra}
