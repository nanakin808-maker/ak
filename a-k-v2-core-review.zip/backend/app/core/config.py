from __future__ import annotations

import os
from pathlib import Path
from pydantic_settings import BaseSettings


ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    app_name: str = "AStock Guard v2"
    host: str = "0.0.0.0"
    port: int = 8766
    debug: bool = False

    # Data sources
    ths_cookie: str = ""
    ths_hexin_v: str = ""
    feishu_webhook: str = ""
    feishu_secret: str = ""

    # Notification thresholds
    notify_kline_min_score: float = 50.0
    notify_seal_board_min_score: float = 50.0

    model_config = {"env_prefix": "ASTOCK_", "env_file": str(ROOT / ".env"), "extra": "ignore"}


settings = Settings()
