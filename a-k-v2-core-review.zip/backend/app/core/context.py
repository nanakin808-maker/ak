"""Application context holding shared services and state.

All singletons live here, initialized during lifespan startup.
"""

from __future__ import annotations


class AppContext:
    """Mutable app-wide context. Populated in lifespan on startup."""

    def __init__(self) -> None:
        self._started = False

    @property
    def started(self) -> bool:
        return self._started

    def start(self) -> None:
        self._started = True

    def stop(self) -> None:
        self._started = False


app_context = AppContext()
