from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import ExternalSourceActivationCurrent


class ExternalSourceActivationRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def get(self, *, source_key: str, trading_date: str) -> ExternalSourceActivationCurrent | None:
        return self.session.execute(
            select(ExternalSourceActivationCurrent).where(
                ExternalSourceActivationCurrent.source_key == source_key,
                ExternalSourceActivationCurrent.trading_date == trading_date,
            )
        ).scalar_one_or_none()

    def get_or_create(self, *, source_key: str, trading_date: str, default_state: str = "shadow") -> ExternalSourceActivationCurrent:
        row = self.get(source_key=source_key, trading_date=trading_date)
        if row is not None:
            return row
        row = ExternalSourceActivationCurrent(
            source_key=source_key, trading_date=trading_date, state=default_state,
            business_enabled=default_state in {"candidate", "active"},
            shadow_only=default_state not in {"candidate", "active"},
        )
        self.session.add(row)
        self.session.flush()
        return row

    def update_state(self, *, source_key: str, trading_date: str, state: str, reason: str = "", business_enabled: bool | None = None, shadow_only: bool | None = None, circuit_open_until: datetime | None = None) -> ExternalSourceActivationCurrent:
        row = self.get_or_create(source_key=source_key, trading_date=trading_date, default_state=state)
        row.state = state
        row.reason = reason
        if business_enabled is not None:
            row.business_enabled = business_enabled
        if shadow_only is not None:
            row.shadow_only = shadow_only
        row.circuit_open_until = circuit_open_until
        row.updated_at = datetime.utcnow()
        return row
