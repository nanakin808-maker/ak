from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import MonitoringEvent, MonitoringStateTransition, MonitoringStockState


class MonitoringRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def upsert_stock_state(
        self,
        *,
        trading_date: str,
        source_trading_date: str | None,
        code: str,
        name: str,
        stage: str,
        as_of: datetime,
        seq: int,
        freshness_status: str,
        price: float | None = None,
        change_pct: float | None = None,
        is_st: bool = False,
        is_sealed: bool = False,
        at_limit: bool = False,
        open_count: int | None = None,
        config_version: str | None = None,
        active_monitoring: bool | None = None,
        inactive_reason: str | None = None,
        inactive_at: datetime | None = None,
        clear_inactive: bool = False,
        first_seen_at: datetime | None = None,
        candidate_at: datetime | None = None,
    ) -> MonitoringStockState:
        existing = self.session.execute(
            select(MonitoringStockState).where(
                MonitoringStockState.trading_date == trading_date,
                MonitoringStockState.code == code,
            )
        ).scalar_one_or_none()

        if existing is None:
            existing = MonitoringStockState(
                trading_date=trading_date,
                source_trading_date=source_trading_date,
                code=code,
                name=name,
                stage=stage,
                as_of=as_of,
                seq=seq,
                freshness_status=freshness_status,
            )
            self.session.add(existing)

        existing.source_trading_date = source_trading_date
        existing.name = name
        existing.stage = stage
        existing.price = price
        existing.change_pct = change_pct
        existing.is_st = is_st
        existing.is_sealed = is_sealed
        existing.at_limit = at_limit
        existing.open_count = open_count
        existing.as_of = as_of
        existing.seq = seq
        existing.freshness_status = freshness_status
        if active_monitoring is not None:
            existing.active_monitoring = active_monitoring
        if inactive_reason is not None:
            existing.inactive_reason = inactive_reason
        if inactive_at is not None:
            existing.inactive_at = inactive_at
        if clear_inactive:
            existing.inactive_reason = None
            existing.inactive_at = None
        if first_seen_at is not None:
            existing.first_seen_at = first_seen_at
        if candidate_at is not None:
            existing.candidate_at = candidate_at
        existing.config_version = config_version
        return existing

    def get_stock_state(self, trading_date: str, code: str) -> MonitoringStockState | None:
        return self.session.execute(
            select(MonitoringStockState).where(
                MonitoringStockState.trading_date == trading_date,
                MonitoringStockState.code == code,
            )
        ).scalar_one_or_none()

    def list_stock_states(
        self,
        trading_date: str,
        *,
        freshness_status: str | None = None,
    ) -> list[MonitoringStockState]:
        stmt = select(MonitoringStockState).where(
            MonitoringStockState.trading_date == trading_date,
        )
        if freshness_status is not None:
            stmt = stmt.where(MonitoringStockState.freshness_status == freshness_status)
        stmt = stmt.order_by(MonitoringStockState.code.asc())
        return list(self.session.execute(stmt).scalars())

    def add_event(
        self,
        *,
        trading_date: str,
        source_trading_date: str | None,
        code: str,
        name: str,
        event_type: str,
        event_source: str,
        as_of: datetime,
        seq: int,
        freshness_status: str,
        event_time: str | None = None,
        price: float | None = None,
        change_pct: float | None = None,
        is_sealed: bool = False,
        is_first_seal: bool = False,
        open_count: int | None = None,
        raw_json: str = "{}",
    ) -> MonitoringEvent:
        event = MonitoringEvent(
            trading_date=trading_date,
            source_trading_date=source_trading_date,
            code=code,
            name=name,
            event_type=event_type,
            event_source=event_source,
            event_time=event_time,
            price=price,
            change_pct=change_pct,
            is_sealed=is_sealed,
            is_first_seal=is_first_seal,
            open_count=open_count,
            raw_json=raw_json,
            as_of=as_of,
            seq=seq,
            freshness_status=freshness_status,
        )
        self.session.add(event)
        return event

    def list_events_since(self, trading_date: str, since_seq: int = 0, limit: int = 100) -> list[MonitoringEvent]:
        return list(
            self.session.execute(
                select(MonitoringEvent)
                .where(
                    MonitoringEvent.trading_date == trading_date,
                    MonitoringEvent.seq > since_seq,
                )
                .order_by(MonitoringEvent.seq.asc())
                .limit(limit)
            ).scalars()
        )

    def add_transition(
        self,
        *,
        trading_date: str,
        source_trading_date: str | None,
        code: str,
        from_stage: str | None,
        to_stage: str,
        reason: str,
        as_of: datetime,
        seq: int,
        freshness_status: str,
        event_id: int | None = None,
        score_snapshot_id: int | None = None,
        config_version: str | None = None,
    ) -> MonitoringStateTransition:
        transition = MonitoringStateTransition(
            trading_date=trading_date,
            source_trading_date=source_trading_date,
            code=code,
            from_stage=from_stage,
            to_stage=to_stage,
            reason=reason,
            event_id=event_id,
            score_snapshot_id=score_snapshot_id,
            config_version=config_version,
            as_of=as_of,
            seq=seq,
            freshness_status=freshness_status,
        )
        self.session.add(transition)
        return transition
