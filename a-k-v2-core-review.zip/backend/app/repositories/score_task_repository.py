from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import ScoreTaskCurrent


class ScoreTaskRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def upsert_task(
        self,
        *,
        trading_date: str,
        source_trading_date: str | None,
        code: str,
        name: str,
        task_type: str,
        score_stage: str,
        source_type: str,
        as_of: datetime,
        seq: int,
        freshness_status: str,
        source_event_id: int | None = None,
        source_snapshot_id: int | None = None,
        source_row_id: int | None = None,
        components_json: str = '["technical","sentiment","volume"]',
        status: str = "pending",
        priority: int = 100,
        next_run_at: datetime | None = None,
        input_refs_json: str = "{}",
        config_version: str = "default",
    ) -> ScoreTaskCurrent:
        existing = self.session.execute(
            select(ScoreTaskCurrent).where(
                ScoreTaskCurrent.trading_date == trading_date,
                ScoreTaskCurrent.code == code,
                ScoreTaskCurrent.task_type == task_type,
                ScoreTaskCurrent.score_stage == score_stage,
                ScoreTaskCurrent.source_type == source_type,
                ScoreTaskCurrent.source_snapshot_id == source_snapshot_id,
                ScoreTaskCurrent.source_row_id == source_row_id,
                ScoreTaskCurrent.config_version == config_version,
            )
        ).scalar_one_or_none()

        if existing is None:
            existing = ScoreTaskCurrent(
                trading_date=trading_date,
                source_trading_date=source_trading_date,
                code=code,
                name=name,
                task_type=task_type,
                score_stage=score_stage,
                source_type=source_type,
                source_event_id=source_event_id,
                source_snapshot_id=source_snapshot_id,
                source_row_id=source_row_id,
                config_version=config_version,
                as_of=as_of,
                seq=seq,
                freshness_status=freshness_status,
            )
            self.session.add(existing)

        existing.source_trading_date = source_trading_date
        existing.name = name
        existing.source_event_id = source_event_id
        existing.components_json = components_json
        existing.status = status
        existing.priority = priority
        existing.next_run_at = next_run_at
        existing.input_refs_json = input_refs_json
        existing.as_of = as_of
        existing.seq = seq
        existing.freshness_status = freshness_status
        existing.updated_at = datetime.utcnow()
        return existing

    def list_pending(self, *, trading_date: str, limit: int = 100) -> list[ScoreTaskCurrent]:
        now = datetime.utcnow()
        return list(
            self.session.execute(
                select(ScoreTaskCurrent)
                .where(
                    ScoreTaskCurrent.trading_date == trading_date,
                    ScoreTaskCurrent.status == "pending",
                    (ScoreTaskCurrent.next_run_at.is_(None)) | (ScoreTaskCurrent.next_run_at <= now),
                )
                .order_by(ScoreTaskCurrent.priority.asc(), ScoreTaskCurrent.seq.asc(), ScoreTaskCurrent.id.asc())
                .limit(limit)
            ).scalars()
        )

    def mark_running(self, task_id: int, *, started_at: datetime | None = None) -> ScoreTaskCurrent | None:
        task = self.session.get(ScoreTaskCurrent, task_id)
        if task is None:
            return None
        task.status = "running"
        task.started_at = started_at or datetime.utcnow()
        task.attempts = (task.attempts or 0) + 1
        task.updated_at = datetime.utcnow()
        return task

    def mark_ready(self, task_id: int, *, finished_at: datetime | None = None) -> ScoreTaskCurrent | None:
        task = self.session.get(ScoreTaskCurrent, task_id)
        if task is None:
            return None
        task.status = "ready"
        task.finished_at = finished_at or datetime.utcnow()
        task.last_error = ""
        task.updated_at = datetime.utcnow()
        return task

    def mark_failed(self, task_id: int, *, error: str, next_run_at: datetime | None = None, finished_at: datetime | None = None) -> ScoreTaskCurrent | None:
        task = self.session.get(ScoreTaskCurrent, task_id)
        if task is None:
            return None
        max_attempts = task.max_attempts or 3
        task.status = "failed" if (task.attempts or 0) >= max_attempts else "pending"
        task.finished_at = finished_at or datetime.utcnow()
        task.last_error = error
        task.next_run_at = next_run_at
        task.updated_at = datetime.utcnow()
        return task
