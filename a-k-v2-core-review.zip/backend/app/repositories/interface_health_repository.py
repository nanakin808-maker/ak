from __future__ import annotations

from datetime import datetime

from sqlalchemy.orm import Session

from app.db.models import InterfaceHealth


class InterfaceHealthRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def record(
        self,
        *,
        name: str,
        category: str,
        ok: bool,
        latency_ms: float | None = None,
        error: str = "",
        detail_json: str = "{}",
        timestamp: datetime | None = None,
    ) -> InterfaceHealth:
        row = InterfaceHealth(
            timestamp=timestamp or datetime.utcnow(),
            name=name,
            category=category,
            ok=ok,
            latency_ms=latency_ms,
            error=error,
            detail_json=detail_json,
        )
        self.session.add(row)
        return row
