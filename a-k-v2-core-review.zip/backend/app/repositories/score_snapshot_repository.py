from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import ScoreSnapshot


class ScoreSnapshotRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def add_snapshot(
        self,
        *,
        trading_date: str,
        source_trading_date: str | None,
        code: str,
        name: str,
        score_type: str,
        score_stage: str,
        as_of: datetime,
        seq: int,
        freshness_status: str,
        score: float | None = None,
        status: str = "ready",
        passed: bool | None = None,
        reject_reason: str | None = None,
        technical_score: float | None = None,
        sentiment_score: float | None = None,
        volume_score: float | None = None,
        main_logic: str | None = None,
        board_rank: int | None = None,
        source_type: str | None = None,
        source_event_id: int | None = None,
        source_snapshot_id: int | None = None,
        source_row_id: int | None = None,
        score_json: str = "{}",
        input_refs_json: str = "{}",
        config_version: str | None = None,
    ) -> ScoreSnapshot:
        snapshot = ScoreSnapshot(
            trading_date=trading_date,
            source_trading_date=source_trading_date,
            code=code,
            name=name,
            score_type=score_type,
            score_stage=score_stage,
            score=score,
            status=status,
            passed=passed,
            reject_reason=reject_reason,
            technical_score=technical_score,
            sentiment_score=sentiment_score,
            volume_score=volume_score,
            main_logic=main_logic,
            board_rank=board_rank,
            source_type=source_type,
            source_event_id=source_event_id,
            source_snapshot_id=source_snapshot_id,
            source_row_id=source_row_id,
            score_json=score_json,
            input_refs_json=input_refs_json,
            config_version=config_version,
            as_of=as_of,
            seq=seq,
            freshness_status=freshness_status,
        )
        self.session.add(snapshot)
        return snapshot

    def list_for_code(self, trading_date: str, code: str, limit: int = 50) -> list[ScoreSnapshot]:
        return list(
            self.session.execute(
                select(ScoreSnapshot)
                .where(
                    ScoreSnapshot.trading_date == trading_date,
                    ScoreSnapshot.code == code,
                )
                .order_by(ScoreSnapshot.seq.desc(), ScoreSnapshot.id.desc())
                .limit(limit)
            ).scalars()
        )

    def latest_for_source(
        self,
        *,
        source_type: str,
        source_snapshot_id: int | None,
        source_row_id: int | None,
    ) -> ScoreSnapshot | None:
        return self.session.execute(
            select(ScoreSnapshot)
            .where(
                ScoreSnapshot.source_type == source_type,
                ScoreSnapshot.source_snapshot_id == source_snapshot_id,
                ScoreSnapshot.source_row_id == source_row_id,
            )
            .order_by(ScoreSnapshot.seq.desc(), ScoreSnapshot.id.desc())
            .limit(1)
        ).scalar_one_or_none()
