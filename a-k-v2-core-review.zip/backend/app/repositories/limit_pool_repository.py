from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import LimitPoolRow, LimitPoolSnapshot


class LimitPoolRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def add_snapshot(
        self,
        *,
        trading_date: str,
        source_trading_date: str | None,
        source: str,
        primary_source: str,
        as_of: datetime,
        seq: int,
        freshness_status: str,
        source_counts_json: str = "{}",
        fallback_errors_json: str = "[]",
        market_session: str | None = None,
        raw_json: str = "{}",
    ) -> LimitPoolSnapshot:
        snapshot = LimitPoolSnapshot(
            trading_date=trading_date,
            source_trading_date=source_trading_date,
            source=source,
            primary_source=primary_source,
            source_counts_json=source_counts_json,
            fallback_errors_json=fallback_errors_json,
            market_session=market_session,
            raw_json=raw_json,
            as_of=as_of,
            seq=seq,
            freshness_status=freshness_status,
        )
        self.session.add(snapshot)
        return snapshot

    def add_row(
        self,
        *,
        snapshot_id: int,
        trading_date: str,
        source_trading_date: str | None,
        pool: str,
        code: str,
        name: str,
        source: str,
        as_of: datetime,
        seq: int,
        freshness_status: str,
        price: float | None = None,
        change_pct: float | None = None,
        first_limit_time: str | None = None,
        last_limit_time: str | None = None,
        open_count: int | None = None,
        seal_amount: float | None = None,
        streak: int | None = None,
        industry: str | None = None,
        reason: str | None = None,
        raw_json: str = "{}",
    ) -> LimitPoolRow:
        row = LimitPoolRow(
            snapshot_id=snapshot_id,
            trading_date=trading_date,
            source_trading_date=source_trading_date,
            pool=pool,
            code=code,
            name=name,
            source=source,
            price=price,
            change_pct=change_pct,
            first_limit_time=first_limit_time,
            last_limit_time=last_limit_time,
            open_count=open_count,
            seal_amount=seal_amount,
            streak=streak,
            industry=industry,
            reason=reason,
            raw_json=raw_json,
            as_of=as_of,
            seq=seq,
            freshness_status=freshness_status,
        )
        self.session.add(row)
        return row

    def latest_snapshot(self, trading_date: str) -> LimitPoolSnapshot | None:
        return self.session.execute(
            select(LimitPoolSnapshot)
            .where(LimitPoolSnapshot.trading_date == trading_date)
            .order_by(LimitPoolSnapshot.seq.desc(), LimitPoolSnapshot.as_of.desc())
            .limit(1)
        ).scalar_one_or_none()

    def list_rows(self, snapshot_id: int, pool: str | None = None) -> list[LimitPoolRow]:
        stmt = select(LimitPoolRow).where(LimitPoolRow.snapshot_id == snapshot_id)
        if pool:
            stmt = stmt.where(LimitPoolRow.pool == pool)
        stmt = stmt.order_by(LimitPoolRow.pool.asc(), LimitPoolRow.first_limit_time.asc(), LimitPoolRow.code.asc())
        return list(self.session.execute(stmt).scalars())
