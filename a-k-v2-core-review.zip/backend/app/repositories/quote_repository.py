from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import QuoteSample


class QuoteRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def add_sample(
        self,
        *,
        trading_date: str,
        source_trading_date: str | None,
        code: str,
        timestamp: datetime,
        as_of: datetime,
        seq: int,
        freshness_status: str,
        price: float | None = None,
        change_pct: float | None = None,
        amount: float | None = None,
        volume: float | None = None,
        bid_vol1: float | None = None,
        ask_vol1: float | None = None,
        source: str = "",
    ) -> QuoteSample:
        sample = QuoteSample(
            trading_date=trading_date,
            source_trading_date=source_trading_date,
            code=code,
            timestamp=timestamp,
            price=price,
            change_pct=change_pct,
            amount=amount,
            volume=volume,
            bid_vol1=bid_vol1,
            ask_vol1=ask_vol1,
            source=source,
            as_of=as_of,
            seq=seq,
            freshness_status=freshness_status,
        )
        self.session.add(sample)
        return sample

    def list_window(self, trading_date: str, code: str, since: datetime) -> list[QuoteSample]:
        return list(
            self.session.execute(
                select(QuoteSample)
                .where(
                    QuoteSample.trading_date == trading_date,
                    QuoteSample.code == code,
                    QuoteSample.timestamp >= since,
                )
                .order_by(QuoteSample.timestamp.asc(), QuoteSample.seq.asc())
            ).scalars()
        )

    def list_recent_seconds(self, trading_date: str, code: str, now: datetime, seconds: int) -> list[QuoteSample]:
        return self.list_window(trading_date, code, now - timedelta(seconds=seconds))
