from __future__ import annotations

from typing import Any
from app.adapters.legacy.common_fields import board_change_pct, primary_board

from app.adapters.legacy.parsing import (
    Raw,
    as_dict,
    as_float,
    as_int,
    as_text,
    nested,
    extract_dict_rows,
    pick_float,
    pick_text,
)
from app.domain.opportunity_rules import infer_volume_status
from app.schemas.speed_rank import SpeedRankItem




def volume_score(row: Raw) -> float | None:
    return as_float(nested(row.get("volume_momentum_score"), "total")) or pick_float(
        row,
        "volume_score",
        "last_volume_event_score",
    )


def normalize_item(row: Raw, index: int) -> SpeedRankItem:
    v_score = volume_score(row)
    explicit_volume_status = pick_text(row, "volume_status")

    return SpeedRankItem(
        rank=as_int(row.get("rank")) or index + 1,
        code=pick_text(row, "code", "stock_code"),
        name=pick_text(row, "name", "stock_name") or "--",
        price=pick_float(row, "price", "latest_price", "last_price"),
        changePct=pick_float(row, "change_pct", "pct_chg", "changePct"),
        speedPct=pick_float(row, "speed_pct", "speedPct", "rank_speed", "velocity"),
        technicalScore=pick_float(row, "technical_score", "kline_score"),
        sentimentScore=pick_float(row, "display_sentiment_score", "sentiment_score"),
        volumeScore=v_score,
        volumeStatus=infer_volume_status(explicit_volume_status, v_score),
        board=primary_board(row),
        boardChangePct=board_change_pct(row),
        signal=pick_text(row, "signal", "event", "event_title", "reason"),
        eventTime=pick_text(row, "event_time", "time", "updated_at") or None,
        source=pick_text(row, "source", "event_source"),
    )


def extract_rows(payload: Raw) -> list[Raw]:
    return extract_dict_rows(
        payload,
        "rows",
        "data",
        "speed_rank",
        "speedRank",
        "rankings",
        "items",
        "stocks",
        nested_data_keys=("rows", "items", "speed_rank", "rankings", "stocks"),
    )


def normalize_speed_rank(payload: Raw) -> list[SpeedRankItem]:
    rows = extract_rows(payload)
    result: list[SpeedRankItem] = []
    seen: set[str] = set()

    for index, row in enumerate(rows):
        item = normalize_item(row, index)

        if not item.code or item.code in seen:
            continue

        seen.add(item.code)
        result.append(item)

    return result
