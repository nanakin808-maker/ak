from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any


LEGACY_TIMEOUT_SECONDS = 8


class LegacyHttpError(RuntimeError):
    pass


def fetch_legacy_json(
    url: str,
    *,
    method: str = "GET",
    timeout: int = LEGACY_TIMEOUT_SECONDS,
    body: bytes | None = None,
) -> dict[str, Any]:
    if not url:
        raise LegacyHttpError("旧接口 URL 未配置")

    request = urllib.request.Request(
        url,
        data=body,
        method=method,
        headers={
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw_body = response.read().decode("utf-8")
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise LegacyHttpError(f"旧接口请求失败：{exc}") from exc

    try:
        payload = json.loads(raw_body) if raw_body.strip() else {}
    except json.JSONDecodeError as exc:
        raise LegacyHttpError(f"旧接口 JSON 解析失败：{exc}") from exc

    if not isinstance(payload, dict):
        raise LegacyHttpError("旧接口返回不是 JSON object")

    return payload
