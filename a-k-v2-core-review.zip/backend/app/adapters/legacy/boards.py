from __future__ import annotations

from app.adapters.legacy.parsing import (
    Raw,
    as_dict,
    as_float,
    extract_dict_rows,
    pick_float,
    pick_int,
    pick_text,
)
from app.schemas.board import BoardItem


def infer_board_type(row: Raw) -> str:
    raw = pick_text(row, "board_type", "type", "category")

    if raw in {"concept", "industry", "region"}:
        return raw

    if any(word in raw for word in ("概念", "题材")):
        return "concept"

    if any(word in raw for word in ("行业", "申万")):
        return "industry"

    if "地域" in raw or "地区" in raw:
        return "region"

    return "unknown"


def extract_leader(row: Raw) -> tuple[str, str, float | None]:
    leader = as_dict(row.get("leader") or row.get("leading_stock"))

    code = str(leader.get("code") or pick_text(row, "leader_code", "leading_code", "leaderCode") or "")
    name = str(leader.get("name") or pick_text(row, "leader_name", "leading_name", "leaderName") or "")
    change = as_float(leader.get("change_pct")) or pick_float(row, "leader_change_pct", "leaderChangePct")

    return code, name, change


def normalize_item(row: Raw, index: int) -> BoardItem:
    leader_code, leader_name, leader_change = extract_leader(row)

    return BoardItem(
        rank=pick_int(row, "rank", "position") or index + 1,
        boardCode=pick_text(row, "board_code", "code", "boardCode"),
        boardName=pick_text(row, "board_name", "name", "boardName") or "--",
        boardType=infer_board_type(row),  # type: ignore[arg-type]
        changePct=pick_float(row, "change_pct", "pct_chg", "changePct"),
        hotScore=pick_float(row, "hot_score", "heat_score", "hotScore"),
        sentimentScore=pick_float(row, "sentiment_score", "score", "board_score"),
        limitUpCount=pick_int(row, "limit_up_count", "limit_count", "sealed_count"),
        openedCount=pick_int(row, "opened_count", "open_count", "broken_count"),
        stockCount=pick_int(row, "stock_count", "member_count", "count"),
        leaderCode=leader_code,
        leaderName=leader_name,
        leaderChangePct=leader_change,
        mainLogic=pick_text(row, "main_logic", "logic", "reason"),
        eventTime=pick_text(row, "event_time", "time", "updated_at") or None,
        source=pick_text(row, "source", "event_source"),
    )


def normalize_boards(payload: Raw) -> list[BoardItem]:
    rows = extract_dict_rows(
        payload,
        "rows",
        "data",
        "boards",
        "board_rank",
        "industries",
        "concepts",
        "items",
        nested_data_keys=("rows", "items", "boards", "board_rank", "industries", "concepts"),
    )

    result: list[BoardItem] = []
    seen: set[str] = set()

    for index, row in enumerate(rows):
        item = normalize_item(row, index)
        dedupe_key = item.boardCode or item.boardName

        if not dedupe_key or dedupe_key in seen:
            continue

        seen.add(dedupe_key)
        result.append(item)

    return result
