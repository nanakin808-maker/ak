from __future__ import annotations

from typing import Any
from app.adapters.legacy.common_fields import board_change_pct, primary_board
from app.adapters.legacy.parsing import (
    Raw,
    as_dict,
    as_float,
    as_text,
    nested,
    pick_float,
)

from app.domain.opportunity_rules import (
    infer_decision_stage,
    infer_event_tone,
    infer_volume_status,
)
from app.schemas.event import MonitorEvent
from app.schemas.opportunity import CandidateSummary









def sentiment_score(row: Raw) -> float:
    return (
        pick_float(
            row,
            "display_sentiment_score",
            "sentiment_score",
            "realtime_sentiment_score",
            "first_seal_sentiment_score",
            "entry_sentiment_score",
        )
        or as_float(nested(row.get("board_score"), "score"))
        or 0
    )


def first_seal_score(row: Raw) -> float | None:
    return pick_float(row, "first_seal_sentiment_score") or as_float(
        nested(row.get("board_score_seal_snapshot"), "score")
    )


def volume_score(row: Raw) -> float | None:
    return as_float(nested(row.get("volume_momentum_score"), "total")) or pick_float(
        row, "volume_score", "last_volume_event_score"
    )





def normalize_stock(row: Raw, fallback_stage: str) -> CandidateSummary:
    v_score = volume_score(row)

    return CandidateSummary(
        code=as_text(row.get("code")),
        name=as_text(row.get("name"), "--"),
        price=pick_float(row, "price", "latest_price") or 0,
        changePct=pick_float(row, "change_pct", "pct_chg") or 0,
        technicalScore=pick_float(row, "technical_score", "kline_score") or 0,
        sentimentScore=sentiment_score(row),
        firstSealSentimentScore=first_seal_score(row),
        volumeScore=v_score,
        volumeStatus=infer_volume_status(as_text(row.get("volume_status")), v_score),
        board=primary_board(row),
        boardChangePct=board_change_pct(row),
        decisionStage=infer_decision_stage(
      in_core=row.get("in_core") is True,
      sealed=row.get("sealed") is True,
      in_candidate=row.get("in_candidate") is True,
      rejected_today=row.get("rejected_today") is True,
      candidate_removed=row.get("candidate_removed") is True,
      fallback=fallback_stage,
    ),
    )


def normalize_opportunities(payload: Raw) -> list[CandidateSummary]:
    core = payload.get("core") if isinstance(payload.get("core"), list) else []
    candidates = payload.get("candidates") if isinstance(payload.get("candidates"), list) else []

    rows = [
        *(normalize_stock(row, "core") for row in core if isinstance(row, dict)),
        *(normalize_stock(row, "candidate") for row in candidates if isinstance(row, dict)),
    ]

    seen: set[str] = set()
    result: list[CandidateSummary] = []

    for row in rows:
        if not row.code or row.code in seen:
            continue
        seen.add(row.code)
        result.append(row)

    return result


def normalize_events(payload: Raw) -> list[MonitorEvent]:
    raw_events = payload.get("monitor_events")
    if not isinstance(raw_events, list):
        raw_events = payload.get("alerts") if isinstance(payload.get("alerts"), list) else []

    result: list[MonitorEvent] = []

    for index, item in enumerate(raw_events[:30]):
        if not isinstance(item, dict):
            continue

        event = (
            as_text(item.get("event"))
            or as_text(item.get("event_type"))
            or as_text(item.get("title"))
            or as_text(item.get("event_title"))
            or "事件"
        )
        time = (
            as_text(item.get("event_time"))
            or as_text(item.get("time"))
            or as_text(item.get("created_at"))
            or "--:--:--"
        )
        code = as_text(item.get("code"))
        name = as_text(item.get("name"), code or "--")
        source = as_text(item.get("source")) or as_text(item.get("event_source"))

        result.append(
            MonitorEvent(
                id=as_text(item.get("id"), f"{time}-{code}-{event}-{index}"),
                time=time,
                code=code,
                name=name,
                event=event,
                detail=source or event,
                tone=infer_event_tone(event),
            )
        )

    return result
