from __future__ import annotations

from typing import Any


Raw = dict[str, Any]


def as_dict(value: Any) -> Raw:
    return value if isinstance(value, dict) else {}


def as_float(value: Any) -> float | None:
    if isinstance(value, (int, float)):
        return float(value)

    if isinstance(value, str) and value.strip():
        try:
            return float(value)
        except ValueError:
            return None

    return None


def as_int(value: Any) -> int | None:
    if isinstance(value, int):
        return value

    if isinstance(value, float):
        return int(value)

    if isinstance(value, str) and value.strip():
        try:
            return int(float(value))
        except ValueError:
            return None

    return None


def as_text(value: Any, fallback: str = "") -> str:
    return value.strip() if isinstance(value, str) and value.strip() else fallback


def nested(value: Any, *keys: str) -> Any:
    current = value

    for key in keys:
        current = as_dict(current).get(key)

    return current


def pick_float(row: Raw, *keys: str) -> float | None:
    for key in keys:
        value = as_float(row.get(key))
        if value is not None:
            return value

    return None


def pick_int(row: Raw, *keys: str) -> int | None:
    for key in keys:
        value = as_int(row.get(key))
        if value is not None:
            return value

    return None


def pick_text(row: Raw, *keys: str) -> str:
    for key in keys:
        value = as_text(row.get(key))
        if value:
            return value

    return ""

def extract_dict_rows(
    payload: Raw,
    *top_level_keys: str,
    nested_data_keys: tuple[str, ...] | None = None,
) -> list[Raw]:
    for key in top_level_keys:
        value = payload.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]

    data = as_dict(payload.get("data"))
    keys = nested_data_keys or top_level_keys

    for key in keys:
        value = data.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]

    return []

