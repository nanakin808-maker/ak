from __future__ import annotations

from typing import Any
from app.adapters.legacy.common_fields import board_change_pct, primary_board

from app.adapters.legacy.parsing import (
    Raw,
    as_dict,
    as_float,
    as_int,
    as_text,
    nested,
    extract_dict_rows,
    pick_float,
    pick_text,
)
from app.schemas.limit_pool import LimitPoolItem


def infer_status(row: Raw) -> str:
    raw = pick_text(row, "status", "state", "pool_status", "event")

    if raw in {"sealed", "opened", "resealed", "near_limit", "broken"}:
        return raw

    if any(word in raw for word in ("回封", "再封")):
        return "resealed"

    if any(word in raw for word in ("炸板", "开板")):
        return "opened"

    if "涨停" in raw or "封板" in raw:
        return "sealed"

    if any(word in raw for word in ("接近涨停", "近涨停")):
        return "near_limit"

    if "破板" in raw:
        return "broken"

    if row.get("sealed") is True or row.get("at_limit") is True:
        return "sealed"

    if row.get("opened") is True or row.get("broken") is True:
        return "opened"

    return "unknown"




def normalize_item(row: Raw) -> LimitPoolItem:
    return LimitPoolItem(
        code=pick_text(row, "code", "stock_code"),
        name=pick_text(row, "name", "stock_name") or "--",
        price=pick_float(row, "price", "latest_price", "last_price"),
        changePct=pick_float(row, "change_pct", "pct_chg", "changePct"),
        status=infer_status(row),  # type: ignore[arg-type]
        board=primary_board(row),
        boardChangePct=board_change_pct(row),
        firstSealTime=pick_text(row, "first_seal_time", "seal_time", "firstSealTime") or None,
        lastEventTime=pick_text(row, "event_time", "last_event_time", "updated_at") or None,
        openCount=as_int(row.get("open_count") or row.get("openCount")),
        sealAmount=pick_float(row, "seal_amount", "sealAmount", "sealed_amount"),
        sentimentScore=pick_float(row, "sentiment_score", "display_sentiment_score"),
        firstSealSentimentScore=pick_float(row, "first_seal_sentiment_score")
        or as_float(nested(row.get("board_score_seal_snapshot"), "score")),
        source=pick_text(row, "source", "event_source"),
    )


def extract_rows(payload: Raw) -> list[Raw]:
    return extract_dict_rows(
        payload,
        "rows",
        "data",
        "limit_pool",
        "pool",
        "items",
        "stocks",
        nested_data_keys=("rows", "items", "pool", "stocks"),
    )


def normalize_limit_pool(payload: Raw) -> list[LimitPoolItem]:
    rows = extract_rows(payload)
    result: list[LimitPoolItem] = []
    seen: set[str] = set()

    for row in rows:
        item = normalize_item(row)

        if not item.code or item.code in seen:
            continue

        seen.add(item.code)
        result.append(item)

    return result
