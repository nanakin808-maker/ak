from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from datetime import datetime
from typing import Any

from app.schemas.engine import EngineResponse, EngineState


ACTION_ENV = {
    "status": "LEGACY_ENGINE_STATUS_URL",
    "start": "LEGACY_ENGINE_START_URL",
    "stop": "LEGACY_ENGINE_STOP_URL",
    "reset": "LEGACY_ENGINE_RESET_URL",
}

METHOD_ENV = {
    "status": "LEGACY_ENGINE_STATUS_METHOD",
    "start": "LEGACY_ENGINE_START_METHOD",
    "stop": "LEGACY_ENGINE_STOP_METHOD",
    "reset": "LEGACY_ENGINE_RESET_METHOD",
}

VALID_STATUS = {"idle", "running", "stopped", "error"}


def now_text() -> str:
    return datetime.now().isoformat(timespec="seconds")


def legacy_url(action: str) -> str:
    value = os.getenv(ACTION_ENV[action], "").strip()

    if value:
        return value

    if action == "status":
        return os.getenv("LEGACY_ALERTS_STATE_URL", "").strip()

    return ""


def legacy_method(action: str) -> str:
    default = "GET" if action == "status" else "POST"
    return os.getenv(METHOD_ENV[action], default).strip().upper()


def is_configured(action: str) -> bool:
    return bool(legacy_url(action))


def any_legacy_engine_configured() -> bool:
    return any(legacy_url(action) for action in ACTION_ENV)


def as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def text(value: Any, fallback: str = "") -> str:
    return value.strip() if isinstance(value, str) and value.strip() else fallback


def bool_value(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        lower = value.strip().lower()
        if lower in {"true", "1", "yes", "running", "active"}:
            return True
        if lower in {"false", "0", "no", "stopped", "idle"}:
            return False
    return None


def request_json(action: str) -> dict[str, Any]:
    url = legacy_url(action)

    if not url:
        raise RuntimeError(f"{ACTION_ENV[action]} 未配置")

    method = legacy_method(action)
    data = b"{}" if method in {"POST", "PUT", "PATCH"} else None

    request = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
    )

    with urllib.request.urlopen(request, timeout=8) as response:
        body = response.read().decode("utf-8")
        payload = json.loads(body) if body.strip() else {}

    if not isinstance(payload, dict):
        raise RuntimeError("旧引擎接口返回不是 JSON object")

    return payload


def flatten_payload(payload: dict[str, Any]) -> dict[str, Any]:
    state = as_dict(payload.get("state"))
    data = as_dict(payload.get("data"))
    control = as_dict(payload.get("control"))
    engine = as_dict(payload.get("engine"))

    merged: dict[str, Any] = {}
    merged.update(payload)
    merged.update(data)
    merged.update(state)
    merged.update(control)
    merged.update(engine)

    return merged


def infer_running(data: dict[str, Any]) -> bool:
    for key in (
        "running",
        "is_running",
        "active",
        "enabled",
        "alert_running",
        "engine_running",
    ):
        value = bool_value(data.get(key))
        if value is not None:
            return value

    status = text(data.get("status")).lower()
    if status == "running":
        return True
    if status in {"idle", "stopped", "error"}:
        return False

    return False


def infer_status(data: dict[str, Any], action: str, running: bool) -> str:
    explicit = text(data.get("status")).lower()

    if explicit in VALID_STATUS:
        return explicit

    legacy_error = text(data.get("last_error"))
    if legacy_error:
        return "error"

    if action == "start":
        return "running"
    if action == "stop":
        return "stopped"
    if action == "reset":
        return "idle"

    return "running" if running else "stopped"


def infer_message(data: dict[str, Any], payload: dict[str, Any], action: str) -> str:
    last_error = text(data.get("last_error"))

    if last_error:
        return last_error

    return (
        text(data.get("message"))
        or text(payload.get("message"))
        or f"旧引擎 {action} 接口调用成功"
    )


def normalize_response(payload: dict[str, Any], action: str) -> EngineResponse:
    data = flatten_payload(payload)
    running = infer_running(data)
    status = infer_status(data, action, running)
    message = infer_message(data, payload, action)

    state = EngineState(
        status=status,  # type: ignore[arg-type]
        running=status == "running" or running,
        startedAt=text(data.get("startedAt")) or text(data.get("started_at")) or None,
        stoppedAt=text(data.get("stoppedAt")) or text(data.get("stopped_at")) or None,
        resetAt=text(data.get("resetAt")) or text(data.get("reset_at")) or None,
        message=message,
    )

    if action == "start" and state.startedAt is None:
        state.startedAt = now_text()
    if action == "stop" and state.stoppedAt is None:
        state.stoppedAt = now_text()
    if action == "reset" and state.resetAt is None:
        state.resetAt = now_text()

    return EngineResponse(ok=status != "error", state=state)


def error_response(action: str, error: Exception) -> EngineResponse:
    return EngineResponse(
        ok=False,
        state=EngineState(
            status="error",
            running=False,
            message=f"旧引擎 {action} 接口请求失败：{error}",
        ),
    )


def call_legacy_engine(action: str) -> EngineResponse:
    try:
        payload = request_json(action)
        return normalize_response(payload, action)
    except (
        RuntimeError,
        urllib.error.URLError,
        TimeoutError,
        json.JSONDecodeError,
        OSError,
    ) as exc:
        return error_response(action, exc)
