from __future__ import annotations

from app.adapters.legacy.parsing import Raw, as_dict, as_float, as_text, nested, pick_float, pick_text


def primary_board(row: Raw) -> str:
    board_summary = as_dict(row.get("board_summary"))
    concepts = board_summary.get("strong_concepts")
    first = as_dict(concepts[0]) if isinstance(concepts, list) and concepts else {}

    return (
        as_text(first.get("board_name"))
        or as_text(nested(row.get("board_score"), "main_logic", "primary", "board_name"))
        or as_text(nested(row.get("main_logic"), "board_name"))
        or pick_text(row, "board", "main_board", "concept")
        or "--"
    )


def board_change_pct(row: Raw) -> float | None:
    board_summary = as_dict(row.get("board_summary"))
    concepts = board_summary.get("strong_concepts")
    first = as_dict(concepts[0]) if isinstance(concepts, list) and concepts else {}

    return (
        as_float(first.get("change_pct"))
        or as_float(nested(row.get("board_score"), "main_logic", "primary", "change_pct"))
        or pick_float(row, "main_logic_change_pct", "board_change_pct")
    )
