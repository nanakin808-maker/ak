from __future__ import annotations

from sqlalchemy.engine import Engine

from app.db.base import Base
from app.db.models import (  # noqa: F401
    DailyBar,
    DailyBarCoverage,
    ExternalSourceActivationCurrent,
    GateConfigVersion,
    InterfaceHealth,
    LimitPoolRow,
    LimitPoolSnapshot,
    MonitoringEvent,
    MonitoringStateTransition,
    MonitoringStockState,
    NotificationRecord,
    QuoteSample,
    ScoreSnapshot,
    ScoreTaskCurrent,
    SelfStockRecord,
    StockMetaCache,
)
from app.db.session import engine


def init_db(target_engine: Engine | None = None) -> None:
    eng = target_engine or engine
    Base.metadata.create_all(bind=eng)
    # Enable WAL mode so concurrent reads don't block on writes
    with eng.connect() as conn:
        conn.exec_driver_sql("PRAGMA journal_mode=WAL")
        conn.exec_driver_sql("PRAGMA busy_timeout=5000")


if __name__ == "__main__":
    init_db()
