from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.db.models.mixins import TimeScopeMixin


class DailyBar(Base):
    __tablename__ = "daily_bars"

    code: Mapped[str] = mapped_column(String(16), primary_key=True)
    date: Mapped[str] = mapped_column(String(10), primary_key=True)
    name: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    open: Mapped[float | None] = mapped_column(Float)
    close: Mapped[float | None] = mapped_column(Float)
    high: Mapped[float | None] = mapped_column(Float)
    low: Mapped[float | None] = mapped_column(Float)
    volume: Mapped[int | None] = mapped_column(Integer)
    amount: Mapped[float | None] = mapped_column(Float)
    amplitude: Mapped[float | None] = mapped_column(Float)
    change_pct: Mapped[float | None] = mapped_column(Float)
    change_amount: Mapped[float | None] = mapped_column(Float)
    turnover_rate: Mapped[float | None] = mapped_column(Float)
    source: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    fetched_at: Mapped[datetime | None] = mapped_column(DateTime)


class DailyBarCoverage(Base):
    __tablename__ = "daily_bar_coverage"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    start_date: Mapped[str] = mapped_column(String(10), nullable=False)
    end_date: Mapped[str] = mapped_column(String(10), nullable=False)
    source: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="ready", nullable=False)
    error: Mapped[str] = mapped_column(Text, default="", nullable=False)
    fetched_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        Index("ix_daily_bar_coverage_code_range", "code", "start_date", "end_date"),
    )


class QuoteSample(Base, TimeScopeMixin):
    __tablename__ = "quote_samples"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    timestamp: Mapped[datetime] = mapped_column(DateTime, index=True, nullable=False)
    price: Mapped[float | None] = mapped_column(Float)
    change_pct: Mapped[float | None] = mapped_column(Float)
    amount: Mapped[float | None] = mapped_column(Float)
    volume: Mapped[float | None] = mapped_column(Float)
    bid_vol1: Mapped[float | None] = mapped_column(Float)
    ask_vol1: Mapped[float | None] = mapped_column(Float)
    source: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        Index("ix_quote_samples_code_date_ts", "code", "trading_date", "timestamp"),
    )


class StockMetaCache(Base):
    __tablename__ = "stock_meta_cache"

    code: Mapped[str] = mapped_column(String(16), primary_key=True)
    name: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    float_share: Mapped[float | None] = mapped_column(Float)
    float_market_value: Mapped[float | None] = mapped_column(Float)
    total_market_value: Mapped[float | None] = mapped_column(Float)
    source: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    source_updated_at: Mapped[datetime | None] = mapped_column(DateTime)
    as_of: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    freshness_status: Mapped[str] = mapped_column(String(32), default="unknown", nullable=False)
    raw_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class GateConfigVersion(Base):
    __tablename__ = "gate_config_versions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    version: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    base_filter_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    candidate_entry_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    core_gate_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    notification_gate_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    self_stock_gate_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    created_by: Mapped[str] = mapped_column(String(64), default="system", nullable=False)
    note: Mapped[str] = mapped_column(Text, default="", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class InterfaceHealth(Base):
    __tablename__ = "interface_health"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(128), index=True, nullable=False)
    category: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    ok: Mapped[bool] = mapped_column(Boolean, nullable=False)
    latency_ms: Mapped[float | None] = mapped_column(Float)
    error: Mapped[str] = mapped_column(Text, default="", nullable=False)
    detail_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
