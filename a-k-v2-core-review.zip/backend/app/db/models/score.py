from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.db.models.mixins import TimeScopeMixin


class ScoreSnapshot(Base, TimeScopeMixin):
    __tablename__ = "score_snapshots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(64), default="", nullable=False)

    score_type: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    score_stage: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    score: Mapped[float | None] = mapped_column(Float)

    status: Mapped[str] = mapped_column(String(32), default="unknown", nullable=False)
    passed: Mapped[bool | None] = mapped_column(Boolean)
    reject_reason: Mapped[str | None] = mapped_column(Text)

    technical_score: Mapped[float | None] = mapped_column(Float)
    sentiment_score: Mapped[float | None] = mapped_column(Float)
    volume_score: Mapped[float | None] = mapped_column(Float)
    main_logic: Mapped[str | None] = mapped_column(String(128))
    board_rank: Mapped[int | None] = mapped_column(Integer)

    source_type: Mapped[str | None] = mapped_column(String(64))
    source_event_id: Mapped[int | None] = mapped_column(Integer)
    source_snapshot_id: Mapped[int | None] = mapped_column(Integer)
    source_row_id: Mapped[int | None] = mapped_column(Integer)

    score_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    input_refs_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    config_version: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        Index("ix_score_snapshots_code_date_type", "code", "trading_date", "score_type"),
        Index("ix_score_snapshots_source", "source_type", "source_snapshot_id", "source_row_id"),
    )
