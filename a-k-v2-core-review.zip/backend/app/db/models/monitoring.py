from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.db.models.mixins import TimeScopeMixin, TimestampMixin


class MonitoringStockState(Base, TimeScopeMixin, TimestampMixin):
    __tablename__ = "monitoring_stock_states"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    stage: Mapped[str] = mapped_column(String(32), index=True, nullable=False)

    price: Mapped[float | None] = mapped_column(Float)
    change_pct: Mapped[float | None] = mapped_column(Float)
    is_st: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_sealed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    at_limit: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    seal_volume: Mapped[float | None] = mapped_column(Float)
    open_count: Mapped[int | None] = mapped_column(Integer)

    first_seen_at: Mapped[datetime | None] = mapped_column(DateTime)
    candidate_at: Mapped[datetime | None] = mapped_column(DateTime)
    core_at: Mapped[datetime | None] = mapped_column(DateTime)
    rejected_at: Mapped[datetime | None] = mapped_column(DateTime)

    last_event_id: Mapped[int | None] = mapped_column(Integer)
    last_score_snapshot_id: Mapped[int | None] = mapped_column(Integer)
    last_notification_id: Mapped[int | None] = mapped_column(Integer)
    active_monitoring: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    inactive_reason: Mapped[str | None] = mapped_column(String(128))
    inactive_at: Mapped[datetime | None] = mapped_column(DateTime)
    self_stock_status: Mapped[str | None] = mapped_column(String(32))
    config_version: Mapped[str | None] = mapped_column(String(64))

    __table_args__ = (
        UniqueConstraint("trading_date", "code", name="uq_monitoring_stock_states_date_code"),
        Index("ix_monitoring_stock_states_stage_date", "trading_date", "stage"),
    )


class MonitoringEvent(Base, TimeScopeMixin, TimestampMixin):
    __tablename__ = "monitoring_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    event_type: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    event_source: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    event_time: Mapped[str | None] = mapped_column(String(32))

    price: Mapped[float | None] = mapped_column(Float)
    change_pct: Mapped[float | None] = mapped_column(Float)
    is_sealed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_first_seal: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    seal_volume: Mapped[float | None] = mapped_column(Float)
    open_count: Mapped[int | None] = mapped_column(Integer)

    raw_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)

    __table_args__ = (
        Index("ix_monitoring_events_date_seq", "trading_date", "seq"),
        Index("ix_monitoring_events_code_date", "code", "trading_date"),
    )


class MonitoringStateTransition(Base, TimeScopeMixin):
    __tablename__ = "monitoring_state_transitions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    from_stage: Mapped[str | None] = mapped_column(String(32))
    to_stage: Mapped[str] = mapped_column(String(32), index=True, nullable=False)
    reason: Mapped[str] = mapped_column(Text, default="", nullable=False)
    event_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("monitoring_events.id"))
    score_snapshot_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("score_snapshots.id"))
    config_version: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        Index("ix_monitoring_state_transitions_code_date", "code", "trading_date"),
    )
