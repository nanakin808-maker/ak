"""
Scoring context: stores raw input data snapshots for replay/audit.

SQLite keeps last 3 per (code, score_stage). Full history in JSONL.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Float, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class ScoringContext(Base):
    __tablename__ = "scoring_contexts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    trading_date: Mapped[str] = mapped_column(String(10), index=True, nullable=False)
    code: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(64), default="")
    event_type: Mapped[str] = mapped_column(String(32), default="")
    score_stage: Mapped[str] = mapped_column(String(32), default="")
    snapshot_time: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    price: Mapped[float | None] = mapped_column(Float)
    change_pct: Mapped[float | None] = mapped_column(Float)
    scores_json: Mapped[str] = mapped_column(Text, default="{}")
    context_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_scoring_ctx_code_date_stage", "code", "trading_date", "score_stage"),
    )
