from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.db.models.mixins import TimeScopeMixin


class ScoreTaskCurrent(Base, TimeScopeMixin):
    __tablename__ = "score_task_current"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    code: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(64), default="", nullable=False)

    task_type: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    score_stage: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    components_json: Mapped[str] = mapped_column(Text, default="[]", nullable=False)

    source_type: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    source_event_id: Mapped[int | None] = mapped_column(Integer)
    source_snapshot_id: Mapped[int | None] = mapped_column(Integer)
    source_row_id: Mapped[int | None] = mapped_column(Integer)

    status: Mapped[str] = mapped_column(String(32), default="pending", index=True, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, default=100, index=True, nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    max_attempts: Mapped[int] = mapped_column(Integer, default=3, nullable=False)
    next_run_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime)
    last_error: Mapped[str] = mapped_column(Text, default="", nullable=False)

    input_refs_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    config_version: Mapped[str] = mapped_column(String(64), default="default", nullable=False)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    __table_args__ = (
        UniqueConstraint(
            "trading_date",
            "code",
            "task_type",
            "score_stage",
            "source_type",
            "source_snapshot_id",
            "source_row_id",
            "config_version",
            name="uq_score_task_current_idempotency",
        ),
        Index("ix_score_task_current_ready", "trading_date", "status", "priority", "next_run_at"),
        Index("ix_score_task_current_source", "source_type", "source_snapshot_id", "source_row_id"),
    )
