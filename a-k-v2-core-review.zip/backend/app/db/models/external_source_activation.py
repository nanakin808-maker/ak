from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class ExternalSourceActivationCurrent(Base):
    __tablename__ = "external_source_activation_current"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    source_key: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    trading_date: Mapped[str] = mapped_column(String(16), nullable=False, index=True)

    state: Mapped[str] = mapped_column(String(32), default="shadow", nullable=False, index=True)
    reason: Mapped[str] = mapped_column(String(256), default="", nullable=False)

    total_calls: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    ok_calls: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    fail_calls: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    consecutive_failures: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    last_ok_at: Mapped[datetime | None] = mapped_column(DateTime)
    last_fail_at: Mapped[datetime | None] = mapped_column(DateTime)
    circuit_open_until: Mapped[datetime | None] = mapped_column(DateTime)

    last_freshness_status: Mapped[str] = mapped_column(String(32), default="unknown", nullable=False)
    last_latency_ms: Mapped[float | None] = mapped_column(Float)
    last_error: Mapped[str] = mapped_column(Text, default="", nullable=False)
    last_detail_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)

    business_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    shadow_only: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    __table_args__ = (
        UniqueConstraint("source_key", "trading_date", name="uq_external_source_activation_current"),
        Index("ix_external_source_activation_state", "trading_date", "state"),
    )
