from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.db.models.mixins import TimeScopeMixin


class LimitPoolSnapshot(Base, TimeScopeMixin):
    __tablename__ = "limit_pool_snapshots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source: Mapped[str] = mapped_column(String(64), nullable=False)
    primary_source: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    source_counts_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    fallback_errors_json: Mapped[str] = mapped_column(Text, default="[]", nullable=False)
    data_event_time: Mapped[str | None] = mapped_column(String(32))
    source_updated_at: Mapped[datetime | None] = mapped_column(DateTime)
    market_session: Mapped[str | None] = mapped_column(String(32))
    raw_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        Index("ix_limit_pool_snapshots_date_seq", "trading_date", "seq"),
    )


class LimitPoolRow(Base, TimeScopeMixin):
    __tablename__ = "limit_pool_rows"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    snapshot_id: Mapped[int] = mapped_column(Integer, ForeignKey("limit_pool_snapshots.id"), index=True, nullable=False)
    pool: Mapped[str] = mapped_column(String(32), index=True, nullable=False)
    code: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    source: Mapped[str] = mapped_column(String(64), default="", nullable=False)

    price: Mapped[float | None] = mapped_column(Float)
    change_pct: Mapped[float | None] = mapped_column(Float)
    first_limit_time: Mapped[str | None] = mapped_column(String(32))
    last_limit_time: Mapped[str | None] = mapped_column(String(32))
    open_count: Mapped[int | None] = mapped_column(Integer)
    seal_amount: Mapped[float | None] = mapped_column(Float)
    streak: Mapped[int | None] = mapped_column(Integer)
    industry: Mapped[str | None] = mapped_column(String(128))
    reason: Mapped[str | None] = mapped_column(Text)
    raw_json: Mapped[str] = mapped_column(Text, default="{}", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        Index("ix_limit_pool_rows_snapshot_pool", "snapshot_id", "pool"),
        Index("ix_limit_pool_rows_code_date", "code", "trading_date"),
    )
