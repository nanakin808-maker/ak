from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class TimeScopeMixin:
    trading_date: Mapped[str] = mapped_column(String(10), index=True, nullable=False)
    source_trading_date: Mapped[str | None] = mapped_column(String(10), index=True, nullable=True)
    as_of: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True, nullable=False)
    seq: Mapped[int] = mapped_column(Integer, default=0, index=True, nullable=False)
    freshness_status: Mapped[str] = mapped_column(String(32), default="unknown", index=True, nullable=False)
