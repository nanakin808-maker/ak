from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from sqlalchemy.orm import Session

from app.domain.time_scope import (
    MarketSession,
    TimeScope,
    can_trigger_core,
    evaluate_freshness,
)
from app.repositories import MonitoringRepository
from app.runtime.state import RuntimeState, RuntimeStockState


@dataclass(slots=True)
class RuntimeInputEvent:
    trading_date: str
    source_trading_date: str | None
    code: str
    name: str
    event_type: str
    event_source: str
    as_of: datetime
    seq: int
    market_session: MarketSession = MarketSession.UNKNOWN
    event_time: str | None = None
    price: float | None = None
    change_pct: float | None = None
    is_sealed: bool = False
    is_first_seal: bool = False
    at_limit: bool = False
    open_count: int | None = None
    raw_json: str = "{}"


@dataclass(slots=True)
class EventProcessResult:
    event_id: int
    trading_date: str
    source_trading_date: str | None
    code: str
    freshness_status: str
    action: str
    stage: str | None = None
    transition_id: int | None = None
    reason: str = ""


class EventProcessor:
    def __init__(self, session: Session, runtime: RuntimeState) -> None:
        self.session = session
        self.runtime = runtime
        self.monitoring = MonitoringRepository(session)

    def _freshness_str(self, freshness: str) -> str:
        return freshness if isinstance(freshness, str) else freshness.value

    def _make_scope(self, event: RuntimeInputEvent, freshness: str) -> TimeScope:
        return TimeScope(
            trading_date=event.trading_date,
            source_trading_date=event.source_trading_date,
            as_of=event.as_of,
            source_updated_at=None,
            freshness_status=self._freshness_str(freshness),
            seq=event.seq,
            market_session=event.market_session.value if hasattr(event.market_session, "value") else str(event.market_session),
        )

    def _update_runtime(self, state: Any) -> None:
        self.runtime.set_stock_state(
            RuntimeStockState(
                trading_date=state.trading_date,
                source_trading_date=state.source_trading_date,
                code=state.code,
                name=state.name,
                stage=state.stage,
                price=state.price,
                change_pct=state.change_pct,
                is_sealed=state.is_sealed,
                at_limit=state.at_limit,
                open_count=state.open_count,
                as_of=state.as_of,
                seq=state.seq,
                freshness_status=state.freshness_status,
                active_monitoring=state.active_monitoring,
                inactive_reason=state.inactive_reason,
                inactive_at=state.inactive_at,
            )
        )

    def _upsert_active_state(self, event: RuntimeInputEvent, freshness: str, stage: str) -> Any:
        return self.monitoring.upsert_stock_state(
            trading_date=event.trading_date,
            source_trading_date=event.source_trading_date,
            code=event.code,
            name=event.name,
            stage=stage,
            price=event.price,
            change_pct=event.change_pct,
            is_sealed=event.is_sealed,
            at_limit=event.at_limit,
            open_count=event.open_count,
            as_of=event.as_of,
            seq=event.seq,
            freshness_status=self._freshness_str(freshness),
            active_monitoring=True,
            clear_inactive=True,
        )

    def _record_event_only(self, db_event: Any, event: RuntimeInputEvent, freshness: str, reason: str) -> EventProcessResult:
        return EventProcessResult(
            event_id=db_event.id,
            trading_date=event.trading_date,
            source_trading_date=event.source_trading_date,
            code=event.code,
            freshness_status=self._freshness_str(freshness),
            action="record_event_only",
            reason=reason,
        )

    def process_event(self, event: RuntimeInputEvent) -> EventProcessResult:
        freshness = evaluate_freshness(
            trading_date=event.trading_date,
            source_trading_date=event.source_trading_date,
            market_session=event.market_session,
        )

        scope = self._make_scope(event, freshness)

        # 1. Always record the event
        db_event = self.monitoring.add_event(
            trading_date=event.trading_date,
            source_trading_date=event.source_trading_date,
            code=event.code,
            name=event.name,
            event_type=event.event_type,
            event_source=event.event_source,
            event_time=event.event_time,
            price=event.price,
            change_pct=event.change_pct,
            is_sealed=event.is_sealed,
            is_first_seal=event.is_first_seal,
            open_count=event.open_count,
            raw_json=event.raw_json,
            as_of=event.as_of,
            seq=event.seq,
            freshness_status=self._freshness_str(freshness),
        )
        self.session.flush()
        self.runtime.record_event(event.trading_date, db_event.id, event.seq)

        # 2. Freshness check — only FRESH allows lifecycle transitions
        if not can_trigger_core(scope):
            return self._record_event_only(db_event, event, freshness, "freshness_not_allowed")

        # 3. Read current state
        previous = self.monitoring.get_stock_state(event.trading_date, event.code)
        is_opening = event.event_type == "LIMIT_UP_OPENED" or not event.is_sealed
        is_sealing = event.event_type == "LIMIT_UP_SEALED" and event.is_sealed

        # 4. CORE -> CANDIDATE: opened/unsealed while in CORE
        if previous is not None and previous.stage == "CORE" and is_opening:
            state = self._upsert_active_state(event, freshness, "CANDIDATE")
            transition = self.monitoring.add_transition(
                trading_date=event.trading_date,
                source_trading_date=event.source_trading_date,
                code=event.code,
                from_stage="CORE",
                to_stage="CANDIDATE",
                reason="limit_up_opened",
                event_id=db_event.id,
                as_of=event.as_of,
                seq=event.seq,
                freshness_status=self._freshness_str(freshness),
            )
            self.session.flush()
            self._update_runtime(state)

            return EventProcessResult(
                event_id=db_event.id,
                trading_date=event.trading_date,
                source_trading_date=event.source_trading_date,
                code=event.code,
                freshness_status=self._freshness_str(freshness),
                action="core_opened_to_candidate",
                stage="CANDIDATE",
                transition_id=transition.id,
                reason="limit_up_opened",
            )

        # 5. Already CORE + still sealed → update state, no duplicate transition
        if previous is not None and previous.stage == "CORE" and is_sealing:
            state = self._upsert_active_state(event, freshness, "CORE")
            self.session.flush()
            self._update_runtime(state)

            return EventProcessResult(
                event_id=db_event.id,
                trading_date=event.trading_date,
                source_trading_date=event.source_trading_date,
                code=event.code,
                freshness_status=self._freshness_str(freshness),
                action="already_core",
                stage="CORE",
                reason="already_core",
            )

        # 6. CANDIDATE / NEW -> CORE: first-time or re-seal after open
        if is_sealing:
            from_stage = previous.stage if previous else "CANDIDATE"
            state = self._upsert_active_state(event, freshness, "CORE")
            transition = self.monitoring.add_transition(
                trading_date=event.trading_date,
                source_trading_date=event.source_trading_date,
                code=event.code,
                from_stage=from_stage,
                to_stage="CORE",
                reason="limit_up_sealed",
                event_id=db_event.id,
                as_of=event.as_of,
                seq=event.seq,
                freshness_status=self._freshness_str(freshness),
            )
            self.session.flush()
            self._update_runtime(state)

            return EventProcessResult(
                event_id=db_event.id,
                trading_date=event.trading_date,
                source_trading_date=event.source_trading_date,
                code=event.code,
                freshness_status=self._freshness_str(freshness),
                action="promote_core",
                stage="CORE",
                transition_id=transition.id,
                reason="limit_up_sealed",
            )

        return self._record_event_only(db_event, event, freshness, "no_lifecycle_transition")
