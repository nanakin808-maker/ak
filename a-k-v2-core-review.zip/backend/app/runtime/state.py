from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


RuntimeKey = tuple[str, str]


@dataclass(slots=True)
class RuntimeStockState:
    trading_date: str
    source_trading_date: str | None
    code: str
    name: str
    stage: str
    as_of: datetime
    seq: int
    freshness_status: str
    price: float | None = None
    change_pct: float | None = None
    is_sealed: bool = False
    at_limit: bool = False
    open_count: int | None = None
    active_monitoring: bool = True
    inactive_reason: str | None = None
    inactive_at: datetime | None = None


@dataclass(slots=True)
class RuntimeState:
    stock_states: dict[RuntimeKey, RuntimeStockState] = field(default_factory=dict)
    recent_events_by_date: dict[str, list[int]] = field(default_factory=dict)
    latest_seq_by_date: dict[str, int] = field(default_factory=dict)

    # ── event dedup ──
    seen_events: set[str] = field(default_factory=set)
    rejected_today: set[str] = field(default_factory=set)
    active_trade_date: str = ""

    def _ensure_date(self, trading_date: str) -> None:
        """Reset daily state when trading date changes."""
        if self.active_trade_date != trading_date:
            self.seen_events.clear()
            self.rejected_today.clear()
            self.active_trade_date = trading_date
            # Keep stock_states — those are loaded from DB by restore

    def is_event_seen(self, dedup_key: str) -> bool:
        return dedup_key in self.seen_events

    def mark_event_seen(self, dedup_key: str) -> None:
        self.seen_events.add(dedup_key)

    def can_enter(self, code: str) -> bool:
        """Check if code can enter lifecycle (not rejected, not already tracked)."""
        return code not in self.rejected_today

    def reject_code(self, code: str) -> None:
        self.rejected_today.add(code)

    def key(self, trading_date: str, code: str) -> RuntimeKey:
        return (trading_date, code)

    def get_stock_state(self, trading_date: str, code: str) -> RuntimeStockState | None:
        return self.stock_states.get(self.key(trading_date, code))

    def set_stock_state(self, state: RuntimeStockState) -> None:
        self.stock_states[self.key(state.trading_date, state.code)] = state
        self.latest_seq_by_date[state.trading_date] = max(
            self.latest_seq_by_date.get(state.trading_date, 0),
            state.seq,
        )

    def record_event(self, trading_date: str, event_id: int, seq: int) -> None:
        self.recent_events_by_date.setdefault(trading_date, []).append(event_id)
        self.latest_seq_by_date[trading_date] = max(
            self.latest_seq_by_date.get(trading_date, 0),
            seq,
        )
