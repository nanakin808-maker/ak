from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from sqlalchemy.orm import Session

from app.db.models import LimitPoolRow
from app.repositories import MonitoringRepository
from app.runtime.candidate_base import (
    CandidateEntryInput, CandidateLifecycleResult, CandidateQuoteInput,
)
from app.runtime.candidate_lifecycle import CandidateLifecycleService
from app.runtime.restore import RuntimeRestoreResult, RuntimeRestoreService
from app.runtime.state import RuntimeState
from app.services.limit_pool_ingestion_service import (
    LimitPoolIngestionResult, LimitPoolIngestionService, LimitPoolInputSnapshot,
)
from app.services.score_task_service import ScoreTaskScheduleResult, ScoreTaskService
from app.services.score_worker_service import ScoreWorkerRunResult, ScoreWorkerService

VOLUME_SPIKE_RATIO_PURE = 0.03       # 纯量: 12s成交量 > 日均量×3%
VOLUME_SPIKE_RATIO_PRICE = 0.0075    # 价量: 12s成交量 > 日均量×0.75%
VOLUME_SPIKE_MIN_CHANGE_DELTA = 0.15  # 短窗口涨幅推进 >= 0.15%

@dataclass(slots=True)
class MonitoringEngineResult:
    action: str
    code: str | None = None
    stage: str | None = None
    reason: str = ""
    details: dict[str, Any] = field(default_factory=dict)

class MonitoringEngine:
    def __init__(self, session: Session, runtime: RuntimeState) -> None:
        self.session = session
        self.runtime = runtime
        self.monitoring = MonitoringRepository(session)
        self.candidates = CandidateLifecycleService(session, runtime)
        self.limit_pool = LimitPoolIngestionService(session)
        self.restore_service = RuntimeRestoreService(session, runtime)
        self.score_tasks = ScoreTaskService(session)
        self.score_worker = ScoreWorkerService(session)
        self._last_volume_event: dict[str, float] = {}
        self._avg_daily_volume: dict[str, float] = {}  # code → 5日均量(手)

    def restore_trading_date(self, trading_date: str,
                             *, require_fresh: bool = True) -> RuntimeRestoreResult:
        return self.restore_service.restore_trading_date(
            trading_date, require_fresh=require_fresh,
        )

    def handle_source_event(self, event: CandidateEntryInput) -> CandidateLifecycleResult:
        return self.candidates.enter_pre_candidate(event)

    def promote_pre_candidate(
        self, *, trading_date: str, source_trading_date: str | None,
        code: str, name: str = "", as_of: datetime, seq: int,
        freshness_status: str, price: float | None = None,
        change_pct: float | None = None,
    ) -> CandidateLifecycleResult:
        result = self.candidates.promote_pre_to_candidate(
            trading_date=trading_date, source_trading_date=source_trading_date,
            code=code, name=name, as_of=as_of, seq=seq,
            freshness_status=freshness_status, price=price, change_pct=change_pct,
        )
        # Trigger technical score on first entry to CANDIDATE
        if result.action == "promote_candidate":
            self.score_tasks.schedule_scoring(
                trading_date=trading_date,
                source_trading_date=source_trading_date,
                code=code, name=name,
                score_stage="candidate_entry",
                task_type="candidate_technical",
                components_json='["technical","board","sentiment"]',
                source_type="candidate_promotion",
                input_refs_json=json.dumps({
                    "price": price, "change_pct": change_pct,
                }),
                as_of=as_of, seq=seq, freshness_status=freshness_status,
            )
        return result

    def process_quote(self, quote: CandidateQuoteInput) -> CandidateLifecycleResult:
        state = self.monitoring.get_stock_state(quote.trading_date, quote.code)
        runtime_state = self.runtime.get_stock_state(quote.trading_date, quote.code)
        current = state or runtime_state
        if current is None:
            return CandidateLifecycleResult(
                code=quote.code, action="ignored", stage=None,
                reason="no_runtime_or_db_state",
            )

        if current.stage == "CANDIDATE":
            result = self.candidates.process_candidate_quote(quote)
            if result.action == "promote_core":
                self._schedule_seal_scoring(quote, result.event_id)
            return result

        if current.stage == "CORE":
            result = self.candidates.process_core_quote(quote)
            if result.action and "demote" in result.action:
                self._schedule_open_board_scoring(quote, result.event_id)
            return result

        return CandidateLifecycleResult(
            code=quote.code, action="ignored", stage=current.stage,
            reason="stage_not_quote_managed",
        )

    def drop_stale_candidate(
        self, quote: CandidateQuoteInput, *, candidate_stale_minutes: float,
        candidate_min_active_pct: float,
    ) -> CandidateLifecycleResult:
        return self.candidates.drop_stale_candidate(
            quote, candidate_stale_minutes=candidate_stale_minutes,
            candidate_min_active_pct=candidate_min_active_pct,
        )

    def ingest_limit_pool_snapshot(
        self, snapshot: LimitPoolInputSnapshot,
    ) -> LimitPoolIngestionResult:
        return self.limit_pool.ingest_snapshot(snapshot)

    def schedule_score_for_limit_pool_row(
        self, row: LimitPoolRow, *, priority: int = 100,
    ) -> ScoreTaskScheduleResult:
        return self.score_tasks.schedule_for_limit_pool_row(row, priority=priority)

    def process_pending_score_tasks(
        self, *, trading_date: str, limit: int = 100,
    ) -> ScoreWorkerRunResult:
        return self.score_worker.process_pending(trading_date=trading_date, limit=limit)

    def list_latest_limit_pool_rows(self, trading_date: str) -> list[LimitPoolRow]:
        snapshot = self.limit_pool.limit_pool.latest_snapshot(trading_date)
        return self.limit_pool.limit_pool.list_rows(snapshot.id) if snapshot else []

    def _schedule_seal_scoring(
        self, quote: CandidateQuoteInput, event_id: int | None,
    ) -> ScoreTaskScheduleResult:
        return self.score_tasks.schedule_scoring(
            trading_date=quote.trading_date,
            source_trading_date=quote.source_trading_date,
            code=quote.code, name=quote.name,
            score_stage="core_seal", task_type="seal_full_score",
            components_json='["technical","board","sentiment"]',
            source_type="seal_event", source_event_id=event_id,
            input_refs_json=json.dumps({
                "price": quote.price, "change_pct": quote.change_pct,
                "is_sealed": True, "bid_vol1": quote.bid_vol1,
            }),
            as_of=quote.as_of, seq=quote.seq, freshness_status="fresh",
        )

    def _schedule_open_board_scoring(
        self, quote: CandidateQuoteInput, event_id: int | None,
    ) -> ScoreTaskScheduleResult:
        return self.score_tasks.schedule_scoring(
            trading_date=quote.trading_date,
            source_trading_date=quote.source_trading_date,
            code=quote.code, name=quote.name,
            score_stage="open_board", task_type="open_board_sentiment",
            components_json='["sentiment"]',
            source_type="open_board_event", source_event_id=event_id,
            input_refs_json=json.dumps({
                "price": quote.price, "change_pct": quote.change_pct,
                "is_sealed": False,
            }),
            as_of=quote.as_of, seq=quote.seq, freshness_status="fresh",
        )

    def _get_avg_daily_volume(self, code: str) -> float:
        """Get 5-day average daily volume (手). Cached per session."""
        if code in self._avg_daily_volume:
            return self._avg_daily_volume[code]
        try:
            from app.sources.daily_kline import fetch_daily_kline
            bars = fetch_daily_kline(code, limit=10)
            if not bars or len(bars) < 5:
                return 0
            volumes = [b.volume for b in bars[-5:]]
            avg = sum(volumes) / len(volumes)
            self._avg_daily_volume[code] = avg
            return avg
        except Exception:
            return 0

    def check_volume_spikes(self, trading_date: str) -> int:
        """Check all active CORE/CANDIDATE for volume spikes. Returns count."""
        from sqlalchemy import text
        states = self.monitoring.list_stock_states(trading_date)
        active = [s for s in states
                  if s.stage in ("CORE", "CANDIDATE") and s.active_monitoring]
        count = 0
        now = datetime.utcnow().timestamp()
        for ast in active:
            if now - self._last_volume_event.get(ast.code, 0) < 60:
                continue
            samples = self.session.execute(
                text(
                    """SELECT volume, change_pct FROM quote_samples
                       WHERE code = :code AND trading_date = :td
                       ORDER BY timestamp DESC LIMIT 24"""
                ),
                {"code": ast.code, "td": trading_date},
            ).fetchall()
            if len(samples) < 2:
                continue
            avg_vol = self._get_avg_daily_volume(ast.code)
            if avg_vol <= 0:
                continue
            window = list(reversed(samples))
            first_vol = float(window[0].volume or 0)
            last_vol = float(window[-1].volume or 0)
            vol_delta = abs(last_vol - first_vol)
            first_chg = float(window[0].change_pct or 0)
            last_chg = float(window[-1].change_pct or 0)
            change_delta = abs(last_chg - first_chg)

            # Condition 1: pure volume spike (3% of daily avg)
            if vol_delta >= avg_vol * VOLUME_SPIKE_RATIO_PURE:
                self._last_volume_event[ast.code] = now
                self.score_tasks.schedule_scoring(
                    trading_date=trading_date,
                    source_trading_date=ast.source_trading_date,
                    code=ast.code, name=ast.name,
                    score_stage="volume_spike", task_type="volume_spike",
                    components_json='["volume"]', source_type="volume_event",
                    input_refs_json=json.dumps({
                        "price": ast.price, "change_pct": ast.change_pct,
                        "vol_delta": vol_delta, "avg_daily_vol": avg_vol,
                    }),
                    as_of=datetime.utcnow(), seq=0, freshness_status="fresh",
                )
                count += 1
                continue
            # Condition 2: price + volume spike
            if (change_delta >= VOLUME_SPIKE_MIN_CHANGE_DELTA
                    and vol_delta >= avg_vol * VOLUME_SPIKE_RATIO_PRICE):
                self._last_volume_event[ast.code] = now
                self.score_tasks.schedule_scoring(
                    trading_date=trading_date,
                    source_trading_date=ast.source_trading_date,
                    code=ast.code, name=ast.name,
                    score_stage="volume_spike", task_type="volume_spike",
                    components_json='["volume"]', source_type="volume_event",
                    input_refs_json=json.dumps({
                        "price": ast.price, "change_pct": ast.change_pct,
                    }),
                    as_of=datetime.utcnow(), seq=0, freshness_status="fresh",
                )
                count += 1
        return count

    def check_notification_candidates(
        self, trading_date: str,
    ) -> list[dict[str, Any]]:
        states = self.monitoring.list_stock_states(trading_date)
        core_states = [s for s in states
                       if s.stage == "CORE" and s.active_monitoring]
        results: list[dict[str, Any]] = []
        for state in core_states:
            scores = self.score_worker.snapshots.list_for_code(
                trading_date, state.code, limit=1,
            )
            latest_score = scores[0] if scores else None
            results.append({
                "code": state.code, "name": state.name,
                "is_sealed": state.is_sealed,
                "technical_score": latest_score.technical_score if latest_score else None,
                "sentiment_score": latest_score.sentiment_score if latest_score else None,
                "should_notify": (
                    latest_score is not None
                    and latest_score.technical_score is not None
                    and latest_score.technical_score >= 70
                ),
            })
        return results

    def on_board_members_loaded(
        self, *, trading_date: str, code: str, name: str = "",
        as_of: datetime | None = None, seq: int = 0,
    ) -> ScoreTaskScheduleResult:
        return self.score_tasks.schedule_scoring(
            trading_date=trading_date, source_trading_date=trading_date,
            code=code, name=name,
            score_stage="board_members_sentiment",
            task_type="board_sentiment",
            components_json='["sentiment"]',
            source_type="board_members_loaded",
            as_of=as_of or datetime.utcnow(), seq=seq,
        )
