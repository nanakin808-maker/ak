"""
QuoteSampleCollector: polls quotes for active stocks and fills quote_samples table.

Runs as a background asyncio task. Configurable interval (default 500ms).
Keeps last 120 samples per stock; auto-cleans older entries.
"""

from __future__ import annotations

import asyncio
import json
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any

from sqlalchemy import text
from sqlalchemy.orm import Session

EASTMONEY_QUOTE_BATCH_URL = "https://push2.eastmoney.com/api/qt/stock/get"
_HEADERS = {"User-Agent": "Mozilla/5.0", "Referer": "https://quote.eastmoney.com/"}


class QuoteSampleCollector:
    """Collects real-time quote samples for active stocks into quote_samples table."""

    def __init__(
        self,
        session_factory,
        max_samples_per_code: int = 120,
        collect_interval_seconds: float = 0.5,
    ) -> None:
        self.session_factory = session_factory
        self.max_samples_per_code = max_samples_per_code
        self.collect_interval = collect_interval_seconds
        self._active_codes: set[str] = set()
        self._running = False
        self._task: asyncio.Task | None = None

    def set_codes(self, codes: set[str]) -> None:
        self._active_codes = set(codes)

    def add_code(self, code: str) -> None:
        self._active_codes.add(code)

    def remove_code(self, code: str) -> None:
        self._active_codes.discard(code)

    async def start(self) -> None:
        self._running = True
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def _loop(self) -> None:
        while self._running:
            codes = list(self._active_codes)
            if codes:
                try:
                    await asyncio.to_thread(self._collect_batch, codes)
                except Exception:
                    pass
            await asyncio.sleep(self.collect_interval)

    def _collect_batch(self, codes: list[str]) -> None:
        quotes = self._fetch_quotes(codes)
        if not quotes:
            return

        session: Session = self.session_factory()
        try:
            now = datetime.utcnow()
            trading_date = now.strftime("%Y-%m-%d")

            for q in quotes:
                session.execute(
                    text(
                        """INSERT INTO quote_samples
                           (code, timestamp, trading_date, price, change_pct,
                            amount, volume, bid_vol1, ask_vol1, source, created_at)
                           VALUES
                           (:code, :ts, :td, :price, :change_pct,
                            :amount, :volume, :bid_vol1, :ask_vol1, :source, :now)"""
                    ),
                    {
                        "code": q["code"],
                        "ts": now,
                        "td": trading_date,
                        "price": q.get("price"),
                        "change_pct": q.get("change_pct"),
                        "amount": q.get("amount"),
                        "volume": q.get("volume"),
                        "bid_vol1": q.get("bid_vol1"),
                        "ask_vol1": q.get("ask_vol1"),
                        "source": q.get("source", "eastmoney"),
                        "now": now,
                    },
                )

                # cleanup old samples for this code
                session.execute(
                    text(
                        """DELETE FROM quote_samples
                           WHERE code = :code
                           AND id NOT IN (
                             SELECT id FROM quote_samples
                             WHERE code = :code2
                             ORDER BY timestamp DESC
                             LIMIT :max_n
                           )"""
                    ),
                    {"code": q["code"], "code2": q["code"], "max_n": self.max_samples_per_code},
                )

            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _fetch_quotes(self, codes: list[str]) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for code in codes:
            try:
                q = self._fetch_one(code)
                if q:
                    results.append(q)
            except Exception:
                continue
        return results

    @staticmethod
    def _fetch_one(code: str) -> dict[str, Any] | None:
        secid = f"1.{code}" if code.startswith("6") else f"0.{code}"
        url = (
            f"{EASTMONEY_QUOTE_BATCH_URL}?"
            f"ut=fa5fd1943c7b386f172d6893dbfb2dc6"
            f"&invt=2&fltt=2&fields=f43,f169,f170,f46,f44,f51,f168,f47,f48"
            f"&secid={secid}"
        )
        req = urllib.request.Request(url, headers=_HEADERS)
        resp = urllib.request.urlopen(req, timeout=3)
        body = json.loads(resp.read().decode())
        data = body.get("data")
        if not data:
            return None

        price = _float_or_none(data.get("f43"))
        change_pct = _float_or_none(data.get("f170"))
        if price is None or change_pct is None:
            return None

        return {
            "code": code,
            "price": price,
            "change_pct": change_pct,
            "amount": _float_or_none(data.get("f48")),
            "volume": _float_or_none(data.get("f47")),
            "bid_vol1": _float_or_none(data.get("f46")),
            "ask_vol1": _float_or_none(data.get("f51")),
            "source": "eastmoney",
        }


def _float_or_none(value: Any) -> float | None:
    try:
        v = float(value)
        return v if v > -1e12 else None  # filter eastmoney sentinel values
    except (TypeError, ValueError):
        return None
