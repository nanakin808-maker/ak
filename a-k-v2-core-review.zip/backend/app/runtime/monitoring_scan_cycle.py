from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable

from sqlalchemy.orm import Session

from app.domain.time_scope import MarketSession
from app.runtime.monitoring_engine import MonitoringEngine
from app.runtime.state import RuntimeState
from app.services.provider_bridge_service import ProviderFetchResult


@dataclass(slots=True)
class MonitoringScanCycleResult:
    trading_date: str
    restored_count: int = 0
    source_events_processed: int = 0
    quotes_processed: int = 0
    limit_pool_rows_ingested: int = 0
    score_tasks_scheduled: int = 0
    score_tasks_processed: int = 0
    score_tasks_ready: int = 0
    score_tasks_failed: int = 0
    actions: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


class MonitoringScanCycle:
    def __init__(self, session: Session, runtime: RuntimeState) -> None:
        self.session = session
        self.runtime = runtime
        self.engine = MonitoringEngine(session, runtime)
        from app.services.market_source_adapter_service import MarketSourceAdapterService as MSA  # noqa: E402
        self.adapter = MSA(session, runtime, self.engine)

    def run_once(
        self,
        *,
        trading_date: str,
        as_of: datetime,
        seq_start: int,
        speed_rank_fetcher: Callable[[], ProviderFetchResult] | None = None,
        shortline_fetcher: Callable[[], ProviderFetchResult] | None = None,
        quote_batch_fetcher: Callable[[], ProviderFetchResult] | None = None,
        limit_pool_fetcher: object | None = None,
        market_session: MarketSession = MarketSession.UNKNOWN,
        promote_pre_candidates: bool = True,
        process_score_tasks: bool = True,
    ) -> MonitoringScanCycleResult:
        result = MonitoringScanCycleResult(trading_date=trading_date)

        restored = self.engine.restore_trading_date(trading_date)
        result.restored_count = restored.restored_stock_count

        seq = seq_start

        if speed_rank_fetcher is not None:
            r = self.adapter.ingest_event_source(
                source_type="speed_rank", provider_name="speed_rank",
                requested_trading_date=trading_date, fetcher=speed_rank_fetcher,
                as_of=as_of, seq_start=seq, market_session=market_session,
            )
            result.source_events_processed += r.processed
            result.actions.extend(r.actions)
            if r.error:
                result.errors.append(r.error)
            seq += max(r.processed, 1)

        if shortline_fetcher is not None:
            r = self.adapter.ingest_event_source(
                source_type="shortline", provider_name="shortline",
                requested_trading_date=trading_date, fetcher=shortline_fetcher,
                as_of=as_of, seq_start=seq, market_session=market_session,
            )
            result.source_events_processed += r.processed
            result.actions.extend(r.actions)
            if r.error:
                result.errors.append(r.error)
            seq += max(r.processed, 1)

        if promote_pre_candidates:
            for state in self.engine.monitoring.list_stock_states(trading_date, freshness_status="fresh"):
                if state.stage == "PRE_CANDIDATE" and state.active_monitoring:
                    promoted = self.engine.promote_pre_candidate(
                        trading_date=trading_date,
                        source_trading_date=state.source_trading_date,
                        code=state.code,
                        as_of=as_of,
                        seq=seq,
                        freshness_status=state.freshness_status,
                    )
                    result.actions.append(promoted.action)
                    seq += 1

        if quote_batch_fetcher is not None:
            r = self.adapter.ingest_quote_batch(
                provider_name="quote_batch",
                requested_trading_date=trading_date, fetcher=quote_batch_fetcher,
                as_of=as_of, seq_start=seq, market_session=market_session,
            )
            result.quotes_processed += r.processed
            result.actions.extend(r.actions)
            if r.error:
                result.errors.append(r.error)
            seq += max(r.processed, 1)

        # ── seal check: orderbook → CANDIDATE → CORE ──
        sr = self.adapter.ingest_seal_check_for_candidates(
            trading_date=trading_date, as_of=as_of, seq_start=seq,
            market_session=market_session,
        )
        result.actions.extend(sr.actions)
        if sr.processed > 0:
            result.actions.append(f"seal_check:{sr.processed}")
        if sr.error:
            result.errors.append(sr.error)

        if limit_pool_fetcher is not None:
            lp = self.adapter.ingest_limit_pool(
                requested_trading_date=trading_date, as_of=as_of, seq=seq,
                fetcher=limit_pool_fetcher, market_session=market_session,
                provider_name="limit_pool", primary_source="mock_limit_pool",
            )
            result.limit_pool_rows_ingested += lp.row_count
            result.actions.append("ingest_limit_pool" if lp.ingested else "limit_pool_failed")
            if lp.error:
                result.errors.append(lp.error)
            seq += 1

            rows = self.engine.list_latest_limit_pool_rows(trading_date)
            for row in rows:
                self.engine.schedule_score_for_limit_pool_row(row)
                result.score_tasks_scheduled += 1
                result.actions.append("score_task_scheduled")

        if process_score_tasks:
            worker = self.engine.process_pending_score_tasks(trading_date=trading_date, limit=100)
            result.score_tasks_processed = worker.processed
            result.score_tasks_ready = worker.ready
            result.score_tasks_failed = worker.failed

        return result
