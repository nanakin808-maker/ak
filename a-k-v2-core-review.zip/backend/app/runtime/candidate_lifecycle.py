from __future__ import annotations

from datetime import datetime

from sqlalchemy.orm import Session

from app.repositories import MonitoringRepository, ScoreSnapshotRepository
from app.runtime.candidate_base import (
    CandidateEntryConfig, CandidateEntryInput, CandidateLifecycleResult, CandidateQuoteInput,
    candidate_entry_threshold_pct, is_st_name,
)
from app.runtime.state import RuntimeState, RuntimeStockState


class CandidateLifecycleService:
    def __init__(self, session: Session, runtime: RuntimeState) -> None:
        self.session = session
        self.runtime = runtime
        self.monitoring = MonitoringRepository(session)
        self.scores = ScoreSnapshotRepository(session)

    def _freshness_str(self, freshness: str) -> str:
        return freshness if isinstance(freshness, str) else freshness.value

    def _update_runtime_from_state(self, state: object) -> None:
        self.runtime.set_stock_state(
            RuntimeStockState(
                trading_date=state.trading_date, source_trading_date=state.source_trading_date,
                code=state.code, name=state.name, stage=state.stage,
                price=state.price, change_pct=state.change_pct,
                is_sealed=state.is_sealed, at_limit=state.at_limit, open_count=state.open_count,
                as_of=state.as_of, seq=state.seq, freshness_status=state.freshness_status,
                active_monitoring=state.active_monitoring, inactive_reason=state.inactive_reason,
                inactive_at=state.inactive_at,
            )
        )

    def enter_pre_candidate(self, event: CandidateEntryInput, config: CandidateEntryConfig | None = None) -> CandidateLifecycleResult:
        cfg = config or CandidateEntryConfig()
        freshen = self._freshness_str(event.freshness_status)
        db_event = self.monitoring.add_event(
            trading_date=event.trading_date, source_trading_date=event.source_trading_date,
            code=event.code, name=event.name, event_type=event.event_type,
            event_source=event.event_source, event_time=event.event_time,
            price=event.price, change_pct=event.change_pct, raw_json=event.raw_json,
            as_of=event.as_of, seq=event.seq, freshness_status=freshen,
        )
        self.session.flush()
        self.runtime.record_event(event.trading_date, db_event.id, event.seq)
        if freshen != "fresh":
            return CandidateLifecycleResult(code=event.code, action="record_event_only", stage=None, reason="freshness_not_fresh")
        if is_st_name(event.name):
            state = self.monitoring.upsert_stock_state(
                trading_date=event.trading_date, source_trading_date=event.source_trading_date,
                code=event.code, name=event.name, stage="REJECTED_TODAY",
                price=event.price, change_pct=event.change_pct,
                as_of=event.as_of, seq=event.seq, freshness_status=freshen,
                active_monitoring=False, inactive_reason="st_filter", inactive_at=event.as_of,
                first_seen_at=event.as_of,
            )
            self._update_runtime_from_state(state)
            return CandidateLifecycleResult(code=event.code, action="rejected_today", stage="REJECTED_TODAY", event_id=db_event.id, reason="st_filter")
        threshold = candidate_entry_threshold_pct(event.code, cfg)
        if event.change_pct is None or event.change_pct <= threshold:
            return CandidateLifecycleResult(code=event.code, action="entry_gate_failed", stage=None, reason="change_pct_below_threshold")
        previous = self.monitoring.get_stock_state(event.trading_date, event.code)
        if previous is not None and (previous.stage in ("REJECTED_TODAY", "CORE", "CANDIDATE") or (previous.stage == "PRE_CANDIDATE" and previous.active_monitoring)):
            return CandidateLifecycleResult(code=event.code, action="ignored_existing_active_state", stage=previous.stage, reason=f"already_{previous.stage.lower()}")
        state = self.monitoring.upsert_stock_state(
            trading_date=event.trading_date, source_trading_date=event.source_trading_date,
            code=event.code, name=event.name, stage="PRE_CANDIDATE",
            price=event.price, change_pct=event.change_pct,
            as_of=event.as_of, seq=event.seq, freshness_status=freshen,
            active_monitoring=True, clear_inactive=True, first_seen_at=event.as_of,
        )
        score_snapshot = self.scores.add_snapshot(
            trading_date=event.trading_date, source_trading_date=event.source_trading_date,
            code=event.code, name=event.name, score_type="COMPOSITE", score_stage="pre_candidate",
            status="ready", source_type="monitoring_event", source_event_id=db_event.id,
            score_json='{"stage":"pre_candidate"}',
            input_refs_json=f'{{"monitoring_event_id": {db_event.id}}}',
            as_of=event.as_of, seq=event.seq, freshness_status=freshen,
        )
        self.session.flush()
        self._update_runtime_from_state(state)
        return CandidateLifecycleResult(code=event.code, action="enter_pre_candidate", stage="PRE_CANDIDATE", event_id=db_event.id, score_snapshot_id=score_snapshot.id, reason="entry_gate_passed")

    def promote_pre_to_candidate(self, *, trading_date, source_trading_date, code, name, as_of, seq, freshness_status, price=None, change_pct=None, reason="history_ready", event_id=None) -> CandidateLifecycleResult:
        state = self.monitoring.get_stock_state(trading_date, code)
        if state is None or state.stage != "PRE_CANDIDATE":
            return CandidateLifecycleResult(code=code, action="ignored", stage=state.stage if state else None, reason="not_pre_candidate")
        if not state.active_monitoring:
            return CandidateLifecycleResult(code=code, action="ignored", stage=state.stage, reason="inactive_pre_candidate")
        freshen = self._freshness_str(freshness_status)
        updated = self.monitoring.upsert_stock_state(
            trading_date=trading_date, source_trading_date=source_trading_date,
            code=code, name=name, stage="CANDIDATE",
            price=price, change_pct=change_pct,
            as_of=as_of, seq=seq, freshness_status=freshen,
            active_monitoring=True, clear_inactive=True, candidate_at=as_of,
        )
        transition = self.monitoring.add_transition(
            trading_date=trading_date, source_trading_date=source_trading_date,
            code=code, from_stage="PRE_CANDIDATE", to_stage="CANDIDATE",
            reason=reason, event_id=event_id, as_of=as_of, seq=seq, freshness_status=freshen,
        )
        score_snapshot = self.scores.add_snapshot(
            trading_date=trading_date, source_trading_date=source_trading_date,
            code=code, name=name, score_type="COMPOSITE", score_stage="candidate",
            status="ready", source_type="monitoring_event", source_event_id=event_id,
            score_json='{"stage":"candidate"}',
            input_refs_json=f'{{"monitoring_event_id": {event_id if event_id else 0}}}',
            as_of=as_of, seq=seq, freshness_status=freshen,
        )
        self.session.flush()
        self._update_runtime_from_state(updated)
        return CandidateLifecycleResult(code=code, action="promote_candidate", stage="CANDIDATE", event_id=event_id, transition_id=transition.id, score_snapshot_id=score_snapshot.id, reason=reason)

    def _may_promote_core(self, quote: CandidateQuoteInput) -> bool:
        return quote.is_sealed and quote.seal_confidence in ("explicit", "reliable")

    def _may_use_seal_decision(self, quote: CandidateQuoteInput) -> bool:
        return quote.seal_confidence in ("explicit", "reliable")

    def process_candidate_quote(self, quote: CandidateQuoteInput) -> CandidateLifecycleResult:
        state = self.monitoring.get_stock_state(quote.trading_date, quote.code)
        if state is None or state.stage != "CANDIDATE" or not state.active_monitoring:
            return CandidateLifecycleResult(code=quote.code, action="ignored", stage=state.stage if state else None, reason="not_candidate")
        freshen = self._freshness_str(quote.freshness_status)
        if freshen != "fresh":
            return CandidateLifecycleResult(code=quote.code, action="ignored", stage=state.stage, reason=f"freshness_{freshen}")

        if not self._may_promote_core(quote):
            # Update quote, then check if candidate is stale
            updated = self.monitoring.upsert_stock_state(
                trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
                code=quote.code, name=quote.name, stage="CANDIDATE",
                price=quote.price, change_pct=quote.change_pct,
                is_sealed=quote.is_sealed, at_limit=quote.at_limit, open_count=quote.open_count,
                as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
                active_monitoring=True, clear_inactive=True,
            )
            self.session.flush()
            self._update_runtime_from_state(updated)
            # Check stale: skip during lunch/closed — data stall doesn't mean stock is dead
            stale_result = self.drop_stale_candidate(quote, candidate_stale_minutes=10.0, candidate_min_active_pct=8.0)
            if stale_result.action == "candidate_removed":
                return stale_result
            reason = "insufficient_seal_data" if quote.seal_confidence == "insufficient" else "quote_not_sealed"
            return CandidateLifecycleResult(code=quote.code, action="update_candidate_quote", stage="CANDIDATE", reason=reason)

        db_event = self.monitoring.add_event(
            trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
            code=quote.code, name=quote.name, event_type="LIMIT_UP_SEALED",
            event_source=quote.event_source, event_time=quote.as_of.isoformat(timespec="seconds"),
            price=quote.price, change_pct=quote.change_pct, is_sealed=True, is_first_seal=False,
            open_count=quote.open_count, raw_json=quote.raw_json,
            as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
        )
        self.session.flush()
        updated = self.monitoring.upsert_stock_state(
            trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
            code=quote.code, name=quote.name, stage="CORE",
            price=quote.price, change_pct=quote.change_pct,
            is_sealed=True, at_limit=quote.at_limit, open_count=quote.open_count,
            as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
            active_monitoring=True, clear_inactive=True,
        )
        transition = self.monitoring.add_transition(
            trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
            code=quote.code, from_stage="CANDIDATE", to_stage="CORE",
            reason="limit_up_sealed", event_id=db_event.id,
            as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
        )
        self.session.flush()
        self._update_runtime_from_state(updated)
        return CandidateLifecycleResult(code=quote.code, action="promote_core", stage="CORE", event_id=db_event.id, transition_id=transition.id, reason="limit_up_sealed")

    def process_core_quote(self, quote: CandidateQuoteInput) -> CandidateLifecycleResult:
        state = self.monitoring.get_stock_state(quote.trading_date, quote.code)
        if state is None or state.stage != "CORE" or not state.active_monitoring:
            return CandidateLifecycleResult(code=quote.code, action="ignored", stage=state.stage if state else None, reason="not_core")
        freshen = self._freshness_str(quote.freshness_status)
        if freshen != "fresh":
            return CandidateLifecycleResult(code=quote.code, action="ignored", stage=state.stage, reason=f"freshness_{freshen}")

        was_sealed = bool(state.is_sealed)

        if quote.is_sealed:
            updated = self.monitoring.upsert_stock_state(
                trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
                code=quote.code, name=quote.name, stage="CORE",
                price=quote.price, change_pct=quote.change_pct,
                is_sealed=True, at_limit=quote.at_limit, open_count=quote.open_count,
                as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
                active_monitoring=True, clear_inactive=True,
            )
            self.session.flush()
            self._update_runtime_from_state(updated)
            stale_result = self._check_core_volume_stale(quote)
            if stale_result:
                return stale_result
            return CandidateLifecycleResult(code=quote.code, action="update_core_quote", stage="CORE", reason="quote_still_sealed")

        # Not sealed now. If it was sealed before → open board (炸板)
        if was_sealed:
            db_event = self.monitoring.add_event(
                trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
                code=quote.code, name=quote.name, event_type="LIMIT_UP_OPENED",
                event_source=quote.event_source, event_time=quote.as_of.isoformat(timespec="seconds"),
                price=quote.price, change_pct=quote.change_pct, is_sealed=False, is_first_seal=False,
                open_count=quote.open_count, raw_json=quote.raw_json,
                as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
            )
            self.session.flush()
            updated = self.monitoring.upsert_stock_state(
                trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
                code=quote.code, name=quote.name, stage="CANDIDATE",
                price=quote.price, change_pct=quote.change_pct,
                is_sealed=False, at_limit=quote.at_limit, open_count=quote.open_count,
                as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
                active_monitoring=True, clear_inactive=True,
            )
            transition = self.monitoring.add_transition(
                trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
                code=quote.code, from_stage="CORE", to_stage="CANDIDATE",
                reason="limit_up_opened", event_id=db_event.id,
                as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
            )
            self.session.flush()
            self._update_runtime_from_state(updated)
            return CandidateLifecycleResult(code=quote.code, action="demote_core_to_candidate", stage="CANDIDATE", event_id=db_event.id, transition_id=transition.id, reason="limit_up_opened")

        # Not sealed and wasn't sealed — just update price
        updated = self.monitoring.upsert_stock_state(
            trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
            code=quote.code, name=quote.name, stage="CORE",
            price=quote.price, change_pct=quote.change_pct,
            is_sealed=False, at_limit=quote.at_limit, open_count=quote.open_count,
            as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
            active_monitoring=True, clear_inactive=True,
        )
        self.session.flush()
        self._update_runtime_from_state(updated)
        stale_result = self._check_core_volume_stale(quote)
        if stale_result:
            return stale_result
        return CandidateLifecycleResult(code=quote.code, action="update_core_quote", stage="CORE", reason="not_sealed_no_change")

    def _check_core_volume_stale(
        self, quote: CandidateQuoteInput, *, core_volume_stale_minutes: float = 30.0,
    ) -> CandidateLifecycleResult | None:
        """Remove CORE stocks that haven't had volume score updates."""
        state = self.monitoring.get_stock_state(quote.trading_date, quote.code)
        if state is None or state.stage != "CORE" or not state.active_monitoring:
            return None
        # Skip only during post-close/closed — data stall then is expected
        try:
            from app.domain.market_calendar import MarketSession, market_session
            ms = market_session()
            if ms in (MarketSession.POST_CLOSE, MarketSession.CLOSED_NO_DATA):
                return None
        except Exception:
            pass
        # Find latest volume score
        from sqlalchemy import select
        from app.db.models import ScoreSnapshot
        vol_snap = self.session.execute(
            select(ScoreSnapshot)
            .where(ScoreSnapshot.trading_date == quote.trading_date, ScoreSnapshot.code == quote.code)
            .where(ScoreSnapshot.score_stage == "volume_spike")
            .order_by(ScoreSnapshot.id.desc()).limit(1)
        ).scalar_one_or_none()
        if vol_snap and vol_snap.as_of:
            stale_seconds = (quote.as_of - vol_snap.as_of).total_seconds()
            if stale_seconds < core_volume_stale_minutes * 60:
                return None  # still fresh
        else:
            # No volume score ever — check time since entering CORE
            entered_at = state.core_at or state.as_of
            if entered_at:
                stale_seconds = (quote.as_of - entered_at).total_seconds()
                if stale_seconds < core_volume_stale_minutes * 60:
                    return None
        # Stale — remove
        freshen = quote.freshness_status if isinstance(quote.freshness_status, str) else str(quote.freshness_status)
        self.monitoring.add_event(
            trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
            code=quote.code, name=quote.name, event_type="CORE_VOLUME_STALE",
            event_source=quote.event_source, event_time=quote.as_of.isoformat(timespec="seconds"),
            price=quote.price, change_pct=quote.change_pct, is_sealed=False,
            as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
            raw_json=f'{{"reason":"core_volume_stale","stale_minutes":{core_volume_stale_minutes}}}',
        )
        self.session.flush()
        updated = self.monitoring.upsert_stock_state(
            trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
            code=quote.code, name=quote.name, stage="CORE",
            price=quote.price, change_pct=quote.change_pct,
            is_sealed=quote.is_sealed, at_limit=quote.at_limit,
            as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
            active_monitoring=False, inactive_reason="core_volume_stale", inactive_at=quote.as_of,
        )
        self.session.flush()
        self._update_runtime_from_state(updated)
        return CandidateLifecycleResult(code=quote.code, action="core_volume_stale_removed", stage="CORE", reason="core_volume_stale")

    def drop_stale_candidate(self, quote: CandidateQuoteInput, *, candidate_stale_minutes: float, candidate_min_active_pct: float) -> CandidateLifecycleResult:
        state = self.monitoring.get_stock_state(quote.trading_date, quote.code)
        runtime_state = self.runtime.get_stock_state(quote.trading_date, quote.code)
        current_stage = state.stage if state is not None else runtime_state.stage if runtime_state is not None else None
        if current_stage != "CANDIDATE":
            return CandidateLifecycleResult(code=quote.code, action="ignored", stage=current_stage, reason="not_candidate")
        entered_at = (state.candidate_at or state.first_seen_at or state.as_of) if state is not None else (runtime_state.as_of if runtime_state is not None else quote.as_of)
        stale_seconds = max(0.0, (quote.as_of - entered_at).total_seconds())
        max_age_seconds = max(0.0, candidate_stale_minutes * 60.0)
        if stale_seconds < max_age_seconds:
            return CandidateLifecycleResult(code=quote.code, action="kept_candidate", stage="CANDIDATE", reason="within_candidate_window")
        if quote.change_pct > candidate_min_active_pct:
            return CandidateLifecycleResult(code=quote.code, action="kept_candidate", stage="CANDIDATE", reason="still_active")
        freshen = quote.freshness_status if isinstance(quote.freshness_status, str) else quote.freshness_status.value
        event = self.monitoring.add_event(
            trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
            code=quote.code, name=quote.name, event_type="CANDIDATE_REMOVED",
            event_source=quote.event_source, event_time=quote.as_of.isoformat(timespec="seconds"),
            price=quote.price, change_pct=quote.change_pct, is_sealed=False, is_first_seal=False,
            raw_json=f'{{"reason":"candidate_weak_removed","stale_seconds":{round(stale_seconds,1)},"candidate_min_active_pct":{candidate_min_active_pct},"change_pct":{quote.change_pct}}}',
            as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
        )
        self.session.flush()
        updated = self.monitoring.upsert_stock_state(
            trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
            code=quote.code, name=quote.name, stage="PRE_CANDIDATE",
            price=quote.price, change_pct=quote.change_pct, is_sealed=False, at_limit=False,
            as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
            active_monitoring=False, inactive_reason="candidate_weak_removed", inactive_at=quote.as_of,
        )
        transition = self.monitoring.add_transition(
            trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
            code=quote.code, from_stage="CANDIDATE", to_stage="PRE_CANDIDATE",
            reason="candidate_weak_removed", event_id=event.id,
            as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
        )
        score_snapshot = self.scores.add_snapshot(
            trading_date=quote.trading_date, source_trading_date=quote.source_trading_date,
            code=quote.code, name=quote.name, score_type="COMPOSITE",
            score_stage="candidate_removed", status="ready", passed=False,
            reject_reason="候选弱势移除",
            technical_score=quote.technical_score, sentiment_score=quote.sentiment_score,
            volume_score=quote.volume_score, source_type="monitoring_event",
            source_event_id=event.id,
            score_json=f'{{"stage":"candidate_removed","reason":"候选弱势移除","stale_seconds":{round(stale_seconds,1)},"candidate_min_active_pct":{candidate_min_active_pct},"change_pct":{quote.change_pct}}}',
            input_refs_json=f'{{"monitoring_event_id": {event.id}}}',
            as_of=quote.as_of, seq=quote.seq, freshness_status=freshen,
        )
        self.session.flush()
        self._update_runtime_from_state(updated)
        return CandidateLifecycleResult(code=quote.code, action="candidate_removed", stage="PRE_CANDIDATE", event_id=event.id, transition_id=transition.id, score_snapshot_id=score_snapshot.id, reason="candidate_weak_removed")
