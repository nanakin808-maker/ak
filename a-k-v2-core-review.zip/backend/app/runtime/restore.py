from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy.orm import Session

from app.repositories import MonitoringRepository
from app.runtime.state import RuntimeState, RuntimeStockState


@dataclass(slots=True)
class RuntimeRestoreResult:
    trading_date: str
    restored_stock_count: int
    skipped_stock_count: int
    latest_seq: int


class RuntimeRestoreService:
    def __init__(self, session: Session, runtime: RuntimeState) -> None:
        self.session = session
        self.runtime = runtime
        self.monitoring = MonitoringRepository(session)

    def restore_trading_date(self, trading_date: str, *, require_fresh: bool = True) -> RuntimeRestoreResult:
        states = self.monitoring.list_stock_states(
            trading_date,
            freshness_status="fresh" if require_fresh else None,
        )

        restored = 0
        skipped = 0
        max_seq = self.runtime.latest_seq_by_date.get(trading_date, 0)

        for state in states:
            if require_fresh and state.source_trading_date not in (None, trading_date):
                skipped += 1
                continue

            self.runtime.set_stock_state(
                RuntimeStockState(
                    trading_date=state.trading_date,
                    source_trading_date=state.source_trading_date,
                    code=state.code,
                    name=state.name,
                    stage=state.stage,
                    price=state.price,
                    change_pct=state.change_pct,
                    is_sealed=state.is_sealed,
                    at_limit=state.at_limit,
                    open_count=state.open_count,
                    as_of=state.as_of,
                    seq=state.seq,
                    freshness_status=state.freshness_status,
                    active_monitoring=state.active_monitoring,
                    inactive_reason=state.inactive_reason,
                    inactive_at=state.inactive_at,
                )
            )
            restored += 1
            max_seq = max(max_seq, state.seq)

        self.runtime.latest_seq_by_date[trading_date] = max_seq
        return RuntimeRestoreResult(
            trading_date=trading_date,
            restored_stock_count=restored,
            skipped_stock_count=skipped + (len(states) - restored - skipped),
            latest_seq=max_seq,
        )
