from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


def is_st_name(name: str) -> bool:
    normalized = name.upper().replace("＊", "*").strip()
    return normalized.startswith("*ST") or normalized.lstrip("*").strip().startswith("ST")


def candidate_entry_threshold_pct(code: str, config: CandidateEntryConfig) -> float:
    normalized = str(code).strip()
    if normalized.startswith(("300", "301", "688", "689")):
        return config.candidate_entry_threshold_twenty_pct
    if normalized.startswith(("8", "4", "9")):
        return config.candidate_entry_threshold_thirty_pct
    return config.candidate_entry_threshold_main_pct


@dataclass(slots=True)
class CandidateEntryConfig:
    candidate_entry_threshold_main_pct: float = 5.0
    candidate_entry_threshold_twenty_pct: float = 10.0
    candidate_entry_threshold_thirty_pct: float = 15.0


@dataclass(slots=True)
class CandidateEntryInput:
    trading_date: str
    source_trading_date: str | None
    code: str
    name: str
    event_type: str
    event_source: str
    event_title: str
    event_time: str | None
    as_of: datetime
    seq: int
    freshness_status: str
    price: float | None
    change_pct: float | None
    raw_json: str = "{}"


@dataclass(slots=True)
class CandidateQuoteInput:
    trading_date: str
    source_trading_date: str | None
    code: str
    name: str
    as_of: datetime
    seq: int
    freshness_status: str
    price: float | None
    change_pct: float
    event_source: str = "monitor"
    is_sealed: bool = False
    at_limit: bool = False
    open_count: int | None = None
    raw_json: str = "{}"
    technical_score: float | None = None
    sentiment_score: float | None = None
    volume_score: float | None = None
    seal_confidence: str = "explicit"
    seal_source: str | None = None
    seal_reason: str | None = None
    pre_close: float | None = None
    bid1: float | None = None
    bid_vol1: float | None = None
    ask1: float | None = None
    ask_vol1: float | None = None


@dataclass(slots=True)
class CandidateLifecycleResult:
    code: str
    action: str
    stage: str | None
    event_id: int | None = None
    transition_id: int | None = None
    score_snapshot_id: int | None = None
    reason: str = ""
