"""
RealtimeDevScanRunner: periodic scan. Fetches real data, writes dev DB.
Flow: speed_rank→PRE_CANDIDATE→CANDIDATE→Tencent orderbook→CORE→scoring.
"""
from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path
from typing import Any
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from app.db.init_db import init_db
from app.db.models import LimitPoolRow, MonitoringStockState
from app.runtime import MonitoringEngine, RuntimeState
from app.runtime.candidate_base import CandidateEntryInput, CandidateQuoteInput
from app.services.limit_pool_ingestion_service import LimitPoolInputRow, LimitPoolInputSnapshot
from app.sources.composite_quote import fetch_composite_quotes
from app.sources.scan_fetchers import _fetch_limit_pool, _fetch_speed_rank
class RealtimeDevScanRunner:
    """One-shot or periodic scan.  Writes to data/astock_guard_v2_shadow.db."""
    def __init__(
        self,
        db_path: str = "data/astock_guard_v2_shadow.db",
        trading_date: str | None = None,
    ) -> None:
        self.db_path = Path(db_path)
        from app.domain.market_calendar import effective_trading_date_ymd
        self.trading_date = trading_date or effective_trading_date_ymd()
        self._lp_signatures: dict[str, str] = {}
        self._last_speed_rank = 0.0
        self._last_shortline = 0.0
        self._last_limit_pool = 0.0
        self._last_volume_score = 0.0

    @staticmethod
    def _validate_event_time(
        time_str: str | None,
        today_ymd: str,
        max_age_minutes: int = 120,
        source: str = "",
    ) -> tuple[bool, str]:
        """Check if event time is fresh. Returns (is_valid, freshness_label)."""
        if not time_str:
            return True, "unknown_time"
        now = datetime.utcnow()
        try:
            # Try common formats: HH:MM:SS, HHMMSS, ISO
            ts = time_str.strip()
            parsed = None
            for fmt in ["%H:%M:%S", "%H%M%S"]:
                try:
                    t = datetime.strptime(ts, fmt).time()
                    parsed = datetime.strptime(f"{today_ymd}T{t.isoformat()}", "%Y%m%dT%H:%M:%S")
                    break
                except ValueError:
                    continue
            if parsed is None:
                # Full datetime string
                parsed = datetime.fromisoformat(ts.replace("Z", "+00:00").replace("+00:00", ""))
            age_seconds = (now - parsed).total_seconds()
            if age_seconds < 0:
                # Future timestamp — accept but flag
                return True, "future_time"
            if age_seconds > max_age_minutes * 60:
                return False, f"expired_{int(age_seconds//60)}m"
            if parsed.strftime("%Y%m%d") != today_ymd:
                return False, "wrong_date"
            return True, "fresh"
        except (ValueError, TypeError):
            return True, "unknown_time"

    def run_once(self) -> dict[str, Any]:
        from app.domain.market_calendar import (
            effective_trading_date_ymd, annotate_data_date, is_live_trading,
            is_nominal_trading_day, market_session,
        )
        t0 = datetime.utcnow()
        seq = 0
        session = market_session()
        summary: dict[str, Any] = {
            "scan_at": t0.isoformat(), "trading_date": self.trading_date,
            "market_session": session.value,
            "effective_date": effective_trading_date_ymd(),
            "is_live": is_live_trading(),
            "data_freshness": annotate_data_date(self.trading_date),
            "speed_rank": 0, "shortline": 0, "shortline_skipped": 0,
            "pre_candidate": 0, "rejected": 0, "candidates": 0,
            "core_states": 0, "core_transitions": 0, "open_transitions": 0,
            "volume_spikes": 0,
            "limit_pool": 0, "score_processed": 0, "score_ready": 0,
            "notifiable": 0,
            "errors": [],
        }
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        engine = create_engine(f"sqlite:///{self.db_path.resolve()}", future=True)
        init_db(engine)
        Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
        with Session() as session:
            runtime = RuntimeState()
            runtime._ensure_date(self.trading_date)
            mgr = MonitoringEngine(session, runtime)
            # ── collect already-tracked codes from DB (cross-scan dedup) ──
            existing_codes: set[str] = set()
            for state in session.execute(
                select(MonitoringStockState).where(
                    MonitoringStockState.trading_date == self.trading_date,
                )
            ).scalars():
                if state.code:
                    existing_codes.add(state.code)
            def _can_enter(code: str) -> bool:
                """A code can enter if not already tracked in DB or runtime rejected."""
                if code in existing_codes:
                    return False
                return runtime.can_enter(code)
            # ══ 1. speed_rank → PRE_CANDIDATE ══ (interval: 3s)
            try:
                t_now = datetime.utcnow().timestamp()
                if t_now - self._last_speed_rank < 3.0:
                    sr_rows: list[dict] = []
                else:
                    self._last_speed_rank = t_now
                    sr_rows = _fetch_speed_rank()
                summary["speed_rank"] = len(sr_rows)
                for row in sr_rows:
                    code = row["code"]
                    if not _can_enter(code):
                        continue
                    seq += 1
                    evt = CandidateEntryInput(
                        trading_date=self.trading_date,
                        source_trading_date=self.trading_date,
                        code=code, name=row["name"],
                        event_type="speed_rank", event_source="eastmoney_rank",
                        event_title="speed_rank", event_time=None,
                        as_of=datetime.utcnow(), seq=seq,
                        freshness_status="fresh",
                        price=row.get("price"), change_pct=row.get("change_pct"),
                        raw_json=json.dumps(row, ensure_ascii=False),
                    )
                    result = mgr.handle_source_event(evt)
                    if "enter_pre_candidate" in (result.action or ""):
                        summary["pre_candidate"] += 1; existing_codes.add(code)
                    elif "reject" in (result.action or "") or "failed" in (result.action or ""):
                        summary["rejected"] += 1; runtime.reject_code(code)
            except Exception as exc:
                summary["errors"].append(f"speed_rank:{exc}")
            session.flush()
            # 2. shortline → PRE_CANDIDATE (interval: 2s)
            try:
                t_now = datetime.utcnow().timestamp()
                if t_now - self._last_shortline < 2.0:
                    sl_events: list = []
                else:
                    self._last_shortline = t_now
                    from app.sources.eastmoney_shortline import fetch_shortline_events
                    sl_events = fetch_shortline_events()
                summary["shortline"] = len(sl_events)
                for evt in sl_events:
                    valid, freshness = self._validate_event_time(
                        evt.event_time, self.trading_date, source="shortline",
                    )
                    if not valid:
                        summary["shortline_skipped"] += 1
                        continue
                    # dedup 1: per-event composite key (same API row never processed twice)
                    if runtime.is_event_seen(evt.dedup_key):
                        summary["shortline_skipped"] += 1
                        continue
                    # dedup 2: per-stock — only one lifecycle entry per stock
                    if not _can_enter(evt.code):
                        runtime.mark_event_seen(evt.dedup_key)  # mark seen but skip
                        continue
                    runtime.mark_event_seen(evt.dedup_key)
                    seq += 1
                    entry = CandidateEntryInput(
                        trading_date=self.trading_date,
                        source_trading_date=self.trading_date,
                        code=evt.code, name=evt.name,
                        event_type=evt.kind,
                        event_source="eastmoney_changes",
                        event_title=evt.title,
                        event_time=evt.event_time,
                        as_of=datetime.utcnow(), seq=seq,
                        freshness_status="fresh",
                        price=evt.price, change_pct=evt.change_pct,
                        raw_json=json.dumps(evt.raw or {}, ensure_ascii=False),
                    )
                    result = mgr.handle_source_event(entry)
                    if "enter_pre_candidate" in (result.action or ""):
                        summary["pre_candidate"] += 1; existing_codes.add(evt.code)
                    elif "reject" in (result.action or "") or "failed" in (result.action or ""):
                        summary["rejected"] += 1; runtime.reject_code(evt.code)
            except Exception as exc:
                summary["errors"].append(f"shortline:{exc}")
            session.flush()
            # 3. promote → CANDIDATE
            try:
                pre_states = list(session.execute(
                    select(MonitoringStockState).where(
                        MonitoringStockState.trading_date == self.trading_date,
                        MonitoringStockState.stage == "PRE_CANDIDATE",
                        MonitoringStockState.active_monitoring.is_(True),
                    )
                ).scalars())
                for state in pre_states:
                    seq += 1
                    r = mgr.promote_pre_candidate(
                        trading_date=self.trading_date,
                        source_trading_date=state.source_trading_date,
                        code=state.code, name=state.name,
                        as_of=datetime.utcnow(), seq=seq,
                        freshness_status=state.freshness_status or "fresh",
                        price=state.price, change_pct=state.change_pct,
                    )
                    if r.action == "promote_candidate":
                        summary["candidates"] += 1
            except Exception as exc:
                summary["errors"].append(f"promote:{exc}")
            session.flush()
            # 4. Tencent orderbook → CANDIDATE seal + CORE open check
            try:
                active_states = list(session.execute(
                    select(MonitoringStockState).where(
                        MonitoringStockState.trading_date == self.trading_date,
                        MonitoringStockState.stage.in_(["CANDIDATE", "CORE"]),
                        MonitoringStockState.active_monitoring.is_(True),
                    )
                ).scalars())
                if active_states:
                    codes = [s.code for s in active_states]
                    quotes = fetch_composite_quotes(codes)
                    qmap = {q["code"]: q for q in quotes}
                    for state in active_states:
                        q = qmap.get(state.code)
                        if not q:
                            continue
                        seq += 1
                        limit_up = q.get("limit_up")
                        at_limit = (limit_up is not None and q["price"] is not None
                                    and abs(q["price"] - limit_up) < 0.01)
                        bid_at_limit = (limit_up is not None and q["bid1"] is not None
                                        and abs(q["bid1"] - limit_up) < 0.01)
                        is_sealed = bid_at_limit and q["bid_vol1"] > 0
                        confidence = "explicit" if is_sealed else "insufficient"
                        quote = CandidateQuoteInput(
                            trading_date=self.trading_date,
                            source_trading_date=state.source_trading_date,
                            code=state.code, name=state.name,
                            as_of=datetime.utcnow(), seq=seq,
                            freshness_status="fresh",
                            price=q["price"], change_pct=q.get("change_pct") or 0,
                            bid1=q.get("bid1"), bid_vol1=q.get("bid_vol1"),
                            ask1=q.get("ask1"), ask_vol1=q.get("ask_vol1"),
                            is_sealed=is_sealed, at_limit=at_limit,
                            seal_confidence=confidence,
                            event_source="tencent_quote",
                        )
                        r = mgr.process_quote(quote)
                        if r.action == "promote_core":
                            summary["core_transitions"] += 1
                        elif r.action and "demote" in r.action:
                            summary["open_transitions"] += 1
            except Exception as exc:
                summary["errors"].append(f"seal_check:{exc}")
            session.flush()
            # 4.5 volume spike detection
            try:
                spikes = mgr.check_volume_spikes(self.trading_date)
                summary["volume_spikes"] = spikes
                seq += spikes
            except Exception as exc:
                summary["errors"].append(f"volume_spike:{exc}")
            session.flush()
            # 4. limit_pool → score tasks (interval: 8s)
            try:
                t_now = datetime.utcnow().timestamp()
                if t_now - self._last_limit_pool >= 8.0:
                    self._last_limit_pool = t_now
                    lp_rows = _fetch_limit_pool(self.trading_date)
                    # Filter by last_limit_time validity
                    lp_filtered: list[dict] = []
                    for r in lp_rows:
                        valid, _ = self._validate_event_time(
                            r.get("last_limit_time"), self.trading_date, source="limit_pool",
                        )
                        if valid:
                            lp_filtered.append(r)
                    summary["limit_pool"] = len(lp_filtered)
                    summary["limit_pool_discarded"] = len(lp_rows) - len(lp_filtered)
                    if lp_filtered:
                        snapshot = LimitPoolInputSnapshot(
                            trading_date=self.trading_date,
                            source_trading_date=self.trading_date,
                            source="eastmoney_limit_pool",
                            primary_source="eastmoney_limit_pool",
                            as_of=datetime.utcnow(), seq=seq,
                            freshness_status="fresh", market_session="trading",
                            rows=[LimitPoolInputRow(
                                pool=r["pool"], code=r["code"], name=r["name"],
                                source="eastmoney_limit_pool",
                                price=r.get("price"), change_pct=r.get("change_pct"),
                                first_limit_time=r.get("first_limit_time"),
                                last_limit_time=r.get("last_limit_time"),
                                open_count=r.get("open_count"),
                                seal_amount=r.get("seal_amount"),
                                industry=r.get("industry"),
                                reason=r.get("reason"),
                            ) for r in lp_filtered],
                        )
                        mgr.ingest_limit_pool_snapshot(snapshot)
                        session.flush()
                        db_rows = list(session.execute(
                            select(LimitPoolRow).where(
                                LimitPoolRow.trading_date == self.trading_date,
                            )
                        ).scalars())
                        for db_row in db_rows:
                            sig = "|".join([
                                str(db_row.pool or ""),
                                str(db_row.price or ""),
                                str(db_row.change_pct or ""),
                                str(db_row.first_limit_time or ""),
                                str(db_row.last_limit_time or ""),
                                str(db_row.open_count or ""),
                                str(db_row.seal_amount or ""),
                                str(db_row.streak or ""),
                                str(db_row.reason or ""),
                            ])
                            key = f"{db_row.code}:{db_row.pool}"
                            prev = self._lp_signatures.get(key)
                            if sig != prev:
                                self._lp_signatures[key] = sig
                                mgr.schedule_score_for_limit_pool_row(db_row)
                        # Score tasks created — async queue will process them
                        session.flush()
            except Exception as exc:
                summary["errors"].append(f"limit_pool:{exc}")
            session.flush()
            # 5. seal/open scoring + notification gate
            try:
                # Score tasks already created by process_quote/mgr — queue handles them
                notifiable = mgr.check_notification_candidates(self.trading_date)
                summary["notifiable"] = len(
                    [n for n in notifiable if n.get("should_notify")]
                )
            except Exception as exc:
                summary["errors"].append(f"post_scoring:{exc}")
            # counts + stock snapshots for WS push
            all_active = list(session.execute(
                select(MonitoringStockState).where(
                    MonitoringStockState.trading_date == self.trading_date,
                    MonitoringStockState.active_monitoring.is_(True),
                )
            ).scalars())
            summary["core_states"] = sum(1 for s in all_active if s.stage == "CORE")
            summary["_stock_snapshots"] = [
                {
                    "code": s.code, "name": s.name, "stage": s.stage,
                    "price": s.price, "change_pct": s.change_pct,
                    "is_sealed": s.is_sealed, "at_limit": s.at_limit,
                    "active_monitoring": s.active_monitoring,
                    "freshness_status": s.freshness_status or "fresh",
                    "source_trading_date": s.source_trading_date,
                }
                for s in all_active
            ]
            session.commit()
        return summary
