from __future__ import annotations

from fastapi import APIRouter

from app.api.routes.engine import router as engine_router
from app.api.routes.events import router as events_router
from app.api.routes.health import router as health_router
from app.api.routes.limit_pool import router as limit_pool_router
from app.api.routes.opportunities import router as opportunities_router
from app.api.routes.speed_rank import router as speed_rank_router
from app.api.routes.boards import router as boards_router
from app.api.routes.monitoring_shadow import router as monitoring_shadow_router
from app.api.routes.monitoring_realtime import router as monitoring_realtime_router

api_router = APIRouter()
api_router.include_router(health_router)
api_router.include_router(opportunities_router)
api_router.include_router(events_router)
api_router.include_router(engine_router)
api_router.include_router(limit_pool_router)
api_router.include_router(speed_rank_router)
api_router.include_router(boards_router)
api_router.include_router(monitoring_shadow_router)
api_router.include_router(monitoring_realtime_router)
