"""Realtime dev monitoring API (read-only, reads data/astock_guard_v2.db)."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Query

router = APIRouter(prefix="/api/monitoring/realtime", tags=["monitoring_realtime"])

_REALTIME_DB = Path(__file__).resolve().parents[4] / "data" / "astock_guard_v2.db"


def _conn() -> sqlite3.Connection | None:
    if not _REALTIME_DB.exists():
        return None
    conn = sqlite3.connect(f"file:{_REALTIME_DB.resolve()}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def _dicts(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> list[dict[str, Any]]:
    return [dict(row) for row in conn.execute(sql, params)]


def _one(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> dict[str, Any]:
    row = conn.execute(sql, params).fetchone()
    return dict(row) if row else {}


_FLAGS = {
    "data_mode": "realtime_dev",
    "scoring_mode": "legacy_full_partial",
    "quote_can_drive_seal": False,
    "core_active_enabled": False,
    "notification_enabled": False,
    "self_stock_enabled": False,
}


@router.get("/overview")
def realtime_overview():
    conn = _conn()
    if conn is None:
        return {"db_path": str(_REALTIME_DB), "warning": "realtime_db_not_found", **_FLAGS}
    try:
        dates = _dicts(conn, "select distinct trading_date from monitoring_stock_states order by trading_date")
        counts = {
            "monitoring_stock_states": _one(conn, "select count(*) as c from monitoring_stock_states")["c"],
            "monitoring_events": _one(conn, "select count(*) as c from monitoring_events")["c"],
            "monitoring_state_transitions": _one(conn, "select count(*) as c from monitoring_state_transitions")["c"],
            "limit_pool_snapshots": _one(conn, "select count(*) as c from limit_pool_snapshots")["c"],
            "limit_pool_rows": _one(conn, "select count(*) as c from limit_pool_rows")["c"],
            "score_task_current": _one(conn, "select count(*) as c from score_task_current")["c"],
            "score_snapshots": _one(conn, "select count(*) as c from score_snapshots")["c"],
            "interface_health": _one(conn, "select count(*) as c from interface_health")["c"],
        }
        return {"db_path": str(_REALTIME_DB), "trading_dates": [r["trading_date"] for r in dates], "counts": counts, **_FLAGS}
    finally:
        conn.close()


@router.get("/stocks")
def realtime_stocks(trading_date: str = Query(default="")):
    conn = _conn()
    if conn is None:
        return {"stocks": [], "warning": "realtime_db_not_found", **_FLAGS}
    try:
        where = "" if not trading_date else " where s.trading_date = ?"
        params = (trading_date,) if trading_date else ()
        stocks = _dicts(conn, f"""
            select s.trading_date, s.code, s.name, s.stage, s.active_monitoring, s.inactive_reason,
                   s.price, s.change_pct, s.is_sealed, s.at_limit, s.freshness_status,
                   s.source_trading_date, s.as_of, s.seq
            from monitoring_stock_states s
            {where}
            order by s.code
        """, params)
        for s in stocks:
            snap = _one(conn, """
                select score_stage, score, technical_score, sentiment_score, volume_score, status, passed, reject_reason, score_json
                from score_snapshots
                where trading_date = ? and code = ? and score_stage in ('pre_candidate','limit_pool_first_score')
                order by id desc limit 1
            """, (s["trading_date"], s["code"]))
            if snap:
                snap["scoring_mode"] = "legacy_full_partial"
            s["latest_score_snapshot"] = snap or None
        return {"stocks": stocks, **_FLAGS}
    finally:
        conn.close()


@router.get("/limit-pool")
def realtime_limit_pool(trading_date: str = Query(default="")):
    conn = _conn()
    if conn is None:
        return {"snapshot": None, "warning": "realtime_db_not_found", **_FLAGS}
    try:
        snapshot = _one(conn, """
            select id, source, primary_source, freshness_status, source_trading_date, as_of
            from limit_pool_snapshots
            order by id desc limit 1
        """)
        if not snapshot:
            return {"snapshot": None, **_FLAGS}
        rows = _dicts(conn, """
            select code, name, pool, price, change_pct,
                   first_limit_time, last_limit_time, open_count, seal_amount,
                   streak, industry, reason, freshness_status, source_trading_date
            from limit_pool_rows
            where snapshot_id = ?
            order by pool, first_limit_time, code
        """, (snapshot["id"],))
        return {"snapshot": snapshot, "rows": rows, **_FLAGS}
    finally:
        conn.close()


@router.get("/scores")
def realtime_scores(trading_date: str = Query(default="")):
    conn = _conn()
    if conn is None:
        return {"scores": [], "warning": "realtime_db_not_found", **_FLAGS}
    try:
        where = "" if not trading_date else " where s.trading_date = ?"
        params = (trading_date,) if trading_date else ()
        scores = _dicts(conn, f"""
            select s.trading_date, s.code, s.name, s.score_type, s.score_stage,
                   s.score, s.technical_score, s.sentiment_score, s.volume_score,
                   s.status, s.passed, s.reject_reason, s.source_type, s.source_row_id,
                   s.input_refs_json, s.score_json, s.as_of, s.freshness_status
            from score_snapshots s
            {where}
            order by s.id
        """, params)
        for sc in scores:
            sc["scoring_mode"] = "legacy_full_partial"
        return {"scores": scores, **_FLAGS}
    finally:
        conn.close()


@router.get("/interface-health")
def realtime_interface_health(limit: int = Query(default=50, ge=1, le=200)):
    conn = _conn()
    if conn is None:
        return {"records": [], "warning": "realtime_db_not_found", **_FLAGS}
    try:
        records = _dicts(conn, """
            select name, category, ok, latency_ms, error, timestamp, detail_json
            from interface_health
            order by id desc
            limit ?
        """, (limit,))
        return {"records": records, **_FLAGS}
    finally:
        conn.close()
