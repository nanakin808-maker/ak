from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Query

router = APIRouter(prefix="/api/monitoring/shadow", tags=["monitoring_shadow"])

_SHADOW_DB = Path(__file__).resolve().parents[4] / "data" / "astock_guard_v2_shadow.db"


def _conn() -> sqlite3.Connection | None:
    if not _SHADOW_DB.exists():
        return None
    conn = sqlite3.connect(f"file:{_SHADOW_DB.resolve()}?mode=ro", uri=True, timeout=5)
    conn.row_factory = sqlite3.Row
    return conn


def _dicts(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> list[dict[str, Any]]:
    return [dict(row) for row in conn.execute(sql, params)]


def _one(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> dict[str, Any]:
    row = conn.execute(sql, params).fetchone()
    return dict(row) if row else {}


@router.get("/overview")
def shadow_overview():
    conn = _conn()
    if conn is None:
        return {"data_mode": "shadow", "db_path": str(_SHADOW_DB), "counts": {}, "warning": "shadow_db_not_found"}
    try:
        dates = _dicts(conn, "select distinct trading_date from monitoring_stock_states order by trading_date")
        counts = {
            "monitoring_stock_states": _one(conn, "select count(*) as c from monitoring_stock_states")["c"],
            "monitoring_events": _one(conn, "select count(*) as c from monitoring_events")["c"],
            "monitoring_state_transitions": _one(conn, "select count(*) as c from monitoring_state_transitions")["c"],
            "limit_pool_snapshots": _one(conn, "select count(*) as c from limit_pool_snapshots")["c"],
            "limit_pool_rows": _one(conn, "select count(*) as c from limit_pool_rows")["c"],
            "score_task_current": _one(conn, "select count(*) as c from score_task_current")["c"],
            "score_snapshots": _one(conn, "select count(*) as c from score_snapshots")["c"],
            "interface_health": _one(conn, "select count(*) as c from interface_health")["c"],
        }
        market_meta = {}
        try:
            from app.domain.market_calendar import (
                effective_trading_date, is_live_trading, market_session,
            )
            market_meta = {
                "marketSession": market_session().value,
                "effectiveTradingDate": effective_trading_date(),
                "isLiveTrading": is_live_trading(),
            }
        except Exception:
            pass
        return {
            "data_mode": "shadow",
            "scoring_mode": "legacy_full",
            "quote_can_drive_seal": True,
            "limit_pool_can_drive_lifecycle": True,
            "seal_source": "tencent_orderbook",
            "db_path": str(_SHADOW_DB),
            "trading_dates": [r["trading_date"] for r in dates],
            **market_meta,
            "counts": counts,
        }
    finally:
        conn.close()


@router.get("/stocks")
def shadow_stocks(trading_date: str = Query(default="")):
    conn = _conn()
    if conn is None:
        return {"data_mode": "shadow", "stocks": [], "warning": "shadow_db_not_found"}
    try:
        where = "" if not trading_date else " where s.trading_date = ?"
        params = (trading_date,) if trading_date else ()
        stocks = _dicts(conn, f"""
            select s.trading_date, s.code, s.name, s.stage, s.active_monitoring, s.inactive_reason,
                   s.price, s.change_pct, s.is_sealed, s.at_limit, s.freshness_status,
                   s.source_trading_date, s.as_of, s.seq
            from monitoring_stock_states s
            {where}
            order by s.as_of desc
        """, params)
        for s in stocks:
            snap = _one(conn, """
                select score_stage, score, technical_score, sentiment_score, volume_score, status, passed, reject_reason
                from score_snapshots
                where trading_date = ? and code = ? and score_stage in ('pre_candidate','limit_pool_first_score')
                order by id desc limit 1
            """, (s["trading_date"], s["code"]))
            if snap:
                s["latest_score_snapshot"] = {**snap, "scoring_mode": "static_mock" if snap["score_stage"] == "limit_pool_first_score" else "entry_rule"}
            else:
                s["latest_score_snapshot"] = None
        return {"data_mode": "shadow", "scoring_mode": "static_mock", "stocks": stocks}
    finally:
        conn.close()


@router.get("/limit-pool")
def shadow_limit_pool(trading_date: str = Query(default="")):
    conn = _conn()
    if conn is None:
        return {"data_mode": "shadow", "snapshot": None, "warning": "shadow_db_not_found"}
    try:
        snapshot = _one(conn, """
            select id, source, primary_source, freshness_status, source_trading_date, as_of
            from limit_pool_snapshots
            order by id desc limit 1
        """)
        if not snapshot:
            return {"data_mode": "shadow", "snapshot": None}
        rows = _dicts(conn, """
            select code, name, pool, price, change_pct,
                   first_limit_time, last_limit_time, open_count, seal_amount,
                   streak, industry, reason, freshness_status, source_trading_date
            from limit_pool_rows
            where snapshot_id = ?
            order by pool, first_limit_time, code
        """, (snapshot["id"],))
        return {"data_mode": "shadow", "snapshot": snapshot, "rows": rows}
    finally:
        conn.close()


@router.get("/scores")
def shadow_scores(trading_date: str = Query(default="")):
    conn = _conn()
    if conn is None:
        return {"data_mode": "shadow", "scores": [], "warning": "shadow_db_not_found"}
    try:
        where = "" if not trading_date else " where s.trading_date = ?"
        params = (trading_date,) if trading_date else ()
        scores = _dicts(conn, f"""
            select s.trading_date, s.code, s.name, s.score_type, s.score_stage,
                   s.score, s.technical_score, s.sentiment_score, s.volume_score,
                   s.status, s.passed, s.reject_reason, s.source_type, s.source_row_id,
                   s.input_refs_json, s.as_of, s.freshness_status
            from score_snapshots s
            {where}
            order by s.id desc
        """, params)
        for sc in scores:
            if sc["score_stage"] == "limit_pool_first_score":
                sc["scoring_mode"] = "static_mock"
            elif sc["score_stage"] == "pre_candidate":
                sc["scoring_mode"] = "entry_rule"
            else:
                sc["scoring_mode"] = "unknown"
        return {"data_mode": "shadow", "scoring_mode": "static_mock", "scores": scores}
    finally:
        conn.close()


@router.get("/interface-health")
def shadow_interface_health(limit: int = Query(default=50, ge=1, le=200)):
    conn = _conn()
    if conn is None:
        return {"data_mode": "shadow", "records": [], "warning": "shadow_db_not_found"}
    try:
        records = _dicts(conn, """
            select name, category, ok, latency_ms, error, timestamp, detail_json
            from interface_health
            order by id desc
            limit ?
        """, (limit,))
        return {"data_mode": "shadow", "records": records}
    finally:
        conn.close()
