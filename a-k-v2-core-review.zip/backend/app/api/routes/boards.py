from __future__ import annotations

from fastapi import APIRouter

from app.schemas.board import BoardsResponse
from app.services.board_service import get_boards

router = APIRouter(prefix="/api", tags=["boards"])


@router.get("/boards", response_model=BoardsResponse)
def read_boards() -> BoardsResponse:
    return get_boards()
