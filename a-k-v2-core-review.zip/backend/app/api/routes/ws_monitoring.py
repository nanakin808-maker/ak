"""
WebSocket endpoint for real-time monitoring push.

Endpoint: /ws/monitoring/realtime?trading_date=YYYY-MM-DD
Receives: heartbeat, scan_status, stock_state_upsert, monitoring_event,
          score_snapshot, limit_pool_snapshot
"""

from __future__ import annotations

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect

from app.realtime.event_bus import get_event_bus
from app.realtime.ws_manager import get_ws_manager

router = APIRouter()


@router.websocket("/ws/monitoring/realtime")
async def ws_monitoring_realtime(
    websocket: WebSocket,
    trading_date: str = Query(default=""),
) -> None:
    if not trading_date:
        from datetime import datetime
        trading_date = datetime.now().strftime("%Y%m%d")

    mgr = get_ws_manager()
    conn = await mgr.connect(websocket, trading_date)

    # Start event bus broadcast loop if not running
    bus = get_event_bus()
    q = await bus.subscribe()

    try:
        while True:
            msg = await q.get()
            if msg.get("trading_date") != trading_date:
                continue
            try:
                await websocket.send_json(msg)
                conn.last_msg_at = __import__("time").time()
                conn.last_seq = max(conn.last_seq, msg.get("seq", 0))
            except Exception:
                break
    except WebSocketDisconnect:
        pass
    finally:
        bus.unsubscribe(q)
        mgr.disconnect(conn)
