from __future__ import annotations

from fastapi import APIRouter

from app.schemas.limit_pool import LimitPoolResponse
from app.services.limit_pool_service import get_limit_pool

router = APIRouter(prefix="/api", tags=["limit-pool"])


@router.get("/limit-pool", response_model=LimitPoolResponse)
def read_limit_pool() -> LimitPoolResponse:
    return get_limit_pool()
