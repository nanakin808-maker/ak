from __future__ import annotations

from fastapi import APIRouter

from app.schemas.engine import EngineResponse
from app.services.engine_service import (
    engine_status,
    reset_engine,
    start_engine,
    stop_engine,
)

router = APIRouter(prefix="/api/engine", tags=["engine"])


@router.get("/status", response_model=EngineResponse)
def read_engine_status() -> EngineResponse:
    return engine_status()


@router.post("/start", response_model=EngineResponse)
async def start_engine_route() -> EngineResponse:
    return await start_engine()


@router.post("/stop", response_model=EngineResponse)
async def stop_engine_route() -> EngineResponse:
    return await stop_engine()


@router.post("/reset", response_model=EngineResponse)
async def reset_engine_route() -> EngineResponse:
    return await reset_engine()
