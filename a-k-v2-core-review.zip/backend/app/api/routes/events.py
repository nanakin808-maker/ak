from __future__ import annotations

from fastapi import APIRouter

from app.schemas.event import EventsResponse
from app.services.opportunity_service import get_events

router = APIRouter(prefix="/api/events", tags=["events"])


@router.get("/realtime", response_model=EventsResponse)
def read_realtime_events() -> EventsResponse:
    return get_events()
