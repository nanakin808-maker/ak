from __future__ import annotations

from fastapi import APIRouter

from app.schemas.speed_rank import SpeedRankResponse
from app.services.speed_rank_service import get_speed_rank

router = APIRouter(prefix="/api", tags=["speed-rank"])


@router.get("/speed-rank", response_model=SpeedRankResponse)
def read_speed_rank() -> SpeedRankResponse:
    return get_speed_rank()
