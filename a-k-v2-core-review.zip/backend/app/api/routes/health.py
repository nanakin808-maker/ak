from __future__ import annotations

from fastapi import APIRouter

from app.schemas.opportunity import HealthResponse
from app.services.opportunity_service import legacy_configured, now_text

router = APIRouter(prefix="/api", tags=["health"])


@router.get("/health", response_model=HealthResponse)
def read_health() -> HealthResponse:
    return HealthResponse(
        updatedAt=now_text(),
        legacyConfigured=legacy_configured(),
    )
