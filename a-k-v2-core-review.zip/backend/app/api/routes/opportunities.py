from __future__ import annotations

from fastapi import APIRouter

from app.schemas.opportunity import OpportunitiesResponse
from app.services.opportunity_service import get_opportunities

router = APIRouter(prefix="/api", tags=["opportunities"])


@router.get("/opportunities", response_model=OpportunitiesResponse)
def read_opportunities() -> OpportunitiesResponse:
    return get_opportunities()
