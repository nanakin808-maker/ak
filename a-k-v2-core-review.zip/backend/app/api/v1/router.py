from fastapi import APIRouter

from app.api.v1.routes import (
    health,
    alerts,
    candidates,
    limit_pool,
    speed_rank,
    settings as settings_routes,
    strategies,
    qwen,
    system,
    websocket,
)

router = APIRouter()
router.include_router(health.router, tags=["health"])
router.include_router(alerts.router, prefix="/alerts", tags=["alerts"])
router.include_router(candidates.router, prefix="/candidates", tags=["candidates"])
router.include_router(limit_pool.router, prefix="/limit-pool", tags=["limit-pool"])
router.include_router(speed_rank.router, prefix="/speed-rank", tags=["speed-rank"])
router.include_router(settings_routes.router, prefix="/settings", tags=["settings"])
router.include_router(strategies.router, prefix="/strategies", tags=["strategies"])
router.include_router(qwen.router, prefix="/qwen", tags=["qwen"])
router.include_router(system.router, prefix="/system", tags=["system"])
router.include_router(websocket.router, prefix="/ws", tags=["websocket"])
