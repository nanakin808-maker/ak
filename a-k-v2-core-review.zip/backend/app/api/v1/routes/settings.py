"""App settings endpoints."""

from fastapi import APIRouter

from app.core.responses import ok
from app.schemas.settings import SettingsResponse

router = APIRouter()


@router.get("/")
def get_settings() -> SettingsResponse:
    return SettingsResponse(
        ths_ok=False,
        feishu_ok=False,
        notification=SettingsResponse.NotificationSettings(),
        speed_rank=SettingsResponse.SpeedRankHealth(available=False),
    )


@router.post("/feishu")
def update_feishu():
    return ok({}, message="placeholder")


@router.post("/feishu/test")
def test_feishu():
    return ok({}, message="placeholder - not configured")


@router.post("/ths-cookie")
def update_ths_cookie():
    return ok({}, message="placeholder")


@router.post("/notification")
def update_notification():
    return ok({}, message="placeholder")
