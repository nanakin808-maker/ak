"""Speed ranking endpoints."""

from fastapi import APIRouter, Query

from app.core.responses import ok

router = APIRouter()


@router.get("/")
def get_speed_rank(limit: int = Query(20, le=100)):
    return ok({"limit": limit, "rows": []})
