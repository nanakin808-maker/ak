"""Limit-up pool and open-board pool endpoints."""

from fastapi import APIRouter, Query

from app.core.responses import ok

router = APIRouter()


@router.get("/")
def get_limit_pool(
    date: str | None = Query(None),
    pool: str | None = Query(None, description="limit_up | open_board"),
    limit: int = Query(300, le=500),
):
    return ok({"date": date, "pool": pool, "limit": limit, "rows": []})


@router.get("/dates")
def get_limit_pool_dates(limit: int = Query(20, le=60)):
    return ok({"dates": [], "limit": limit})
