"""Strategy definition and evaluation endpoints."""

from fastapi import APIRouter, Query

from app.core.responses import ok

router = APIRouter()


@router.get("/")
def list_strategies(enabled_only: bool = False):
    return ok({"strategies": [], "enabled_only": enabled_only})


@router.get("/definitions")
def list_strategy_definitions():
    return ok({"definitions": []})


@router.post("/")
def create_strategy():
    return ok({}, message="placeholder")


@router.patch("/{strategy_id}")
def update_strategy(strategy_id: str):
    return ok({"strategy_id": strategy_id}, message="placeholder")


@router.delete("/{strategy_id}")
def delete_strategy(strategy_id: str):
    return ok({"strategy_id": strategy_id}, message="placeholder")
