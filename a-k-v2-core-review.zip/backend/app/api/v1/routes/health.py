"""Health-check endpoint."""

from fastapi import APIRouter

from app.core.context import app_context
from app.core.responses import ok

router = APIRouter()


@router.get("/health")
def health_check():
    return ok({"status": "running", "started": app_context.started})
