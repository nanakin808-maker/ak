"""Alert engine control and state endpoints."""

from fastapi import APIRouter

from app.core.responses import ok
from app.schemas.alerts import AlertStateResponse, AlertStartPayload, AlertControlResponse

router = APIRouter()


@router.get("/state")
def get_alert_state() -> AlertStateResponse:
    return AlertStateResponse(
        running=False,
        monitor_events=0,
        candidates=0,
        core=0,
        pre_candidates=0,
    )


@router.post("/start")
def start_alerts(payload: AlertStartPayload) -> AlertControlResponse:
    return AlertControlResponse(action="start", payload=payload)


@router.post("/stop")
def stop_alerts() -> AlertControlResponse:
    return AlertControlResponse(action="stop")


@router.post("/reset")
def reset_alerts() -> AlertControlResponse:
    return AlertControlResponse(action="reset")


@router.post("/scan-once")
def scan_once() -> AlertControlResponse:
    return AlertControlResponse(action="scan-once", scanned=0)
