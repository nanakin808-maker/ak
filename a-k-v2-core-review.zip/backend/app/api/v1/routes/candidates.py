"""Candidate stock lifecycle endpoints."""

from fastapi import APIRouter, Query

from app.core.responses import ok

router = APIRouter()


@router.get("/")
def list_candidates(
    stage: str | None = Query(None, description="pre_candidate | candidate | core"),
    limit: int = Query(200, le=500),
):
    return ok({"stage": stage, "limit": limit, "rows": []})
