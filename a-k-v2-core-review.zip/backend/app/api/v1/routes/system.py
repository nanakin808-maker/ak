"""System control endpoints."""

from fastapi import APIRouter

from app.core.responses import ok

router = APIRouter()


@router.get("/market/status")
def get_market_status():
    return ok({"phase": "unknown", "today": None})


@router.post("/restart")
def restart_system():
    return ok({}, message="placeholder - restart triggered")


@router.get("/health/interfaces")
def get_interface_health():
    return ok({"summary": {}, "failures": []})
