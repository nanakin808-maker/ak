"""Qwen AI read-only analysis endpoints."""

from fastapi import APIRouter

from app.core.responses import ok

router = APIRouter()


@router.get("/status")
def get_qwen_status():
    return ok({"available": False, "model": "placeholder"})


@router.post("/read-only")
def ask_qwen_read_only():
    return ok({"answer": "placeholder - qwen not configured"}, message="placeholder")
