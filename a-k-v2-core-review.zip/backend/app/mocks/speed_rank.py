from __future__ import annotations

from app.schemas.speed_rank import SpeedRankItem


def mock_speed_rank() -> list[SpeedRankItem]:
    return [
        SpeedRankItem(
            rank=1,
            code="300750",
            name="宁德时代",
            price=214.28,
            changePct=4.12,
            speedPct=2.18,
            technicalScore=86,
            sentimentScore=91,
            volumeScore=94,
            volumeStatus="confirmed",
            board="锂电池",
            boardChangePct=3.82,
            signal="量能确认",
            eventTime="09:41:02",
            source="mock",
        ),
        SpeedRankItem(
            rank=2,
            code="002594",
            name="比亚迪",
            price=238.64,
            changePct=1.76,
            speedPct=1.44,
            technicalScore=79,
            sentimentScore=72,
            volumeScore=68,
            volumeStatus="monitoring",
            board="新能源车",
            boardChangePct=3.25,
            signal="快速拉升",
            eventTime="09:40:11",
            source="mock",
        ),
        SpeedRankItem(
            rank=3,
            code="600519",
            name="贵州茅台",
            price=1688.50,
            changePct=2.83,
            speedPct=1.21,
            technicalScore=82,
            sentimentScore=78,
            volumeScore=None,
            volumeStatus="pending",
            board="白酒",
            boardChangePct=1.26,
            signal="等待量能",
            eventTime="09:35:18",
            source="mock",
        ),
    ]
