from __future__ import annotations

from app.schemas.event import MonitorEvent


def mock_events() -> list[MonitorEvent]:
    return [
        MonitorEvent(
            id="mock-e1",
            time="09:41:02",
            code="300750",
            name="宁德时代",
            event="量能确认",
            detail="进入候选后量能确认，晋级核心候选",
            tone="red",
        ),
        MonitorEvent(
            id="mock-e2",
            time="09:40:11",
            code="002594",
            name="比亚迪",
            event="快速拉升",
            detail="涨速触发，等待量能确认",
            tone="blue",
        ),
        MonitorEvent(
            id="mock-e3",
            time="09:38:20",
            code="300308",
            name="中际旭创",
            event="涨停",
            detail="涨停池新增",
            tone="red",
        ),
        MonitorEvent(
            id="mock-e4",
            time="09:36:02",
            code="002625",
            name="光启技术",
            event="炸板",
            detail="涨停炸板，进入风险观察",
            tone="green",
        ),
    ]
