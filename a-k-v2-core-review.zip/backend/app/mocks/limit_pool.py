from __future__ import annotations

from app.schemas.limit_pool import LimitPoolItem


def mock_limit_pool() -> list[LimitPoolItem]:
    return [
        LimitPoolItem(
            code="300308",
            name="中际旭创",
            price=158.26,
            changePct=10.0,
            status="sealed",
            board="通信设备",
            boardChangePct=2.41,
            firstSealTime="09:40:11",
            lastEventTime="09:40:11",
            openCount=0,
            sealAmount=2.8,
            sentimentScore=92,
            firstSealSentimentScore=90,
            source="mock",
        ),
        LimitPoolItem(
            code="002625",
            name="光启技术",
            price=34.72,
            changePct=7.35,
            status="opened",
            board="国防军工",
            boardChangePct=1.98,
            firstSealTime="09:31:22",
            lastEventTime="09:38:20",
            openCount=1,
            sealAmount=1.1,
            sentimentScore=85,
            firstSealSentimentScore=81,
            source="mock",
        ),
        LimitPoolItem(
            code="300750",
            name="宁德时代",
            price=214.28,
            changePct=4.12,
            status="near_limit",
            board="锂电池",
            boardChangePct=3.82,
            firstSealTime=None,
            lastEventTime="09:41:02",
            openCount=None,
            sealAmount=None,
            sentimentScore=91,
            firstSealSentimentScore=None,
            source="mock",
        ),
    ]
