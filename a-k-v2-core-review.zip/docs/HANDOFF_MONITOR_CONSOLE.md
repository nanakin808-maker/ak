# A Stock Guard v2 交接总索引（归档）

## 注意

主交接入口已迁移到以下文档：

```text
CLAUDE.md              — 全局规则、禁止项、当前阶段
docs/README.md         — 文档索引和阅读顺序
docs/PROJECT_STATUS.md — 当前完成/未完成状态
docs/BACKEND_HANDOFF.md — 后端实现细节
docs/FRONTEND_HANDOFF.md — 前端实现细节
```

本文件保留为归档参考，不作为主入口。

## 项目定位

A Stock Guard v2 是旧项目 `a-k/` 的重构版本。

核心业务：

```text
实时事件监控 -> 机会队列 -> 技术/情绪/量能评分 -> 候选/核心判断 -> 通知/自选
```

v2 目标：

```text
前后端分离
后端正式分层（api/schemas/services/domain/adapters）
前端成熟技术栈（Vue 3 + TypeScript + Element Plus）
避免超大文件
旧系统只作为 legacy adapter，不照抄
```

## 当前阶段

后端 domain 层已建立骨架。下一步：只读审计旧系统评分来源。详见 `docs/NEXT_STEPS.md`。

## 禁止事项

见 `CLAUDE.md`。
