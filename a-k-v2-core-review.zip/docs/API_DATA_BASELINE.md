# A Stock Guard v2 API × 数据基线

## 1. 本文目的

记录旧系统 API、数据库表、内存状态的事实。供 v2 建表、建 API 时参考。

**这是只读基线，不是架构设计文档。不要求立即据此建表或改代码。**

## 2. 旧系统数据架构总览

```
─── 53 个 API 端点 ───
       │
       ├──→ provider（东方财富/同花顺/飞书，不持久化）
       │
       ├──→ 内存（AlertRuntime dicts：候选状态、去重、self_stock、通知频率）
       │
       └──→ 数据库（sqlite3，约 14 张表）
                │
                ├── daily_stock_state（核心混合宽表 ~60 列）
                ├── score_snapshots（评分快照 ~25 列）
                ├── limit_pool_{snapshots,rows}（涨停池快照+行，~40 列）
                ├── {candidate_archive,feishu_inbox,limit_pool_premiums,interface_health}
                ├── {daily_bars,daily_bar_fetch_ranges,stock_fund_flow}
                ├── {stock_boards,stock_meta}
                └── saved_strategies
```

## 3. 核心 API × 数据来源矩阵

### 监控台核心

| API | 数据来源 | 写操作 | 备注 |
|---|---|---|---|
| `/api/alerts/state` | runtime.snapshot() + daily_stock_state + score_snapshots | 无 | WebSocket /ws/alerts 每秒推送相同内容 |
| `/api/alerts/start` | — | 改 runtime.running | |
| `/api/alerts/stop` | — | 改 runtime.running | |
| `/api/alerts/reset` | — | 改 runtime | |

### 涨停池

| API | 数据来源 | 写操作 | 备注 |
|---|---|---|---|
| `/api/limit-pool` | daily_stock_state + limit_pool_rows + limit_pool_snapshots + score_snapshots + limit_pool_premiums | 写 daily_stock_state + limit_pool_rows，改 runtime | 混合读路径 |
| `/api/limit-pool/status` | runtime.limit_pool_snapshot | 无 | 数据含在 `/api/limit-pool` |
| `/api/limit-pool/dates` | daily_stock_state | 无 | |

### 涨速榜 / 板块

| API | 数据来源 | 写操作 |
|---|---|---|
| `/api/ranks/speed` | provider | 无 |
| `/api/speed-rank/health` | 内存（含在 `/api/settings`） | 无 |
| `/api/boards/ths/*` | provider | 无 |
| `/api/boards/em/*` | stock_boards + provider | 无 |
| `/api/stocks/{code}/boards` | stock_boards + provider | 无 |
| `/api/stocks/{code}/limit-history` | daily_bars | 无 |
| `/api/stocks/{code}/limit-analysis` | daily_bars | 无 |

### 评分 / 状态

| API | 数据来源 | 写操作 |
|---|---|---|
| `/api/score-snapshots` | score_snapshots | 无 |
| `/api/daily-state` | daily_stock_state | 无 |
| `/api/candidate-archive` | daily_stock_state（同 daily-state！） | 无 |

### 设置 / 健康

| API | 数据来源 | 写操作 |
|---|---|---|
| `/api/settings` | 环境变量 + runtime 配置 | 无 |
| `/api/health/interfaces` | interface_health | 无 |

### 同花顺自选

| API | 数据来源 | 写操作 |
|---|---|---|
| `GET /api/ths/self-stock/add/{code}` | provider + daily_stock_state | 写 daily_stock_state + runtime |
| `/api/ths/self-stock/list` | daily_stock_state | 无 |

### Qwen / 策略（非主闭环）

| API | 数据来源 | 写操作 |
|---|---|---|
| `/api/qwen/data` | 多表查询 | 无 |
| `/api/strategies/*` | saved_strategies | 写 saved_strategies |

## 4. 旧系统关键数据流

### 监控引擎扫描循环

```
provider(s) → AlertEngine.scan_once()
  ↓
发送事件到 queue → /ws 推送
  ↓
更新 AlertRuntime 内存状态（候选/核心/剔除）
  ↓
异步 upsert → daily_stock_state 表
  ↓
评分 → score_snapshots 表
  ↓
评价 → 发送飞书通知
  ↓
评价 → 同花顺加自选
```

### 监控台数据查询

```
/ws/alerts 或 /api/alerts/state
  ↓
alert_engine.snapshot() → runtime dict（包含 monitor_events）
  ↓
daily_stock_state.list_monitor_by_codes() → 前 1000 条候选状态
  ↓
score_snapshots 评分回填 → 每行附加评分
  ↓
合并返回
```

## 5. 旧系统核心事实

### daily_stock_state（约 60 列混合大宽表）

```text
混合了生命周期标记、多阶段评分、量能事件、自选状态、通知状态。
主键 (trade_date, code) 可沿用，但列必须拆分。
```

### 生命周期事实来源是内存

```text
PRE_CANDIDATE / CANDIDATE / CORE / REJECTED_TODAY 的事实来源是
AlertRuntime 的 pre_candidate_codes / candidate_codes / core_codes / rejected_today 内存 dict。
daily_stock_state 的 in_pre_candidate / in_candidate / in_core / rejected_today 是冗余备份，
与内存异步同步，不是主数据源。
v2 应当用数据库作为唯一事实来源。
```

### 已确认的孤立/冗余

| 表/API | 问题 |
|---|---|
| `candidate_archive` | 不再被代码使用，不应迁移 |
| `/api/candidate-archive` | 与 `/api/daily-state` 100% 重复 |
| `/api/start` | 死桩 |
| `daily_stock_state.last_volume_event_*`（8 列） | 量能事件独立字段组 |
| `daily_stock_state.seen_speed_rank` 等 | 事件去重字段 |
| `daily_stock_state.realtime_sentiment_cache_at` | 评分缓存时间戳 |
| `limit_pool_rows.*_sentiment_score`（4 套） | 与 score_snapshots 数据重复 |
| `GET /api/ths/self-stock/add/{code}` | 实际执行同花顺 API 写操作（GET 语义错误） |
| `GET /api/speed-rank/health` | 与 `/api/settings` 数据重复 |
| `GET /api/limit-pool/status` | 与 `/api/limit-pool` 数据重复 |

### 可沿用的设计思想

```text
score_snapshots 独立保存评分快照
limit_pool_snapshots（快照）+ limit_pool_rows（行明细）分离
limit_pool_rows PK (trade_date, pool, code)
```

## 6. AlertRuntime 内存状态关键字段

| 字段 | 说明 |
|---|---|
| `pre_candidate_codes` | pre_candidate 状态 dict，key=code |
| `candidate_codes` | candidate 状态 dict |
| `core_codes` | core 状态 dict |
| `rejected_today` | 当日剔除 dict |
| `monitor_event_codes` | 实时监控事件 dict |
| `seen_events` | 事件去重 set |
| `limit_pool_snapshot` | 最近一次涨停池快照 |
| `self_stock_added_codes` | 同花顺自选已添加记录 |
| `per_stock_notice_times` | 个股通知频率 dict |
| `shortline_first_limit_times` | 首封时间 dict |
| `state_versions` | 候选状态版本号 dict |
| `score_snapshot_once_keys` | 评分快照去重 set |

## 7. v2 迁移原则

```text
评分应当独立：score_snapshots 设计正确，评分不写入 daily_stock_state。
生命周期应当持久化：v2 以数据库为准，内存只作为缓存。
事件流应当独立：v2 独立记录事件流水，不依赖内存 monitor_event_codes。
通知记录应当独立：不散落在 daily_stock_state 多个列中。
```

## 8. v2 第一阶段候选（非建表命令）

> 以下是指标性的候选基线。评分来源审计完成前，不得建评分相关表。

| 候选表 | 说明 | 前置条件 |
|---|---|---|
| monitoring_stock_states | 个股生命周期状态 | — |
| monitoring_events | 个股事件流水 | — |
| monitoring_state_transitions | 生命周期迁移记录 | — |
| score_snapshots | 评分快照 | **评分来源审计完成后** |
| limit_pool_snapshots | 涨停池快照 | — |
| limit_pool_rows | 涨停池行明细 | — |
| notification_records | 飞书通知发送记录 | — |
| self_stock_records | 同花顺加自选记录 | — |
| gate_config_versions | 门禁配置版本记录 | — |
| interface_health | 接口健康记录 | — |

### 第一阶段暂不迁移

```text
candidate_archive（遗留表）
Qwen 相关表
策略系统
资金流
日 K 明细
板块成员
飞书 inbox 等非主闭环能力
```

## 9. 评分来源初步审计结论

### 重要说明

**本次评分来源审计是初步审计（方向性调查），不是最终实现说明。**

审计结论可用于：
- 更新 API × 表 × 评分输入矩阵草案
- 标记 v2 与旧系统的数据缺口
- 指导下一步代码复核范围（见 §11）

审计结论**不能直接用于**：
- 实现评分算法
- 建评分输入表
- 接入 provider
- 定最终 API schema

到真正实现评分相关功能时，必须先逐函数复核对应旧代码（复核清单见 §11），确认审计方向的正确性后再进入设计阶段。

### 审计内容

### 技术分

- 依赖：`StrategyEngine` → `kline_structure_score` → `history_provider.get_kline_score()` → `_technical_score_v1()`
- 数据源：`daily_bars` 表（日 K 收盘/最高/最低/成交额）
- Provider：`ThsKlineProvider`（同花顺 HTTP API）
- 内存缓存：`strategy_engine.store`、`StrategyContext._limit_analysis_cache`
- 不依赖：分钟 K 线接口、分时 K

### 分时 K / 日内质量

- 旧系统提供 `/api/stocks/{code}/intraday/bars` 分钟 K 线查询接口，**仅用于前端展示**。
- `intraday_provider.seal_quality()` 用于情绪分的外部修正（开板次数、封板率、开板低点），**不做为量能分输入**。
- 分钟 K 线接口不等于实时报价样本。两者必须区分。

### 量能分

**关键事实：不要简单表述为"量能分不依赖分时 K"。准确表述如下：**

- 旧系统量能分 **不直接依赖** `/api/stocks/{code}/intraday/bars` 这种"分钟 K 线接口"。
- **但**旧系统量能分依赖盘中连续量价数据，即 **`quote_window` / 实时报价样本**（内存 `deque`，按 `quote_window_seconds` 过期）。
- 因此不能理解为"量能分不需要盘中量价序列"。

#### 5 个子评分及输入字段

| 子评分 | 输入字段 | 依赖 quote_window？ | 间接依赖 daily_bars？ |
|---|---|---|---|
| short_window | `change_pct_delta`, `amount_delta`, `volume_delta`, `monotonic_ratio`, `drawdown` | 是 | 否 |
| amount_confirm | `quote.amount`, `strategy.metrics.amount_ratio20` | 否 | 是（amount_ratio20 来自技术分） |
| turnover_fit | `quote.volume`, `stock_meta.float_share`, `stock_meta.float_market_value` | 否 | 否 |
| history_compare | `strategy.metrics.amount_ratio20`, `strategy.metrics.amount_std20` | 否 | 是（来自技术分） |
| risk_penalty | quote_window 样本、quote、strategy.metrics、stock_meta | 是 | 是 |

#### 总结

- 核心实时输入：`amount`, `volume`, `change_pct`, `amount_delta`, `volume_delta`, `change_pct_delta`, `monotonic_ratio`, `drawdown`（来自 `quote_window`）
- 间接日 K 派生 metrics：`amount_ratio20`, `amount_std20`
- 流通股本依赖：`stock_meta.float_share`, `stock_meta.float_market_value`
- 数据库表：无（quote_window 是内存 deque，不持久化）

### 板块情绪分

- 依赖：股票所属板块（`StockBoardProvider` → `stock_boards` 表 + efinance API）
- 板块成分股 Top20（`EastmoneyBoardMemberProvider`，无持久表，内存缓存 + 实时 API）
- 涨停池顺位（`_apply_limit_pool_order_to_board()` → `runtime.limit_pool_snapshot` → `limit_pool_rows`）
- 涨停家数/炸板数（`limit_up_count`, `open_board_count` 来自涨停池）
- 个股资金流（`fund_flow_provider.get_flow()` → `stock_fund_flow` 表）
- 分时封板质量（`intraday_provider.seal_quality()` → 实时 API，无持久表）
- 技术分修正（`kline_score` → 限制情绪分高估）

### 涨停池评分

- `LimitPoolScoringQueue` **不是独立评分算法**，它调用 `AlertEngine.evaluate_stock_score()`。
- `limit_pool_rows` 同时混合：
  - **输入列**：`code, name, source, price, change_pct, first_limit_time, last_limit_time, open_count, seal_amount, streak, industry, reason`
  - **结果列**：`technical_score, sentiment_score, volume_score, main_logic, trigger_sentiment_score, seal_sentiment_score, open_sentiment_score, realtime_sentiment_score, board_rank, main_board_rank, limit_order_rank, main_board_limit_order_rank, score_status, score_source, score_snapshot_time, score_passed, score_reject_reason`
- v2 必须区分输入和结果。

### trigger / seal / open / reseal 情绪快照

- 生成函数：`_board_score_stage_snapshot(target, stage)`
- 触发 stage：`trigger/near_limit/self_stock` → trigger 快照；`seal/first_limit/limit_pool_first_score` → seal 快照 + old_board_score；`open` → open 快照；`reseal/reseal_realtime` → reseal 快照
- 情绪分数值（`first_seal_sentiment_score` 等）：来自 `score_snapshots` archive 反序列化
- 所有快照依赖 board_score 输入体系

### 初步审计使用限制

```text
评分输入表和评分结果表必须分开设计。
不得把 volume.py placeholder 当最终算法。
本审计结论是方向性参考，不能替代逐函数代码复核。
```

## 10. v2 量能分数据设计提醒

### 关键区分

```
"分钟 K 线接口未参与量能分" ≠ "量能分不需要盘中量价数据"
```

v2 不能只保存 `volume_score` 结果，必须先设计量能评分输入数据。

### v2 建库前必须明确

1. **是否持久化 `quote_samples` 表**。旧系统 `quote_window` 是内存 `deque`，重启后丢失。v2 评分如果需要跨窗口期，必须持久化。

2. **quote window 保留多长时间**。旧系统通过 `runtime.quote_window_seconds` 控制窗口大小。v2 需要确定保留策略。

3. **quote sample schema 设计**。每个样本至少包含以下字段，并带时间口径：

   ```
   requested_trading_date
   source_trading_date
   as_of（数据提取时间）
   seq（同一 entity 的多版本序号）
   freshness_status（fresh / stale / mismatch / no_data）
   ```

4. **quote window 隔离策略**。以下场景必须清理或隔离窗口：

   - 非交易时间（盘前、盘后）
   - 跨交易日切换
   - 停牌恢复

### 当前阶段

**本次审计未建表、未新增 API、未写代码。** 以上是初步审计结论，待逐函数复核后进入 v2 建库决策。

### 2026-05-10 实测修正

- `quote_batch`（eastmoney 实时报价）验证：可用字段只限 `code/price/change_pct/amount/volume`，不可靠字段：`bid_vol1/ask_vol1`（为空），封板/盘口字段缺失。
- `quote_batch` 的 `change_pct` 不能推断 `is_sealed`。必须从 `limit_pool` 的 seal_amount 或独立 provider 获取封板状态。
- `limit_pool` 已验证可从 `EastmoneyLimitPoolProvider.snapshot()` 获取 100+ 行实时涨停/炸板数据。
- `speed_rank` 已验证可从 `EastmoneyRankProvider.speed_rank()` 获取 30 行实时涨速数据，字段已标准化。

## 11. 评分实现前代码复核清单

> 实现评分相关功能时，必须先逐函数复核以下旧代码，确认审计方向的正确性。

### 技术分

- `astock_guard/alerts.py`
- `astock_guard/strategies/engine.py`
- `astock_guard/strategies/builtin.py`
- `astock_guard/providers/history.py`
- `astock_guard/providers/ths_kline.py`

### 量能分

- `astock_guard/engine/scoring/volume.py`
- `astock_guard/alerts.py` 中 quote_window、strategy metrics、stock_meta 使用处

### 板块情绪分

- `astock_guard/alerts.py` 中 `_board_score`、`_sentiment_score`、`_board_external_adjustments`
- `astock_guard/providers/stock_boards.py`
- `astock_guard/providers/em_board_members.py`
- `astock_guard/providers/ths_board.py`
- `astock_guard/providers/limit_pool.py`
- `astock_guard/providers/fund_flow.py`
- `astock_guard/providers/intraday.py`

### 涨停池评分

- `astock_guard/limit_pool_scoring.py`
- `astock_guard/providers/limit_pool.py`
- `astock_guard/alerts.py` 中 `evaluate_stock_score`

### 情绪快照

- `_board_score_stage_snapshot`
- `_record_score_snapshot`
- `_score_snapshot_to_state`

### 量能分易错点

```
"分钟 K 线接口未直接参与量能分" ≠ "量能分不需要盘中量价序列"
```

量能分依赖 `quote_window` / 实时报价样本形成的盘中连续量价数据。v2 不能只保存 `volume_score` 结果，必须在实现前确认 `quote_samples / quote_window` 设计。
