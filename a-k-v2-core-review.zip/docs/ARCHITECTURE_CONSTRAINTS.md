# A Stock Guard v2 架构约束

## 1. 五条链路必须分离

```
1. 监控生命周期链路
   PRE_CANDIDATE → CANDIDATE → CORE → REJECTED_TODAY
   不处理飞书通知，不处理同花顺加自选。
   已实现 domain 层：backend/app/domain/monitoring_lifecycle.py

2. 评分与快照链路
   技术分、实时情绪分、量能分、trigger/seal/open/reseal 快照。
   评分结果独立存储，不混入生命周期表。
   已实现骨架：backend/app/domain/scoring/*
   注意：volume.py 是 placeholder，不能当最终算法。
   旧系统量能分依赖 quote_window（盘中量价序列：amount/volume/change_pct/amount_delta/volume_delta/monotonic_ratio/drawdown）、日 K 派生 metrics（amount_ratio20/amount_std20）、stock_meta（float_share/float_mv）。
   "分钟 K 线接口未参与量能分"不等于"量能分不需要盘中量价数据"。
   v2 必须明确 quote_samples 持久化策略后再实现量能评分。

3. 飞书通知门禁链路
   BUYABLE / WARNING / INFO / SUPPRESSED
   不改变生命周期阶段。
   已实现 domain 层：backend/app/domain/notification_gate.py

4. 同花顺加自选链路
   独立外部动作，不改变生命周期，不发送飞书通知。
   已实现 domain 模型：backend/app/domain/external_actions.py
   未实现 provider。

5. 数据时间一致性链路
   所有时变数据必须带时间口径。
```

### 链路依赖关系

```
评分 → 生命周期（评分结果作为 CORE 门禁输入）
评分 → 通知门禁（评分结果作为通知阈值判断）
生命周期 ↛ 通知（CORE 不等于通知）
同花顺加自选 ↛ 生命周期（不改变阶段）
同花顺加自选 → 通知豁免（已加自选可降低通知阈值）
时间 → 全部（每个链路必须验证数据时间一致性）
```

## 2. 核心监控股（CORE）定义

```text
CORE 是内部监控状态，不等于飞书通知。
CORE 不是粘死状态。封板炸开后必须允许回退到 CANDIDATE。
ST 过滤固定不可关闭。
CORE 门槛可配置（是否要求封板、技术分、情绪分、量能分、板块强度等）。
通知门禁必须独立于生命周期。
```

### candidate_removed

```text
candidate_removed 不是第五个生命周期阶段。
candidate_removed 不等于 REJECTED_TODAY。
candidate_removed 表示"候选弱势移除 / 临时停止主动监控"。
```

v2 表达：

```text
stage = PRE_CANDIDATE
active_monitoring = false
inactive_reason = candidate_weak_removed
inactive_at = as_of
```

重新进入 CORE/CANDIDATE 时清空 inactive 信息。

### 已知旧库偏差

```text
score_snapshots.stage 不能直接等同生命周期 stage。
603050 样本：score_snapshots 有 candidate/seal/open_board，但最终不是 CORE。
```

## 3. 时间口径约束

所有时变数据必须考虑：

| 字段 | 说明 |
|---|---|
| requested_trading_date | 查询方期望的交易日 |
| source_trading_date | 上游数据标识的交易日 |
| as_of | 数据提取/计算时间 |
| source_updated_at | 上游数据更新时间 |
| freshness_status | fresh / stale / mismatch / no_data |
| seq | 同一 entity 的多版本序号 |

### 防误判规则

```text
非交易时间（盘前、盘后、周末、节假日、停牌）上游可能返回上一交易日数据。
source_trading_date != requested_trading_date 时：
  - 不得触发 CORE 提升
  - 不得发送飞书通知
  - 不得触发同花顺加自选
前端展示必须标记 stale / mismatch。
```

## 4. 内存隔离约束

```text
runtime 内存结构必须按 (trade_date, code) 隔离，不能只用 code 作为 key。
每个交易日独立状态，切换交易日时必须清理或归档旧状态。
```

## 5. REST / WebSocket 分工

```text
REST API 提供 snapshot 查询。
WebSocket 后续只推 delta（增量更新），不做全量同步。
WebSocket 必须在数据库层稳定后才能引入。
```

## 6. 配置版本化

```text
门禁配置必须版本化，每次变更记录版本号和变更时间。
gate_config_versions 表记录所有配置变更历史。
```

## 7. 候选表/API 提醒

> 以下候选基线来自 `docs/API_DATA_BASELINE.md`。不是建表命令。

```text
评分来源初步审计结论不能直接用于建表或实现评分。
实现评分前必须逐函数复核旧代码（复核清单见 docs/API_DATA_BASELINE.md §11）。
评分输入表和评分结果表必须分开设计。
新增 API 前必须先写清：读哪些表、写哪些表、读哪些内存、是否调 provider。
WebSocket 第一阶段不做。
```

旧系统 API / 表 / 内存状态事实见 `docs/API_DATA_BASELINE.md`。
