# A Stock Guard v2 下一步任务

## 当前状态

```
✅ 扫描循环: speed_rank + shortline + limit_pool → lifecycle
✅ 盘口封板: Tencent(主) + 新浪(备) → CORE
✅ 去重逻辑: per-event + per-stock + daily reset
✅ 评分管线: LegacyFullScoringExecutor (dev: StaticExecutor)
✅ 前端展示: v2_shadow 真实数据
✅ 文件规范: 全部 ≤ 300 行
```

## 下一步: 阶段 3 — 通知 + 自选

```text
1. 飞书通知桥接
   domain/notification_gate.py 已完成 (271行纯函数)
   需要: FeishuNotifier provider → 发送交互卡片

2. 同花顺自选桥接
   domain/external_actions.py 已完成 (模型)
   需要: ThsSelfStockProvider → 加自选

3. 通知触发条件
   CORE 确认后 → 评分通过阈值 → 飞书通知
   每股票限频 (60s内最多4条)
   全局限频 (1s间隔)
```

## 后续: 阶段 4 — 完善

```text
1. LegacyFullScoringExecutor 切换为生产默认 (而非 Static)
2. quote_samples 采集管道上线 (量能分)
3. WebSocket 真实推送
4. 交易时段端到端验证
```

## 暂停

```text
前端涨停炸板池、涨速榜、涨幅榜、板块动向页面
```
