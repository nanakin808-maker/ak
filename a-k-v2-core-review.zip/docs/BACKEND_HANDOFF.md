# A Stock Guard v2 后端交接文档

## 1. 后端目标

v2 后端建立正式分层架构。旧系统只允许作为 legacy adapter 来源。

禁止：直接复制旧 server.py / alerts.py，在 services 层堆旧字段兼容逻辑，单文件膨胀。

## 2. 当前后端目录

```text
backend/app/
  api/routes/       -> 请求响应和路由
  schemas/          -> API 出入参模型
  services/         -> v2 业务编排
  domain/           -> 纯业务规则（不依赖 FastAPI/adapters/provider/网络）
  adapters/legacy/  -> 旧系统 HTTP 桥接和字段提取
  mocks/            -> 开发 fallback 数据
```

## 3. 当前已实现 API

| API | 文件 | 说明 |
|---|---|---|
| GET /api/health | routes/health.py | 健康检查 |
| GET /api/opportunities | routes/opportunities.py | 机会队列（桥接旧 /api/alerts/state） |
| GET /api/events/realtime | routes/events.py | 实时事件流 |
| GET /api/engine/status | routes/engine.py | 引擎状态 |
| POST /api/engine/start | routes/engine.py | 启动引擎 |
| POST /api/engine/stop | routes/engine.py | 停止引擎 |
| POST /api/engine/reset | routes/engine.py | 重置引擎 |
| GET /api/limit-pool | routes/limit_pool.py | 涨停炸板池 |
| GET /api/speed-rank | routes/speed_rank.py | 涨速榜 |
| GET /api/boards | routes/boards.py | 板块动向 |

行为：配置旧接口 URL 时尝试桥接，失败或为空则回退 mock。环境变量见 `backend/.env.example`。

## 4. 当前 schema 文件

| 文件 | 内容 |
|---|---|
| schemas/opportunity.py | CandidateSummary / OpportunitiesResponse / HealthResponse |
| schemas/event.py | MonitorEvent / EventsResponse |
| schemas/score.py | ScoreRule / CandidateScoreDetails |
| schemas/engine.py | EngineState / EngineResponse |
| schemas/limit_pool.py | LimitPoolItem / LimitPoolResponse |
| schemas/speed_rank.py | SpeedRankItem / SpeedRankResponse |
| schemas/board.py | BoardItem / BoardResponse |

新增 schema 时按业务域拆文件，不塞回 opportunity.py。

## 5. 当前 domain 层

### 核心模型

```text
domain/events.py      -> EventType / EventSource / StockEvent
domain/stocks.py      -> StockSnapshot / BoardSnapshot
domain/scores.py      -> ScoreType / ScoreRuleResult / ScoreResult / StockScoreBundle
domain/decisions.py   -> CandidateStage / DecisionAction / CandidateState / OpportunityDecision
domain/snapshots.py   -> 快照模型
```

### 评分引擎骨架

```text
domain/scoring/common.py        -> 公共结构
domain/scoring/signals.py       -> 信号
domain/scoring/technical.py     -> score_technical() — 骨架
domain/scoring/sentiment.py     -> score_sentiment() — 骨架
domain/scoring/volume.py        -> score_volume() — PLACEHOLDER，不能当最终算法
domain/scoring/seal_snapshot.py -> score_seal_snapshot() — 骨架
```

旧系统量能分是 5 分量实时窗口算法，依赖 `quote_window`（内存 deque，盘中连续量价样本）和日 K 派生 metrics。评分来源初步审计完成后，所有评分模块仍标记为骨架。初步审计结论不能直接用于实现，实现评分前必须先逐函数复核旧代码（复核清单见 docs/API_DATA_BASELINE.md §11）。

量能分输入说明：
- 核心实时字段：`amount`, `volume`, `change_pct`, `amount_delta`, `volume_delta`, `change_pct_delta`, `monotonic_ratio`, `drawdown`
- quote_window：内存 deque，按 `quote_window_seconds` 过期，不持久化
- 间接日 K 依赖：`amount_ratio20`, `amount_std20`（来自技术分 metrics）
- 流通股本依赖：`stock_meta.float_share`, `stock_meta.float_market_value`

**注意**："分钟 K 线接口未参与量能分"不等于"量能分不需要盘中量价数据"。v2 不能只保存 `volume_score` 结果，必须先设计量能评分输入数据。

### 门禁与决策引擎（domain 层）

| 文件 | 说明 | 状态 |
|---|---|---|
| domain/gates.py | 可配置门禁模型（ST/Candidate/Core/Notification/SelfStock） | 已完成模型 |
| domain/monitoring_lifecycle.py | 生命周期迁移（PRE_CANDIDATE/CANDIDATE/CORE/REJECTED_TODAY） | 已完成 |
| domain/notification_gate.py | 飞书通知门禁（BUYABLE/WARNING/SUPPRESSED） | 已完成 |
| domain/external_actions.py | 同花顺加自选 domain 模型 | 仅模型，无 provider |

核心约束：

```text
CORE 不等于飞书通知
ST 过滤固定不可关闭
同花顺自选不改变生命周期
通知门禁不处理生命周期迁移
domain 层不调用 provider/adapters/FastAPI
```

## 6. 当前 adapters/legacy

| 文件 | 职责 |
|---|---|
| http_client.py | 统一旧接口 HTTP 请求（fetch_legacy_json） |
| parsing.py | 统一字段解析（as_text/as_float/as_int/nested/pick_*/extract_dict_rows） |
| common_fields.py | 公共字段提取（primary_board/board_change_pct） |
| alerts_state.py | 旧 /api/alerts/state 桥接 |
| engine_client.py | 旧引擎控制桥接 |
| limit_pool.py | 旧涨停池桥接 |
| speed_rank.py | 旧涨速榜桥接 |
| boards.py | 旧板块动向桥接 |

所有 adapter 统一使用 parsing.py 和 common_fields.py，不再本地定义重复工具函数。

## 7. 当前 mocks

```text
mocks/opportunities.py
mocks/events.py
mocks/limit_pool.py
mocks/speed_rank.py
mocks/boards.py
```

services 层不再承载 mock 数据。新增模块 mock 必须放在 mocks/。

## 8. 验证命令

```bash
cd ~/Documents/Codex/2026-04-26/a-k-v2
python3 scripts/verify_v2_stack.py
```

检查：文件大小、Python compileall、前端 typecheck、FastAPI 路由存在性（10 条路由）、API 契约 smoke test。

API 契约 smoke test 文件：`scripts/smoke_api_contracts.py`（使用 FastAPI TestClient，需要 httpx）。

后续新增 API 时必须同步更新 `scripts/verify_v2_stack.py` 和 `scripts/smoke_api_contracts.py`。

## 9. runtime skeleton

### 当前状态

```text
RuntimeState / EventProcessor / RuntimeRestoreService 已完成最小骨架。
验证了：event -> time_scope -> repository -> DB -> runtime hot cache 通道。

EventProcessor 当前只是通道骨架，不是最终旧业务生命周期实现。
其中 fresh LIMIT_UP_SEALED -> CORE 只能作为通道 smoke，不得当作最终业务规则。

不要继续基于 EventProcessor mock 扩展业务。
真正业务迁移前，必须先读取旧代码分支，再用旧库样本验证。
```

### candidate_removed 语义（已落地）

```text
candidate_removed 不是第五个生命周期阶段。
candidate_removed 不等于 REJECTED_TODAY。
candidate_removed 表示"候选弱势移除 / 临时停止主动监控"。
```

v2 当前表达：

```text
monitoring_stock_states.stage = PRE_CANDIDATE
monitoring_stock_states.active_monitoring = false
monitoring_stock_states.inactive_reason = candidate_weak_removed
monitoring_stock_states.inactive_at = as_of

monitoring_events.event_type = CANDIDATE_REMOVED
monitoring_state_transitions: CANDIDATE -> PRE_CANDIDATE
score_snapshots.score_stage = candidate_removed
score_snapshots.reject_reason = 候选弱势移除
```

重新进入主动监控 / CORE / CANDIDATE 时，必须 `active_monitoring=true` 并清空 `inactive_reason / inactive_at`。RuntimeRestoreService 必须恢复 `active_monitoring / inactive_reason / inactive_at`，不能默认重新激活。

## 10. 真实外部源 shadow 状态（2026-05-10 实测）

### limit_pool

```text
调用 EastmoneyLimitPoolProvider.snapshot() 成功。
115 行，fresh，383ms。已可写 v2 limit_pool_snapshots + limit_pool_rows。
不得直接触发生命周期。只作为 source input。
```

### speed_rank

```text
调用 EastmoneyRankProvider.speed_rank() 成功。
30 行，字段映射已修正（f12→code, f14→name, f3→change_pct），339ms。
1 条进入 PRE_CANDIDATE，其余低于 5% 入口阈值。
只触发 PRE_CANDIDATE，不能直接 CORE。
```

### quote_batch

```text
调用 EastmoneyProvider.get_quotes() 成功。
price/change_pct 字段已标准化，343ms。
当前接口缺少可靠盘口/封板字段（bid_vol1/ask_vol1 为空）。
禁止用于 promote_core / seal 判断；只能用于 price/change_pct 更新。
```

### 触发禁止

```text
- 不得把 quote_batch 的 change_pct 或松散盘口字段推断为 is_sealed。
- quote_batch 在找到可靠 seal/open 数据源前，只能用于 price/change_pct 更新。
- limit_pool 只作为 source input，不直接触发生命周期。
- speed_rank/shortline 只触发 PRE_CANDIDATE，不能直接 CORE。
- 真实接口不能一次成功就 active，必须经过 shadow/candidate/active 分级。
- provider 失败不能默认达标。
```

## 11. 当前风险与下一工程入口

**风险**：

```text
domain/scoring/volume.py 是 placeholder，不能当最终算法；旧系统量能分依赖 quote_window（盘中量价序列）+ 日 K 派生 metrics，v2 设计 quote_samples 持久化前不能替代
评分来源初步审计已完成，但仅是方向性结论；实现评分前必须逐函数复核旧代码
EventProcessor 只是通道骨架，不是最终业务逻辑
WebSocket 未开始
同花顺 provider 未实现
```

**下一工程入口**：见 `docs/NEXT_STEPS.md`。

当前阶段不新增 API、不建表、不实现 provider/WebSocket、不继续扩展 EventProcessor 业务分支。

## 12. 外部源决策表 v2（2026-05-11）

详见 `reports/external_source_decision_table_draft.md`。关键结论：

### 1. quote/seal/orderbook 决策

```text
eastmoney quote_batch: 只用于 price/change_pct 更新。
  禁止用于 seal/open 判断（实测 bid_vol1/ask_vol1 为空）。

pytdx (通达信 TCP): seal/open 主源，有 bid1-5/ask1-5 字段。
  v2 直接使用 pytdx adapter，不经过 composite wrapper。

sina: orderbook 备源（有 bid1/ask1，无 bid_vol1）。
tencent/eastmoney: 纯价格备源，不用于 orderbook。
```

### 2. limit_pool 决策

```text
eastmoney_limit_pool + akshare (fallback): 主源双保险。
ths_limit_pool: 禁用（cookie 依赖 + 重复）。
composite wrapper: v2 不实现。

来源数据写入 limit_pool_source table，不直接触发生命周期。
```

### 3. Free API 策略

```text
BaoStock:  历史K线备源、交易日历主源。免费，无频率限制。
AKShare:   广度数据主源（stock_basic, board, fund_flow, limit_pool backup）。
efinance:  quote/kline 备源，不做唯一核心主源。
Tushare:   暂不作为当前免费主源（注册+积分门槛）。
PyTDX:     orderbook/seal-open 唯一主源。
Sina:      orderbook 备源。
Eastmoney: price/change_pct + speed_rank + limit_pool + fund_flow。
           不做 seal/open。
Tencent:   通用报价备源，不用于 orderbook。
```

### 4. scoring 源决策

```text
daily_kline: 保持现有 subprocess 方案
  (LegacyScoringFacadeExecutor)，不阻塞 lifecycle。考虑 BaoStock 备源。

intraday: eastmoney 主 → pytdx 备；ths 禁用。
board_mapping: ths_board (akshare) 主 → stock_board_summary (efinance) 备。
board_members: eastmoney_board_member 单源。
fund_flow: eastmoney_fund_flow 主 → akshare 备；5min cache TTL。
stock_meta: akshare 主 → baostock 备；6h cache TTL。

所有 scoring 源 → ScoreWorker/LegacyScoringFacadeExecutor，不阻塞 lifecycle。
```

### 5. 外部动作决策（最后一阶段）

```text
feishu_notify: 最后一阶段接入。
ths_self_stock (同花顺加自选): 最后一阶段接入。
  必须在评分链路稳定 + 通知链路稳定后才实施。
```

### 6. M1 优先级

```text
Phase 1 (M1):
  1. stock_basic/ST          → akshare adapter
  2. calendar                → baostock primary + bitefu fallback
  3. Eastmoney speed_rank    → ExternalSourceAdapter
  4. Eastmoney/AKShare price → quote_price adapter (no seal/open)
  5. PyTDX orderbook         → pytdx adapter (seal/open)
  6. Eastmoney/AKShare limit_pool → source table writer

Phase 2 (scoring):
  7. daily_kline             → keep subprocess + add baostock
  8. board/fund_flow/intraday → adapters → ScoreWorker

Phase 3 (external actions):
  9. Feishu notify
  10. THS self-stock
```

### 7. 外部源验证 v1 结论 (2026-05-11) — Corrected

```text
验证脚本: scripts/validate_external_sources.py --runs 1 --market-session CLOSED
21 个候选源，10 OK，7 FAIL，3 dep missing，1 non_trading_unverified。

关键结论（注意：验证在 CLOSED 非交易时段执行）：
1. pytdx_quote: 3/3 timeout (>30s)，标记 non_trading_unverified。
   → 盘口接口可能在非交易时段关闭/限流。需要 TRADING 时段重新验证。
   不结论性判定为不可用。
2. sina_orderbook: 有 bid1/ask1（CLOSED 仍有数据），bid_vol1 为空。
   → 不满足 sealed 判断（缺 volume），但需 TRADING 时段确认。
3. eastmoney negative control: bid_vol1 为空（CLOSED 时段确认）。
   → 即使交易时段也可能为空。不能单独用于 seal/open。
4. eastmoney_quote / tencent_quote / sina_quote:
   → 均可用于 price/change_pct 更新（avg 200-320ms）。
5. eastmoney_limit_pool OK (432ms), akshare_limit_pool OK (781ms).
6. daily_kline: old subprocess OK (435ms), akshare OK (485ms previous),
   efinance 不稳定, baostock 未安装。
```

### 8. M1 策略调整

```text
由于 orderbook/seal-open 源未在 TRADING 时段验证，
M1 从"正式 source adapter 接入"改为"Realtime Dev v1 without CORE active"：

允许:
  event source → PRE_CANDIDATE
  quote price/change_pct 更新
  limit_pool source table 写入
  LegacyScoringFacadeExecutor technical scoring
  REST polling frontend

禁止:
  CORE promotion/demotion (直到 seal/open 在 TRADING 时段验证通过)
  Feishu notify
  THS self-stock
  新增 scoring 输入表
```

### 9. 禁用/重复源汇总

```text
ths_limit_pool       — eastmoney + akshare sufficient
ths_speed_rank       — eastmoney sufficient
ths_intraday         — eastmoney + pytdx sufficient
ths_kline (direct)   — via DailyHistoryProvider
composite_limit_pool — v2 单源
composite_intraday   — v2 直接 adapter
old CompositeProvider — v2 直接 pytdx + sina
efinance (as primary) — fallback only
Tushare (current)    — not free primary
pytdx_quote (current) — timeout, 不可用
```

