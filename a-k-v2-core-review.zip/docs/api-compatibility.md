# API Compatibility with v1 (old project)

## Mapping

| Old (v1) | New (v2) | Status |
|----------|----------|--------|
| `GET /api/settings` | `GET /api/v1/settings/` | placeholder |
| `GET /api/alerts/state` | `GET /api/v1/alerts/state` | placeholder |
| `POST /api/alerts/start` | `POST /api/v1/alerts/start` | placeholder |
| `POST /api/alerts/stop` | `POST /api/v1/alerts/stop` | placeholder |
| `POST /api/alerts/reset` | `POST /api/v1/alerts/reset` | placeholder |
| `GET /api/limit-pool` | `GET /api/v1/limit-pool/` | placeholder |
| `GET /api/limit-pool/dates` | `GET /api/v1/limit-pool/dates` | placeholder |
| `GET /api/ranks/speed` | `GET /api/v1/speed-rank/` | placeholder |
| `GET /api/strategies` | `GET /api/v1/strategies/` | placeholder |
| `GET /api/market/status` | `GET /api/v1/system/market/status` | placeholder |
| `GET /api/qwen/status` | `GET /api/v1/qwen/status` | placeholder |
| `WS /ws/alerts` | `WS /api/v1/ws/alerts` | placeholder |
| `GET /api/candidate-archive` | `GET /api/v1/candidates/` | renamed |
| `POST /api/start` | — | removed (dead) |
| `GET /api/speed-rank/health` | merged into `/settings/` | consolidated |

## Key Changes

1. All endpoints now prefixed with `/api/v1/`.
2. Dead legacy endpoint `/api/start` removed.
3. `candidate-archive` renamed to `candidates`.
4. Speed rank health merged into settings.
5. Route files organized by domain instead of flat.
