# A Stock Guard v2 前端交接文档

## 1. 技术栈

```text
Vue 3 + TypeScript + Element Plus + Vite
CSS Grid 自定义行情表
状态管理：Pinia + TanStack Query
```

项目位置：`frontend/`

## 2. 当前页面

主监控台：`/` 或 `/dashboard`

核心文件：

```text
frontend/src/features/dashboard/DashboardPage.vue
frontend/src/features/dashboard/OpportunityQueueTable.vue
frontend/src/features/dashboard/ScoreDetailPanel.vue
frontend/src/features/dashboard/ScoreCardTabs.vue
frontend/src/features/dashboard/ScoreRuleList.vue
frontend/src/features/dashboard/CompactEventFeed.vue
```

页面结构：

```text
AppLayout
  AppSidebar（左侧文字导航）
  AppTopbar（引擎控制栏）
  RouterView
    DashboardPage
      左侧：机会队列
      右侧上：评分详情 / 决策说明
      右侧下：实时事件流
```

## 3. 左侧导航

文件：`frontend/src/layouts/AppSidebar.vue`

导航项：机会总览、涨停炸板池、涨速榜、涨幅榜、板块动向、设置

约束：不要恢复导航图标，只保留文字导航，当前页高亮。

## 4. 顶部栏

文件：`frontend/src/layouts/AppTopbar.vue`

已接入引擎控制 API（status/start/stop/reset）。显示：引擎状态、行情状态、交易日、当前时间。

## 5. 机会队列表

文件：`frontend/src/features/dashboard/OpportunityQueueTable.vue`

约束：**不要改回 el-table**。当前使用 CSS Grid 自定义行情表，精确控制列宽和行情终端密度。

字段：代码、名称、最新价、涨幅、技术、情绪、封板、量能、状态、主板块。

## 6. 评分详情面板

文件：

```text
frontend/src/features/dashboard/ScoreDetailPanel.vue
frontend/src/features/dashboard/ScoreCardTabs.vue
frontend/src/features/dashboard/ScoreRuleList.vue
```

四个分数小卡片：技术分、实时情绪分、量能分、封板情绪分。

约束：点击哪个只显示哪个构成，不一次性展开全部。封板情绪分为空时显示 `--`。不用实时情绪覆盖封板情绪。

## 7. 前端数据层

```text
frontend/src/services/http.ts
frontend/src/services/opportunityApi.ts
frontend/src/services/engineApi.ts
frontend/src/composables/useOpportunityDashboard.ts
frontend/src/composables/useEngineControl.ts
```

当前调用：GET /api/opportunities, GET /api/events/realtime, GET/POST /api/engine/*

开发环境配置：`frontend/.env.development`（VITE_API_BASE_URL）

## 8. 暂停事项

以下前端页面暂停开发，等后端稳定后再做：

```text
涨停炸板池（仅保留占位页 LimitPoolPage.vue，不调 API、不展示表格）
涨速榜
涨幅榜
板块动向
```

不要继续新增 limitPoolApi.ts、useLimitPool.ts、LimitPoolTable.vue。不要在当前阶段继续新增前端页面。

## 9. 验证命令

```bash
cd ~/Documents/Codex/2026-04-26/a-k-v2/frontend
npm run typecheck
npm run dev
```

访问 `http://localhost:5173/dashboard`（端口占用时可能切到 5174）。
