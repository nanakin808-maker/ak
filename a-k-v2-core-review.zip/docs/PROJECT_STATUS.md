# A Stock Guard v2 项目状态

## 总览

```
框架层:     ✅ DB 16 张表 / Domain / Runtime / Service
事件采集:   ✅ 全部 v1 接口已接入 (pytdx/th/sina/tencent/eastmoney)
盘口封板:   ✅ composite_quote 4 层回退
生命周期:   ✅ PRE_CANDIDATE → CANDIDATE → CORE → open_board
评分管线:   ✅ v2 原生 LegacyFullScoringExecutor (不再依赖旧系统)
去重:       ✅ per-event + 9-field signature + daily reset
量能异动:   ✅ 5日均量百分比 (3条条件)
交易日识别: ✅ market_calendar (新浪指数探测)
前端:       ✅ REST + WebSocket (增量推送)
pytest:     ✅ 40 tests, 3 files
文件规范:   ✅ 全部 ≤ 300 行
通知/自选:  ⏳ 待阶段 3
```

## 事件源覆盖

| v1 源 | v2 源 | 方式 |
|-------|-------|------|
| pytdx TCP | `sources/pytdx_worker.py` | 子进程 |
| tencent HTTP | `sources/tencent_quote.py` | 原生 |
| sina HTTP | `sources/sina_orderbook.py` | 原生 |
| eastmoney HTTP | `sources/eastmoney_realtime.py` | 原生 |
| eastmoney speed_rank | `sources/scan_fetchers.py` | 原生 |
| eastmoney shortline | `sources/eastmoney_shortline.py` | 原生 |
| eastmoney limit_pool | `sources/scan_fetchers.py` | 原生 |
| THS speed_rank | `sources/ths_speed_rank.py` | 原生+cookie |
| eastmoney fund_flow | `sources/fund_flow.py` | 原生 |
| eastmoney stock_meta | `sources/stock_meta.py` | 原生 |
| eastmoney board_members | `sources/board_members.py` | 原生 |
| tencent daily_kline | `sources/daily_kline.py` | 原生 |
| tencent intraday | `sources/intraday_kline.py` | 原生 |
| tencent stock_boards | `sources/stock_boards.py` | 原生 |

## 评分触发点

| 事件 | 触发 | 评分内容 |
|------|------|---------|
| PRE_CANDIDATE → CANDIDATE | promote | technical + board + sentiment |
| CANDIDATE → CORE (seal) | process_quote | technical + board + sentiment |
| CORE → CANDIDATE (open) | process_quote | sentiment |
| limit_pool 签名变化 | 9-field sig check | technical + sentiment + volume |
| volume spike | 5日均量×3% | volume |
| board_members loaded | callback | sentiment |

## 评分去重

```
limit_pool: 9-field signature (pool|price|chg_pct|first_time|last_time|open_count|seal_amount|streak|reason)
  签名不变 → 跳过评分
  签名变化 → 触发评分 (新涨停/炸板/回封)
  key = code:pool (区分同 code 在不同池)
```

## pytest 状态

```
40 tests, 全部通过
├── test_pipeline_scan.py     10 tests  扫描流水线
├── test_scoring_pipeline.py   8 tests  评分管线
├── test_lifecycle.py          3 tests  生命周期
├── test_market_calendar.py   17 tests  交易日历
└── smoke_realtime_websocket   6 tests  WebSocket (scripts/)
```

## 未完成

```
⏳ 通知: 飞书 provider 桥接 (domain/notification_gate 已完成)
⏳ 自选: 同花顺 provider 桥接 (domain/external_actions 已完成)
⏳ WebSocket Step 2/3: 完整增量 delta + 可靠性
```

## 禁止

```
- 不修改 a-k/
- 不让单文件超 300 行
- 不用固定值做量能判断
- 不用 datetime.now() 获取交易日
- 不让 WebSocket 替代 REST
```
