# A Stock Guard v2 文档索引

## 1. 阅读顺序

不要全文扫文档。按任务选择。

### 默认必读

```text
CLAUDE.md
docs/README.md
docs/PROJECT_STATUS.md
```

### 按任务选读

| 任务 | 文档 |
|---|---|
| 后端开发 | `docs/BACKEND_HANDOFF.md` |
| 前端开发 | `docs/FRONTEND_HANDOFF.md` |
| 架构/约束 | `docs/ARCHITECTURE_CONSTRAINTS.md` |
| 旧系统 API/表/内存事实 | `docs/API_DATA_BASELINE.md` |
| 下一步任务 | `docs/NEXT_STEPS.md` |
| 历史交接总览 | `docs/HANDOFF_MONITOR_CONSOLE.md`（归档） |

## 2. 文档职责

| 文档 | 一句话定位 |
|---|---|
| `CLAUDE.md` | 全局规则、禁止项、当前阶段、文档入口 |
| `docs/README.md` | 本文档，纯索引 |
| `docs/PROJECT_STATUS.md` | 当前完成/未完成/风险一张表 |
| `docs/NEXT_STEPS.md` | 当前 1-3 个下一步任务 |
| `docs/ARCHITECTURE_CONSTRAINTS.md` | 稳定架构约束（链路分离、时间口径、分层） |
| `docs/API_DATA_BASELINE.md` | 旧系统 API/表/内存事实唯一来源 |
| `docs/BACKEND_HANDOFF.md` | 后端当前实现状态、模块索引、验证命令 |
| `docs/FRONTEND_HANDOFF.md` | 前端当前结构、组件、约束 |
| `docs/HANDOFF_MONITOR_CONSOLE.md` | 归档：监控台交接历史 |
