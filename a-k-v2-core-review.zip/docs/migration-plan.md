# Migration Plan

## Phase 1 (current): Project Skeleton

- Frontend: Vue 3 + TS + Vite + Element Plus, static page skeletons.
- Backend: FastAPI layered architecture, health check + placeholder endpoints.
- No business logic, no database connection, no data providers.
- Old project `a-k/` unchanged.

## Phase 2 (planned): Service Layer

- Implement provider interfaces for market data (Eastmoney, THS, TDX).
- Implement services: AlertService, LimitPoolService, SpeedRankService.
- Wire services to routes.
- Frontend starts calling live APIs.

## Phase 3 (planned): Feature Parity

- Migrate scoring logic (technical, sentiment, volume).
- Implement notification pipeline (Feishu).
- Implement self-stock automation.
- Frontend fully functional with live data.

## Phase 4 (planned): Cleanup

- Remove old `a-k/` directory.
- Documentation updates.
- CI/CD setup.

## Phase 5 (planned): Production

- Testing, monitoring, error handling.
- Docker deployment.
- Production configuration.
