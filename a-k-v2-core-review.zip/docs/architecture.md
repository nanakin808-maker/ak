# Architecture (v2)

## Directory Structure

```
a-k-v2/
├── backend/                  FastAPI application
│   ├── app/
│   │   ├── main.py           FastAPI app entry
│   │   ├── api/v1/           HTTP routes (v1)
│   │   ├── core/             Config, context, lifespan, responses
│   │   ├── schemas/          Pydantic models
│   │   ├── services/         Business logic orchestration
│   │   └── domain/           Domain models, repositories, providers (future)
│   └── pyproject.toml
├── frontend/                 Vue 3 SPA
│   ├── src/
│   │   ├── api/              HTTP & WebSocket clients
│   │   ├── components/       Reusable UI components
│   │   ├── features/         Page-level feature modules
│   │   ├── layouts/          App shell (sidebar, topbar)
│   │   ├── router/           Vue Router routes
│   │   ├── styles/           CSS tokens & main styles
│   │   └── types/            TypeScript interfaces
│   ├── index.html
│   └── package.json
└── docs/                     Architecture & migration docs
```

## Design Principles

1. **Separation of concerns** — routes handle HTTP, services handle business logic, schemas define data shapes.
2. **No huge files** — each module is focused and under 500 lines.
3. **Dark financial UI** — professional dashboard aesthetic with CSS custom properties.
4. **API versioned** — `/api/v1/` prefix for all endpoints.
5. **Type-safe** — TypeScript on the frontend, Pydantic on the backend.
