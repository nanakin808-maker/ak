import { api } from "./client"

export const qwenApi = {
  status: () => api.get<{ available: boolean; model: string }>("/qwen/status"),
  ask: (question: string) =>
    api.post<{ answer: string }>("/qwen/read-only", { question }),
}
