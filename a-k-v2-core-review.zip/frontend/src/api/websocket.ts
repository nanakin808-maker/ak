export function connectAlertsWs(
  onMessage: (data: unknown) => void,
): WebSocket {
  const protocol = location.protocol === "https:" ? "wss:" : "ws:"
  const ws = new WebSocket(`${protocol}//${location.host}/api/v1/ws/alerts`)

  ws.onmessage = (event: MessageEvent) => {
    try {
      onMessage(JSON.parse(event.data))
    } catch {
      /* ignore malformed */
    }
  }

  return ws
}
