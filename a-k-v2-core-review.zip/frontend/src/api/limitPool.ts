import { api } from "./client"
import type { LimitPoolResponse } from "@/types/limitPool"

export const limitPoolApi = {
  get: (date?: string, pool?: string, limit = 300) => {
    const params = new URLSearchParams()
    if (date) params.set("date", date)
    if (pool) params.set("pool", pool)
    params.set("limit", String(limit))
    return api.get<LimitPoolResponse>(`/limit-pool/?${params}`)
  },
  getDates: (limit = 20) => api.get<{ dates: string[] }>(`/limit-pool/dates?limit=${limit}`),
}
