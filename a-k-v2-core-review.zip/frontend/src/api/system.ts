import { api } from "./client"

export const systemApi = {
  getMarketStatus: () => api.get("/system/market/status"),
  restart: () => api.post("/system/restart"),
  getInterfaceHealth: () => api.get("/system/health/interfaces"),
}
