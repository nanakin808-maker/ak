import { api } from "./client"
import type { SettingsResponse } from "@/types/settings"

export const settingsApi = {
  get: () => api.get<SettingsResponse>("/settings/"),
  updateFeishu: (webhook: string, secret: string) =>
    api.post("/settings/feishu", { webhook, secret }),
  testFeishu: () => api.post("/settings/feishu/test"),
  updateThsCookie: (cookie: string) =>
    api.post("/settings/ths-cookie", { cookie }),
  updateNotification: (thresholds: Record<string, number>) =>
    api.post("/settings/notification", thresholds),
}
