import { api } from "./client"
import type { StrategyDefinition, SavedStrategy } from "@/types/strategy"

export const strategiesApi = {
  list: (enabledOnly = false) =>
    api.get<{ strategies: SavedStrategy[] }>(`/strategies/?enabled_only=${enabledOnly}`),
  definitions: () =>
    api.get<{ definitions: StrategyDefinition[] }>("/strategies/definitions"),
  create: (data: unknown) => api.post("/strategies/", data),
  update: (id: string, data: unknown) => api.patch(`/strategies/${id}`, data),
  delete: (id: string) => api.delete(`/strategies/${id}`),
}
