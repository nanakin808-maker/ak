import { api } from "./client"

export const speedRankApi = {
  get: (limit = 20) => api.get<{ rows: unknown[] }>(`/speed-rank/?limit=${limit}`),
}
