import { api } from "./client"
import type { AlertState, AlertControlResponse, AlertStartPayload } from "@/types/alerts"

export const alertsApi = {
  getState: () => api.get<AlertState>("/alerts/state"),
  start: (p: AlertStartPayload) => api.post<AlertControlResponse>("/alerts/start", p),
  stop: () => api.post<AlertControlResponse>("/alerts/stop"),
  reset: () => api.post<AlertControlResponse>("/alerts/reset"),
  scanOnce: () => api.post<AlertControlResponse>("/alerts/scan-once"),
}
