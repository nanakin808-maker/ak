<script setup lang="ts">
import { ref } from "vue"
import SectionCard from "@/components/common/SectionCard.vue"
import StatusBadge from "@/components/common/StatusBadge.vue"

const question = ref("")
const busy = ref(false)
</script>

<template>
  <div class="qwen-page">
    <SectionCard title="Qwen AI 分析">
      <template #actions>
        <StatusBadge label="Qwen" :active="false" />
      </template>
      <div class="qwen-input">
        <el-input
          v-model="question"
          type="textarea"
          :rows="3"
          placeholder="输入分析问题（例如：今天哪些涨停板有回封迹象？）"
        />
        <el-button type="primary" :loading="busy" style="margin-top: var(--space-md)">
          提问
        </el-button>
      </div>
      <div class="qwen-answer">
        <el-empty description="等待提问" :image-size="60" />
      </div>
    </SectionCard>
  </div>
</template>

<style scoped>
.qwen-page {
  display: flex;
  flex-direction: column;
  gap: var(--space-xl);
}
.qwen-input { margin-bottom: var(--space-xl); }
.qwen-answer {
  min-height: 200px;
  background: var(--bg-primary);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-md);
  padding: var(--space-xl);
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
