<script setup lang="ts">
import { computed, ref } from 'vue'
import { monitoringShadowApi } from '@/services/monitoringShadowApi'
import { useMonitoringShadowWs } from '@/composables/useMonitoringShadowWs'
import type {
  InterfaceHealthRecord, LimitPoolRow, LimitPoolSnapshot,
  ShadowOverview, ShadowScore, ShadowStock,
} from '@/types/monitoringShadow'

const overview = ref<ShadowOverview | null>(null)
const stocks = ref<ShadowStock[]>([])
const limitPoolSnapshot = ref<LimitPoolSnapshot | null>(null)
const limitPoolRows = ref<LimitPoolRow[]>([])
const scores = ref<ShadowScore[]>([])
const healthRecords = ref<InterfaceHealthRecord[]>([])
const loading = ref(true)
const error = ref<string | null>(null)
let initialLoadDone = false

async function fetchAll() {
  if (!initialLoadDone) loading.value = true
  error.value = null
  try {
    const [ov, st, lp, sc, ih] = await Promise.all([
      monitoringShadowApi.overview(), monitoringShadowApi.stocks(),
      monitoringShadowApi.limitPool(), monitoringShadowApi.scores(),
      monitoringShadowApi.interfaceHealth(100),
    ])
    overview.value = ov; stocks.value = st.stocks ?? []
    limitPoolSnapshot.value = lp.snapshot ?? null
    limitPoolRows.value = lp.rows ?? []; scores.value = sc.scores ?? []
    healthRecords.value = ih.records ?? []
    initialLoadDone = true
  } catch (e) { error.value = String(e) }
  finally { loading.value = false }
}

const wsTradingDate = computed(() => {
  return overview.value?.effectiveTradingDate?.replace(/-/g, '') || '20260512'
})

const { wsState, wsLastSeq, wsLastMsgAt } = useMonitoringShadowWs(
  wsTradingDate, stocks, scores, fetchAll,
)
fetchAll()

function fmt(v: number | null | undefined, digits = 2): string {
  if (v == null) return '--'
  return Number(v).toFixed(digits)
}

function pct(v: number | null | undefined): string {
  if (v == null) return '--'
  const sign = v >= 0 ? '+' : ''
  return `${sign}${Number(v).toFixed(2)}%`
}

function fmtTime(iso?: string): string {
  if (!iso) return '--'
  const m = iso.match(/T?(\d{2}:\d{2}:\d{2})/)
  return m ? m[1] : iso.slice(-8) || iso
}
</script>

<template>
  <div class="shadow-page">
    <!-- header -->
    <div class="shadow-header">
      <h2>Shadow 数据监控</h2>
      <div class="shadow-flags">
        <span class="flag flag-shadow">{{ overview?.effectiveTradingDate || '--' }}</span>
        <span class="flag" :class="overview?.isLiveTrading ? 'flag-ok' : 'flag-warn'">
          {{ overview?.marketSession || '--' }}
        </span>
        <span class="flag" :class="wsState === 'connected' ? 'flag-ok' : 'flag-warn'">
          WS: {{ wsState }}
        </span>
        <span class="flag flag-muted">seq={{ wsLastSeq }} | {{ wsLastMsgAt }}</span>
      </div>
      <div v-if="loading" class="shadow-loading">加载中…</div>
      <div v-if="overview?.warning" class="shadow-warning">{{ overview.warning }}</div>
    </div>

    <!-- overview counts -->
    <section v-if="overview" class="shadow-section">
      <h3>概览</h3>
      <div class="counts-grid">
        <div v-for="(cnt, key) in overview.counts" :key="key" class="count-card">
          <div class="count-value">{{ cnt }}</div>
          <div class="count-label">{{ key }}</div>
        </div>
      </div>
    </section>

    <!-- stocks table -->
    <section v-if="stocks.length" class="shadow-section">
      <h3>监控状态（{{ stocks.length }}）</h3>
      <table class="shadow-table">
        <thead>
          <tr>
            <th>代码</th><th>名称</th><th>stage</th><th>价格</th>
            <th>涨幅</th><th>封板</th><th>评分</th><th>得分</th>
            <th>入库时间</th><th>源</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="s in stocks" :key="s.code" :class="{ 'row-ws': (s as any)._source === 'ws' }">
            <td class="mono">{{ s.code }}</td>
            <td>{{ s.name }}</td>
            <td><span :class="'stage-' + s.stage.toLowerCase()">{{ s.stage }}</span></td>
            <td class="mono">{{ fmt(s.price, 2) }}</td>
            <td :class="(s.change_pct ?? 0) >= 0 ? 'up' : 'down'">{{ pct(s.change_pct) }}</td>
            <td>{{ s.is_sealed ? '封' : s.at_limit ? '触板' : '-' }}</td>
            <td>{{ s.latest_score_snapshot?.score_stage ?? '-' }}</td>
            <td class="mono">{{ s.latest_score_snapshot ? fmt(s.latest_score_snapshot.score, 1) : '--' }}</td>
            <td class="mono time-cell">{{ fmtTime((s as any).as_of) }}</td>
            <td class="source-cell">
              <span v-if="(s as any)._source === 'ws'" class="src-ws">WS</span>
              <span v-else class="src-db">DB</span>
            </td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- limit_pool -->
    <section v-if="limitPoolRows.length" class="shadow-section">
      <h3>涨停池（{{ limitPoolRows.length }} 行）</h3>
      <div class="shadow-meta" v-if="limitPoolSnapshot">
        snapshot_id={{ limitPoolSnapshot.id }} source={{ limitPoolSnapshot.source }}
        freshness={{ limitPoolSnapshot.freshness_status }}
        as_of={{ limitPoolSnapshot.as_of }}
      </div>
      <table class="shadow-table">
        <thead>
          <tr>
            <th>pool</th><th>代码</th><th>名称</th><th>价格</th><th>涨幅</th>
            <th>首封</th><th>炸板</th><th>封单</th><th>连板</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in limitPoolRows.slice(0, 50)" :key="r.code + r.pool">
            <td><span :class="'pool-' + r.pool">{{ r.pool }}</span></td>
            <td class="mono">{{ r.code }}</td>
            <td>{{ r.name }}</td>
            <td class="mono">{{ fmt(r.price, 2) }}</td>
            <td :class="(r.change_pct ?? 0) >= 0 ? 'up' : 'down'">{{ pct(r.change_pct) }}</td>
            <td class="mono">{{ r.first_limit_time ?? '--' }}</td>
            <td>{{ r.open_count != null ? r.open_count : '-' }}</td>
            <td class="mono">{{ r.seal_amount != null ? fmt(r.seal_amount / 100_000_000, 2) + '亿' : '--' }}</td>
            <td>{{ r.streak ?? '-' }}</td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- scores -->
    <section v-if="scores.length" class="shadow-section">
      <h3>评分快照（{{ scores.length }}）</h3>
      <table class="shadow-table">
        <thead>
          <tr>
            <th>时间</th><th>代码</th><th>名称</th><th>stage</th><th>总分</th>
            <th>技术</th><th>情绪</th><th>量能</th><th>源</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="s in scores.slice(0, 50)" :key="s.code + s.score_stage + (s as any).as_of">
            <td class="mono time-cell">{{ fmtTime((s as any).as_of) }}</td>
            <td class="mono">{{ s.code }}</td>
            <td>{{ s.name }}</td>
            <td>{{ s.score_stage }}</td>
            <td class="mono">{{ fmt(s.score, 1) }}</td>
            <td class="mono">{{ fmt(s.technical_score, 1) }}</td>
            <td class="mono">{{ fmt(s.sentiment_score, 1) }}</td>
            <td class="mono">{{ fmt(s.volume_score, 1) }}</td>
            <td class="source-cell">
              <span v-if="(s as any)._source === 'ws'" class="src-ws">WS</span>
              <span v-else class="src-db">DB</span>
            </td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- interface health -->
    <section v-if="healthRecords.length" class="shadow-section">
      <h3>接口健康（{{ healthRecords.length }}）</h3>
      <table class="shadow-table">
        <thead>
          <tr><th>名称</th><th>类别</th><th>状态</th><th>耗时 ms</th><th>错误</th></tr>
        </thead>
        <tbody>
          <tr v-for="h in healthRecords" :key="h.name + h.timestamp">
            <td>{{ h.name }}</td>
            <td>{{ h.category }}</td>
            <td>{{ h.ok ? 'OK' : 'FAIL' }}</td>
            <td class="mono">{{ h.latency_ms != null ? h.latency_ms.toFixed(1) : '--' }}</td>
            <td class="error-text">{{ h.error || '' }}</td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- status box -->
    <div class="shadow-disclaimer">
      <p><strong>数据说明</strong></p>
      <ul>
        <li><b>DB</b> = REST 快照（SQLite 读取） | <b>WS</b> = WebSocket 增量推送（内存合并）</li>
        <li>入库时间 = as_of 字段，数据写入 shadow DB 的时间</li>
        <li>排序：按入库时间倒序，最新数据在最上面</li>
        <li>封板判断：Tencent bid1==涨停价 && bid_vol1>0</li>
        <li>断线自动重连 + REST 重载兜底</li>
      </ul>
    </div>
  </div>
</template>

<style scoped>
.shadow-page { padding: 20px; color: var(--ag-text); }
.shadow-header { margin-bottom: 20px; }
.shadow-header h2 { margin: 0 0 8px; }
.shadow-flags { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px; }
.flag { padding: 2px 10px; border-radius: 8px; font-size: 12px; font-family: var(--ag-font-mono); }
.flag-shadow { background: rgba(79,140,255,0.2); color: #8ab4f8; }
.flag-mock { background: rgba(255,170,60,0.2); color: #fabe2c; }
.flag-ok { background: rgba(80,220,100,0.18); color: #6ee; }
.flag-muted { background: rgba(148,163,184,0.15); color: var(--ag-text-muted); }
.flag-warn { background: rgba(255,80,80,0.15); color: #f88; }
.shadow-loading { color: var(--ag-text-muted); font-size: 14px; }
.shadow-warning { color: #f88; font-size: 14px; }
.shadow-section { margin-bottom: 24px; }
.shadow-section h3 { margin: 0 0 8px; font-size: 15px; }
.shadow-meta { font-size: 12px; color: var(--ag-text-muted); margin-bottom: 6px; font-family: var(--ag-font-mono); }
.counts-grid { display: flex; flex-wrap: wrap; gap: 8px; }
.count-card { min-width: 80px; padding: 10px 14px; border: 1px solid var(--ag-border); border-radius: 10px; background: rgba(255,255,255,0.04); }
.count-value { font-size: 20px; font-weight: 700; font-family: var(--ag-font-mono); }
.count-label { font-size: 11px; color: var(--ag-text-muted); margin-top: 2px; }
.shadow-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.shadow-table th, .shadow-table td { padding: 5px 8px; border-bottom: 1px solid var(--ag-border); text-align: left; white-space: nowrap; }
.shadow-table th { color: var(--ag-text-muted); font-size: 12px; }
.mono { font-family: var(--ag-font-mono); }
.up { color: var(--ag-red); }
.down { color: var(--ag-green); }
.error-text { color: var(--ag-text-faint); font-size: 12px; max-width: 200px; overflow: hidden; text-overflow: ellipsis; }
.stage-pre_candidate { color: #8ab4f8; }
.stage-rejected_today { color: #f88; }
.stage-candidate { color: #fabe2c; }
.stage-core { color: #4caf50; }
.pool-limit_up { color: var(--ag-red); }
.pool-open_board { color: var(--ag-text-muted); }
.shadow-disclaimer { margin-top: 20px; padding: 12px 16px; border: 1px solid rgba(255,80,80,0.3); border-radius: 10px; background: rgba(255,80,80,0.06); font-size: 13px; line-height: 1.6; }
.shadow-disclaimer ul { margin: 6px 0 0; padding-left: 18px; }
.shadow-disclaimer li { margin-bottom: 3px; }
.time-cell { font-size: 11px; color: var(--ag-text-muted); }
.source-cell { text-align: center; }
.src-db { font-size: 10px; padding: 1px 5px; border-radius: 4px; background: rgba(148,163,184,0.15); color: var(--ag-text-muted); }
.src-ws { font-size: 10px; padding: 1px 5px; border-radius: 4px; background: rgba(80,220,100,0.15); color: #6ee; }
.row-ws { background: rgba(80,220,100,0.04); }
</style>
