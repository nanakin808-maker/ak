<script setup lang="ts">
import SectionCard from "@/components/common/SectionCard.vue"
</script>

<template>
  <div class="candidates-page">
    <div class="toolbar">
      <el-radio-group model-value="all" size="small">
        <el-radio-button value="all">全部</el-radio-button>
        <el-radio-button value="pre_candidate">预备</el-radio-button>
        <el-radio-button value="candidate">候选</el-radio-button>
        <el-radio-button value="core">核心</el-radio-button>
      </el-radio-group>
      <el-input
        placeholder="搜索代码或名称…"
        size="small"
        style="width: 200px"
        clearable
      />
    </div>

    <SectionCard title="候选股列表">
      <el-empty description="暂无数据" :image-size="80" />
    </SectionCard>
  </div>
</template>

<style scoped>
.candidates-page {
  display: flex;
  flex-direction: column;
  gap: var(--space-xl);
}
.toolbar {
  display: flex;
  align-items: center;
  gap: var(--space-lg);
}
</style>
