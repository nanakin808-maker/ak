<script setup lang="ts">
import type { ScoreCard, ScorePanelId } from '../../mocks/scoreDetail'

defineProps<{
  cards: ScoreCard[]
  activeId: ScorePanelId
}>()

const emit = defineEmits<{
  'update:activeId': [value: ScorePanelId]
}>()

function scoreText(value: number | null) {
  return value === null ? '--' : String(value)
}

function cardClass(item: ScoreCard, activeId: ScorePanelId) {
  return [
    `score-card--${item.tone}`,
    { 'score-card--active': activeId === item.id }
  ]
}
</script>

<template>
  <div class="score-card-grid">
    <button
      v-for="item in cards"
      :key="item.id"
      class="score-card"
      :class="cardClass(item, activeId)"
      @click="emit('update:activeId', item.id)"
    >
      <span>{{ item.title }}</span>
      <strong>{{ scoreText(item.value) }}</strong>
    </button>
  </div>
</template>

<style scoped>
.score-card-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 7px;
  margin-bottom: 10px;
}

.score-card {
  height: 54px;
  padding: 6px 4px;
  border: 1px solid var(--tone-border);
  border-radius: 11px;
  color: var(--ag-text-soft);
  background:
    radial-gradient(circle at 80% 0%, var(--tone-soft), transparent 55%),
    rgba(255, 255, 255, 0.035);
  cursor: pointer;
  transition: 0.16s ease;
}

.score-card span,
.score-card strong {
  display: block;
}

.score-card span {
  overflow: hidden;
  font-size: 11px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.score-card strong {
  margin-top: 4px;
  color: var(--tone);
  font-family: var(--ag-font-mono);
  font-size: 20px;
}

.score-card--active {
  border-color: var(--tone);
  box-shadow: 0 0 0 1px var(--tone-soft), 0 12px 24px rgba(0, 0, 0, 0.18);
}

.score-card--blue {
  --tone: var(--ag-blue);
  --tone-soft: var(--ag-blue-soft);
  --tone-border: rgba(79, 140, 255, 0.28);
}

.score-card--purple {
  --tone: var(--ag-purple);
  --tone-soft: var(--ag-purple-soft);
  --tone-border: rgba(155, 123, 255, 0.28);
}

.score-card--green {
  --tone: var(--ag-green);
  --tone-soft: var(--ag-green-soft);
  --tone-border: rgba(43, 212, 125, 0.28);
}

.score-card--red {
  --tone: var(--ag-red);
  --tone-soft: var(--ag-red-soft);
  --tone-border: rgba(255, 77, 95, 0.28);
}
</style>
