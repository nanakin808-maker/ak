<script setup lang="ts">
import type { ScoreDetail } from '../../mocks/scoreDetail'

defineProps<{
  detail: ScoreDetail
}>()
</script>

<template>
  <div class="score-detail">
    <div class="detail-head">
      <h3>{{ detail.title }}</h3>
      <p>{{ detail.subtitle }}</p>
    </div>

    <div class="rule-list">
      <div
        v-for="rule in detail.rules"
        :key="rule.label"
        class="rule-row"
      >
        <span>{{ rule.label }}</span>
        <strong :class="rule.delta >= 0 ? 'ag-up' : 'ag-down'">
          {{ rule.delta >= 0 ? '+' : '' }}{{ rule.delta }}
        </strong>
      </div>
    </div>
  </div>
</template>

<style scoped>
.score-detail {
  padding: 10px;
  border: 1px solid var(--ag-border);
  border-radius: var(--ag-radius-lg);
  background: rgba(255, 255, 255, 0.035);
}

.detail-head h3 {
  margin: 0;
  font-size: 14px;
}

.detail-head p {
  margin: 4px 0 8px;
  color: var(--ag-text-muted);
  font-size: 12px;
  line-height: 1.4;
}

.rule-list {
  display: flex;
  flex-direction: column;
}

.rule-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  padding: 6px 0;
  border-top: 1px solid var(--ag-border);
  color: var(--ag-text-soft);
  font-size: 12px;
}

.rule-row strong {
  font-family: var(--ag-font-mono);
}
</style>
