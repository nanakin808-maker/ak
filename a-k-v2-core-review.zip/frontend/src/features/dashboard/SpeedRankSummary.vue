<script setup lang="ts">
import SectionCard from '../../components/common/SectionCard.vue'
import StockChangeTag from '../../components/common/StockChangeTag.vue'
import { speedRankItems } from '../../mocks/dashboard'
</script>

<template>
  <SectionCard title="涨速榜摘要" subtitle="高频异动股票的观察窗口">
    <div class="speed-list">
      <article
        v-for="item in speedRankItems"
        :key="item.code"
        class="speed-item"
      >
        <div class="rank">#{{ item.rank }}</div>
        <div class="stock">
          <strong>{{ item.name }}</strong>
          <span>{{ item.code }} · {{ item.board }}</span>
        </div>
        <div class="change">
          <StockChangeTag :value="item.changePct" />
          <span>涨速 {{ item.speedPct.toFixed(2) }}%</span>
        </div>
        <div class="signal">{{ item.signal }}</div>
      </article>
    </div>
  </SectionCard>
</template>

<style scoped>
.speed-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.speed-item {
  display: grid;
  grid-template-columns: 52px minmax(0, 1fr) 128px 96px;
  align-items: center;
  gap: 12px;
  min-height: 58px;
  padding: 10px 12px;
  border: 1px solid var(--ag-border);
  border-radius: var(--ag-radius-md);
  background: rgba(255, 255, 255, 0.035);
}

.rank {
  color: var(--ag-orange);
  font-family: var(--ag-font-mono);
  font-weight: 800;
}

.stock {
  min-width: 0;
}

.stock strong,
.stock span {
  display: block;
}

.stock strong {
  color: var(--ag-text);
  font-size: 14px;
}

.stock span,
.change span {
  margin-top: 3px;
  color: var(--ag-text-muted);
  font-size: 12px;
}

.change {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}

.signal {
  color: var(--ag-text-soft);
  font-size: 13px;
  text-align: right;
}
</style>
