<script setup lang="ts">
import SectionCard from '../../components/common/SectionCard.vue'
import HealthIndicator from '../../components/common/HealthIndicator.vue'
import { healthItems } from '../../mocks/dashboard'
</script>

<template>
  <SectionCard title="系统健康摘要" subtitle="后端、连接和外部服务状态">
    <div class="health-list">
      <HealthIndicator
        v-for="item in healthItems"
        :key="item.name"
        :name="item.name"
        :status="item.status"
        :detail="item.detail"
        :latency="item.latency"
      />
    </div>
  </SectionCard>
</template>

<style scoped>
.health-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
</style>
