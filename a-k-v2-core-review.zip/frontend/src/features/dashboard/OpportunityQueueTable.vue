<script setup lang="ts">
import StockChangeTag from '../../components/common/StockChangeTag.vue'
import StatusBadge from '../../components/common/StatusBadge.vue'
import type { CandidateSummary, DecisionStage } from '../../mocks/dashboard'

defineProps<{
  rows: CandidateSummary[]
  selectedCode?: string
}>()

const emit = defineEmits<{
  'select-row': [row: CandidateSummary]
}>()

function stageLabel(stage: DecisionStage) {
  const labels: Record<DecisionStage, string> = {
    watch: '观察',
    candidate: '候选',
    core: '核心',
    rejected: '剔除'
  }
  return labels[stage]
}

function stageTone(stage: DecisionStage) {
  const tones: Record<DecisionStage, 'orange' | 'blue' | 'red' | 'green'> = {
    watch: 'orange',
    candidate: 'blue',
    core: 'red',
    rejected: 'green'
  }
  return tones[stage]
}

function scoreClass(score: number | null) {
  if (score === null) return 'score-mini--empty'
  if (score >= 85) return 'score-mini--hot'
  if (score >= 70) return 'score-mini--strong'
  if (score >= 55) return 'score-mini--watch'
  return 'score-mini--weak'
}

function scoreText(score: number | null) {
  return score === null ? '--' : String(score)
}
</script>

<template>
  <div class="queue-grid">
    <div class="queue-row queue-row--head">
      <span>代码</span>
      <span>名称</span>
      <span class="align-right">最新价</span>
      <span class="align-right">涨幅</span>
      <span class="align-center">技术</span>
      <span class="align-center">情绪</span>
      <span class="align-center">封板</span>
      <span class="align-center">量能</span>
      <span class="align-center">状态</span>
      <span>主板块</span>
    </div>

    <button
      v-for="row in rows"
      :key="row.code"
      class="queue-row queue-row--body"
      :class="{ 'queue-row--selected': row.code === selectedCode }"
      @click="emit('select-row', row)"
    >
      <span class="ag-mono code">{{ row.code }}</span>
      <span class="name">{{ row.name }}</span>
      <span class="ag-mono align-right price">{{ row.price.toFixed(2) }}</span>

      <span class="align-right">
        <StockChangeTag :value="row.changePct" />
      </span>

      <span class="align-center">
        <span class="score-mini" :class="scoreClass(row.technicalScore)">
          {{ scoreText(row.technicalScore) }}
        </span>
      </span>

      <span class="align-center">
        <span class="score-mini" :class="scoreClass(row.sentimentScore)">
          {{ scoreText(row.sentimentScore) }}
        </span>
      </span>

      <span class="align-center">
        <span class="score-mini" :class="scoreClass(row.firstSealSentimentScore)">
          {{ scoreText(row.firstSealSentimentScore) }}
        </span>
      </span>

      <span class="align-center">
        <span class="score-mini" :class="scoreClass(row.volumeScore)">
          {{ scoreText(row.volumeScore) }}
        </span>
      </span>

      <span class="align-center">
        <StatusBadge
          :label="stageLabel(row.decisionStage)"
          :tone="stageTone(row.decisionStage)"
        />
      </span>

      <span class="board-cell">
        <span class="board-name">{{ row.board }}</span>
        <StockChangeTag :value="row.boardChangePct" />
      </span>
    </button>
  </div>
</template>

<style scoped>
.queue-grid { width: 100%; min-width: 0; overflow: hidden; }
.queue-row {
  display: grid;
  grid-template-columns: 64px 86px 84px 76px 56px 56px 56px 56px 68px minmax(150px, 1fr);
  align-items: center;
  column-gap: 6px;
  min-height: 34px;
  padding: 0 10px;
  border: 0;
  border-bottom: 1px solid rgba(148, 163, 184, 0.12);
  color: var(--ag-text-soft);
  background: transparent;
  font-size: 12px;
  text-align: left;
}
.queue-row--head {
  min-height: 32px;
  border-bottom-color: rgba(148, 163, 184, 0.18);
  color: var(--ag-text-muted);
  background: rgba(255, 255, 255, 0.035);
  font-weight: 680;
}
.queue-row--body { width: 100%; cursor: pointer; transition: background 0.14s ease; }
.queue-row--body:hover { background: rgba(79, 140, 255, 0.07); }
.queue-row--selected {
  background: linear-gradient(90deg, rgba(79, 140, 255, 0.16), rgba(79, 140, 255, 0.05));
}
.queue-row > span {
  min-width: 0;
  overflow: hidden;
  padding: 0 3px;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.code, .price { color: var(--ag-text); }
.name { color: var(--ag-text-soft); font-weight: 650; }
.align-right { text-align: right; }
.align-center { text-align: center; }
.score-mini {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 32px;
  height: 19px;
  padding: 0 6px;
  border: 1px solid var(--tone-border);
  border-radius: 999px;
  color: var(--tone);
  background: var(--tone-soft);
  font-family: var(--ag-font-mono);
  font-size: 11px;
  font-weight: 720;
  line-height: 1;
}
.score-mini--hot { --tone: #ff5c6c; --tone-soft: rgba(255, 77, 95, 0.09); --tone-border: rgba(255, 77, 95, 0.16); }
.score-mini--strong { --tone: #ffbd4a; --tone-soft: rgba(255, 176, 32, 0.08); --tone-border: rgba(255, 176, 32, 0.15); }
.score-mini--watch { --tone: #66a1ff; --tone-soft: rgba(79, 140, 255, 0.08); --tone-border: rgba(79, 140, 255, 0.15); }
.score-mini--weak { --tone: #47dd93; --tone-soft: rgba(43, 212, 125, 0.08); --tone-border: rgba(43, 212, 125, 0.15); }
.score-mini--empty { --tone: var(--ag-text-faint); --tone-soft: rgba(148, 163, 184, 0.055); --tone-border: rgba(148, 163, 184, 0.1); }
.board-cell { display: inline-flex; align-items: center; gap: 8px; min-width: 0; }
.board-name { min-width: 4em; overflow: hidden; color: var(--ag-text-soft); text-overflow: ellipsis; white-space: nowrap; }
:deep(.status-badge) { height: 21px; padding: 0 8px; font-size: 11px; }
:deep(.stock-change) { font-size: 12px; }
</style>
