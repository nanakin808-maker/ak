<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import type { CandidateSummary } from '../../mocks/dashboard'
import { useOpportunityDashboard } from '../../composables/useOpportunityDashboard'
import CandidateSummaryTable from './CandidateSummaryTable.vue'
import CompactEventFeed from './CompactEventFeed.vue'
import ScoreDetailPanel from './ScoreDetailPanel.vue'

const opportunity = useOpportunityDashboard()
const selectedRow = ref<CandidateSummary | null>(null)

const selectedCode = computed(() => selectedRow.value?.code ?? '')

watch(
  () => opportunity.rows.value,
  (rows) => {
    const currentCode = selectedRow.value?.code
    const stillExists = rows.some((row) => row.code === currentCode)

    if (stillExists) return

    selectedRow.value = rows.find((row) => row.decisionStage === 'core')
      ?? rows[0]
      ?? null
  },
  { immediate: true }
)
</script>

<template>
  <div class="opportunity-page">
    <section class="opportunity-layout">
      <main class="left-column">
        <CandidateSummaryTable
          :rows="opportunity.rows.value"
          :selected-code="selectedCode"
          :source="opportunity.source.value"
          :loading="opportunity.loading.value"
          :error="opportunity.error.value"
          @select-row="selectedRow = $event"
        />
      </main>

      <aside class="right-column">
        <ScoreDetailPanel :stock="selectedRow" />
        <CompactEventFeed :events="opportunity.events.value" />
      </aside>
    </section>
  </div>
</template>

<style scoped>
.opportunity-page {
  width: 100%;
  min-width: 0;
}

.opportunity-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 330px;
  gap: 8px;
  align-items: start;
  width: 100%;
  min-width: 0;
}

.left-column,
.right-column {
  min-width: 0;
}

.left-column {
  overflow: hidden;
}

.right-column {
  display: grid;
  grid-template-rows: auto auto;
  gap: 8px;
  align-content: start;
  min-width: 0;
}

@media (min-width: 1680px) {
  .opportunity-layout {
    grid-template-columns: minmax(0, 1fr) 340px;
  }
}

@media (max-width: 1180px) {
  .opportunity-layout {
    grid-template-columns: 1fr;
  }
}
</style>
