<script setup lang="ts">
import MetricCard from '../../components/common/MetricCard.vue'
import { dashboardMetrics } from '../../mocks/dashboard'
</script>

<template>
  <div class="ag-grid ag-grid--metrics">
    <MetricCard
      v-for="item in dashboardMetrics"
      :key="item.title"
      :title="item.title"
      :value="item.value"
      :subtitle="item.subtitle"
      :delta="item.delta"
      :tone="item.tone"
    />
  </div>
</template>
