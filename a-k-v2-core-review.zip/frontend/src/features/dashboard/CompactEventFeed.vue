<script setup lang="ts">
import SectionCard from '../../components/common/SectionCard.vue'
import {
  recentMonitorEvents,
  type MonitorEvent
} from '../../mocks/scoreDetail'

withDefaults(defineProps<{
  events?: MonitorEvent[]
}>(), {
  events: () => recentMonitorEvents
})
</script>

<template>
  <SectionCard title="实时事件流" compact>
    <div class="event-list">
      <article
        v-for="item in events"
        :key="item.id"
        class="event-row"
        :class="`event-row--${item.tone}`"
      >
        <span class="event-dot" />
        <span class="event-time">{{ item.time }}</span>
        <span class="event-name">{{ item.name }}</span>
        <span class="event-tag">{{ item.event }}</span>
      </article>
    </div>
  </SectionCard>
</template>

<style scoped>
.event-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
  max-height: 210px;
  overflow: auto;
}

.event-row {
  display: grid;
  grid-template-columns: 8px 52px 62px minmax(0, 1fr);
  align-items: center;
  gap: 6px;
  min-height: 28px;
  padding: 5px 7px;
  border: 1px solid var(--ag-border);
  border-radius: var(--ag-radius-md);
  background: rgba(255, 255, 255, 0.03);
  font-size: 11px;
}

.event-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--tone);
  box-shadow: 0 0 10px var(--tone);
}

.event-time {
  color: var(--ag-text-muted);
  font-family: var(--ag-font-mono);
}

.event-name {
  overflow: hidden;
  color: var(--ag-text-soft);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.event-tag {
  color: var(--tone);
  font-weight: 720;
}

.event-row--red {
  --tone: var(--ag-red);
}

.event-row--orange {
  --tone: var(--ag-orange);
}

.event-row--green {
  --tone: var(--ag-green);
}

.event-row--blue {
  --tone: var(--ag-blue);
}

.event-row--purple {
  --tone: var(--ag-purple);
}
</style>
