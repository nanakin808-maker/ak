<script setup lang="ts">
import { computed } from 'vue'
import SectionCard from '../../components/common/SectionCard.vue'
import { candidateSummaries, type CandidateSummary } from '../../mocks/dashboard'
import OpportunityQueueTable from './OpportunityQueueTable.vue'

const props = withDefaults(defineProps<{
  rows?: CandidateSummary[]
  selectedCode?: string
  source?: 'api' | 'mock'
  loading?: boolean
  error?: string | null
}>(), {
  rows: () => candidateSummaries,
  selectedCode: '',
  source: 'mock',
  loading: false,
  error: null
})

const emit = defineEmits<{
  'select-row': [row: CandidateSummary]
}>()

const sourceRows = computed(() => props.rows)
const coreRows = computed(() => sourceRows.value.filter((row) => row.decisionStage === 'core'))
const candidateRows = computed(() => sourceRows.value.filter((row) => row.decisionStage !== 'core'))

const subtitle = computed(() => {
  if (props.loading) return '正在刷新机会队列'
  if (props.source === 'api') return '数据来源：/api/alerts/state'
  if (props.error) return `接口未连接，使用 mock 数据：${props.error}`
  return '核心候选与候选观察'
})
</script>

<template>
  <SectionCard title="机会队列" :subtitle="subtitle" compact>
    <div class="queue-block">
      <div class="queue-title queue-title--core">
        核心候选
        <span>{{ coreRows.length }}</span>
      </div>
      <OpportunityQueueTable
        :rows="coreRows"
        :selected-code="selectedCode"
        @select-row="emit('select-row', $event)"
      />
    </div>

    <div class="queue-block">
      <div class="queue-title queue-title--candidate">
        候选观察
        <span>{{ candidateRows.length }}</span>
      </div>
      <OpportunityQueueTable
        :rows="candidateRows"
        :selected-code="selectedCode"
        @select-row="emit('select-row', $event)"
      />
    </div>
  </SectionCard>
</template>

<style scoped>
.queue-block + .queue-block {
  margin-top: 12px;
}

.queue-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 8px;
  padding-left: 9px;
  border-left: 3px solid var(--tone);
  color: var(--ag-text);
  font-size: 14px;
  font-weight: 760;
}

.queue-title span {
  color: var(--ag-text-muted);
  font-family: var(--ag-font-mono);
  font-size: 12px;
}

.queue-title--core {
  --tone: var(--ag-red);
}

.queue-title--candidate {
  --tone: var(--ag-blue);
}

:deep(.section-card__header) {
  padding: 12px 12px 0;
}

:deep(.section-card__body) {
  padding: 12px;
}
</style>
