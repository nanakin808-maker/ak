<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import SectionCard from '../../components/common/SectionCard.vue'
import StockChangeTag from '../../components/common/StockChangeTag.vue'
import type { CandidateSummary, ScoreRule } from '../../mocks/dashboard'
import {
  scoreDetails,
  selectedStock,
  type ScoreCard,
  type ScoreDetail,
  type ScorePanelId
} from '../../mocks/scoreDetail'
import ScoreCardTabs from './ScoreCardTabs.vue'
import ScoreRuleList from './ScoreRuleList.vue'

const props = defineProps<{
  stock?: CandidateSummary | null
}>()

const activeId = ref<ScorePanelId>('technical')
const viewStock = computed(() => props.stock ?? null)

const stockCode = computed(() => viewStock.value?.code ?? selectedStock.code)
const stockName = computed(() => viewStock.value?.name ?? selectedStock.name)
const stockPrice = computed(() => viewStock.value?.price ?? selectedStock.price)
const stockChangePct = computed(() => viewStock.value?.changePct ?? selectedStock.changePct)

const stageText = computed(() => {
  const stage = viewStock.value?.decisionStage
  if (stage === 'core') return '核心候选'
  if (stage === 'candidate') return '候选观察'
  if (stage === 'watch') return '观察'
  if (stage === 'rejected') return '剔除'
  return selectedStock.decision
})

const cards = computed<ScoreCard[]>(() => {
  const stock = viewStock.value

  return [
    { id: 'technical', title: '技术分', value: stock?.technicalScore ?? 86, tone: 'blue' },
    { id: 'realtimeSentiment', title: '实时情绪分', value: stock?.sentimentScore ?? 91, tone: 'purple' },
    { id: 'volume', title: '量能分', value: stock?.volumeScore ?? 94, tone: 'green' },
    { id: 'sealSentiment', title: '封板情绪分', value: stock?.firstSealSentimentScore ?? null, tone: 'red' }
  ]
})

function fallbackDetail(id: ScorePanelId): ScoreDetail {
  if (id === 'sealSentiment' && viewStock.value?.firstSealSentimentScore === null) {
    return {
      title: '封板情绪分构成',
      subtitle: '尚未触发首次封板；封板情绪快照为空，不用实时情绪覆盖。',
      rules: [
        { label: '尚未触发首次封板', delta: 0 },
        { label: '等待涨停池事件确认', delta: 0 }
      ]
    }
  }

  return scoreDetails[id]
}

function detailFromRules(id: ScorePanelId, rules?: ScoreRule[]): ScoreDetail {
  if (!rules || rules.length === 0) return fallbackDetail(id)

  const fallback = fallbackDetail(id)

  return {
    title: fallback.title,
    subtitle: `${fallback.subtitle} 当前显示接口返回的评分明细。`,
    rules
  }
}

const activeDetail = computed(() => {
  const details = viewStock.value?.scoreDetails

  if (activeId.value === 'technical') {
    return detailFromRules(activeId.value, details?.technical)
  }

  if (activeId.value === 'realtimeSentiment') {
    return detailFromRules(activeId.value, details?.realtimeSentiment)
  }

  if (activeId.value === 'volume') {
    return detailFromRules(activeId.value, details?.volume)
  }

  return detailFromRules(activeId.value, details?.sealSentiment)
})

const reason = computed(() => {
  const stock = viewStock.value

  if (!stock) return selectedStock.reason
  if (stock.decisionStage === 'core') return '技术结构合格，实时情绪强，量能确认。'
  if (stock.volumeScore === null) return '技术和情绪已进入观察，等待量能确认。'
  if (stock.volumeScore < 55) return '量能不足，暂不晋级核心候选。'
  return '技术和情绪已达标，量能仍在监控。'
})

watch(() => props.stock?.code, () => {
  activeId.value = 'technical'
})
</script>

<template>
  <SectionCard title="评分详情 / 决策说明" compact>
    <div class="stock-head">
      <div>
        <div class="stock-title">
          <span class="ag-mono">{{ stockCode }}</span>
          <strong>{{ stockName }}</strong>
        </div>
        <div class="stock-meta">
          阶段：<span>{{ stageText }}</span>
        </div>
      </div>

      <div class="stock-price">
        <strong>{{ stockPrice.toFixed(2) }}</strong>
        <StockChangeTag :value="stockChangePct" />
      </div>
    </div>

    <ScoreCardTabs
      v-model:active-id="activeId"
      :cards="cards"
    />

    <ScoreRuleList :detail="activeDetail" />

    <div class="decision-box">
      <div class="decision-title">
        判断结果：<strong>{{ stageText }}</strong>
      </div>
      <p>原因：{{ reason }}</p>
    </div>
  </SectionCard>
</template>

<style scoped>
.stock-head {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 10px;
}

.stock-title {
  display: flex;
  align-items: baseline;
  gap: 8px;
  color: var(--ag-text);
}

.stock-title strong {
  font-size: 15px;
}

.stock-meta {
  margin-top: 4px;
  color: var(--ag-text-muted);
  font-size: 12px;
}

.stock-meta span {
  color: var(--ag-text-soft);
}

.stock-price {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 3px;
}

.stock-price strong {
  color: var(--ag-text);
  font-family: var(--ag-font-mono);
  font-size: 17px;
}

.decision-box {
  margin-top: 10px;
  padding: 10px;
  border: 1px solid rgba(255, 77, 95, 0.22);
  border-radius: var(--ag-radius-lg);
  background: linear-gradient(90deg, rgba(255, 77, 95, 0.12), rgba(255, 255, 255, 0.03));
}

.decision-title {
  color: var(--ag-text-soft);
  font-size: 13px;
}

.decision-title strong {
  color: var(--ag-red);
}

.decision-box p {
  margin: 4px 0 0;
  color: var(--ag-text-muted);
  font-size: 12px;
}
</style>
