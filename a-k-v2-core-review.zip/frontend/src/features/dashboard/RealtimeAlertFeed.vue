<script setup lang="ts">
import SectionCard from '../../components/common/SectionCard.vue'
import StatusBadge from '../../components/common/StatusBadge.vue'
import { alertFeedItems } from '../../mocks/dashboard'
</script>

<template>
  <SectionCard title="最新告警流" subtitle="按时间倒序展示关键事件">
    <div class="alert-feed">
      <article
        v-for="item in alertFeedItems"
        :key="item.id"
        class="alert-feed__item"
      >
        <div class="alert-feed__head">
          <StatusBadge :label="item.title" :tone="item.tone" />
          <span class="alert-feed__time">{{ item.time }}</span>
        </div>
        <p class="alert-feed__message">{{ item.message }}</p>
      </article>
    </div>
  </SectionCard>
</template>

<style scoped>
.alert-feed {
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-height: 336px;
  overflow: auto;
}

.alert-feed__item {
  padding: 12px;
  border: 1px solid var(--ag-border);
  border-radius: var(--ag-radius-md);
  background:
    linear-gradient(180deg, rgba(255, 255, 255, 0.045), rgba(255, 255, 255, 0.025));
}

.alert-feed__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.alert-feed__time {
  color: var(--ag-text-muted);
  font-family: var(--ag-font-mono);
  font-size: 12px;
}

.alert-feed__message {
  margin: 9px 0 0;
  color: var(--ag-text-soft);
  font-size: 13px;
  line-height: 1.55;
}
</style>
