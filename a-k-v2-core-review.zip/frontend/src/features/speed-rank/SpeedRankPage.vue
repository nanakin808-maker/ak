<script setup lang="ts">
import SectionCard from "@/components/common/SectionCard.vue"
import StockChangeTag from "@/components/common/StockChangeTag.vue"
</script>

<template>
  <div class="speed-rank-page">
    <SectionCard title="涨速榜">
      <template #actions>
        <el-button size="small" text :icon="'Refresh'">刷新</el-button>
      </template>
      <el-empty description="暂无涨速数据" :image-size="80" />
    </SectionCard>
  </div>
</template>
