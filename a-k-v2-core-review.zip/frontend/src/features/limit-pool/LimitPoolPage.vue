<script setup lang="ts">
import SectionCard from '../../components/common/SectionCard.vue'
</script>

<template>
  <div class="limit-pool-placeholder">
    <SectionCard title="涨停炸板池" subtitle="后端接口已完成，前端页面暂停开发" compact>
      <div class="placeholder-box">
        <div class="placeholder-title">页面暂未开放</div>
        <p>
          当前阶段优先继续后端分层、schema、adapter 和 service 稳定工作。
          涨停炸板池后端接口 <span class="ag-mono">GET /api/limit-pool</span> 已保留，
          前端正式页面将在后端接口稳定后重新开发。
        </p>
      </div>
    </SectionCard>
  </div>
</template>

<style scoped>
.limit-pool-placeholder {
  width: 100%;
  min-width: 0;
}

.placeholder-box {
  padding: 18px;
  border: 1px dashed rgba(148, 163, 184, 0.28);
  border-radius: var(--ag-radius-lg);
  background:
    radial-gradient(circle at 100% 0%, rgba(79, 140, 255, 0.12), transparent 45%),
    rgba(255, 255, 255, 0.035);
}

.placeholder-title {
  margin-bottom: 8px;
  color: var(--ag-text);
  font-size: 16px;
  font-weight: 760;
}

.placeholder-box p {
  max-width: 680px;
  margin: 0;
  color: var(--ag-text-muted);
  font-size: 13px;
  line-height: 1.7;
}
</style>
