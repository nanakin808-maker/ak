<script setup lang="ts">
import SectionCard from "@/components/common/SectionCard.vue"
</script>

<template>
  <div class="settings-page">
    <SectionCard title="同花顺配置">
      <el-form label-position="top" size="small">
        <el-form-item label="Cookie">
          <el-input type="password" placeholder="THS Cookie" show-password />
        </el-form-item>
        <el-form-item>
          <el-button type="primary">保存</el-button>
          <el-button>测试连接</el-button>
        </el-form-item>
      </el-form>
    </SectionCard>

    <SectionCard title="飞书通知">
      <el-form label-position="top" size="small">
        <el-form-item label="Webhook URL">
          <el-input placeholder="https://open.feishu.cn/..." />
        </el-form-item>
        <el-form-item label="Secret">
          <el-input type="password" placeholder="签名密钥" show-password />
        </el-form-item>
        <el-form-item>
          <el-button type="primary">保存</el-button>
          <el-button>测试通知</el-button>
        </el-form-item>
      </el-form>
    </SectionCard>

    <SectionCard title="通知阈值">
      <el-form label-position="top" size="small">
        <el-form-item label="K线最低分">
          <el-input-number :min="0" :max="100" :value="50" />
        </el-form-item>
        <el-form-item label="首封情绪最低分">
          <el-input-number :min="0" :max="100" :value="50" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary">保存</el-button>
        </el-form-item>
      </el-form>
    </SectionCard>
  </div>
</template>

<style scoped>
.settings-page {
  display: flex;
  flex-direction: column;
  gap: var(--space-xl);
  max-width: 600px;
}
</style>
