<script setup lang="ts">
import SectionCard from "@/components/common/SectionCard.vue"
import ScoreTag from "@/components/common/ScoreTag.vue"
</script>

<template>
  <div class="strategies-page">
    <div class="toolbar">
      <el-button type="primary" size="small">新建策略</el-button>
    </div>

    <SectionCard title="策略定义">
      <el-empty description="暂无策略定义" :image-size="80" />
    </SectionCard>

    <SectionCard title="已保存策略">
      <el-empty description="暂无已保存策略" :image-size="60" />
    </SectionCard>
  </div>
</template>

<style scoped>
.strategies-page {
  display: flex;
  flex-direction: column;
  gap: var(--space-xl);
}
.toolbar {
  display: flex;
  align-items: center;
}
</style>
