<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useEngineControl } from '../composables/useEngineControl'

const {
  state, loading, error, statusLabel, statusTone, start, stop, reset,
} = useEngineControl()

const nowText = new Date().toLocaleString('zh-CN', {
  hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit',
})

const engineMessage = computed(() => {
  if (error.value) return error.value
  return state.value.message || '引擎状态正常'
})

const marketSession = ref('--')
const tradingDate = ref('--')
const isLive = ref(false)

const SESSION_LABELS: Record<string, string> = {
  weekend: '周末休市', before_open: '未开盘', call_auction: '集合竞价',
  morning: '交易中', lunch_break: '午休', afternoon: '交易中',
  post_close: '已收盘', closed_no_trade_data: '休市',
}

const sessionLabel = computed(() => SESSION_LABELS[marketSession.value] || marketSession.value)

async function fetchMarketMeta() {
  try {
    const r = await fetch('/api/opportunities')
    const d = await r.json()
    marketSession.value = d.marketSession || '--'
    tradingDate.value = d.effectiveTradingDate || '--'
    isLive.value = d.isLiveTrading || false
  } catch { /* ignore */ }
}

onMounted(() => { fetchMarketMeta(); setInterval(fetchMarketMeta, 30000) })
</script>

<template>
  <header class="app-topbar">
    <div class="status-left">
      <div class="status-pill" :class="`status-${statusTone}`" :title="engineMessage">
        <span class="dot" />
        <span>引擎 {{ statusLabel }}</span>
      </div>

      <div class="status-pill" :class="isLive ? 'status-green' : 'status-red'">
        <span class="dot" />
        <span>{{ sessionLabel }}</span>
      </div>
    </div>

    <div class="topbar-actions">
      <el-button
        type="danger"
        :loading="loading"
        :disabled="state.running"
        @click="start"
      >
        启动引擎
      </el-button>
      <el-button
        :loading="loading"
        :disabled="!state.running"
        @click="stop"
      >
        停止
      </el-button>
      <el-button
        :loading="loading"
        @click="reset"
      >
        重置
      </el-button>
    </div>

    <div class="status-right">
      <span class="trade-date">交易日：{{ tradingDate }}</span>
      <span class="clock">{{ nowText }}</span>
    </div>
  </header>
</template>

<style scoped>
.app-topbar {
  height: var(--ag-topbar-height);
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto auto;
  align-items: center;
  gap: 18px;
  padding: 0 18px;
  border-bottom: 1px solid var(--ag-border);
  background: var(--ag-bg-topbar);
  backdrop-filter: blur(14px);
}

.status-left,
.status-right,
.topbar-actions {
  display: flex;
  align-items: center;
}

.status-left {
  min-width: 0;
  gap: 10px;
}

.topbar-actions {
  gap: 10px;
}

.status-right {
  justify-content: flex-end;
  gap: 10px;
  min-width: 180px;
}

.status-pill {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  height: 32px;
  padding: 0 12px;
  border: 1px solid var(--ag-border);
  border-radius: 999px;
  color: var(--ag-text-soft);
  background: rgba(255, 255, 255, 0.04);
  font-size: 12px;
  white-space: nowrap;
}

.dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--tone);
  box-shadow: 0 0 12px var(--tone);
}

.status-blue {
  --tone: var(--ag-blue);
}

.status-orange {
  --tone: var(--ag-orange);
}

.status-green {
  --tone: var(--ag-green);
}

.status-red {
  --tone: var(--ag-red);
}

.trade-date,
.clock {
  color: var(--ag-text-muted);
  font-size: 13px;
  white-space: nowrap;
}

.clock {
  font-family: var(--ag-font-mono);
}
</style>
