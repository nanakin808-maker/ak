<script setup lang="ts">
import AppSidebar from './AppSidebar.vue'
import AppTopbar from './AppTopbar.vue'
</script>

<template>
  <div class="app-layout">
    <AppSidebar />

    <section class="app-main">
      <AppTopbar />
      <main class="app-content">
        <slot />
      </main>
    </section>
  </div>
</template>

<style scoped>
.app-layout {
  display: grid;
  grid-template-columns: var(--ag-sidebar-width) minmax(0, 1fr);
  width: 100vw;
  height: 100vh;
  overflow: hidden;
}

.app-main {
  min-width: 0;
  height: 100vh;
  overflow: hidden;
  background:
    linear-gradient(180deg, rgba(8, 17, 31, 0.72), rgba(5, 11, 20, 0.98)),
    var(--ag-bg-shell);
}

.app-content {
  width: 100%;
  min-width: 0;
  height: calc(100vh - var(--ag-topbar-height));
  overflow-y: auto;
  overflow-x: hidden;
  padding: 12px 12px 16px;
}
</style>
