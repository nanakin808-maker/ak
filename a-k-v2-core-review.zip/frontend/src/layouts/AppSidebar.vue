<script setup lang="ts">
const navItems = [
  { path: '/dashboard', label: '机会总览' },
  { path: '/limit-pool', label: '涨停炸板池' },
  { path: '/speed-rank', label: '涨速榜' },
  { path: '', label: '涨幅榜', disabled: true },
  { path: '', label: '板块动向', disabled: true },
  { path: '/shadow', label: 'Shadow 数据' },
  { path: '/settings', label: '设置' }
]
</script>

<template>
  <aside class="app-sidebar">
    <div class="brand">
      <div class="brand-mark">A</div>
      <div class="brand-copy">
        <strong>A Stock Guard</strong>
        <span>Realtime Monitor</span>
      </div>
    </div>

    <div class="sidebar-section-title">工作台</div>

    <nav class="nav-list">
      <RouterLink
        v-for="item in navItems.filter((item) => !item.disabled)"
        :key="item.label"
        :to="item.path"
        class="nav-item"
      >
        <span class="nav-label">{{ item.label }}</span>
      </RouterLink>

      <span
        v-for="item in navItems.filter((item) => item.disabled)"
        :key="item.label"
        class="nav-item nav-item--disabled"
      >
        <span class="nav-label">{{ item.label }}</span>
      </span>
    </nav>

    <div class="sidebar-footer">
      <div class="footer-label">环境</div>
      <div class="footer-value">a-k-v2 · isolated</div>
    </div>
  </aside>
</template>

<style scoped>
.app-sidebar {
  width: var(--ag-sidebar-width);
  height: 100vh;
  display: flex;
  flex-direction: column;
  padding: 18px 14px;
  border-right: 1px solid var(--ag-border);
  background:
    radial-gradient(circle at 30% 0%, rgba(79, 140, 255, 0.16), transparent 34%),
    linear-gradient(180deg, #091526, #050b14);
}

.brand {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 8px 24px;
}

.brand-mark {
  display: grid;
  place-items: center;
  width: 42px;
  height: 42px;
  border-radius: 14px;
  color: #fff;
  background: linear-gradient(135deg, var(--ag-red), var(--ag-blue));
  box-shadow: 0 14px 28px rgba(79, 140, 255, 0.22);
  font-weight: 900;
}

.brand-copy {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.brand-copy strong {
  font-size: 15px;
}

.brand-copy span {
  color: var(--ag-text-muted);
  font-size: 12px;
}

.sidebar-section-title {
  padding: 0 10px 8px;
  color: var(--ag-text-faint);
  font-size: 12px;
}

.nav-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.nav-item {
  display: flex;
  align-items: center;
  min-height: 44px;
  padding: 0 14px;
  border: 1px solid transparent;
  border-radius: 12px;
  color: var(--ag-text-soft);
  transition: 0.16s ease;
}

.nav-item:hover {
  background: var(--ag-bg-hover);
  color: var(--ag-text);
}

.nav-item.router-link-active {
  border-color: rgba(79, 140, 255, 0.42);
  background: linear-gradient(90deg, rgba(79, 140, 255, 0.22), rgba(79, 140, 255, 0.08));
  color: #fff;
}

.nav-item--disabled {
  cursor: default;
  color: var(--ag-text-faint);
  opacity: 0.7;
}

.nav-label {
  font-size: 15px;
  font-weight: 680;
  letter-spacing: 0.01em;
}

.sidebar-footer {
  margin-top: auto;
  padding: 12px;
  border: 1px solid var(--ag-border);
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.04);
}

.footer-label {
  color: var(--ag-text-muted);
  font-size: 12px;
}

.footer-value {
  margin-top: 4px;
  color: var(--ag-text-soft);
  font-family: var(--ag-font-mono);
  font-size: 12px;
}
</style>
