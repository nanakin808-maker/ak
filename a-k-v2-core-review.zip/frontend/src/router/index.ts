import { createRouter, createWebHistory } from "vue-router"

const routes = [
  { path: "/", redirect: "/dashboard" },
  {
    path: "/dashboard",
    name: "dashboard",
    component: () => import("@/features/dashboard/DashboardPage.vue"),
    meta: { title: "监控总览" },
  },
  {
    path: "/candidates",
    name: "candidates",
    component: () => import("@/features/candidates/CandidatesPage.vue"),
    meta: { title: "候选池" },
  },
  {
    path: "/limit-pool",
    name: "limit-pool",
    component: () => import("@/features/limit-pool/LimitPoolPage.vue"),
    meta: { title: "涨停池" },
  },
  {
    path: "/speed-rank",
    name: "speed-rank",
    component: () => import("@/features/speed-rank/SpeedRankPage.vue"),
    meta: { title: "涨速榜" },
  },
  {
    path: "/strategies",
    name: "strategies",
    component: () => import("@/features/strategies/StrategiesPage.vue"),
    meta: { title: "策略" },
  },
  {
    path: "/qwen",
    name: "qwen",
    component: () => import("@/features/qwen/QwenPage.vue"),
    meta: { title: "Qwen 分析" },
  },
  {
    path: "/settings",
    name: "settings",
    component: () => import("@/features/settings/SettingsPage.vue"),
    meta: { title: "系统设置" },
  },
  {
    path: "/shadow",
    name: "shadow",
    component: () => import("@/features/monitoring-shadow/MonitoringShadowPage.vue"),
    meta: { title: "Shadow 数据" },
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
