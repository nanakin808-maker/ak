/**
 * WebSocket client for /ws/monitoring/realtime
 * Receives incremental deltas: scan_status, stock_state_upsert, score_snapshot, etc.
 * Reconnects with exponential backoff. On reconnect, caller must reload REST snapshot.
 */

export type WsMessageType =
  | "scan_status"
  | "stock_state_upsert"
  | "monitoring_event"
  | "score_snapshot"
  | "heartbeat"

export type WsConnectionState = "connected" | "reconnecting" | "disconnected"

export type WsMessage = {
  type: WsMessageType
  trading_date: string
  seq: number
  as_of: string | null
  data: Record<string, unknown>
}

export type RealtimeSocketCallbacks = {
  onMessage: (msg: WsMessage) => void
  onStateChange: (state: WsConnectionState, lastSeq: number) => void
  onReconnect: () => void  // caller must reload REST snapshot
}

export class MonitoringRealtimeSocket {
  private _ws: WebSocket | null = null
  private _tradingDate: string
  private _callbacks: RealtimeSocketCallbacks
  private _seq = 0
  private _state: WsConnectionState = "disconnected"
  private _wasConnected = false
  private _reconnectTimer: ReturnType<typeof setTimeout> | null = null
  private _reconnectDelay = 1000
  private _maxReconnectDelay = 30000

  constructor(tradingDate: string, callbacks: RealtimeSocketCallbacks) {
    this._tradingDate = tradingDate
    this._callbacks = callbacks
  }

  connect(): void {
    this._doConnect()
  }

  disconnect(): void {
    this._clearReconnect()
    if (this._ws) {
      this._ws.onclose = null
      this._ws.close()
      this._ws = null
    }
    this._setState("disconnected")
  }

  get lastSeq(): number { return this._seq }
  get state(): WsConnectionState { return this._state }

  private _doConnect(): void {
    const protocol = location.protocol === "https:" ? "wss:" : "ws:"
    const url = `${protocol}//${location.host}/ws/monitoring/realtime?trading_date=${this._tradingDate}`
    this._ws = new WebSocket(url)

    this._ws.onopen = () => {
      this._setState("connected")
      this._reconnectDelay = 1000
      // Only reload on REconnect, not initial connection
      if (this._wasConnected) {
        this._callbacks.onReconnect()
      }
      this._wasConnected = true
    }

    this._ws.onmessage = (event: MessageEvent) => {
      try {
        const msg = JSON.parse(event.data) as WsMessage
        this._seq = Math.max(this._seq, msg.seq || 0)
        this._callbacks.onMessage(msg)
      } catch { /* ignore malformed */ }
    }

    this._ws.onclose = () => {
      this._setState("reconnecting")
      this._scheduleReconnect()
    }

    this._ws.onerror = () => {
      // onclose will fire after this
    }
  }

  private _scheduleReconnect(): void {
    this._clearReconnect()
    this._reconnectTimer = setTimeout(() => {
      this._doConnect()
    }, this._reconnectDelay)
    this._reconnectDelay = Math.min(
      this._reconnectDelay * 2,
      this._maxReconnectDelay,
    )
  }

  private _clearReconnect(): void {
    if (this._reconnectTimer) {
      clearTimeout(this._reconnectTimer)
      this._reconnectTimer = null
    }
  }

  private _setState(state: WsConnectionState): void {
    this._state = state
    this._callbacks.onStateChange(state, this._seq)
  }
}
