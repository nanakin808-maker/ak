const DEFAULT_TIMEOUT_MS = 8000

function apiBaseUrl() {
  const value = import.meta.env.VITE_API_BASE_URL || ''
  return String(value).replace(/\/$/, '')
}

async function requestJson<T>(
  path: string,
  init: RequestInit,
  timeoutMs = DEFAULT_TIMEOUT_MS
): Promise<T> {
  const controller = new AbortController()
  const timer = window.setTimeout(() => controller.abort(), timeoutMs)

  try {
    const base = apiBaseUrl()
    const url = path.startsWith('http') ? path : `${base}${path}`
    const response = await fetch(url, {
      ...init,
      headers: {
        Accept: 'application/json',
        ...(init.body ? { 'Content-Type': 'application/json' } : {}),
        ...init.headers
      },
      signal: controller.signal
    })

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`)
    }

    return await response.json() as T
  } finally {
    window.clearTimeout(timer)
  }
}

export async function getJson<T>(path: string, timeoutMs = DEFAULT_TIMEOUT_MS): Promise<T> {
  return requestJson<T>(path, { method: 'GET' }, timeoutMs)
}

export async function postJson<T>(
  path: string,
  body?: unknown,
  timeoutMs = DEFAULT_TIMEOUT_MS
): Promise<T> {
  return requestJson<T>(
    path,
    {
      method: 'POST',
      body: body === undefined ? undefined : JSON.stringify(body)
    },
    timeoutMs
  )
}
