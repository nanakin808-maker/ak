import { candidateSummaries, type CandidateSummary } from '../mocks/dashboard'
import { recentMonitorEvents, type MonitorEvent } from '../mocks/scoreDetail'
import { getJson } from './http'

type Source = 'api' | 'mock'

type OpportunitiesApiResponse = {
  ok: boolean
  source?: 'legacy' | 'mock'
  updatedAt?: string
  rows?: CandidateSummary[]
  error?: string | null
}

type EventsApiResponse = {
  ok: boolean
  source?: 'legacy' | 'mock'
  updatedAt?: string
  events?: MonitorEvent[]
  error?: string | null
}

export type OpportunityRowsResult = {
  rows: CandidateSummary[]
  events: MonitorEvent[]
  source: Source
  error: string | null
}

function normalizeSource(source?: string): Source {
  if (source === 'legacy' || source === 'v2_shadow') return 'api'
  return 'mock'
}

async function fetchRows() {
  const payload = await getJson<OpportunitiesApiResponse>('/api/opportunities')
  const rows = Array.isArray(payload.rows) ? payload.rows : []

  return {
    rows,
    source: normalizeSource(payload.source),
    error: payload.error ?? null
  }
}

async function fetchEvents() {
  const payload = await getJson<EventsApiResponse>('/api/events/realtime')
  const events = Array.isArray(payload.events) ? payload.events : []

  return {
    events,
    source: normalizeSource(payload.source),
    error: payload.error ?? null
  }
}

export async function fetchOpportunityRows(): Promise<OpportunityRowsResult> {
  try {
    const [rowsResult, eventsResult] = await Promise.all([
      fetchRows(),
      fetchEvents()
    ])

    const rows = rowsResult.rows.length > 0
      ? rowsResult.rows
      : candidateSummaries

    const events = eventsResult.events.length > 0
      ? eventsResult.events
      : recentMonitorEvents

    const source: Source = rowsResult.source === 'api' || eventsResult.source === 'api'
      ? 'api'
      : 'mock'

    const error = rowsResult.error || eventsResult.error || null

    return {
      rows,
      events,
      source,
      error
    }
  } catch (error) {
    return {
      rows: candidateSummaries,
      events: recentMonitorEvents,
      source: 'mock',
      error: error instanceof Error ? error.message : 'v2 后端接口请求失败'
    }
  }
}
