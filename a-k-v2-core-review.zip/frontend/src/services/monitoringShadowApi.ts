import { getJson } from './http'
import type {
  InterfaceHealthResponse,
  LimitPoolResponse,
  ShadowOverview,
  ShadowScoresResponse,
  ShadowStocksResponse,
} from '@/types/monitoringShadow'

export const monitoringShadowApi = {
  overview: () => getJson<ShadowOverview>('/api/monitoring/shadow/overview'),
  stocks: (tradingDate?: string) =>
    getJson<ShadowStocksResponse>(
      `/api/monitoring/shadow/stocks${tradingDate ? `?trading_date=${tradingDate}` : ''}`
    ),
  limitPool: (tradingDate?: string) =>
    getJson<LimitPoolResponse>(
      `/api/monitoring/shadow/limit-pool${tradingDate ? `?trading_date=${tradingDate}` : ''}`
    ),
  scores: (tradingDate?: string) =>
    getJson<ShadowScoresResponse>(
      `/api/monitoring/shadow/scores${tradingDate ? `?trading_date=${tradingDate}` : ''}`
    ),
  interfaceHealth: (limit = 50) =>
    getJson<InterfaceHealthResponse>(`/api/monitoring/shadow/interface-health?limit=${limit}`),
}
