import type {
  CandidateScoreDetails, CandidateSummary, DecisionStage, ScoreRule, VolumeStatus
} from '../mocks/dashboard'
import type { MonitorEvent } from '../mocks/scoreDetail'

type RawRecord = Record<string, unknown>
type RawAlertsState = RawRecord & { core?: RawRecord[]; candidates?: RawRecord[]; monitor_events?: RawRecord[]; alerts?: RawRecord[] }

function obj(v: unknown): RawRecord { return v && typeof v === 'object' ? v as RawRecord : {} }
function num(v: unknown): number | null {
  if (typeof v === 'number' && Number.isFinite(v)) return v
  if (typeof v === 'string' && v.trim() !== '') { const p = Number(v); return Number.isFinite(p) ? p : null }
  return null
}
function txt(v: unknown, fb = ''): string { return typeof v === 'string' && v.trim() ? v : fb }
function pickNum(r: RawRecord, ks: string[]): number | null { for (const k of ks) { const v = num(r[k]); if (v !== null) return v } return null }
function nestedVal(src: unknown, path: string[]): unknown { let c = src; for (const k of path) c = obj(c)[k]; return c }
function nestedNum(src: unknown, path: string[]): number | null { return num(nestedVal(src, path)) }
function pushRule(rules: ScoreRule[], label: string, v: unknown) { const d = num(v); if (d !== null) rules.push({ label, delta: d }) }

function technicalScore(r: RawRecord): number { return pickNum(r, ['technical_score', 'kline_score']) ?? 0 }
function currentSentimentScore(r: RawRecord): number {
  return pickNum(r, ['display_sentiment_score', 'sentiment_score', 'realtime_sentiment_score', 'first_seal_sentiment_score', 'entry_sentiment_score'])
    ?? nestedNum(r.board_score, ['score']) ?? 0
}
function firstSealSentimentScore(r: RawRecord): number | null {
  return pickNum(r, ['first_seal_sentiment_score']) ?? nestedNum(r.board_score_seal_snapshot, ['score'])
}
function volumeScore(r: RawRecord): number | null {
  return nestedNum(r.volume_momentum_score, ['total']) ?? pickNum(r, ['volume_score', 'last_volume_event_score'])
}
function volumeStatus(r: RawRecord, sc: number | null): VolumeStatus {
  const e = txt(r.volume_status)
  if (['pending', 'monitoring', 'confirmed', 'failed'].includes(e)) return e as VolumeStatus
  if (sc === null) return 'pending'
  return sc >= 85 ? 'confirmed' : sc >= 55 ? 'monitoring' : 'failed'
}
function decisionStage(r: RawRecord, fb: DecisionStage): DecisionStage {
  if (r.in_core === true || r.sealed === true) return 'core'
  if (r.in_candidate === true) return 'candidate'
  if (r.rejected_today === true || r.candidate_removed === true) return 'rejected'
  return fb
}
function primaryBoard(r: RawRecord): string {
  const concepts: unknown[] = Array.isArray(obj(r.board_summary).strong_concepts) ? obj(r.board_summary).strong_concepts as unknown[] : []
  const fc = obj(concepts[0])
  return txt(fc.board_name) || txt(nestedVal(r, ['board_score', 'main_logic', 'primary', 'board_name'])) || txt(nestedVal(r, ['main_logic', 'board_name'])) || txt(r.board) || '--'
}
function boardChangePct(r: RawRecord): number | null {
  const concepts: unknown[] = Array.isArray(obj(r.board_summary).strong_concepts) ? obj(r.board_summary).strong_concepts as unknown[] : []
  return num(obj(concepts[0]).change_pct) ?? nestedNum(r, ['board_score', 'main_logic', 'primary', 'change_pct']) ?? pickNum(r, ['main_logic_change_pct', 'board_change_pct'])
}

function sentimentRules(snapshot: unknown): ScoreRule[] {
  const snap = obj(snapshot), rules: ScoreRule[] = []
  pushRule(rules, '地位分', snap.position_score ?? snap.sentiment_position)
  pushRule(rules, '强度分', snap.strength_score ?? snap.sentiment_strength)
  pushRule(rules, '封板质量', snap.seal_quality_score)
  pushRule(rules, '板块涨幅', snap.main_logic_change_pct)
  pushRule(rules, '买入可行性', snap.entry_feasibility_score)
  const details = Array.isArray(snap.details) ? snap.details : []
  for (const item of details) {
    const d = obj(item), label = txt(d.label) || txt(d.name), delta = num(d.delta ?? d.score)
    if (label && delta !== null) rules.push({ label, delta })
  }
  return rules
}

function volumeRules(r: RawRecord): ScoreRule[] {
  const vol = obj(r.volume_momentum_score), rules: ScoreRule[] = []
  pushRule(rules, '短窗口动能', nestedVal(vol, ['short_window', 'score']))
  pushRule(rules, '成交额确认', nestedVal(vol, ['amount_confirm', 'score']))
  pushRule(rules, '换手匹配', nestedVal(vol, ['turnover_fit', 'score']))
  pushRule(rules, '历史量能对比', nestedVal(vol, ['history_compare', 'score']))
  const pv = num(nestedVal(vol, ['risk_penalty', 'penalty']))
  if (pv !== null && pv !== 0) rules.push({ label: '风险惩罚', delta: -Math.abs(pv) })
  pushRule(rules, '最近量能事件', r.last_volume_event_score)
  pushRule(rules, '短窗口事件', r.last_volume_event_short_score)
  return rules
}

function technicalRules(r: RawRecord): ScoreRule[] {
  const rules: ScoreRule[] = [], data = obj(obj(obj(obj(r.strategy).results).kline_structure_score).data)
  pushRule(rules, 'K线结构', data.score ?? data.total)
  pushRule(rules, '技术评分', r.technical_score ?? r.kline_score)
  const details = Array.isArray(data.details) ? data.details : []
  for (const item of details) {
    const d = obj(item), label = txt(d.label) || txt(d.name), delta = num(d.delta ?? d.score)
    if (label && delta !== null) rules.push({ label, delta })
  }
  return rules
}

function buildScoreDetails(r: RawRecord): CandidateScoreDetails {
  const technical = technicalRules(r)
  const realtimeSentiment = sentimentRules(r.board_score ?? r.board_score_trigger_snapshot ?? r.board_score_open_snapshot ?? r.board_score_reseal_snapshot)
  const sealSentiment = sentimentRules(r.board_score_seal_snapshot)
  const volume = volumeRules(r)
  return {
    technical: technical.length ? technical : undefined,
    realtimeSentiment: realtimeSentiment.length ? realtimeSentiment : undefined,
    sealSentiment: sealSentiment.length ? sealSentiment : undefined,
    volume: volume.length ? volume : undefined
  }
}

function normalizeStock(r: RawRecord, fb: DecisionStage): CandidateSummary {
  const vs = volumeScore(r)
  return {
    code: txt(r.code), name: txt(r.name, '--'), price: pickNum(r, ['price', 'latest_price']) ?? 0,
    changePct: pickNum(r, ['change_pct', 'pct_chg']) ?? 0,
    technicalScore: technicalScore(r), sentimentScore: currentSentimentScore(r),
    firstSealSentimentScore: firstSealSentimentScore(r), volumeScore: vs, volumeStatus: volumeStatus(r, vs),
    board: primaryBoard(r), boardChangePct: boardChangePct(r), decisionStage: decisionStage(r, fb),
    scoreDetails: buildScoreDetails(r)
  }
}

function uniqueByCode(rows: CandidateSummary[]) {
  const seen = new Set<string>()
  return rows.filter((row) => { if (!row.code || seen.has(row.code)) return false; seen.add(row.code); return true })
}

function eventTone(ev: string): MonitorEvent['tone'] {
  if (ev.includes('炸板') || ev.includes('开板')) return 'green'
  if (ev.includes('量能') || ev.includes('放量')) return 'purple'
  if (ev.includes('涨停') || ev.includes('封板')) return 'red'
  if (ev.includes('拉升') || ev.includes('涨速')) return 'blue'
  return 'orange'
}

function normalizeEvent(r: RawRecord, i: number): MonitorEvent {
  const ev = txt(r.event) || txt(r.event_type) || txt(r.title) || txt(r.event_title) || '事件'
  const tm = txt(r.event_time) || txt(r.time) || txt(r.created_at) || '--:--:--'
  const code = txt(r.code), name = txt(r.name, code || '--')
  const src = txt(r.source) || txt(r.event_source) || txt(r.last_event_source)
  return { id: txt(r.id, `${tm}-${code}-${ev}-${i}`), time: tm, code, name, event: ev, detail: src || ev, tone: eventTone(ev) }
}

export function normalizeAlertsState(payload: RawAlertsState): CandidateSummary[] {
  return uniqueByCode([
    ...(Array.isArray(payload.core) ? payload.core : []).map((r) => normalizeStock(r, 'core')),
    ...(Array.isArray(payload.candidates) ? payload.candidates : []).map((r) => normalizeStock(r, 'candidate'))
  ])
}

export function normalizeMonitorEvents(payload: RawAlertsState): MonitorEvent[] {
  const raw = Array.isArray(payload.monitor_events) ? payload.monitor_events : Array.isArray(payload.alerts) ? payload.alerts : []
  return raw.slice(0, 30).map(normalizeEvent)
}
