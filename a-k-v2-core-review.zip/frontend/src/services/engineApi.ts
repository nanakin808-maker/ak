import { getJson, postJson } from './http'

export type EngineStatus = 'idle' | 'running' | 'stopped' | 'error'

export type EngineState = {
  status: EngineStatus
  running: boolean
  startedAt: string | null
  stoppedAt: string | null
  resetAt: string | null
  message: string
}

export type EngineResponse = {
  ok: boolean
  state: EngineState
}

export async function fetchEngineStatus() {
  return getJson<EngineResponse>('/api/engine/status')
}

export async function startEngine() {
  return postJson<EngineResponse>('/api/engine/start')
}

export async function stopEngine() {
  return postJson<EngineResponse>('/api/engine/stop')
}

export async function resetEngine() {
  return postJson<EngineResponse>('/api/engine/reset')
}
