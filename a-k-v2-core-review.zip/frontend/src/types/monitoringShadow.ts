export interface ShadowOverview {
  data_mode: string
  scoring_mode: string
  quote_can_drive_seal: boolean
  limit_pool_can_drive_lifecycle: boolean
  db_path: string
  trading_dates: string[]
  counts: Record<string, number>
  warning?: string
  marketSession?: string
  effectiveTradingDate?: string
  isLiveTrading?: boolean
}

export interface ShadowStock {
  trading_date: string
  code: string
  name: string
  stage: string
  active_monitoring: boolean
  inactive_reason: string | null
  price: number | null
  change_pct: number | null
  is_sealed: boolean
  at_limit: boolean
  freshness_status: string
  source_trading_date: string | null
  latest_score_snapshot: {
    score_stage: string
    score: number | null
    technical_score: number | null
    sentiment_score: number | null
    volume_score: number | null
    status: string
    passed: boolean | null
    reject_reason: string | null
    scoring_mode: string
  } | null
}

export interface ShadowStocksResponse {
  data_mode: string
  scoring_mode: string
  stocks: ShadowStock[]
}

export interface LimitPoolSnapshot {
  id: number
  source: string
  primary_source: string
  freshness_status: string
  source_trading_date: string | null
  as_of: string
}

export interface LimitPoolRow {
  code: string
  name: string
  pool: string
  price: number | null
  change_pct: number | null
  first_limit_time: string | null
  last_limit_time: string | null
  open_count: number | null
  seal_amount: number | null
  streak: number | null
  industry: string
  reason: string | null
  freshness_status: string
  source_trading_date: string | null
}

export interface LimitPoolResponse {
  data_mode: string
  snapshot: LimitPoolSnapshot | null
  rows: LimitPoolRow[]
}

export interface ShadowScore {
  trading_date: string
  code: string
  name: string
  score_type: string
  score_stage: string
  score: number | null
  technical_score: number | null
  sentiment_score: number | null
  volume_score: number | null
  status: string
  passed: boolean | null
  reject_reason: string | null
  source_type: string
  scoring_mode: string
}

export interface ShadowScoresResponse {
  data_mode: string
  scoring_mode: string
  scores: ShadowScore[]
}

export interface InterfaceHealthRecord {
  name: string
  category: string
  ok: boolean
  latency_ms: number | null
  error: string
  timestamp: string
  detail_json: string
}

export interface InterfaceHealthResponse {
  data_mode: string
  records: InterfaceHealthRecord[]
}
