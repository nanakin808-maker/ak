export interface LimitPoolRow {
  code: string
  name: string
  pool: string
  price: number | null
  change_pct: number | null
  first_limit_time: string | null
  seal_amount: number | null
  open_count: number
  reason: string
}

export interface LimitPoolResponse {
  ok: boolean
  date: string | null
  pool: string | null
  limit: number
  rows: LimitPoolRow[]
}
