export interface NotificationSettings {
  kline_min_score: number
  seal_board_min_score: number
}

export interface SpeedRankHealth {
  available: boolean
}

export interface SettingsResponse {
  ok: boolean
  ths_ok: boolean
  feishu_ok: boolean
  notification: NotificationSettings
  speed_rank: SpeedRankHealth
}
