export interface ApiResponse<T = unknown> {
  ok: boolean
  data?: T
  error?: string
}

export interface PaginatedResponse<T = unknown> {
  total: number
  limit: number
  offset: number
  rows: T[]
}
