export interface StrategyDefinition {
  strategy_id: string
  name: string
  category: string
  enabled: boolean
  veto: boolean
}

export interface SavedStrategy {
  id: string
  strategy_id: string
  config: Record<string, unknown>
  enabled: boolean
}
