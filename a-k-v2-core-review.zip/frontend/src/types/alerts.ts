export interface AlertStartPayload {
  notify_enabled: boolean
  interval_seconds?: number
}

export interface AlertControlResponse {
  ok: boolean
  action: string
  scanned?: number
}

export interface AlertState {
  ok: boolean
  running: boolean
  monitor_events: number
  candidates: number
  core: number
  pre_candidates: number
}
