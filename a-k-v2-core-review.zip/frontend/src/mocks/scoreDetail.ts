export type ScorePanelId = 'technical' | 'realtimeSentiment' | 'volume' | 'sealSentiment'

export type ScoreCard = {
  id: ScorePanelId
  title: string
  value: number | null
  tone: 'blue' | 'purple' | 'green' | 'red'
}

export type ScoreRule = {
  label: string
  delta: number
}

export type ScoreDetail = {
  title: string
  subtitle: string
  rules: ScoreRule[]
}

export type MonitorEvent = {
  id: string
  time: string
  code: string
  name: string
  event: string
  detail: string
  tone: 'red' | 'orange' | 'green' | 'blue' | 'purple'
}

export const selectedStock = {
  code: '300750',
  name: '宁德时代',
  event: '快速拉升',
  stage: '核心候选',
  decision: '核心候选',
  reason: '技术结构合格，实时情绪强，量能确认。',
  price: 214.28,
  changePct: 4.12
}

export const scoreCards: ScoreCard[] = [
  { id: 'technical', title: '技术分', value: 86, tone: 'blue' },
  { id: 'realtimeSentiment', title: '实时情绪分', value: 91, tone: 'purple' },
  { id: 'volume', title: '量能分', value: 94, tone: 'green' },
  { id: 'sealSentiment', title: '封板情绪分', value: null, tone: 'red' }
]

export const scoreDetails: Record<ScorePanelId, ScoreDetail> = {
  technical: {
    title: '技术分构成',
    subtitle: '基于 K 线结构、趋势位置和短线形态判断。',
    rules: [
      { label: '均线向上', delta: 10 },
      { label: '突破前高', delta: 8 },
      { label: 'K线结构完整', delta: 6 },
      { label: '靠近压力位', delta: -4 },
      { label: '趋势延续', delta: 5 }
    ]
  },
  realtimeSentiment: {
    title: '实时情绪分构成',
    subtitle: '根据当前板块热度、涨停生态和事件强度实时更新。',
    rules: [
      { label: '主板块中当前股票涨幅靠前', delta: 18 },
      { label: '板块涨停家数增加', delta: 10 },
      { label: '同板块个股跟涨', delta: 8 },
      { label: '市场风险偏好一般', delta: -4 },
      { label: '事件触发强度较高', delta: 7 }
    ]
  },
  volume: {
    title: '量能分构成',
    subtitle: '进入候选后实时监控成交量、分时承接和资金变化。',
    rules: [
      { label: '量能逐步放大', delta: 12 },
      { label: '净买入增强', delta: 8 },
      { label: '分时承接稳定', delta: 6 },
      { label: '尾盘放量不足', delta: -5 },
      { label: '换手率适中', delta: 4 }
    ]
  },
  sealSentiment: {
    title: '封板情绪分构成',
    subtitle: '封板瞬间保存快照；未封板时显示为空，不用实时情绪覆盖。',
    rules: [
      { label: '尚未触发首次封板', delta: 0 },
      { label: '等待涨停池事件确认', delta: 0 }
    ]
  }
}

export const recentMonitorEvents: MonitorEvent[] = [
  { id: 'e1', time: '19:11:28', code: '300750', name: '宁德时代', event: '快速拉升', detail: '5分钟内涨幅超过 2%', tone: 'blue' },
  { id: 'e2', time: '19:11:12', code: '300059', name: '东方财富', event: '量能放大', detail: '成交量较前一小时放大 2.1 倍', tone: 'purple' },
  { id: 'e3', time: '19:10:57', code: '002594', name: '比亚迪', event: '涨停', detail: '封上涨停板，涨幅 9.99%', tone: 'red' },
  { id: 'e4', time: '19:10:41', code: '300308', name: '中际旭创', event: '炸板', detail: '涨停炸板，当前涨幅 6.12%', tone: 'orange' },
  { id: 'e5', time: '19:10:23', code: '300274', name: '阳光电源', event: '快速拉升', detail: '5分钟内涨幅超过 2%', tone: 'blue' }
]
