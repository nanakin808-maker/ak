export type DashboardMetric = {
  title: string
  value: string | number
  subtitle: string
  delta?: string
  tone: 'red' | 'green' | 'orange' | 'blue' | 'purple' | 'neutral'
}

export type VolumeStatus = 'pending' | 'monitoring' | 'confirmed' | 'failed'
export type DecisionStage = 'watch' | 'candidate' | 'core' | 'rejected'

export type ScoreRule = {
  label: string
  delta: number
}

export type CandidateScoreDetails = {
  technical?: ScoreRule[]
  realtimeSentiment?: ScoreRule[]
  sealSentiment?: ScoreRule[]
  volume?: ScoreRule[]
}

export type CandidateSummary = {
  code: string
  name: string
  price: number
  changePct: number
  technicalScore: number
  sentimentScore: number
  firstSealSentimentScore: number | null
  volumeScore: number | null
  volumeStatus: VolumeStatus
  board: string
  boardChangePct: number | null
  decisionStage: DecisionStage
  scoreDetails?: CandidateScoreDetails
}

export type AlertFeedItem = {
  id: string
  time: string
  title: string
  message: string
  tone: 'red' | 'green' | 'orange' | 'blue' | 'purple' | 'gray'
}

export type SpeedRankItem = {
  rank: number
  code: string
  name: string
  changePct: number
  speedPct: number
  technicalScore: number
  sentimentScore: number
  volumeScore: number | null
  volumeStatus: VolumeStatus
  board: string
  signal: string
}

export type HealthItem = {
  name: string
  status: 'ok' | 'warn' | 'error' | 'unknown'
  detail: string
  latency: string
}

const stock = (
  code: string,
  name: string,
  price: number,
  changePct: number,
  technicalScore: number,
  sentimentScore: number,
  firstSealSentimentScore: number | null,
  volumeScore: number | null,
  volumeStatus: VolumeStatus,
  board: string,
  boardChangePct: number | null,
  decisionStage: DecisionStage
): CandidateSummary => ({
  code,
  name,
  price,
  changePct,
  technicalScore,
  sentimentScore,
  firstSealSentimentScore,
  volumeScore,
  volumeStatus,
  board,
  boardChangePct,
  decisionStage
})

export const dashboardMetrics: DashboardMetric[] = [
  { title: '技术指标数', value: 89, subtitle: 'K线结构、趋势、策略条件达标', delta: '+11', tone: 'blue' },
  { title: '情绪指标数', value: 63, subtitle: '板块热度、涨停生态达标', delta: '+8', tone: 'purple' },
  { title: '双因子共振', value: 24, subtitle: '技术分和情绪分同时达标', delta: '+5', tone: 'red' },
  { title: '量能确认数', value: 9, subtitle: '进入候选后，实时量能已确认', delta: '+2', tone: 'orange' },
  { title: '核心候选数', value: 7, subtitle: '已进入核心跟踪池', delta: '+3', tone: 'red' },
  { title: '通知发送数', value: 19, subtitle: '飞书通知，限频正常', delta: '正常', tone: 'green' }
]

export const candidateSummaries: CandidateSummary[] = [
  stock('300750', '宁德时代', 214.28, 4.12, 86, 91, 88, 94, 'confirmed', '锂电池', 3.82, 'core'),
  stock('300059', '东方财富', 16.73, 3.46, 79, 88, null, 77, 'confirmed', '非银金融', 2.18, 'core'),
  stock('000858', '五粮液', 142.31, 2.49, 80, 72, 85, 81, 'confirmed', '食品饮料', 1.42, 'core'),
  stock('002594', '比亚迪', 238.64, 1.76, 79, 72, null, 68, 'monitoring', '新能源车', 3.25, 'core'),
  stock('300308', '中际旭创', 158.26, 6.72, 88, 92, 90, 90, 'confirmed', '通信设备', 2.41, 'core'),
  stock('002625', '光启技术', 34.72, 7.35, 80, 85, 81, 86, 'confirmed', '国防军工', 1.98, 'core'),
  stock('600519', '贵州茅台', 1688.5, 2.83, 82, 78, null, null, 'pending', '白酒', 1.26, 'candidate'),
  stock('601318', '中国平安', 47.21, -0.62, 61, 54, null, 49, 'failed', '保险', -0.18, 'watch'),
  stock('600036', '招商银行', 37.82, 1.32, 71, 65, null, 68, 'monitoring', '银行', 0.68, 'candidate'),
  stock('002475', '立讯精密', 28.46, 1.85, 69, 61, null, 66, 'monitoring', '消费电子', 1.74, 'candidate'),
  stock('300274', '阳光电源', 92.18, 2.16, 68, 63, null, 70, 'monitoring', '电力设备', 1.63, 'candidate'),
  stock('002352', '顺丰控股', 43.59, 0.93, 66, 58, null, 64, 'monitoring', '物流', 0.82, 'candidate'),
  stock('688111', '金山办公', 384.2, 1.77, 64, 57, null, 61, 'monitoring', '软件服务', 1.12, 'candidate'),
  stock('601688', '华泰证券', 18.57, 1.78, 75, 71, null, 66, 'monitoring', '证券', 1.32, 'candidate'),
  stock('600276', '恒瑞医药', 44.18, 2.09, 77, 71, null, 85, 'confirmed', '创新药', 1.96, 'candidate'),
  stock('300760', '迈瑞医疗', 298.91, 1.22, 72, 64, null, 76, 'monitoring', '医疗器械', 1.63, 'candidate'),
  stock('002371', '北方华创', 402.18, 1.95, 69, 63, null, 74, 'monitoring', '半导体', 2.34, 'candidate'),
  stock('000063', '中兴通讯', 31.25, 1.3, 75, 69, null, 80, 'confirmed', '通信设备', 1.78, 'candidate')
]

export const alertFeedItems: AlertFeedItem[] = [
  { id: 'a1', time: '09:35:18', title: '进入候选', message: '贵州茅台技术分、情绪分达标，进入候选池，等待量能确认。', tone: 'blue' },
  { id: 'a2', time: '09:41:02', title: '量能确认', message: '宁德时代进入候选后，实时量能确认，晋级核心候选。', tone: 'red' },
  { id: 'a3', time: '10:02:44', title: '监控中', message: '比亚迪技术和情绪达标，量能仍在实时监控中。', tone: 'orange' },
  { id: 'a4', time: '10:18:09', title: '暂不晋级', message: '中国平安量能不足，暂不晋级核心候选。', tone: 'green' }
]

export const speedRankItems: SpeedRankItem[] = [
  { rank: 1, code: '300750', name: '宁德时代', changePct: 4.12, speedPct: 2.18, technicalScore: 86, sentimentScore: 91, volumeScore: 94, volumeStatus: 'confirmed', board: '锂电池', signal: '量能确认' },
  { rank: 2, code: '002594', name: '比亚迪', changePct: 1.76, speedPct: 1.44, technicalScore: 79, sentimentScore: 72, volumeScore: 68, volumeStatus: 'monitoring', board: '新能源车', signal: '监控中' },
  { rank: 3, code: '600519', name: '贵州茅台', changePct: 2.83, speedPct: 1.21, technicalScore: 82, sentimentScore: 78, volumeScore: null, volumeStatus: 'pending', board: '白酒', signal: '等待量能' }
]

export const healthItems: HealthItem[] = [
  { name: '后端 API', status: 'ok', detail: 'FastAPI v2 skeleton', latency: '18ms' },
  { name: 'WebSocket', status: 'warn', detail: '等待接入旧 /ws/alerts', latency: '--' },
  { name: '行情源', status: 'unknown', detail: '未接入 provider adapter', latency: '--' },
  { name: '飞书通知', status: 'unknown', detail: '未接入 notifier adapter', latency: '--' }
]
