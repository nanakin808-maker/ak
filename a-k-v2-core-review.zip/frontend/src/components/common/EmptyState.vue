<script setup lang="ts">
withDefaults(defineProps<{
  title?: string
  description?: string
}>(), {
  title: '暂无数据',
  description: '等待数据接入或调整筛选条件。'
})
</script>

<template>
  <div class="empty-state">
    <div class="empty-state__mark">—</div>
    <div class="empty-state__title">{{ title }}</div>
    <div class="empty-state__desc">{{ description }}</div>
  </div>
</template>

<style scoped>
.empty-state {
  display: grid;
  place-items: center;
  min-height: 180px;
  padding: 28px;
  border: 1px dashed var(--ag-border-strong);
  border-radius: var(--ag-radius-lg);
  background: rgba(255, 255, 255, 0.025);
  text-align: center;
}

.empty-state__mark {
  display: grid;
  place-items: center;
  width: 42px;
  height: 42px;
  margin-bottom: 12px;
  border-radius: 50%;
  color: var(--ag-text-muted);
  background: rgba(148, 163, 184, 0.12);
  font-size: 22px;
  font-weight: 700;
}

.empty-state__title {
  color: var(--ag-text-soft);
  font-size: 14px;
  font-weight: 720;
}

.empty-state__desc {
  margin-top: 6px;
  color: var(--ag-text-muted);
  font-size: 12px;
}
</style>
