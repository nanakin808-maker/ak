<script setup lang="ts">
type BadgeTone = 'red' | 'green' | 'orange' | 'blue' | 'purple' | 'gray'

withDefaults(defineProps<{
  label: string
  tone?: BadgeTone
  pulse?: boolean
}>(), {
  tone: 'gray',
  pulse: false
})
</script>

<template>
  <span class="status-badge" :class="[`status-badge--${tone}`, { 'is-pulse': pulse }]">
    <span class="status-badge__dot" />
    <span>{{ label }}</span>
  </span>
</template>

<style scoped>
.status-badge {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 26px;
  padding: 0 10px;
  border: 1px solid var(--tone-border);
  border-radius: 999px;
  color: var(--tone);
  background: var(--tone-soft);
  font-size: 12px;
  font-weight: 640;
  white-space: nowrap;
}

.status-badge__dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--tone);
}

.is-pulse .status-badge__dot {
  box-shadow: 0 0 0 4px var(--tone-soft);
}

.status-badge--red {
  --tone: var(--ag-red);
  --tone-soft: var(--ag-red-soft);
  --tone-border: rgba(255, 77, 95, 0.32);
}

.status-badge--green {
  --tone: var(--ag-green);
  --tone-soft: var(--ag-green-soft);
  --tone-border: rgba(43, 212, 125, 0.32);
}

.status-badge--orange {
  --tone: var(--ag-orange);
  --tone-soft: var(--ag-orange-soft);
  --tone-border: rgba(255, 176, 32, 0.32);
}

.status-badge--blue {
  --tone: var(--ag-blue);
  --tone-soft: var(--ag-blue-soft);
  --tone-border: rgba(79, 140, 255, 0.32);
}

.status-badge--purple {
  --tone: var(--ag-purple);
  --tone-soft: var(--ag-purple-soft);
  --tone-border: rgba(155, 123, 255, 0.32);
}

.status-badge--gray {
  --tone: var(--ag-text-muted);
  --tone-soft: rgba(148, 163, 184, 0.12);
  --tone-border: var(--ag-border);
}
</style>
