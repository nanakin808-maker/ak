<script setup lang="ts">
type HealthStatus = 'ok' | 'warn' | 'error' | 'unknown'

withDefaults(defineProps<{
  name: string
  status?: HealthStatus
  detail?: string
  latency?: string
}>(), {
  status: 'unknown',
  detail: '',
  latency: ''
})

const statusLabel: Record<HealthStatus, string> = {
  ok: '正常',
  warn: '警告',
  error: '异常',
  unknown: '未知'
}
</script>

<template>
  <div class="health-indicator" :class="`health-indicator--${status}`">
    <div class="health-indicator__left">
      <span class="health-indicator__dot" />
      <div>
        <div class="health-indicator__name">{{ name }}</div>
        <div v-if="detail" class="health-indicator__detail">{{ detail }}</div>
      </div>
    </div>

    <div class="health-indicator__right">
      <span class="health-indicator__status">{{ statusLabel[status] }}</span>
      <span v-if="latency" class="health-indicator__latency">{{ latency }}</span>
    </div>
  </div>
</template>

<style scoped>
.health-indicator {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  min-height: 54px;
  padding: 10px 12px;
  border: 1px solid var(--ag-border);
  border-radius: var(--ag-radius-md);
  background: rgba(255, 255, 255, 0.035);
}

.health-indicator__left,
.health-indicator__right {
  display: flex;
  align-items: center;
  gap: 10px;
}

.health-indicator__right {
  flex-direction: column;
  align-items: flex-end;
  gap: 2px;
}

.health-indicator__dot {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  background: var(--tone);
  box-shadow: 0 0 14px var(--tone);
}

.health-indicator__name {
  color: var(--ag-text);
  font-size: 13px;
  font-weight: 680;
}

.health-indicator__detail,
.health-indicator__latency {
  color: var(--ag-text-muted);
  font-size: 12px;
}

.health-indicator__status {
  color: var(--tone);
  font-size: 12px;
  font-weight: 720;
}

.health-indicator--ok {
  --tone: var(--ag-green);
}

.health-indicator--warn {
  --tone: var(--ag-orange);
}

.health-indicator--error {
  --tone: var(--ag-red);
}

.health-indicator--unknown {
  --tone: var(--ag-text-muted);
}
</style>
