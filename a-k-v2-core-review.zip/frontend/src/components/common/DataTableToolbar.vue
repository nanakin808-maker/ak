<script setup lang="ts">
withDefaults(defineProps<{
  searchPlaceholder?: string
  searchValue?: string
  total?: number
}>(), {
  searchPlaceholder: '搜索代码 / 名称',
  searchValue: '',
  total: 0
})

const emit = defineEmits<{
  'update:searchValue': [value: string]
  refresh: []
}>()
</script>

<template>
  <div class="table-toolbar">
    <div class="table-toolbar__left">
      <el-input
        :model-value="searchValue"
        :placeholder="searchPlaceholder"
        clearable
        class="table-toolbar__search"
        @update:model-value="emit('update:searchValue', String($event))"
      />
      <slot name="filters" />
    </div>

    <div class="table-toolbar__right">
      <span class="table-toolbar__count">共 {{ total }} 条</span>
      <el-button @click="emit('refresh')">刷新</el-button>
      <slot name="actions" />
    </div>
  </div>
</template>

<style scoped>
.table-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 12px;
}

.table-toolbar__left,
.table-toolbar__right {
  display: flex;
  align-items: center;
  gap: 10px;
}

.table-toolbar__left {
  min-width: 0;
}

.table-toolbar__search {
  width: 240px;
}

.table-toolbar__count {
  color: var(--ag-text-muted);
  font-size: 12px;
  white-space: nowrap;
}
</style>
