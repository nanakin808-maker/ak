<script setup lang="ts">
const props = withDefaults(defineProps<{
  score?: number | null
  label?: string
  size?: 'small' | 'normal'
}>(), {
  score: null,
  label: '',
  size: 'normal'
})

function toneClass() {
  const score = props.score ?? 0
  if (score >= 85) return 'score-tag--hot'
  if (score >= 70) return 'score-tag--strong'
  if (score >= 55) return 'score-tag--watch'
  if (score > 0) return 'score-tag--weak'
  return 'score-tag--empty'
}
</script>

<template>
  <span class="score-tag" :class="[toneClass(), `score-tag--${size}`]">
    <span class="score-tag__value">{{ score ?? '--' }}</span>
    <span v-if="label" class="score-tag__label">{{ label }}</span>
  </span>
</template>

<style scoped>
.score-tag {
  display: inline-flex;
  align-items: baseline;
  gap: 5px;
  min-width: 54px;
  justify-content: center;
  border: 1px solid var(--tone-border);
  border-radius: 999px;
  background: var(--tone-soft);
  color: var(--tone);
  font-family: var(--ag-font-mono);
  font-weight: 760;
  white-space: nowrap;
}

.score-tag--normal {
  height: 28px;
  padding: 0 10px;
  font-size: 13px;
}

.score-tag--small {
  height: 24px;
  padding: 0 8px;
  font-size: 12px;
}

.score-tag__label {
  color: var(--ag-text-muted);
  font-family: var(--ag-font-sans);
  font-size: 11px;
  font-weight: 600;
}

.score-tag--hot {
  --tone: var(--ag-red);
  --tone-soft: var(--ag-red-soft);
  --tone-border: rgba(255, 77, 95, 0.38);
}

.score-tag--strong {
  --tone: var(--ag-orange);
  --tone-soft: var(--ag-orange-soft);
  --tone-border: rgba(255, 176, 32, 0.34);
}

.score-tag--watch {
  --tone: var(--ag-blue);
  --tone-soft: var(--ag-blue-soft);
  --tone-border: rgba(79, 140, 255, 0.32);
}

.score-tag--weak {
  --tone: var(--ag-green);
  --tone-soft: var(--ag-green-soft);
  --tone-border: rgba(43, 212, 125, 0.28);
}

.score-tag--empty {
  --tone: var(--ag-text-muted);
  --tone-soft: rgba(148, 163, 184, 0.1);
  --tone-border: var(--ag-border);
}
</style>
