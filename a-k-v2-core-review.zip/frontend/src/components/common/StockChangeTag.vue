<script setup lang="ts">
const props = withDefaults(defineProps<{
  value?: number | null
  suffix?: string
  showSign?: boolean
}>(), {
  value: null,
  suffix: '%',
  showSign: true
})

function displayValue() {
  if (props.value === null || props.value === undefined) return '--'
  const sign = props.showSign && props.value > 0 ? '+' : ''
  return `${sign}${props.value.toFixed(2)}${props.suffix}`
}
</script>

<template>
  <span
    class="stock-change"
    :class="{
      'stock-change--up': (value ?? 0) > 0,
      'stock-change--down': (value ?? 0) < 0,
      'stock-change--flat': !value
    }"
  >
    {{ displayValue() }}
  </span>
</template>

<style scoped>
.stock-change {
  font-family: var(--ag-font-mono);
  font-size: 13px;
  font-weight: 780;
  white-space: nowrap;
}

.stock-change--up {
  color: var(--ag-red);
}

.stock-change--down {
  color: var(--ag-green);
}

.stock-change--flat {
  color: var(--ag-text-muted);
}
</style>
