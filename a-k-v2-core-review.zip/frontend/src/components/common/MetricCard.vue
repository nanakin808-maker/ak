<script setup lang="ts">
type MetricTone = 'red' | 'green' | 'orange' | 'blue' | 'purple' | 'neutral'

withDefaults(defineProps<{
  title: string
  value: string | number
  subtitle?: string
  delta?: string
  tone?: MetricTone
}>(), {
  tone: 'neutral'
})
</script>

<template>
  <article class="metric-card" :class="`metric-card--${tone}`">
    <div class="metric-head">
      <span class="metric-title">{{ title }}</span>
      <span class="metric-dot" />
    </div>

    <div class="metric-value">{{ value }}</div>

    <div class="metric-foot">
      <span v-if="subtitle" class="metric-subtitle">{{ subtitle }}</span>
      <span v-if="delta" class="metric-delta">{{ delta }}</span>
    </div>
  </article>
</template>

<style scoped>
.metric-card {
  position: relative;
  min-height: 116px;
  overflow: hidden;
  padding: 16px;
  border: 1px solid var(--ag-border);
  border-radius: var(--ag-radius-lg);
  background:
    radial-gradient(circle at top right, var(--tone-soft), transparent 42%),
    linear-gradient(180deg, var(--ag-bg-card-strong), var(--ag-bg-card));
  box-shadow: var(--ag-shadow-card);
}

.metric-head,
.metric-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.metric-title {
  color: var(--ag-text-muted);
  font-size: 12px;
  font-weight: 620;
}

.metric-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--tone);
  box-shadow: 0 0 16px var(--tone);
}

.metric-value {
  margin-top: 14px;
  color: var(--ag-text);
  font-size: 30px;
  font-weight: 820;
  letter-spacing: -0.03em;
}

.metric-foot {
  margin-top: 10px;
  color: var(--ag-text-muted);
  font-size: 12px;
}

.metric-delta {
  color: var(--tone);
  font-family: var(--ag-font-mono);
}

.metric-card--red {
  --tone: var(--ag-red);
  --tone-soft: var(--ag-red-soft);
}

.metric-card--green {
  --tone: var(--ag-green);
  --tone-soft: var(--ag-green-soft);
}

.metric-card--orange {
  --tone: var(--ag-orange);
  --tone-soft: var(--ag-orange-soft);
}

.metric-card--blue {
  --tone: var(--ag-blue);
  --tone-soft: var(--ag-blue-soft);
}

.metric-card--purple {
  --tone: var(--ag-purple);
  --tone-soft: var(--ag-purple-soft);
}

.metric-card--neutral {
  --tone: var(--ag-text-muted);
  --tone-soft: rgba(148, 163, 184, 0.12);
}
</style>
