<script setup lang="ts">
withDefaults(defineProps<{
  title: string
  subtitle?: string
  compact?: boolean
}>(), {
  compact: false
})
</script>

<template>
  <section class="section-card" :class="{ 'section-card--compact': compact }">
    <header class="section-card__header">
      <div>
        <h2>{{ title }}</h2>
        <p v-if="subtitle">{{ subtitle }}</p>
      </div>
      <div v-if="$slots.action" class="section-card__action">
        <slot name="action" />
      </div>
    </header>

    <div class="section-card__body">
      <slot />
    </div>
  </section>
</template>

<style scoped>
.section-card {
  border: 1px solid var(--ag-border);
  border-radius: var(--ag-radius-xl);
  background:
    linear-gradient(180deg, rgba(17, 31, 53, 0.96), rgba(10, 20, 35, 0.96));
  box-shadow: var(--ag-shadow-card);
}

.section-card__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  padding: 16px 16px 0;
}

.section-card__header h2 {
  margin: 0;
  color: var(--ag-text);
  font-size: 16px;
  font-weight: 760;
}

.section-card__header p {
  margin: 5px 0 0;
  color: var(--ag-text-muted);
  font-size: 12px;
}

.section-card__action {
  display: flex;
  align-items: center;
  gap: 8px;
}

.section-card__body {
  padding: 16px;
}

.section-card--compact .section-card__header {
  padding: 12px 12px 0;
}

.section-card--compact .section-card__body {
  padding: 12px;
}
</style>
