import { computed, onMounted, ref } from 'vue'
import {
  fetchEngineStatus,
  resetEngine,
  startEngine,
  stopEngine,
  type EngineState
} from '../services/engineApi'

const defaultState: EngineState = {
  status: 'idle',
  running: false,
  startedAt: null,
  stoppedAt: null,
  resetAt: null,
  message: '等待连接后端引擎'
}

export function useEngineControl() {
  const state = ref<EngineState>({ ...defaultState })
  const loading = ref(false)
  const error = ref<string | null>(null)

  const statusLabel = computed(() => {
    if (error.value) return '连接异常'
    if (state.value.status === 'running') return '运行中'
    if (state.value.status === 'stopped') return '已停止'
    if (state.value.status === 'error') return '异常'
    return '待启动'
  })

  const statusTone = computed<'blue' | 'green' | 'orange' | 'red'>(() => {
    if (error.value) return 'red'
    if (state.value.status === 'running') return 'green'
    if (state.value.status === 'stopped') return 'orange'
    if (state.value.status === 'error') return 'red'
    return 'blue'
  })

  async function applyAction(action: () => Promise<{ state: EngineState }>) {
    loading.value = true
    error.value = null

    try {
      const response = await action()
      state.value = response.state
    } catch (err) {
      error.value = err instanceof Error ? err.message : '引擎接口请求失败'
      state.value = {
        ...state.value,
        status: 'error',
        running: false,
        message: error.value
      }
    } finally {
      loading.value = false
    }
  }

  async function refresh() {
    await applyAction(fetchEngineStatus)
  }

  async function start() {
    await applyAction(startEngine)
  }

  async function stop() {
    await applyAction(stopEngine)
  }

  async function reset() {
    await applyAction(resetEngine)
  }

  onMounted(() => {
    void refresh()
  })

  return {
    state,
    loading,
    error,
    statusLabel,
    statusTone,
    refresh,
    start,
    stop,
    reset
  }
}
