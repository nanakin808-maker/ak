import { type Ref, type ComputedRef, onMounted, onUnmounted, ref, watch } from 'vue'
import {
  MonitoringRealtimeSocket,
  type WsConnectionState,
  type WsMessage,
} from '@/services/monitoringRealtimeSocket'
import type { ShadowStock, ShadowScore } from '@/types/monitoringShadow'

export function useMonitoringShadowWs(
  tradingDate: Ref<string> | ComputedRef<string>,
  stocks: Ref<ShadowStock[]>,
  scores: Ref<ShadowScore[]>,
  onRefresh: () => Promise<void>,
) {
  const wsState = ref<WsConnectionState>('disconnected')
  const wsLastSeq = ref(0)
  const wsLastMsgAt = ref('--')
  let ws: MonitoringRealtimeSocket | null = null
  let idleTimer: ReturnType<typeof setInterval> | null = null
  let lastWsMsg = 0

  function onWsMessage(msg: WsMessage) {
    lastWsMsg = Date.now()
    wsLastMsgAt.value = new Date().toLocaleTimeString()
    wsLastSeq.value = msg.seq || 0
    if (msg.type === 'heartbeat') return
    if (msg.type === 'scan_status') {
      // metadata only — no full reload
    } else if (msg.type === 'stock_state_upsert') {
      const d = msg.data as Record<string, unknown>
      ;(d as any)._source = 'ws'
      ;(d as any)._wsAt = new Date().toLocaleTimeString('zh-CN', { hour12: false })
      const idx = stocks.value.findIndex((s) => s.code === d.code)
      if (idx >= 0) {
        stocks.value[idx] = { ...stocks.value[idx], ...d } as ShadowStock
      } else {
        stocks.value.unshift(d as unknown as ShadowStock)
      }
    } else if (msg.type === 'score_snapshot') {
      ;(msg.data as any)._source = 'ws'
      scores.value.unshift(msg.data as unknown as ShadowScore)
      if (scores.value.length > 200) scores.value = scores.value.slice(0, 200)
    }
  }

  function connect(td: string) {
    ws?.disconnect()
    lastWsMsg = Date.now()  // reset idle timer on any (re)connect
    ws = new MonitoringRealtimeSocket(td, {
      onMessage: onWsMessage,
      onStateChange: (s) => { wsState.value = s },
      onReconnect: () => {
        lastWsMsg = Date.now()
        onRefresh()
      },
    })
    ws.connect()
  }

  onMounted(() => {
    connect(tradingDate.value)
    // idle fallback: if no WS message for 30s, do a REST reload
    idleTimer = setInterval(() => {
      if (Date.now() - lastWsMsg > 30_000) {
        onRefresh()
        lastWsMsg = Date.now()
      }
    }, 15_000)
  })

  watch(tradingDate, (td) => connect(td))

  onUnmounted(() => {
    ws?.disconnect()
    if (idleTimer) clearInterval(idleTimer)
  })

  return { wsState, wsLastSeq, wsLastMsgAt }
}
