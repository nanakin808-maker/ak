import { onMounted, ref } from 'vue'
import { candidateSummaries, type CandidateSummary } from '../mocks/dashboard'
import { recentMonitorEvents, type MonitorEvent } from '../mocks/scoreDetail'
import { fetchOpportunityRows } from '../services/opportunityApi'

export function useOpportunityDashboard() {
  const rows = ref<CandidateSummary[]>(candidateSummaries)
  const events = ref<MonitorEvent[]>(recentMonitorEvents)
  const loading = ref(false)
  const source = ref<'api' | 'mock'>('mock')
  const error = ref<string | null>(null)

  async function refresh() {
    loading.value = true

    try {
      const result = await fetchOpportunityRows()
      rows.value = result.rows
      events.value = result.events
      source.value = result.source
      error.value = result.error
    } finally {
      loading.value = false
    }
  }

  onMounted(() => {
    void refresh()
  })

  return {
    rows,
    events,
    loading,
    source,
    error,
    refresh
  }
}
